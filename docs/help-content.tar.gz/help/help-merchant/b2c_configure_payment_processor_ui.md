# Configure the User Interface for a Payment Processor

_Use Business Manager to create a payment processor so customers can buy products using that processor. This topic applies to B2C Commerce._

|  |
| --- |
| Available in: **B2C Commerce** |

The Business Manager user interface doesn't automatically show data associated with a new payment processor. To show associated data, create an Internet Store Markup Language (ISML) in a custom cartridge.

1. Create an ISML file containing the data that you want to show on the Order page.
2. Name the ISML file PaymentInstrumentInfo_.{*payment_processor_id*}.

   The {*payment_processor_id*} is the ID of your payment processor under ordering.
3. Create a cartridge for your payment processor.
4. Save the ISML file in cartridge/template/default/order.
5. Customize the ISML file per your requirement.
6. In your local files, navigate to your ecommerce instance and copy your cartridge in appserverinstance/shareddata/cartridges*/version*.

> **Note:** The custom attributes of the system objects order payment instrument and order payment transaction appear by default in Business Manager.
