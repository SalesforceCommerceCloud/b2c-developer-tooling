# Page Meta Tags for B2C Commerce

_Page meta tags are used in HTML documents to provide structured data about a web page. Meta tags are snippets of text that don't appear on the page itself, but in the page’s code, describing a page’s content. Common tags are title, robots, description, and social tags such as open graph tags. This topic applies to B2C Commerce._

Here is an example of some great meta tags:

```
<title>Our dresses make you look stunning.</title>
<meta name="keywords" content="dress,stunning,elegant,party-dress,wedding-guest">
<meta name="description" content="Official wedding guest dresser.">
```

Social media elements such as Facebook Open Graph, Twitter Card, and Pinterest Rich Pins, enable you to optimize your site for sharing products and content on Facebook, Twitter, and Pinterest. To define how page elements appear in social streams, configure Product pages to include open graph meta data for product elements such as title, image, description, price, brand, and Universal Product Code (UPC). When a user likes or shares a product page on a website, social networks collect the open graph data to automatically determine an accurate post title, image, and description.

Search engine crawlers recognize meta elements in web pages. Meta title or page title, and meta description are especially important because they appear on the Search Engine Results Page (SERP) and determine the probability that a customer clicks a search result.

### Meta Title and Page Title

The text that customers see at the top of their browsers. It's important because search engine algorithms set a value on its keyword, which can attract search engine users to the website. Changing the meta tag can significantly improve a page's ranking.

> **Tip:** Create meta descriptions for each website, especially for the main pages. Providing unique meta titles and descriptions can increase website traffic because customers are more apt to click this information.

### Meta Description

Provides a brief description of the page that appears on the SERP, which appears each time a user launches a search request and then looks at the SERPs. Beneath the respective link, a short description text appears as a snippet to draw attention to the content and to prompt users to click it.

### Robots Meta Tag

Provides a page-specific approach to controlling how an individual page is indexed and served to users in search results. The robots meta tag instructs search engines to not show a page in search results. The value of the name attribute (robots) specifies that the directive applies to all crawlers.

Place this meta tag in the <head> section of a page, as shown in this example:

```
<!DOCTYPE html>
            <html>
            <head> <meta name="robots" content="noindex" /> (…) </head>
            <body>(…)</body>
            </html>
```

> **Note:** By default, Googlebot indexes a page and follows links to it, so don't tag pages with content values of INDEX or FOLLOW. However, another function of the meta robots tag is to tell search engine crawlers the links to stop with. If you have too many links going out of your site, the site rating can suffer resulting in a lower page rank.

### Additional Page Meta Tag Resources

- [SEO Page Meta Tags Overview](https://salesforce.vidyard.com/watch/9uqE591fKqxAFENQLCTUP7): This playlist contains an overview of SEO Page Meta Tags for B2C Commerce, including details on rule syntax and two use case examples.
- [SEO Meta Tag Rules - Overview-compressed.pdf](https://resources.docs.salesforce.com/rel1/doc/en-us/static/pdf/SEOMetaTagRules-Overview.pdf): B2C Commerce SEO Meta Tag Rules overview covering definitions, rules, and how to implement.
