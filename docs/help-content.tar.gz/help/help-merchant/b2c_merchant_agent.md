# Merchant Agent for B2C Commerce

_The Merchant Agent for B2C Commerce is an AI-powered assistant in Business Manager that automates merchandising tasks such as sorting rules, boost-and-bury configurations, and categorization for merchant admins. Merchant admins describe their intent in natural language, and the agent generates configurations that they can review and apply._

Access the agent on the right side panel of the Visual Merchandising page in Business Manager. To use Visual Merchandising, a Salesforce admin adds the Business Manager Visual Merchandising module to the person in your company with a merchandiser role.

## Related Content

- [Merchant Agent Setup for B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_merchant_agent_setup.htm&type=5)
  To use the Merchant Agent with B2C Commerce and the connected Salesforce org, complete the required setup tasks. The instructions assume that you are a B2C Commerce admin and Salesforce admin responsible for merchandising in your organization.

- [Merchandising with the B2C Merchant Agent](https://help.salesforce.com/s/articleView?id=cc.b2c_merchandise_using_the_merchant_agent.htm&type=5)
  After you set up the B2C Merchant Agent, use it to automate merchandising tasks. Instead of manually configuring ranking, sorting, and product categorization, use natural language prompts with the Merchant Agent to automate these tasks.
