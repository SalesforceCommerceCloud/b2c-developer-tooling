# Merchant Agent for B2C Commerce

_The Merchant Agent for B2C Commerce is an AI-powered assistant in Business Manager that automates merchandising tasks such as sorting rules, boost-and-bury configurations, and categorization for merchant admins. Merchant admins describe their intent in natural language, and the agent generates configurations that they can review and apply._

Access the agent on the right side panel of the Visual Merchandising page in Business Manager. To use Visual Merchandising, a Salesforce admin adds the Business Manager Visual Merchandising module to the person in your company with a merchandiser role.
