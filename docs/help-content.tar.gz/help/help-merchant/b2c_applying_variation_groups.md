# Apply Variation Groups

_Apply variation groups to your storefront in different configurations. This topic applies to B2C Commerce._

You can:

- import variation groups through the standard catalog import process. B2C Commerce supports the variation group product type in the Catalog.xsd schema. B2C Commerce supports merge-mode for imports.
- create variation groups by at least one variation attribute for a particular base product.
- search to find all variation groups.
- assign a variation group to a content slot.
   
   > **Note:** In the storefront, clicking a content slot with a variation group assigned to it displays the product detail page for the base product. The product detail page shows the selected attributes of the variation group with an appropriate image, similar to the way product sets are merchandised.
- assign a category position to a variation group, which allows you to show all red handbags before all gold handbags.
- assign a variation group to a category or subcategory regardless of the base product’s assigned primary category and storefront category. For example, sell all red variation products in any size using a Holiday category.
- assign a variation group to a promotion.
- assign a variation group to a product set, which enables you to create outfits in specific colors, with specific products that can be sold in any size.
- control storefront search behavior through search preferences for products that have variation groups configured

B2C Commerce:

- disables slicing when variation groups exist for a base product, but only for that product. You can still use slicing for all other products.
- uses attribute value fallback to include variation groups. For example, B2C Commerce first checks that an attribute value is set for the variation product, then the variation group product, and finally the base product.
- collects active data for variation groups. Active data for a variation group is an aggregation of the variation products contained in the group.

Also use the B2C Commerce Script API to show variation groups in landing pages, category pages, and customized search experiences.
