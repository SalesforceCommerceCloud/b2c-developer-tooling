# Analytics Reporting Integration in Salesforce Reference Architecture (SFRA)

_To record Analytics events in SFRA, you construct the corresponding URL patterns by calling helper methods in the `reportingUrls.js` module. Each of these helper methods constructs URLs and returns an array of URLs. This array is then passed as a variable (`pdict.reportingURLs`) to the template `reportingUrls.isml`._

### SFRA Analytics Reporting Helper Script

The `app_storefront_base/cartridge/scripts/reportingUrls.js` script provides the following helper method:

```
getCheckoutReportingURLs(UUID, step, stepName)               // Checkout event
```

### SFRA Analytics Reporting Template

The following code snippet shows the body of the `app_storefront_base/cartridge/templates/default/reporting/reportingUrls.isml` template:

```
<isloop items="${pdict.reportingURLs}" var="URL">
    <isinclude url="${URL}" />
</isloop>
```

For any SFRA template to record Analytics events, include this template. For example, here is a code snippet taken from the `app_storefront_base/cartridge/templates/default/checkout/confirmation/confirmation.isml` template:

```
<isif condition="${pdict.reportingURLs && pdict.reportingURLs.length}">
    <isinclude template="reporting/reportingUrls" />
</isif>
```
