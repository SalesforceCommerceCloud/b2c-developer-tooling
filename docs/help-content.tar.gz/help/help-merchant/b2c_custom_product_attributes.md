# Custom Product Attributes

_Create a new product attribute that you can use for site search, search refinements, or sorting rules. This topic applies to B2C Commerce._

See [Using Custom Product Attributes Pushing Product Sets Down - PDF.](https://resources.docs.salesforce.com/rel1/doc/en-us/static/pdf/Commerce_Cloud_Using_Custom_Product_Attributes_Pushing_Product_Sets_Down.pdf)
