# Troubleshooting and migration

_When a B2C Commerce Dynamic Imaging Service image URL fails, times out, or looks wrong, check the source file, the full URL, and the limits documented in the Dynamic Imaging Service topic. This topic also helps you migrate from other hostnames and from Adobe Scene7 (Dynamic Media) query strings._

File size, timeout, Content Delivery Network (CDN) and non-CDN behavior, and `4xx` or `408` responses are documented under Image Guidelines and Dynamic Imaging Caching in [Dynamic Imaging Service ](https://help.salesforce.com/s/articleView?id=cc.b2c_image_transformation_service.htm&type=5). Use this topic for troubleshooting steps; the numeric limits stay in that topic.

Broken or missing images

- In the browser, copy the full `img` `src` URL and open it in a new tab. If a transform is expected and you do **not** see `/dw/image/v2/` in the path, the template may point to the static file or a host that does not use the Dynamic Imaging Service. Use `URLUtils` and `MediaFile` as in [Create Image Transformation URLs ](https://help.salesforce.com/s/articleView?id=cc.b2c_image_transformation_service.htm&type=5).
- If the HTTP status is **4xx** on the image request, re-check parameter rules in [Image transformation URL structure, validation, and order of operations ](https://help.salesforce.com/s/articleView?id=cc.b2c_image_transformation_url_structure.htm&type=5) and the [Supported Transformations](b2c_image_transformation_service.xml#b2c_image_transformation_service/table_h2n_wpj_jdb) table. Common causes: duplicate `?` in the query string, empty `sw=` or `sh=` values, an incomplete set of crop or overlay parameters, out-of-range values, or an `oimg` that fails length, encoding, or host rules in the main topic.
- If the source file is missing for a view *type*, update content in Business Manager, not only the transform query.

Slowness or timeouts

- The first *cold* request can be slower; after the CDN *cache* is warm, repeat loads should be faster. See [Dynamic Imaging Caching ](https://help.salesforce.com/s/articleView?id=cc.b2c_image_transformation_service.htm&type=5).
- Oversize files and heavy transforms (for example upscaling a large animated `GIF`) can hit the timeout in [Image Guidelines ](https://help.salesforce.com/s/articleView?id=cc.b2c_image_transformation_service.htm&type=5) (see file size and timeout) — reduce source complexity or transform cost first.
- In **nonproduction environments**, Firefox Tracking Protection can block some first fetches. See the browser note in [Image Guidelines ](https://help.salesforce.com/s/articleView?id=cc.b2c_image_transformation_service.htm&type=5) in that file (with file size and timeout).

Migration: legacy hosts and other CDNs

When replacing a historic infrastructure or vendor CDN hostname, do **not** hand-edit a new edge host without an approved *pattern* from your program. Regenerate *correct* URLs with `URLUtils` and `MediaFile`, or from a community *helper* for your vanity storefront domain, as in [Optional community DIS product image wrapper ](https://help.salesforce.com/s/articleView?id=cc.b2c_image_transformation_community_wrapper.htm&type=5).

A **rough** (verify every parameter in the main table) mapping for Adobe Scene7 or similar *dynamic media* query strings:

| Typical Scene7-style | Typical DIS direction |
| --- | --- |
| `wid=400` | `scaleWidth` / `sw=400` in your `transform` or query. |
| `hei=400` | `scaleHeight` / `sh=400`. |
| `fmt=jpeg` or `fmt=png` | Output file *extension* and, when needed, `format` / `sfrm` as in the [Format row in the Supported Transformations table ](b2c_image_transformation_service.xml#b2c_image_transformation_service/table_h2n_wpj_jdb). |
| `qlt=80` | `quality` / `q=80`, or omit when you keep the *default* of 80. |
| Padding or *extend* (vendor-specific) | Use `cx`, `cy`, `cw`, `ch` and then `sw` / `sh` in the *fixed* order in [Image transformation URL structure, validation, and order of operations ](https://help.salesforce.com/s/articleView?id=cc.b2c_image_transformation_url_structure.htm&type=5). |

DAM and bulk migration

For a third-party digital asset manager (DAM), export a large *master* image, upload to the correct B2C Commerce library and *view type* for your feed, run your import and replication jobs, then re-point the storefront to URL generation through `URLUtils` and `MediaFile` or a community *helper* as needed, and stop deep-linking the *old* vendor CDN after *cut over*.

When you open a case with Salesforce Support, include a **full** repro *URL* (path and *query*), realm and *site* context, expected and observed *HTTP* status or bytes, and what you already tried from this topic.
