# View Content Block Usage and References

_See all the pages and storefront regions where a content block is currently used. Reviewing usage helps you understand the impact of changes before editing or deleting a content block._

|  |
| --- |
| Available in: **B2C Commerce** |

The usage panel shows all active storefront areas that reference a content block, including [Page Designer](https://help.salesforce.com/s/articleView?id=cc.b2c_creating_pd_pages.htm&type=5) pages and sitewide regions. This information helps you assess the scope of a change and avoid unintended disruptions to your storefront. View usage information in the Component Panel within Page Designer.

1. Open [Page Designer](https://help.salesforce.com/s/articleView?id=cc.b2c_creating_pd_pages.htm&type=5) and select a page that contains the content block you want to review.
2. In Page Designer, select the content block component on the page.
3. In the Component Panel, click the **Settings** tab.
4. View the **Usage** section.

   The section lists all pages and regions that reference this content block, showing the page name, region name, and page type for each reference.
