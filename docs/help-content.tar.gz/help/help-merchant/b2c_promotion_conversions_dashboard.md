# Promotion Conversions Dashboard

_The B2C Commerce Reports & Dashboards Promotion Conversion dashboard gives you insights about the performance of the promotions that you display on your storefront. You can use the dashboard to evaluate the effectiveness of your promotion strategy. You also can identify the promotions that convert site traffic to revenue and the promotions that underperform._

Three charts and tables illustrate the dashboard data.

- Promotion Conversion Rate
- Promotion Conversion Summary
- Promotion Conversion Details

### Conversion Rate

The conversion rate is the percentage of site visits that result in a placed order that includes a promotion. For example, On November 15, site-X has 10,000 visits. Of those visits, shoppers place 300 orders that include a promotion. The conversion rate for site-X is 3% (300/10,000).

The Conversion Rate graph shows conversion rates plotted over time for total visits and each promotion class. To change the chart display from Total to one of the promotion classes, select the class from the chart key.

- Total: The total number of orders with promotions divided by The total number of visits.
- Order: The number of order class promotion orders divided by The number of order class promotion visits.
- Product: The number of product class promotion orders divided by The number of product promotion class promotion visits.
- Shipping: The number of shipping class promotion orders divided by The number of shipping class promotion visits.

**Promotion Visits**

A site visit is considered a promotion site visit when a shopper triggers a promotion. Shoppers trigger a promotion when they meet the promotion qualifier.

For Example:

- Order Visit: A shopper triggers an order promotion visit when they place two products in their cart that are part of a buy one get one (BOGO) promotion.
- Shipping Visit: A shopper triggers a shipping promotion when their cart includes $50 or more of product.
- Product Visit: A shopper triggers a product promotion when their cart includes a promotional product.

The system tracks a promotion visit when the discount is applied, based on the promotion's setup and qualifiers. For example, a promotion assigned to the Everyone customer group tracks a visit when the shopper adds the required items to the cart. A coupon-driven promotion tracks a visit when the shopper successfully applies the coupon to the cart. If your site doesn't set a default shipping method, then a shipping promotion visit isn’t tracked as a shipping visit until the shopper selects a method on the checkout shipping page.

The Promotion Conversion dashboard tracks Promotions visits by all promotions and by promotion class.

### Promotion Conversion Summary

The Conversion Summary table gives insight into how your promotion strategy affects site visit to order conversion. The chart lists a summary of promotion conversions metrics for these site visit types.

- All Visits: All site visits
- Promo Visit: At least one promotion of any class applied
- Product Promo Visit: A product promotion applied
- Shipping Promo Visit: A shipping promotion applied
- Order Promo Visit: An order promotion applied
- Without Promo Visit: No promotions applied

For each visit type, the chart lists these metrics.

Use the dashboard date range and filters settings to create a custom view of the metrics. Filter the dashboard by site, device type (desktop, phone, tablet, unknown or unrecognized), and customer registration (registered or unregistered). Depending on your business needs, you can also download the metrics for each report as a csv file.

| Metric Label | Description |
| --- | --- |
| Visits | Visits with at least one promotion of specified promotion class applied. |
| Orders | An order with more than one class of promotion applied is tracked under each applicable class. An order with more than one promotion of a single class applied is still tracked as one order under the applicable class. |
| Order Conv | Number of Orders / Number of Visits |
| Merch Total | The total merchandise value (excluding tax and shipping) for all orders using this promotion class. |
| Avg Merch Total per Order | Merchandise Total / Number of Orders |
| Avg Merch Total Per Visit | Merchandise Total / Number of Visits |
| Items per Order | Average number of items across all orders using this promotion class. |
| Promo Merch Total | Promotional Merchandise Total: Total value of merchandise (excluding tax and shipping) discounted by all promotions by promotion class. The value of any merchandise discounted by promotions from more than one class is tracked under each applicable class. |
| Avg Promo Merch per Order | Promotional Merchandise Total / Number of Orders |
| Avg Merch per Visit | Promotional Merchandise Total / Number of Visits |
| Shipping Total | Total value of shipping from all orders using this promotion class. |
| Discount Total | Total discount value applied to orders by promotion class. |
| Avg Disc per Order | Discount Total / Number of Orders |
| Avg Disc per Visit | Discount Total / Number of Visits |
| Avg Promo Items per Order | Average number of items discounted by promotion class. |

To evaluate your promotion strategy, use the table to review the relationship between site visits and conversion metrics. For example, an order conversion rate that is lower than expected coupled with low visit totals can indicate that your promotion strategy isn’t engaging shoppers. A high conversion rate for visits with any promotion coupled with a low conversion rate for shipping promotions can indicate that your shipping promotion strategy is underperforming.

### Promotion Conversion Details

The Promotion Conversion Detail table shows you conversion details for individual promotions. Use the data in the Promotion Conversion Details table to review individual promotion performance. The data offers insight into the conversion rate for each promotion and how it drives orders and revenue.

To populate the table, select a promotion type from the dropdown.

- All Promotions (default selection)
- Product Promotions
- Shipping Promotions
- Order Promotions

The table shows these conversion details.

| Metric Label | Description |
| --- | --- |
| Campaign ID | The campaign ID |
| Site | The site selected in the dashboard filters. |
| Promotion ID | The promotion ID |
| Visits | A promotion visit is tracked when the promotional discount is activated and is dependent on the setup of the promotion and its qualifiers. |
| Orders | Total number of orders placed with the promotion and campaign. The system tracks a single order with multiple promotions against each applicable promotion. |
| Order Conv | Number of Orders / Number of Visits |
| Merch Total | Total value of merchandise excluding tax and shipping of all orders placed with the promotion and campaign. Hover over # Orders definition for details. |
| Avg Merch Total per Order | Merchandise Total / Total Orders |
| Items per Order | Average number of items across all orders placed with the promotion and campaign. |
| Promo Merch Total | Promotional Merchandise Total: Total value of merchandise (excluding tax) discounted by the promotion and campaign. The value of any merchandise discounted by more than one promotion is tracked on each promotion. |
| Discount Total | Total discount value applied to orders by the promotion and campaign. |

Use the data in the table to identify which promotions are driving sales and which are underperforming. For example, if visits are high and orders are low, it can mean that shoppers are abandoning the promotion before checkout. There can be an issue with qualification criteria or expected discounts.
