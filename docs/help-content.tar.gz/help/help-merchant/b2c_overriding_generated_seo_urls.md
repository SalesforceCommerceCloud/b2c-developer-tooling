# Override Generated SEO URLs

_If the URL Rules module enabled, you can use the Page URL attribute to override the URL that is generated from the configuration in the URL Rules module. You can apply character replacement for URLs created with this override._

|  |
| --- |
| Available in: **B2C Commerce** |

> **Note:** This topic assumes that you have enabled the URL Rules module and are not using the deprecated SEO Support module. There is no way to override generated URLs in the SEO Support module. Include the Page URL attribute in your rule syntax to allow for customizable endpoints.

To configure Salesforce B2C Commerce to use the Page URL attribute to override generated URLs:

1. Click App Launcher _(image: App Launcher)_, and then select **Merchant Tools > Site > SEO & Discoverability > URL Rules**.
2. Click the **Catalog URLs** or **Content URLs** tab, depending on the type of URL you want to configure.
3. Under the correct URL rule section, check **Enable override with 'pageURL' attribute (if set)**.
4. Import the appropriate values for the page URL attribute or navigate to the product in Business Manager and add a value to the Page URL field.
5. Wait for the SEO URLs to regenerate. Monitor the status of the generation job on the URL Rules page General tab.

While you are developing a strategy for your URLs, it is recommended to manually create `Page URL` attribute values to test them. Instead of using an input feed, manually enter these in Business Manager.

To Create Category URLs Manually:

1. Click App Launcher _(image: App Launcher)_, and then select **Merchant Tools > Site > Products and Catalogs. > Catalogs**.
2. Click **Edit** for the catalog that you want to create URLs for.
3. Click the **Category Attributes** tab and enter a value for each of the `Search Engine Optimization Support` attributes.
4. Click **Apply** to apply the change.

To Create Product URLs Manually:

1. Click App Launcher _(image: App Launcher)_, and then select **Merchant Tools > Site > Products and Catalogs > Products > *Product* **.
2. Enter information to search for a product. Search using wildcards or a specific product ID.
3. Click a product in the search results to select it.
4. Click the **Attributes** tab and enter a value for each of the `Search Engine Optimization Support` attributes.
5. Click **Apply** to apply the change.

To Create Content URLs Manually:

1. Click App Launcher _(image: App Launcher)_, and then select **Merchant Tools > Site > Content**.
2. Click **Library Folder** and navigate until you click the content ID or Name to select the page.
3. On the General tab and enter a value for each of the `Search Engine Optimization Support` attributes.
4. Click **Apply** to apply the change.
