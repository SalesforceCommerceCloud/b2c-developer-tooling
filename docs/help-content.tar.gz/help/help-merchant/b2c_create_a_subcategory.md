# Create a Subcategory for B2C Commerce

_Create multiple layers of subcategories to further refine how your products show on your storefront. This topic applies to B2C Commerce._

|  |
| --- |
| Available in: **B2C Commerce** |

1. Click App Launcher _(image: App Launcher)_, and then select **Merchant Tools > Site > Products and Catalogs > Catalogs**.
2. Click the category to which you want to add a subcategory.
3. To show the category in your storefront, complete the category fields, and select the Online checkbox.

   > **Note:** To show the category in the storefront menu navigation, you assign available products to the subcategory and select the Show in Menu Navigation checkbox under the Category Attributes tab.
4. Click **Apply**.
