# View Active Data Attributes

_View active data attributes assigned to specific products or customers._

|  |
| --- |
| Available in: **B2C Commerce** |

1. To view product active data:

   1. Click App Launcher _(image: App Launcher)_, and then select **Merchant Tools > Site > Products and Catalogs > Products**.
   2. Enter the name or ID of the product and click **Find**.
   3. Click the name or ID of the product you want to view.
   4. Click the **Active Data** tab.
   
      If active data was successfully imported, the page shows traffic and conversion data.
2. To view customer active data:

   1. Click App Launcher _(image: App Launcher)_, and then select **Merchant Tools > Site > Customers > Customers**.
   2. Enter the name or customer number of a customer.
   3. Click the customer number or login for the customer.
   4. Click the **Active Data** tab.
