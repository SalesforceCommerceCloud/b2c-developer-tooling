# Product Variations

_Most products are available in a variation of sizes or colors. B2C Commerce represents all variations as a single product, called a base product._

### What Is a Product Variation?

Each base product has variation attributes that determine how a product varies. For example, a shirt base product can have size and color as variation attributes. A shoe base product can have size, color, and width as variation attributes.

_(image: Diagram of product variations with a base product and variation attributes)_

- A base product represents all possible variations.
- A variation group represents a subset of values, such as all blue shoes in any size.
- A variation product is a single product with specific values for all variation attributes. For example, a shoe that is blue, size 10, and width A. A variation product is a real product that has attributes in addition to the variation attributes, such as SKU, name, description, images, and price.

With variation products, you can:

- Define variation values per base product
- Overwrite the localized display names of variation values per base product
- Control the sort order of variation values per base product
- Visualize variation values in the storefront (for example, color swatched and Scene7 URLs)

Base product, variation groups, and variation products are all separate product types. However, variation groups and variation products must be associated with a base product. Often, you don't want to sell all possible variation products. You create variation products for each product that you want to sell and assign them to the base product. For example, you only want to sell size 2 and 3 in red and blue. You create four variation products (red-2, red-3, blue-2, blue-3) and assign them to the base product.

It isn't possible to purchase a base product, because it includes all possible variants. A variation group can be purchased as a product, and can function similarly to a product set. When a variation group functions as a product set, the products to purchase are the individual variation products in the group.
