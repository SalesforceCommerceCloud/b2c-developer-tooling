# Automatic vs. Manual URL Redirects for B2C Commerce

_Consider the differences between automatic and manual redirects. This topic applies to B2C Commerce._
