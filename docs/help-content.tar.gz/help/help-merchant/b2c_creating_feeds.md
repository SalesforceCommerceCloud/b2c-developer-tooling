# Creating Active Data Feeds

_When active data is enabled for your site, certain data, as defined by Business Manager system objects, is captured on your Production instance. These data are automatically imported into your Production and Staging instances._

> **Note:** Active data feeds are replicated, but active data is not.

To use this data on your Sandbox instance, download the data (.csv format) from the Production instance and import it into your Sandbox instance. You can also obtain the csv file directly via WebDAV from the impex directory on your Production instance.

To use this data for extra analysis or reporting outside Salesforce B2C Commerce, export it.

The captured data is defined in the *CustomerActiveData* and *ProductActiveData* system objects. Most the attributes for these system objects are used in the following automatic feeds by B2C Commerce's Merchandising Analytics process:

- B2C Commerce Product Active Data
- B2C Commerce Product Weekly Active Data
- B2C Commerce Customer Active Data
- B2C Commerce Customer Weekly Active Data

Some of the attributes of these system objects, however, are not used in any feed. If you want to use these attributes, as shown in the following table, you must create feeds for them.

| System object | Attribute |
| --- | --- |
| CustomerActiveData | Customer.returnItems returnValue returns |
| ProductActiveData | availableDate costPrice returnRate |

> **Note:** If you don't feed in values for the *availableDate* attribute, B2C Commerce uses the *creationDate* attribute instead. B2C Commerce creates this attribute when you add a product.

If you create other custom active data attributes, you must feed them in as well. For example, create different feeds for attributes that require a different import frequency (daily versus weekly) or are fed from different backend systems.

> **Note:** Create a maximum of three feeds for each type: *product* or *customer.*

Unlike with B2C Commerce import/export files, active merchandising feeds don't have a set schema. Instead, define the feed format in Business Manager, which you can then import or export into any other instance using Site Import/Export.

Next, create feed files and then import the feeds for data analysis. You can also automate the active data feed import.
