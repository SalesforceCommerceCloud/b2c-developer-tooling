# Creating Active Data Feeds

_When active data is enabled for your site, certain data, as defined by Business Manager system objects, is captured on your Production instance. These data are automatically imported into your Production and Staging instances._

> **Note:** Active data feeds are replicated, but active data is not.

To use this data on your Sandbox instance, download the data (.csv format) from the Production instance and import it into your Sandbox instance. You can also obtain the csv file directly via WebDAV from the impex directory on your Production instance.

To use this data for extra analysis or reporting outside Salesforce B2C Commerce, export it.

The captured data is defined in the *CustomerActiveData* and *ProductActiveData* system objects. Most the attributes for these system objects are used in the following automatic feeds by B2C Commerce's Merchandising Analytics process:

- B2C Commerce Product Active Data
- B2C Commerce Product Weekly Active Data
- B2C Commerce Customer Active Data
- B2C Commerce Customer Weekly Active Data

Some of the attributes of these system objects, however, are not used in any feed. If you want to use these attributes, as shown in the following table, you must create feeds for them.

| System object | Attribute |
| --- | --- |
| CustomerActiveData | Customer.returnItems returnValue returns |
| ProductActiveData | availableDate costPrice returnRate |

> **Note:** If you don't feed in values for the *availableDate* attribute, B2C Commerce uses the *creationDate* attribute instead. B2C Commerce creates this attribute when you add a product.

If you create other custom active data attributes, you must feed them in as well. For example, create different feeds for attributes that require a different import frequency (daily versus weekly) or are fed from different backend systems.

> **Note:** Create a maximum of three feeds for each type: *product* or *customer.*

Unlike with B2C Commerce import/export files, active merchandising feeds don't have a set schema. Instead, define the feed format in Business Manager, which you can then import or export into any other instance using Site Import/Export.

Next, create feed files and then import the feeds for data analysis. You can also automate the active data feed import.

## Related Content

- [Defining Feeds](https://help.salesforce.com/s/articleView?id=cc.b2c_defining_feeds.htm&type=5)
  Create feeds for the *costPrice* and *returnRate* attributes to use all the system attributes calculated for *ProductActiveData.*

- [Create Feed Files](https://help.salesforce.com/s/articleView?id=cc.b2c_creating_feed_files.htm&type=5)
  Create a maximum of three new feed definitions. Use field definitions when your imported attributes require a different import frequency (daily versus weekly) or when they are fed from different backend systems.

- [Download Active Data on Production](https://help.salesforce.com/s/articleView?id=cc.b2c_downloading_active_data_on_production.htm&type=5)
  If active data is enabled for your site, all data is accumulated from your Production instance and automatically imported into your Production and Staging instances.

- [Import Feeds](https://help.salesforce.com/s/articleView?id=cc.b2c_importing_feeds.htm&type=5)
  To import active data into other instances, upload it in the production instance and then import it into another instance.

- [Import Active Data .csv Files](https://help.salesforce.com/s/articleView?id=cc.b2c_importing_active_data_csv_files.htm&type=5)
  Import Active Data .csv files to use production active data on your Sandbox instance or to test active data sorting rules. Download the daily active data feed from your Production instance and import it into your Sandbox.
