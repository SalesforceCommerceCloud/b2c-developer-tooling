# Promotion Discounts in B2C Commerce

_Salesforce B2C Commerce processes promotions based on the configuration of each discount rule, starting with the assigned promotion class. This topic applies to B2C Commerce._

This chart explains how discounts apply to the various promotion classes.

| Discount Type | [Product](https://help.salesforce.com/s/articleView?id=cc.b2c_product_promotions.htm&type=5) | [Order](https://help.salesforce.com/s/articleView?id=cc.b2c_order_promotions.htm&type=5) | [Shipping](https://help.salesforce.com/s/articleView?id=cc.b2c_shipping_promotions.htm&type=5) |
| --- | --- | --- | --- |
| % off | Applied individually to the price of eligible products | Applied to the order merchandise total of the basket after individual product discounts | Applied to the shipping cost of the default shipping line item of a shipment |
| $ off | Applied to the price of eligible products | Applied to the order merchandise total of the basket after individual product discounts | Applied to the shipping cost of the default shipping line item of a shipment |
| Fixed price | Applied to the price of eligible products | Not applicable | Applied to the shipping cost of the default shipping line item of a shipment |
| [Price from Price Book](https://help.salesforce.com/s/articleView?id=cc.b2c_price_from_pricebook_promotions.htm&type=5) | Overrides the active price book for eligible products (configure a [preference](https://help.salesforce.com/s/articleView?id=cc.b2c_configuring_promotion_preferences.htm&type=5) to prevent this discount from increasing a product's price) | Not applicable | Not applicable |
| [Percent Off Product Options](https://help.salesforce.com/s/articleView?id=cc.b2c_discount_on_a_product_option.htm&type=5) | Applies only to options with a positive price | Not applicable | Not applicable |
| Bonus products | Configured bonus products added to the order | Configured bonus products added to the order (can only grant one bonus product for With number of qualifying products) | Not applicable |
| [Choice of Bonus Products](https://help.salesforce.com/s/articleView?id=cc.b2c_choice_of_bonus_product_discount.htm&type=5) (List) | Bonus placeholder added to an order (requires storefront application changes) | Bonus placeholder added to an order (requires storefront application changes) | Not applicable |
| [Choice of Bonus Products](https://help.salesforce.com/s/articleView?id=cc.b2c_choice_of_bonus_product_discount.htm&type=5) (Rule) | Configured as any rule-based [product](https://help.salesforce.com/s/articleView?id=cc.b2c_product_promotions.htm&type=5) or [order](https://help.salesforce.com/s/articleView?id=cc.b2c_order_promotions.htm&type=5) promotion, with no application change required | Configured as any rule-based [product](https://help.salesforce.com/s/articleView?id=cc.b2c_product_promotions.htm&type=5) or [order](https://help.salesforce.com/s/articleView?id=cc.b2c_order_promotions.htm&type=5) promotion, with no application change required | No applicable |
| Free | For Buy X/Get Y product promotions only and treated the same as a fixed price discount but as a separate discount | Not applicable | Applied per shipment on the shipping cost of shipped items and against the shipping costs of a number of qualifying products with qualifying shipping methods |
| Fixed-price shipping | Applied against each eligible product | Not applicable | Not applicable |
| Free shipping | Applied against each eligible product | Not applicable | Applied against order (if the Restriction checkbox is set, the promotion doesn’t apply for shipments with nonqualifying products) |

Give each discount a unique limit so that no two discounts depend on the same factor. For example, one discount requires a purchase of two, three, or four products, while a second discount requires the purchase of five or more products. When the consumer is eligible for the second discount, the first discount is removed from the order.

> **Note:** When applying product promotion discounts to orders with more than one qualifying product, the price adjustment is calculated based on individual unit prices, not on the sum of multiple units.

The B2C Commerce Catalog supports multiple product types: variation products, bundles, and product options.

> **Note:** Product sets aren't considered products that a customer can purchase because they don't have an SKU with an associated price.

Variation products and product bundles handle promotions the same as standard products. Two prices determine product options pricing: the price of the base product plus the price of the selected option. To search and add a variation product as a bonus product, categorize its base product.

This is how the % off discount applies to option products:

| Product | Option | Discount | Price |
| --- | --- | --- | --- |
| Product X ($100.00) | Product option A (-10.00) | 10% off | (100-10)*.9 = $81 |
| Product X ($100.00) | Product option B (0.00) | 10% off | (100+0)*.9 =$90 |
| Product X ($100.00) | Product option C (+20.00) | 10% off | (100+20)*.9 =$108 |

### Bonus Discounts

A shopper can't add more bonus products than the maximum permitted set in the discount. Though storefront applications can call the API method LineItem.setQuantityValue() to set the quantity to an arbitrary value, the next time a discount applies, the value adjusts. For bonus product discounts, the quantity resets back to one.

### Fixed-Price Discounts

With a fixed amount ($) off discount, if you apply a fixed price discount to an option product, the fixed price is applied regardless of the option selected.

Use discretion when applying discounts to option products because this discount type can increase a product's price. Check your promotion preferences to configure this setting.

| Product Price | Option Adjustment | Discount | Price |
| --- | --- | --- | --- |
| $100.00 | Product option B (0.00) | Fixed Price $90 | $80 (price decrease of $20) |
| $100.00 | Product option C (+20.00) | Fixed Price $90 | $80 (price decrease of $40) |
| $100.00 | Product option A (-15.00) | Fixed Price $90 | $80 (price increase of $5) |

> **Tip:** We recommend applying a % off discount with product options, not a fixed price discount.

### Price from Price Book Discount

To manage prices within price books, while scheduling and qualifier features, use Price From Price Book. This discount assigns price books to fixed-price product promotions to get the fixed price of the discounted products from the assigned price book. This discount is similar to a fixed-price discount, but instead of storing a specific fixed price, it stores a reference to a sale price book.

For example, buy three or more shirts and get prices from SalesPriceBook. Buy five or more shirts and get prices from ClearancePriceBook.
