# Verify Site Ownership for Google in B2C Commerce

_To verify that you’re the owner of a site, Google requests that you add a specific meta tag to your site or deploy a file with a specific name to your web server's root directory. Though this topic refers specifically to Google, other search engines have similar procedures._

|  |
| --- |
| Available in: **B2C Commerce** |

To add the meta tag to your site, you must create a custom site preference for the Google tag and then include the tag in your storefront. Google uses the name `google-site-verification` for the meta-tag used for site verification. The `htmlhead.isml` template in SiteGenesis uses this name for Google site verification with the storefront.

> **Note:** pt_storefront.isml is located in the SiteGenesis Storefront Core cartridge, `/templates/default/content/home`.

1. To render your generated Google meta tag on the `pt_storefront-template` in the SiteGenesis application, click App Launcher _(image: App Launcher)_, and then select **Merchant Tools > Site > Site Preferences > Custom Preferences > Storefront Configs**.
2. On the Custom Site Preferences page, enter the `GoogleVerificationTag - Content Attribute`, which is an attribute of the `SitePreferences` system object.
3. Make sure that the following code exists in your `htmlhead.isml` template:

   ```
   <!--- Insert meta tag for the "Google-Verification" feature to verify that you are the owner of this site. --->
   
   <isif condition="${'GoogleVerificationTag' in dw.system.Site.current.preferences.custom && dw.system.Site.current.preferences.custom.​GoogleVerificationTag!=''}”>
   
   <meta name="verify-v1" content="<isprint value="${dw.system.Site.current.preferences.​custom.​GoogleVerificationTag}"/> "/>
   
   </isif>
   ```
