# Import Boost and Bury Rules

_Use search import and export to create, update, or replace boost and bury rules in bulk._

|  |
| --- |
| Available in: **B2C Commerce** |

1. In Business Manager, click App Launcher _(image: App Launcher)_, and then select **Merchant Tools > Site > Search > Import & Export**.
2. In the Import and Export Files section, click **Upload** and upload your sort file. See the example sort file.
3. In the Sorting Rules section, click **Import**, select the uploaded file, and click **Next**.
4. After validation, select an operation: **Merge**, **Update**, **Replace**, or **Delete**.
5. Click **Next** to run the import.

<sort xmlns="http://www.demandware.com/xml/impex/sort/2009-05-15"> <boost-bury-rule rule-id="boost_red_shirts_search_term" active-flag="true" factor="90"> <description>Boost Red Shirts</description> <boost-bury-qualifier type="Search Term Scope" value="shirt"/> <boost-bury-target attribute-name="refinementColor" attribute-value="red" /> </boost-bury-rule> </sort>
