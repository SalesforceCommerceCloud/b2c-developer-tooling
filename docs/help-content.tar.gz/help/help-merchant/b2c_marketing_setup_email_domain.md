# Set Up an Email Domain for Shopper Notifications

_Using Notifications requires a valid email address to indicate who the notification is from. You can use the default address provided by Salesforce or create an address using an authenticated site domain to provide a branded experience._

By default, notification emails are sent from either `no-reply@101.mx.salesforce.com` or `no-reply@201.mx.salesforce.com`. If your site's domain doesn't match the active authenticated domain, emails are sent from one of the default Salesforce addresses instead.

1. To create your own from email address, in your Salesforce org, from Setup, select **Unified Messaging > Email > Authenticated Domains**.
2. Click **Add Domain** and follow the instructions to activate your domain.
3. From Setup, select **Unified Messaging > Email > Authenticated From Addresses**.
4. Click **Add From Addresses** and add the information for your address. The user name must be `no-reply`.
5. Click **Save**.
