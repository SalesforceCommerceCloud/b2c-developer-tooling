# Assign a Catalog to a Site

_You assign a catalog to a site on the Site Assignments tab of the catalog definition editor._

|  |
| --- |
| Available in: **B2C Commerce** |

When you assign a catalog to a site, the catalog that was previously assigned to that site is automatically unassigned. Assign only one catalog at a time to a site. When you unassign a catalog from a site, a replacement catalog isn't automatically assigned. Manually assign a new catalog to the site.

1. Click App Launcher _(image: App Launcher)_, and then select **Merchant Tools > Site > Products and Catalogs > Catalogs**
2. Click **Edit** for the catalog you want to manage.
3. Click the**Site Assignments** tab.
4. Select the sites you want to assign this catalog to and click **Apply**.

   Assign the catalog to as many sites as you want. When you assign a catalog to a site, the category structure defined within the catalog becomes the navigation structure of the assigned storefront site.
   
   To include the products in the catalog in a search, rebuild the product search index. Click App Launcher _(image: App Launcher)_, and then select **Merchant Tools > Site > Search > Search Indexes**. To rebuild, select the index and click **Rebuild**.
