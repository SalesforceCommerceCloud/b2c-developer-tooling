# Manage Content Blocks

_Use the Content Blocks module in Business Manager to search, filter, target, and manage the lifecycle of content blocks from a centralized location._

To access the module, click App Launcher _(image: App Launcher)_, and then select **Merchant Tools > Content > Content Blocks**.

## Related Content

- [Filter and Search Content Blocks](https://help.salesforce.com/s/articleView?id=cc.b2c_cb_filter_search.htm&type=5)
  Use the Content Blocks module to browse, search, and filter content blocks. Filters let you narrow results by campaign, promotion, schedule, targeting locale, customer group, and creation date.

- [Set Targeting Rules for a Content Block](https://help.salesforce.com/s/articleView?id=cc.b2c_cb_target.htm&type=5)
  Control when and to whom a content block is visible by adding it to a campaign or promotion, or by applying custom targeting rules.

- [Apply Bulk Actions to Content Blocks](https://help.salesforce.com/s/articleView?id=cc.b2c_cb_bulk_actions.htm&type=5)
  Select multiple content blocks and apply targeting or scheduling rules to all of them at once. Bulk actions reduce the time required to manage seasonal campaigns and sitewide content updates.

- [Localize a Content Block](https://help.salesforce.com/s/articleView?id=cc.b2c_cb_localize.htm&type=5)
  Create locale-specific versions of a content block so that localized content appears on your storefront for each target locale.

- [View Content Block Usage and References](https://help.salesforce.com/s/articleView?id=cc.b2c_cb_view_usage.htm&type=5)
  See all the pages and storefront regions where a content block is currently used. Reviewing usage helps you understand the impact of changes before editing or deleting a content block.

- [Delete a Content Block](https://help.salesforce.com/s/articleView?id=cc.b2c_cb_delete.htm&type=5)
  Permanently delete a content block from the Content Blocks module. Before deleting, review the content block's usage to confirm it isn't referenced by any active storefront pages or regions.
