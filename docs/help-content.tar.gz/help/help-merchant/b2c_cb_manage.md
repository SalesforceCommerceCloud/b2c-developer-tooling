# Manage Content Blocks

_Use the Content Blocks module in Business Manager to search, filter, target, and manage the lifecycle of content blocks from a centralized location._

To access the module, click App Launcher _(image: App Launcher)_, and then select **Merchant Tools > Content > Content Blocks**.
