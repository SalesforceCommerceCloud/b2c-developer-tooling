# Troubleshoot Search Results for B2C Commerce

_When configuring B2C Commerce search and navigation for your storefront, itʼs important to troubleshoot your search results frequently. Consider things like queries, indexes, stemming, performance, availability ranking, and how you configure your products._

Use these tips to troubleshoot search results.

- Queries and search results: Identify how a query is constructed using the storefront toolkit Search Information tool.
- Indexes: If a particular feature of indexes doesn't appear to work, verify that the feature is enabled. Click App Launcher _(image: App Launcher)_, and then select **Search > Search Preferences**.
- Stemming: If stemming doesn't work in a non-English locale, change the stemmer language setting. Click App Launcher _(image: App Launcher)_, and then select **Search Indexes > Language Options**.
- Performance: Review the index summary for an index. Click App Launcher _(image: App Launcher)_, and then select **Search Indexes > *Index* > General tab**. The index summary shows the number of elements indexed. If no elements are indexed, return to the Search Indexes page and rebuild the index. If an excessively large number of items are indexed, consider adding stop words.
- Availability ranking: If the availability index doesn't recognize a change in the availability threshold, verify that you made the change on the production system. Because the availability index isn't stageable, changing the availability threshold in the staging search configuration doesn’t replicate to the production system.

### Searching for Standard Products

A standard product is found by keyword search if the product is online, searchable, and assigned to the storefront catalog. If a product is assigned to both online and offline categories, it's indexed. Only product attributes that are configured as searchable attributes are indexed.

### Searching for Bundled Products

Bundled products are treated identically to standard products. The product bundle is online, searchable, and assigned to the storefront catalog.

### Searching for Variation Products

A variation product is found by keyword search if the variation is online and the base product is online, searchable, and assigned to the storefront catalog.

### Searching for Product Sets

For a product set to be found based on a product in the set, the product in the set must be online and the product set must be online, searchable, and assigned to the storefront catalog.

### Searching for Variation Products as Part of Product Sets

A product set is found by keyword search if the search text is contained in the product set or any product in the set. If the product is a variation product, it's found in the base product or any of the variation products.

A product set is contained in a refined search result if the refinement attribute is defined for any products in the set. If the product is a variation product, any of the variation products that match the refinement are included in the refined search result.

If a product set contains variation products, itʼs sorted based on the attributes defined in the variation products, unless the product set or the base product defines its own values for these attributes, such as for aggregated active data metrics.

Availability doesn't affect the search results, even if the variation product searched for, such as "size 28 bootcut jeans" isn't available. The product set that contains the product appears in the search results.

### Searching by Product ID

Product IDs are split for search purposes, and a search containing any part of the split ID returns the product. A product ID is split based on these criteria.

- Punctuation characters '-', '/' and '|'. For example, "PS-40/a" becomes "PS" "40" "a".
- Character-number transitions. For example, "PS40a" becomes "PS" "40" "a".
- Leading zeros. For example, "00001234" becomes "0000" "1234" (if configured to ignore leading zeros).

### Searching for Products in Hidden Categories

If a product is assigned to a subcategory whose parent or any of parent category in the category hierarchy except the root category is offline, the product isnʼt indexed and isnʼt found in keyword search. This includes searching by product ID. The product is only returned by a category search.
