# URL Syntax for B2C Commerce

_Define how your storefront URLs look in Salesforce B2C Commerce via three types of URL syntax._

Consider the following.

| If you... | See these instructions | Use this syntax |
| --- | --- | --- |
| Use the [URL Rules](https://help.salesforce.com/s/articleView?id=cc.b2c_using_url_rules_for_seo.htm&type=5) module | [Configuring SEO URLs](https://help.salesforce.com/s/articleView?id=cc.b2c_configuring_seo_urls.htm&type=5) | [URL Rules Syntax](https://help.salesforce.com/s/articleView?id=cc.b2c_url_rules_url_syntax.htm&type=5) |
| Use the deprecated [SEO Support Module](https://help.salesforce.com/s/articleView?id=cc.b2c_url_evaluation_and_resolution_for_legacy_search_friendly_urls.htm&type=5) (by de-selecting the URL Rules preference) | [Configuring Search-Friendly URLs](https://help.salesforce.com/s/articleView?id=cc.b2c_creating_search_friendly_urls.htm&type=5) | [SEO Support URL Syntax](https://help.salesforce.com/s/articleView?id=cc.b2c_seo_support_url_syntax.htm&type=5) |
| Don't specify URL syntax |  | [B2C Commerce Standard URL Syntax](https://help.salesforce.com/s/articleView?id=cc.b2c_digital_url_syntax_without_seo.htm&type=5) |

> **Note:** Before Release 13.1, the SEO Support module was used to configure storefront URLs. This module is still provided for backwards compatibility, but is deprecated and not recommended for new customers.

The syntax you use depends on which Business Manager module you have enabled. You can't enable both *URL Rules* and *SEO Support*. Salesforce recommends the URL Rules module because it provides greater configuration flexibility.

## Related Content

- [How B2C Commerce Assigns Page URLs](https://help.salesforce.com/s/articleView?id=cc.b2c_how_digital_assigns_page_urls.htm&type=5)
  B2C Commerce provides several layers of inheritance URL attribute values that can be set through page-specific values, category values, or default values. URLs are assigned if the URL Rules module is enabled.

- [URL Generation and Conflict Resolution for B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_url_generation_and_conflict_resolution.htm&type=5)
  B2C Commerce maintains a directory of pipeline, category, folder, and search refinement URLs in B2C Commerce database. Product and content URLs aren’t contained in this directory, because they’re built dynamically. The URL directory contains a URL endpoint for any pipeline alias, category in the storefront catalog, and folder in the site library for each site locale.

- [URL Evaluation and Resolution](https://help.salesforce.com/s/articleView?id=cc.b2c_url_evaluation_and_resolution.htm&type=5)
  When a customer enters a URL into their browser navigation bar, B2C Commerce evaluates the URL and resolves it in this sequence.

- [Characters Allowed in URLs](https://help.salesforce.com/s/articleView?id=cc.b2c_characters_allowed_in_urls.htm&type=5)
  Encode most characters used in URLs. B2C Commerce automatically encodes special or reserved characters, or umlauts in URLs, but doesn't remove them.

- [Substituting Reserved and Special URL Characters](https://help.salesforce.com/s/articleView?id=cc.b2c_urls_substituting_reserved_and_special_characters.htm&type=5)
  When generating your storefront URLs, Eliminate or substitute certain characters. This topic applies to B2C Commerce.

- [URL Evaluation and Resolution for Legacy Search-Friendly URLs](https://help.salesforce.com/s/articleView?id=cc.b2c_url_evaluation_and_resolution_for_legacy_search_friendly_urls.htm&type=5)
  This topic assumes that the legacy feature for search-friendly URLs is enabled and that the URL Rules module is disabled. If you are a new customer, use the URL Rules module. This topic applies to B2C Commerce.

- [URL Syntax Without SEO](https://help.salesforce.com/s/articleView?id=cc.b2c_digital_url_syntax_without_seo.htm&type=5)
  To see the standard B2C Commerce URLs without search engine optimization, make sure that the URL Rules module is disabled. If you are using the deprecated SEO Support module, make sure it's also disabled.
