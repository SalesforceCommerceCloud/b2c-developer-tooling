# URL Syntax for B2C Commerce

_Define how your storefront URLs look in Salesforce B2C Commerce via three types of URL syntax._

Consider the following.

| If you... | See these instructions | Use this syntax |
| --- | --- | --- |
| Use the [URL Rules](https://help.salesforce.com/s/articleView?id=cc.b2c_using_url_rules_for_seo.htm&type=5) module | [Configuring SEO URLs](https://help.salesforce.com/s/articleView?id=cc.b2c_configuring_seo_urls.htm&type=5) | [URL Rules Syntax](https://help.salesforce.com/s/articleView?id=cc.b2c_url_rules_url_syntax.htm&type=5) |
| Use the deprecated [SEO Support Module](https://help.salesforce.com/s/articleView?id=cc.b2c_url_evaluation_and_resolution_for_legacy_search_friendly_urls.htm&type=5) (by de-selecting the URL Rules preference) | [Configuring Search-Friendly URLs](https://help.salesforce.com/s/articleView?id=cc.b2c_creating_search_friendly_urls.htm&type=5) | [SEO Support URL Syntax](https://help.salesforce.com/s/articleView?id=cc.b2c_seo_support_url_syntax.htm&type=5) |
| Don't specify URL syntax |  | [B2C Commerce Standard URL Syntax](https://help.salesforce.com/s/articleView?id=cc.b2c_digital_url_syntax_without_seo.htm&type=5) |

> **Note:** Before Release 13.1, the SEO Support module was used to configure storefront URLs. This module is still provided for backwards compatibility, but is deprecated and not recommended for new customers.

The syntax you use depends on which Business Manager module you have enabled. You can't enable both *URL Rules* and *SEO Support*. Salesforce recommends the URL Rules module because it provides greater configuration flexibility.
