# Upgrade from SEO Support to URL Rules

_If you implemented your site before Release 13.1, this topic contains the information you need to upgrade to the new module. In Release 13.1, B2C Commerce added the URL Rules module, which enables you to customize storefront URLs to optimize search engine results. The SEO Support feature, which provided a limited version of the same functionality, was deprecated for 13.1 and is planned for removal at a future date. The SEO Support functionality is accessible under the URL Rules module, until the new URL Rules module is enabled using the site preference for Storefront URLs._

For customers who are implementing their site using Release 13.1 or later releases, the SEO Support functionality isn't visible and this topic doesn't apply to you.

The URL Rules module helps you optimize your site URLs in the following ways:

- URLs don't contain a page type indicator or a proprietary extension “sc.html”
- URLs are short and meaningful
- URLs do not contain “demandware“

> **Note:** The SEO Support module is hidden once the URL Rules module is enabled.

## Test URL Rules in a Sandbox

_To use the new URL Rules feature, turn it on. The URL Rules module shows the SEO Support page until the URL Rules module is enabled. This is a one-way transition and no redirects are created if you decide to disable URL Rules and reenable the deprecated SEO Support feature. Test your new configuration on Sandboxes before enabling the feature on Staging or Production._

|  |
| --- |
| Available in: **B2C Commerce** |

1. Add permissions to the URL Rules Module.

   The permissions for the SEO Support module are migrated to the URL Rules module. Follow these steps only if you have more roles to add for the module or if you did not use the SEO Support module and so are upgrading from standard B2C Commerce URLs.
   
   1. Select **Administration > Organization > Roles & Permissions**
   2. On the Roles page General tab, select the role to which you want to add the permission.
   3. On the Roles page Business Manager Modules tab, in the Select Context list, select the site to which you want to add permissions.
   4. Under SEO select the **URL Rules** module.
2. Enable URL Rules on your Sandbox.

   1. Click App Launcher _(image: App Launcher)_, and then select **Merchant Tools > Site > Site Preferences > Storefront URLs**.
   2. On the Storefront URL Preferences page, select **Enable Storefront URL Rules** and click **Apply**.
   3. Click App Launcher _(image: App Launcher)_, and then select **Merchant Tools > Site > SEO & Discoverability > URL Rules**. View the URL Rules page General tab.
3. Configure URL Rules.

   See [Configuring SEO URLs.](https://help.salesforce.com/s/articleView?id=cc.b2c_configuring_seo_urls.htm&type=5)
4. Test other features that can be affected.

   After you have configured and tested your storefront URLs, investigate whether to change the following:
   
   - Code: If you use our SEO Support module without custom code for SEO, no code changes are necessary to take advantage of this feature. If you have custom code or have more integrations for SEO, alter the code to work with the feature.
   - Canonical links: B2C Commerce best practice is to create canonical links for categories using the `URLUtils` method. If you used the `URLUtils` method, no changes to code are necessary. However, if you have hardcoded canonical links in your templates, update them to use your new URLs.
   - Content links: Check links in your content assets to make sure that they don't require updating to reflect the new URLs. If you are using the content link functions, they don't require updating. However, if you have included hardcoded links in your content assets, these can require updating.
   - URL redirects: Check your URL redirects to make sure that your redirects don't require adjusting to your new URLs. This can be because the redirects are outdated or conflict with your new URLs.
   - Static mappings and mapping rules: Check your URL mappings to make sure that your redirects don't require adjusting to your new URLs.
      
      > **Note:** If your old URLs now match the new storefront URLs, a redirect is no longer necessary.
   - Product ID search: make sure that the product ID search works as you expect if customers enter the product ID as it appears in the URL.
5. Export URL Rules from your sandbox.

   1. On your Sandbox, select **Administration > Site Development > Site Import & Export**.
   2. On the Site Import & Export page, scroll down to the Export section and enter a name for the export, such as `sandRules`.
   3. Under Data Units to Export, expand **Sites > *site*** and select **Site Preferences** and **SEO & Discoverability**.
   4. Scroll to the top of the section and click **Export**.
   5. Scroll to the bottom of the page and monitor the export in the Status section. Click **Refresh** to refresh the page.

## Configure URL Rules

_When you are confident that you can transition to the new URL Rules feature, enable it on your Staging instance and import your configuration from your Sandbox instance._

|  |
| --- |
| Available in: **B2C Commerce** |

> **Important:** When URL Rules are enabled, the SEO Support page is no longer visible under URL Rules.

1. Disable SEO Support.

   This prevents you from exporting unnecessary files in future site exports.
   
   1. On Staging, click App Launcher _(image: App Launcher)_, and then select **Merchant Tools > Site > SEO & Discoverability > URL Rules**.
   2. On the Search Support Preferences page, in the Instance Type list, select **Staging**.
   3. Deselect **Enable Search Friendly URLs**.
2. Add Permissions for the URL Rules Module.

   1. Select **Administration > Organization > Roles & Permissions**.
   2. On the Roles page, click the role to which you want to add the permission.
   3. On the Roles page General tab, click the **Business Manager Modules** tab.
   4. On the Business Manager Modules tab, in the Select Context list, select the site for which you want to add permissions.
   5. Under SEO, select the **URL Rules** module.
3. Enable URL Rules on Staging.

   1. Click App Launcher _(image: App Launcher)_, and then select **Merchant Tools > Site > Site Preferences > Storefront URLs** .
   2. On the Storefront URL Preferences page, select **Enable Storefront URL Rules** and click **Apply**.
   3. Click App Launcher _(image: App Launcher)_, and then select **Merchant Tools > Site > SEO & Discoverability > URL Rules**. View the URL Rules page General tab.
4. Import URL Rules into Staging.

   1. On your Sandbox, select **Administration > Site Development > Site Import & Export**.
   2. On the Site Import Export page, in the Import section, click **Browse** and select the archive you exported from your Sandbox instance.
   3. Click **Upload**.
   4. Select the uploaded file in the list and click **Import**.
   5. Scroll to the bottom of the page and monitor the import in the Status section. Click **Refresh** to refresh the page.
5. Update Staging Jobs.

   Update:
   
   - Sitemaps: Regenerate your sitemap to include your new URLs. The sitemap isn't automatically regenerated.
   - Replication jobs: Update your replication jobs to include the new URL Rules.
   - Site export jobs: Update your job to include URL Rules.
   - Site backup: Update your scheduled site backups to include URL Rules.
6. Replicate to production and update sitemap.

   Replicate the URL rules and URL-related jobs to your Production instance:
   
   - Replication jobs: Update your replication jobs to include the new URL Rules functionality.
   - Site export jobs: Update your job to include URL Rules.
   
   Regenerate your sitemap on production so it includes your new URLs. The sitemap isn't automatically regenerated, nor is it replicated from Staging.

## Auto-Redirect of Updated URLs

_Old URLs refer to URLs configured prior to Release 13.1, whether they are search-friendly URLs configured through the SEO Support module or standard B2C Commerce URLs not optimized for external search engines. New URLs refer to URLs configured using the URL Rules module. In Release 13.1, new URLs are disabled by default for existing sites and are enabled for sites created after the release. Old URLs work when the URL Rules module is disabled, and are redirected when the URL Rules module is enabled._

SiteGenesis is now updated to use new site URLs.

#### Old URLs to new URLs

If the URL Rules are enabled, existing URLs are automatically redirected to the new site URLs via a 301 redirect.

Example 1: Pipeline URL

Existing URL: www.sitegenesis.com/on/demandware.store/Sites-SiteGenesis-Site/default/Account-Show

Redirected URL:www.sitegenesis.com/account

Example 2: Category URL

Existing URL: www.sitegenesis.com/mens-clothing-shorts,default,sc.html www.sitegenesis.com/on./demandware.store/Sites-SiteGenesis-Site/default/Search-Show?cgid=mens-clothing-shorts

Redirected URL:www.sitegenesis.com/mens-clothing-shorts

Example 3: Product URL

Existing URL: www.sitegenesis.com/on/demandware.store/Sites-SiteGenesis-Site/default/Product-Show?pid=83536828

Redirected URL:www.sitegenesis.com/mens-clothing-shorts/straight-fit-shorts/83536828.html

#### New URLs to New URLs

New URLs can change for the following reasons:B2C Commerce still accepts the old version of the object URL, and redirects to the new URL of the object.

- One of the URL rule parameters has changed
- The URL rule has changed

Example 1: Pipeline URL

Existing URL: www.sitegenesis.com/account

Redirected URL: www.sitegenesis.com/my_account

Example 2: Category URL

Existing URL: www.sitegenesis.com/mens-clothing-shorts

Redirected URL:www.sitegenesis.com/mens-shorts

Example 3: Product URL

Existing URL: www.sitegenesis.com/mens-clothing-shorts/straight-fit-shorts/83536828.html

Redirected URL:www.sitegenesis.com/mens-shorts/straight-fit-shorts/83536828.html B2C Commerce only archives URLs that have replicated previously to Production.
