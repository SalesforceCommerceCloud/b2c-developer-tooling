# Category Linking for B2C Commerce

_Link categories to each other so items in one category can be identified as belonging to another category. For example, link an Accessories category to a Women's category. Use the link to identify certain products within the Women's category as Accessories, such as scarves, jewelry, belts, or shoes. This topic applies to B2C Commerce._
