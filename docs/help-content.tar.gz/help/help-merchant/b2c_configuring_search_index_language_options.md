# Configure Search Index Language Options

_B2C Commerce indexes all allowed site locales by default. To reduce indexing times and overall resource consumption, exclude locales from indexing that don't have a particular set of data. You can also upload an extra dictionary for more directed and appropriate search results._

|  |
| --- |
| Available in: **B2C Commerce** |

Search indexing uses one localizable index for each index type: Product, Spelling, Content, Synonym, and Suggest. Each index contains all localized and non-localized data for all storefront locales. Exclude individual locales from the indexing process if search isn't required for those locales, which reduces indexing times and overall resource consumption.

For more directed and appropriate search results, you can upload an extra dictionary, for example, the *Chinese2* stemmer or a Japanese custom dictionary.

Add locales by clicking App Launcher _(image: App Launcher)_, and then selecting ** *site*  > Merchant Tools > Site Preferences > Locales** (with the appropriate permissions).

1. Click App Launcher _(image: App Launcher)_, and then select ** *site*  > Merchant Tools > Search > Search Indexes > Language Options**.
2. In the Search Suggestion Settings section, set the minimum term length that is required to execute term correction and auto-completion of search suggestions.

   We recommend these settings.
   
   - For single-byte languages such as English, French, Spanish, German, and the like, configure a minimum term length of 2 or higher to avoid search noise.
   - For double-byte or multi-byte languages such as Chinese, Japanese, Korean, and the like, use a minimum term length of 1 or higher.
3. In the Language Options section:

   1. Select by locale which stemmer is applied to the indexed search terms.
   
      For example, select the **Chinese - algorithmic** stemmer for the Chinese locale, and the **Chinese - dictionary** stemmer for the Chinese (China) locale, or the
      
      **Japanese** stemmer for the Japanese (Japan) and Japan locales
      
      .
   2. Select which active locales are required to be indexed by checking that locale in the Indexed column.
   
      By default, all locales are indexed, unless they’re disabled by Salesforce Support.
   3. Click **Apply**.
4. If the `Chinese - dictionary` stemmer is enabled, you see the Upload Custom Dictionary section, where you can upload an extra dictionary for the `Chinese - dictionary` stemmer to improve its predefined stemming behavior.

   Every site that uses the `Chinese - dictionary` stemmer also uses this additional dictionary.
   
   A custom dictionary file is a simple text file (must be named `words-cn-custom-dictionary.dic`) containing `#dictionary` without quotes in the first line, and words that aren’t split during tokenization on each subsequent line.
   
   The earlier mentioned Chinese stemmer removes the zhi-character "子" at the end of a word, which is used to form a compound word. Though the compound word still has the same meaning as the original noun, it provides less meaningful search results.
   
   1. Click **Choose File**.
   2. Select a file and click **Open**.
   3. Click **Upload**.
   
      Upon upload, the old dictionary is overwritten.
5. If the Japanese stemmer is enabled, the Japanese Custom Dictionary section is displayed. Add new dictionary entries as needed.

   1. Click **New Entry**.
   2. Specify the Surface Form, Segmentation, Furigana, and Part of speech.
   3. Save your changes.
   
   The new entry is visible in the Japanese Custom Dictionary section. In this section, you can edit or delete dictionary entries.
6. In the Manage Custom Dictionary section, you can download and back up the existing dictionary before you upload a new one. You can also clear an uploaded dictionary, after which the original dictionary is used.

   You can't upload a Japanese custom dictionary.
7. Click **<<Back** to return to the Search Indexes page.
8. Rebuild the Search Indexes.
