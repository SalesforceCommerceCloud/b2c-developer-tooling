# Shopper Journey Dashboard

_Use the B2C Commerce Reports & Dashboards Shopper Journey dashboard to evaluate how shoppers move from site visit to order conversion. The dashboard is available as a selection on the Traffic Report tab._

The dashboard provides conversion rate data for total shopper visits. And it lists percentage and totals for cart, checkout, and order conversions stages of the shopper journey. You can also review conversion data for the checkout steps you configured for your site.

The Shopper Journey dashboard shows conversion data in the following charts and graphs:

### Shopper Journey Funnel

The Shopper Journey Funnel illustrates how shoppers proceed through your storefront and at what point they abandon the process before they place an order. For each journey stage, the chart displays the number of stage visits and the percentage of the total visits. The Shopper Journey Funnel shows data for the following shopper stages:

- **Site Visits:** Total shopper sessions excluding known robots.
   
   > **Note:** Sessions time out after 30 minutes of inactivity.
- **Cart Visits:** A site visit with one or more cart actions. For example, add, update, or view.
- **Checkout Visits:** A site visit with one of more checkout actions. For example, editing the number of items, adding an item, or deleting an item.
   
   > **Note:** A checkout action is a shopper action that prompts action of the Checkout Controller.
- **Order Visits:** A site visit with one or more orders placed.
- **Percent drop between stages:** The percentage of total visits that drop between stages.

Use the stage metrics to help identify points in your conversion process where shoppers consistently drop their visit and abandon their carts.

**Funnel Gaps**

In the Shopper Journey Funnel, a funnel gap is the percentage of shoppers who don’t transition from one shopping stage to the next. Use these percentages to evaluate the success and failure of the shopping journey on your storefront. A large gap percentage can suggest that you modify the shopper experience at the gap point. For example, a checkout process that is confusing or requires shoppers to engage in excessive data entry.

Use the percentage of shoppers who transition from one stage to the next. Look for trends that show correlations between changes in the funnel gap. Then compare other dashboard data to identify business processes that impact improvements or downward trends.

The Shopper Journey Funnel Report requires that `ReportingEvent`-Start controller is invoked when a shopper interacts with a basket or cart. For more information, see [Analytics Reporting URL Patterns](https://help.salesforce.com/s/articleView?id=cc.b2c_analytics_reporting_integration_url_patterns.htm&type=5)

### Top 10 Checkout Steps

The dashboard shows the top 10 checkout steps used on your storefront. For example, a site can track the number of shopper visits that result in the shopper completing the address step.

For checkout data to populate on your dashboard, your site must include the implementation steps required for data to populate for the appropriate checkout step. For general implementations of Salesforce B2C Commerce, the dashboard gathers event data for the Checkout Steps from the checkout URL pattern. The Top 10 Checkout Steps Report requires that each step in the checkout process invokes the `ReportingEvent`-Start Controller. For Salesforce Reference Application (Salesforce Reference Architecture (SFRA)) and SiteGenesis JavaScript Controllers (SGJC) implementations, the Checkout Steps use data gathered from the checkout event. For more information, see [Analytics Reporting URL Patterns](https://help.salesforce.com/s/articleView?id=cc.b2c_analytics_reporting_integration_url_patterns.htm&type=5).

Your site’s checkout steps are a unique configuration adapted to your storefront and business practices, and can differ from the typical steps.

Typical checkout steps include:

- Checkout
- Billing
- Shipping
- Payment
- Order Summary
- Order Placed

For each checkout step, the table lists the following metrics:

- **Site:** The site to which the data applies. Set a specific site or multiple sites in the dashboard filters.
- **Step:** The process step number. For example, if reviewing an order summary, it's the third shopper journey step your site tracks, order summary appears as step 3.
- **Step Name:** The name of the step in your B2C Commerce implementation code.
- **Step Visits:** The number of site visits that included the listed step.

### Shopper Journey Graphs

The dashboard displays a set of line graphs that illustrate the shopper journey through the journey stage in relation to the previous shopper journey stage.

**Cart Visits / Visits**

Plots cart visits as a percentage of site visits. A high percentage indicates that your site is successful at driving shopper traffic to add items to a cart.

**Checkout Visits / Cart Visits**

Plots the checkout visits as a percentage of cart visits. A low percentage indicates that shoppers aren’t converting items they added to a cart to a checkout visit.

**Order Visits / Checkout Visits**

Plots order visits as a percentage of checkout visits. A high percentage indicates that your shoppers are sticking with their cart choices and moving on to order conversion. A low percentage indicates that shoppers are abandoning their carts or terminating their orders. When the order visit percentage is low, review the checkout steps metrics to identify the steps where shoppers are terminating their order.

**Order Conversion Rate**

Calculates the percentage of total visits during which customers place an order. A percentage that varies slightly from the Checkout Visits rate is normal. A percentage that varies greatly from the Checkout Visits can indicate that your shoppers are abandoning their order during the final checkout steps.
