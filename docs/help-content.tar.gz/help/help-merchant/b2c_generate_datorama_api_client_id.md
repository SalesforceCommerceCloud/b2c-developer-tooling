# Generate an API Client ID for Marketing Cloud Intelligence

_To connect your data to Marketing Cloud Intelligence, generate an API Client ID for Marketing Cloud Intelligence._

|  |
| --- |
| Available in: **B2C Commerce** |

1. Log into Account Manager.
2. Click **API Client**.

   The API Clients page lists the ID, display name, and status for each client.
3. Click **Add API Client**.
4. Complete the API Client information.

   1. In the Display Name field, enter the client display name.
   2. Enter a secure password.
   3. In the Confirm Password field, reenter the password.
   4. Under Organizations, select your organization.
   5. Under Roles, select **Salesforce Commerce API** and add your production instance as a filter.
   
      > **Note:** Data extraction is allowed only for production instances.
   6. Under OpenID Connect, in the Default Scopes field, enter the tenant filter (1) and roles (2) on separate lines.
   
      _(image: Open ID Connect default scopes.)_
      
      > **Note:** The tenantFilter and roles entries are necessary when using the Authorization Code Flow or OpenID Connect.
   7. From the Token Endpoint dropdown, select **client_secret_post**.
   8. From the Access Token Format dropdown, select **JSON Web Token (JWT)**.
   9. Click **Save**.
   
      The saved API Client appears in the API client list for your organization.
5. To view the API Client ID, click the API Client.

   Use the new API Client ID when entering your B2C Commerce credentials in the Salesforce B2C Commerce Connector.
