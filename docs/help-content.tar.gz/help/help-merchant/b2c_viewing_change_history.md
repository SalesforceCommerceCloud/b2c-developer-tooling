# View Change History

_Collect and view change history details for several Business Manager data objects. Use the Business Manager Administrations Change History module to search for and view change history data._

[Which Salesforce Commerce Product Do I Have?](https://help.salesforce.com/s/articleView?id=commerce.comm_what_product.htm)

Use the Business Manager Administrations Change History module to search for and view change history data.

1. Click App Launcher _(image: App Launcher)_, and then select **Administration > Operations > Change History**.
2. Select an object type or enter an object ID to restrict the search to objects of the specified type or ID.

   The list includes the object types that you enabled change history tracking for the corresponding module and their related object types. The list of types changes depending on the enabled settings.
3. Select the scope to restrict the search to objects existing within a limited context.

   For example, if you select **Product** as the object type and a specific catalog as the scope, the page returns changes for products within the context of the selected catalog. It omits changes for products related to price books, inventory lists, and other catalogs. By default, the scope is set to All, indicating that B2C Commerce returns changes across all contexts (or scopes).
4. Select an action to restrict the search further. High-level actions include:

   - **All**, which includes Object Creation, Object Deletion, and Object Update
   - **Object Creation**
   - **Object Deletion**
   - **Object Update**
   
   If an Object Update action can’t be further restricted, the value Attributes appears instead of the value **Object Update**.
5. Further restrict object updates depending on the object type, as shown in the following table:

   | Object type | Update actions |
   | --- | --- |
   | A/B test | All Attributes A/B test Segments Slot Configuration A/B test Assignments Promotion A/B test Assignments Sorting Rule A/B test Assignments |
   | Campaign | All Attributes Promotion Campaign Assignments Slot Configuration Campaign Assignments Sorting Rule Campaign Assignments |
   | Catalog | All Attributes Catalog Site Assignments |
   | Category | All Attributes Search Refinement Definitions Category Links Product Category Assignments Attribute Groups |
   | Content | All Attributes Folder Assignments |
   | Coupon: each change tracking event contains information about an imported coupon and the number of imported coupon codes to which it's related. | All Object creation Attributes Object Deletion |
   | Customer Group | All Attributes |
   | Customer List | All Attributes System Preferences Customer List Site Assignments |
   | Folder | All Attributes Folder Assignments Search Refinement Definitions Attribute Groups |
   | Inventory list | All Object Creation Object Updates All Updates Attributes Inventory List Site Assignments   Object Deletion |
   | Job Schedule | Attributes |
   | Object Definition | All Attributes Attribute Definitions Attribute Groups |
   | Ordering | All Taxation Preference Basket Preference Tax Jurisdiction Tax Jurisdiction Mapping Tax Class Tax Rate Ordering Preference Shipping Product Fixed/Surcharge Cost Shipping Cost Shipping Method Payment Processor Payment Card Payment Method |
   | Organization | All Attributes System Preferences Custom Preferences Locale OAuth Provider Search Service Setting Custom Log Setting |
   | Price Book | All Attributes Price Book Site Assignments |
   | Product | All Attributes Product Category Assignments Product Options Product Option Bindings Variation Attributes Main Variant Assignments Product Links Product Set Assignments Product Bundle Assignments Recommendations Price Tables Inventory Records |
   | Product Option | All Attributes Site Assignments Product Option Bindings Product Option Values |
   | Promotion | All Attributes Promotion Campaign Assignments Promotion A/B test Assignments |
   | Recommendation | Attributes |
   | Search Setting | All Attributes Searchable Attributes Search Driven Redirects Stopwords Category Name Exclusions Synonymns Hypernyms Compound Words Common Phrases Suggestion Phrases Suggestion Blocklists Dynamic Sorting Attributes |
   | Site | All Attributes System Preferences Custom Preferences Catalog Site Assignments Price Book Site Assignments Inventory List Site Assignments Promotion Settings Customer List Site Assignments |
   | Site URL | Object Creation Object Update All Updates Attributes Settings Locale Mappings Pipeline Aliases Redirects Dynamic Mappings Static Mappings Host Name Aliases Character Replacement Rules   Object Deletion |
   | Slot Configuration | All Attributes Slot Configuration Campaign Assignments Slot Configuration A/B test Assignments |
   | Sorting Rule | All Attributes Storefront Sorting Options Sorting Rule Campaign Assignments Sorting Rule A/B test Assignments |
   | Sourcecode Group | All Attributes Sourcecode Assignments |
   | Store | Attributes |
   | Variation Attribute | All Attributes Variation Attribute Values Variation Attribute Bindings |
6. To restrict the changes to only those performed by a job, enter a job ID in Object ID.
7. To restrict the changes to only those performed by a user, enter a user ID in User.
8. To specify a date range in the **From** and **To** fields, enter a date in the specified format in each field or click **...** to select date from the calendar. Also, you can specify a time.
9. Click **Find**.

   B2C Commerce returns a search result with zero or more changes.
10. Click a summary line.

   Individual changes appear in a table. Each row in the table represents a single change event―a creation event, update event, or deletion event. See the exact time when the change occurred.
11. Click the **Show Details** link to see a JSON representation of the object after the change occurred.

   Use a text comparison tool to compare two JSON representations of the same object and identify the exact nature of the change.
