# Prepare Attributes for Boost and Bury Rules

_Prepare your B2C site to create boost and bury rules in Visual Merchandising._

|  |
| --- |
| Available in: **B2C Commerce** |

1. In Business Manager, click App Launcher _(image: App Launcher)_, and then select **Merchant Tools > Site > Products and Catalog > Visual Merchandising**.

   If Visual Merchandising isn’t available, contact your Salesforce admin.
2. Click **Preferences**.
3. Add each product attribute that you plan to use as a boost and bury target.

   You can use only indexed attributes that are exposed to Visual Merchandising in rule criteria. See [Generate Search Indexes](https://help.salesforce.com/s/articleView?id=cc.b2c_generating_search_indexes.htm).
4. Save your changes.
5. Rebuild the search index.

   Rebuilding makes sure that you can target the newly exposed attributes in boost and bury rules. Rebuild the search index once for each new boostable attribute that you add. See [Updating Indexes](https://help.salesforce.com/s/articleView?id=cc.b2c_updating_indexes.htm).
