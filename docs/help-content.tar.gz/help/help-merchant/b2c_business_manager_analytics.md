# Historical Reports

_The B2C Commerce Business Manager Analytics reports are retired. As of January 1, 2021, the reports are no longer populated. Use these historical reports to review metrics published before January 1, 2021._

To access current data with advanced analytics and reporting capabilities, use the [Reports & Dashboards](https://help.salesforce.com/s/articleView?id=cc.b2c_reports_and_dashboards.htm&type=5).
