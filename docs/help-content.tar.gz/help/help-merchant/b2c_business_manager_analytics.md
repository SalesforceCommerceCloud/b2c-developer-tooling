# Historical Reports

_The B2C Commerce Business Manager Analytics reports are retired. As of January 1, 2021, the reports are no longer populated. Use these historical reports to review metrics published before January 1, 2021._

To access current data with advanced analytics and reporting capabilities, use the [Reports & Dashboards](https://help.salesforce.com/s/articleView?id=cc.b2c_reports_and_dashboards.htm&type=5).

## Related Content

- [Historical Reports Set-Up](https://help.salesforce.com/s/articleView?id=cc.b2c_business_manager_analytics_setup.htm&type=5)
  The B2C Commerce Business Manager Analytics reports are retired. As of January 1, 2021, the reports are no longer populated.

- [Historical Reports Metrics Definitions](https://help.salesforce.com/s/articleView?id=cc.b2c_analytics_metrics_definitions.htm&type=5)
  The B2C Commerce Business Manager Analytics reports are retired. As of January 1, 2021, the reports are no longer populated.

- [Historical Reports: Conversion](https://help.salesforce.com/s/articleView?id=cc.b2c_analytic_reports_conversion.htm&type=5)
  The B2C Commerce Business Manager Analytics reports are retired. As of January 1, 2021, the reports are no longer populated.

- [Historical Reports: Purchase](https://help.salesforce.com/s/articleView?id=cc.b2c_analytic_reports_purchase.htm&type=5)
  The B2C Commerce Business Manager Analytics reports are retired. As of January 1, 2021, the reports are no longer populated.

- [Historical Reports: Catalog](https://help.salesforce.com/s/articleView?id=cc.b2c_analytic_reports_catalog.htm&type=5)
  The B2C Commerce Business Manager Analytics reports are retired. As of January 1, 2021, the reports are no longer populated.

- [Historical Reports: Search and Navigation](https://help.salesforce.com/s/articleView?id=cc.b2c_analytic_reports_search_and_navigation.htm&type=5)
  The B2C Commerce Business Manager Analytics reports are retired. As of January 1, 2021, the reports are no longer populated.

- [Historical Reports: Customer](https://help.salesforce.com/s/articleView?id=cc.b2c_analytic_reports_customer.htm&type=5)
  The B2C Commerce Business Manager Analytics reports are retired. As of January 1, 2021, the reports are no longer populated.

- [Historical Reports: Technical](https://help.salesforce.com/s/articleView?id=cc.b2c_analytic_reports_technical.htm&type=5)
  The B2C Commerce Business Manager Analytics reports are retired. As of January 1, 2021, the reports are no longer populated.

- [Historical Reports: Traffic](https://help.salesforce.com/s/articleView?id=cc.b2c_analytic_reports_traffic.htm&type=5)
  The B2C Commerce Business Manager Analytics reports are retired. As of January 1, 2021, the reports are no longer populated.

- [Historical Reports: A/B Testing](https://help.salesforce.com/s/articleView?id=cc.b2c_analytic_reports_ab_testing.htm&type=5)
  The B2C Commerce Business Manager Analytics reports are retired. As of January 1, 2021, the reports are no longer populated.

- [Analytics Reporting Integration](https://help.salesforce.com/s/articleView?id=cc.b2c_analytics_reporting_integration.htm&type=5)
  Salesforce B2C Commerce provides robust storefront Analytics that can help make your storefront more successful.
