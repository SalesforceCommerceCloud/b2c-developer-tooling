# Searchandising

_Configure sorting rules to rank search results, based on an analysis of active data metrics. The sorted search results appear on result pages. This topic applies to B2C Commerce._

For example, import product review data and create rules that show the best rated products at the top of search results. You can also create custom code to show sorted search results in promotional slots.

Use Business Manager to define customer sorting options and associate them with sorting rules. For example, your storefront offers sorting options such as *Price Low-High* and* Bestselling*. Define the rules that set the behavior of these options through Business Manager.

You can also define different sorting rules for specific categories. For example, you want to sort products with low availability at the top of the search results in the Clearance section to clear out seasonal items. Create a new sorting rule based on product availability and assign it as the default category sorting rule for Clearance items.

Test active data sorting rules regularly to make sure they continue to meet your requirements.
