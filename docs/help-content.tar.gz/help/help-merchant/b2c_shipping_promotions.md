# Shipping Promotions for B2C Commerce

_Shipping promotions discount an order's shipping charges. A shipping promotion usually applies to every shipment in an order, unless you specify a maximum application for the promotion. This topic applies to B2C Commerce._

If you set a maximum application, the promotion applies only to the specified number of shipments, starting with the most expensive. All shipping orders only apply for the specific shipping methods you set.

Specify a shipping promotion based on category, brand, ID, price, inventory, and other attributes.

Product-Related Shipping Discounts are considered product promotions. You can also configure product-specific shipping cost (fixed or surcharge).

| Promotion Type | Description | Available discounts |
| --- | --- | --- |
| With Amount of Shipment-Qualifying Products | This promotion triggers when a customer spends a specified amount in a single shipment. For example, a customer spends $100 and receives 10% off Next Day shipping. The amount spent is calculated for each shipment, after product and order promotion applications. Gift certificates, taxes, and shipping charges don't count toward the shipment total. | Percent off Amount off Fixed price Free |
| With Number of Shipment-Qualifying Products | This promotion triggers when a customer buys a specified number of products in a single shipment. For example, a customer buys three shirts and gets $10 off Next Day shipping. The discount applies only if the shipment has the specified number of qualifying products.To prevent the promotion from applying to shipments with non-qualifying products, use restrictions. | Percent off Amount off Fixed price Free |
| With Combination of Shipment-Qualifying Products | This promotion triggers when a customer buys a specified combination of products. For example, a customer buys two shirts and one tie in and gets free Next Day shipping. This promotion type has unique restrictions. See With Combination of Products Promotions.The Disable Global Product Exclusions flag is managed on the promotion details page of the Within the Qualifying Products window. | Percent off Amount off Fixed price Free |

### Shipping Promotion Rules

- If a product is a member of multiple shipping cost groups, the lowest shipping cost takes precedence.
- If both a fixed shipping cost and a surcharge shipping cost are defined for a product, the fixed cost takes precedence.
- Shipping cost defined for a base product is also defined for all variation products of this base product.
- Shipping cost isn't applied to bundled product line items or options line items.
- The value of any bonus products granted from a separate promotion isn’t factored in when calculating shipment qualification or discount. Any shipping costs on a bonus product still apply. The rest of the cart receives the appropriate shipping discount.

> **Note:** If a cart contains only items with fixed, item-level shipping costs, the lowest tier standard shipping cost is also applied to the order. To prevent this, create a "0 to 0.01" order-value tier with a shipping cost of $0.00 for each of your shipping cost tables.

### Product Shipping Costs and Shipping Promotions Example

Shipping costs for all products, without item-level fixed shipping costs:

| Product price range | Shipping costs |
| --- | --- |
| $0.0–$0.1 | $0.00 |
| $0.1–$100 | $5.99 |
| $100 | $9.99 |

Item-level fixed shipping costs, based on product category:

| Category | Shipping costs |
| --- | --- |
| Books, DVDs | $0.99 |
| TV < $1,000 | $24.99 |
| TV > 1,000 | $29.99 |

There are two active shipping promotions.

PROMO1: Buy 1 TV and 5 DVDs and get $5 off shipping.

PROMO2: Spend $250 dollars and get 15% off shipping.

Cart

| Shipment | Item | Qty | Item price | Total price | Shipping cost |
| --- | --- | --- | --- | --- | --- |
| 1 | DVD | 5 | $5.00 | $25.00 | $4.95 |
|  | Book | 2 | $10.00 | $20.00 | $1.98 |
|  | TV | 1 | $1100.00 | $1100.00 | $29.99 |
|  | Shipment subtotal |  |  |  | $36.92 |
|  | PROMO1 |  |  |  | - $5.00 |
|  | PROMO2 |  |  |  | - $4.79 |
|  | Shipment total |  |  |  | $27.13 |
| 2 | Book | 5 | $10.00 | $50.00 | $4.95 |
|  | Headphones | 1 | $99.99 | $99.99 | $5.99 |
|  | Wireless mouse | 2 | $75.00 | $150.00 | $5.99 |
|  | Shipment subtotal |  |  |  | $16.93 |
|  | PROMO2 |  |  |  | - $5.00 |
|  | Shipment total |  |  |  | $11.93 |
| Merchandise total |  |  |  | $1444.99 |  |
| Shipping cost total |  |  |  | $39.06 |  |
| Total |  |  |  | $1484.05 |  |
