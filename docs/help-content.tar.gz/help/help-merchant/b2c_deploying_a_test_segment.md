# Deploy an Effective A/B Test Experience in B2C Commerce

_When you’ve identified a slot configuration, promotion, or sorting rule that produces the results you want, deploy the experience directly to your application using a campaign._

Deploy the experience on a staging instance, not on production. Then replicate the change to production.

1. Click App Launcher _(image: App Launcher)_, and then select **Merchant Tools > Site > Online Marketing > A/B Tests**.
2. On the A/B testing list page, click the actions icon to the left of a test, and then select **View Test Results** from the menu.
3. Alternatively, double-click an A/B test, and then click **Test Results**.
4. On the A/B test details page, click the **Test Results** button.
5. On the A/B test Results page, identify the test segment that produces the best results.
6. Click the **Deploy** icon (on the bottom of the page).
7. Deploy the test segment using either a new campaign or an existing campaign.

   - New Campaign
   - Existing Campaign
8. Click **New Campaign**.

   1. On the A/B test Group Deployment window, configure the following:
   
      - ID
      - Enabled (Yes, No)
      - Description
      - Schedule
      - Customer Groups
      - Source Codes
      - Coupons
   2. Click **Apply**.
9. Click **Existing Campaigns**.

   1. On the A/B test Group Deployment window, click **Edit** beside Select Campaigns.
   2. On the Assign Campaigns window, select the campaigns.
   3. Click **Apply**.
   4. On the A/B test Group Deployment window, where the selected campaigns now appear, click **Apply**.
