# Specify General Settings for B2C Commerce Coupons

_Configure coupon descriptions, status, and redemption limits on the General tab._

> **Note:** After the system generates the coupons, you can't change the coupon ID, case sensitivity, or coupon type.

1. For the relevant site, click App Launcher _(image: App Launcher)_, and then select **Online Marketing > Coupons**.
2. On the Coupons page, click a coupon ID.

   The Edit Coupon page opens.
3. On the **General** tab, add a description.
4. Enable the coupon.
5. Specify redemption limits.

   - Redemption per Coupon Code—the number of total times a shopper can redeem a coupon code. For for single-code coupons, enter a number large enough for your coupon code. For single-code coupons, enter a number large enough for your business requirements. For multiple code coupons, enter one.
   - Redemption per Customer—the number of times a single shopper can redeem this coupon.
   - Redemption per Time Period—the number of times a shopper can redeem a coupon within a given time period. The time period is in days and is a rolling window. For example, if the limit is one time per week, a shopper can use the coupon on the 16th and the 23rd of the month.
   - > **Note:** The lower of the per-customer limit relative to the per-time period takes precedence. For example, a customer can redeem a coupon up to 10 times total, up to two times per week. So, the shopper can use the coupon over five weeks.
   - Redemption per order—the number of coupons redeemed per order.
      
      - One time per order: Shoppers can add only a single code for a specific coupon to a basket.
      - Multiple per Order: Shoppers can add a coupon to a basket multiple times, one time for each distinct coupon code. See [Redeem Multiple Coupons in the Same B2C Commerce Order](https://help.salesforce.com/s/articleView?id=cc.b2c_multiple_coupons_in_a_basket.htm).
6. Save your changes.
