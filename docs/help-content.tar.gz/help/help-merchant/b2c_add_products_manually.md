# Add Products Manually

_Add products to your main catalog manually. This topic applies to B2C Commerce._

|  |
| --- |
| Available in: **B2C Commerce** |

> **Note:** If you see unavailable fields, you have read-only permission. You can search for products and view product data, but you can't change them. If you have mixed permission to access one module (via different roles), B2C Commerce grants the higher-level access. If you require write access, see your administrator.

1. Click App Launcher _(image: App Launcher)_, and then select **Merchant Tools > *site* > Products and Catalogs > Products**.
2. To initiate the wizard, click **New**.

   If you see unavailable fields, you have read-only permission. See your administrator if you need write access.
3. On the Product page General tab, enter general product information:

   - ID: Don't include commas or periods in your IDs. These characters can cause limitations elsewhere in the product.
   - Catalog: Select from dropdown (Only select the dropdown when you are creating a product.)
   - Tax Class: Select from dropdown
   - Online
   - Searchable
   - Searchable If Unavailable: Use this field to control on a product-level if a product is to appear in the search results when it's unavailable (that is, ATS=0).
   - Name
   - Brand
   - Manufacturer
   - Manufacturer Product ID
   - Description
   - Online/Offline for a specific time period
   - Attributes, such as SEO, Sitemap, presentation and search ranking
4. Click the **Edit Site Specific** button to configure site-specific attributes.
5. On the Options tab, select shared product [Create Product Options.](https://help.salesforce.com/s/articleView?id=cc.b2c_create_product_options.htm&type=5)
6. On the Variations tab, specify a product [variation](https://help.salesforce.com/s/articleView?id=cc.b2c_create_a_variation_product.htm&type=5) consisting of a base product, a set of variable product attributes and associated variation products.
7. On the Pricing tab, assign [pricing](https://help.salesforce.com/s/articleView?id=cc.b2c_pricing_and_price_books.htm&type=5) to the product.
8. On the Inventory tab, manage the settings of a single product [inventory](https://help.salesforce.com/s/articleView?id=cc.b2c_inventory_management.htm&type=5) record.
9. On the Categories tab, assign the product to a [category.](https://help.salesforce.com/s/articleView?id=cc.b2c_assign_products_to_a_category.htm&type=5)
10. On the Links tab, specify [static product links](https://help.salesforce.com/s/articleView?id=cc.b2c_linking_products.htm&type=5) between this and other products.
11. On the Recommendations tab, specify the [products that are associated](https://help.salesforce.com/s/articleView?id=cc.b2c_recommendations.htm&type=5) with this product as one of the following recommendation types:

   - Product Detail Page - Cross-Sell
   - Category Landing Page - Featured Items
   - Other
   
   > **Note:** Your configuration can have different recommendation types other than those listed here. If so, choose a type that is appropriate for your organization.
12. On the Bundles tab, specify products that are [bundled](https://help.salesforce.com/s/articleView?id=cc.b2c_create_product_bundles.htm&type=5) with this product.
13. On the Product Sets tab, view the [product sets](https://help.salesforce.com/s/articleView?id=cc.b2c_create_a_product_set.htm&type=5) of the current product.
14. On the Active Data tab, view [active data](https://help.salesforce.com/s/articleView?id=cc.b2c_active_merchandising.htm&type=5) of the current product.
15. On the Page Meta Tag Rules tab, create and manage [page meta tags](https://help.salesforce.com/s/articleView?id=cc.b2c_page_meta_tags.htm&type=5).
16. Click **Apply** to save your changes.

Watch this video to see how to add a product to the B2C Commerce Catalog.

If you can’t watch the video in full screen, open this link in a new tab: [Add a Product to the B2C Commerce Catalog](https://salesforce.vidyard.com/watch/wVTfpobCCwmXV1JnJvFe8J).
