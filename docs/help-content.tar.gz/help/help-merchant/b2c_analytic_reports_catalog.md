# Historical Reports: Catalog

_The B2C Commerce Business Manager Analytics reports are retired. As of January 1, 2021, the reports are no longer populated._

To access current data with advanced analytics and reporting capabilities, use the [Reports & Dashboards](https://help.salesforce.com/s/articleView?id=cc.b2c_reports_and_dashboards.htm&type=5).

This report includes data on the top products ordered by quantity and by revenue.

### Ordered Products Report

The Ordered Products report provides you with an overview of the number of products sold, total quantity sold, and the total revenue of products sold. In addition to these total numbers, the report provides a detailed view of the top products sold by quantity and revenue. From a business perspective, this report gives you a list of revenue drivers for your store.

Summary by Quantity

The list of products sold by quantity is a record of the top products sold. The record provides information on the product name, SKU, quantity, percent of total quantity sold, and the average price of the product over the selected time period. This view shows:

- Product (names)
- SKU
- Manufacturer
- Average Price (of the product over the selected time period)
- Quantity
- Percentage (of the total revenue sold)

Summary by Revenue

The list of products sold by revenue shows you the top products sold, and the following:

- Product (names)
- SKU
- Manufacturer
- Revenue
- Quantity
- Average Price (of the product over the selected time period)
- Percentage (of the total revenue sold)
