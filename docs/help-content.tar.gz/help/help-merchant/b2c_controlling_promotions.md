# Controlling Promotions in B2C Commerce

_In Salesforce B2C Commerce, control how promotions apply._
