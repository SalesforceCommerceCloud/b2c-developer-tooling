# Controlling Promotions in B2C Commerce

_In Salesforce B2C Commerce, control how promotions apply._

## Related Content

- [Configure Promotion Preferences for B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_configuring_promotion_preferences.htm&type=5)
  Configure many of the promotion settings as site preferences, giving you much flexibility in how your promotions are handled. These settings include Buy X/Get Y promotion behavior, discount precision, and how the tax basis is calculated for line items with discounts.

- [Assign a Price Book or Promotion to a Specific Store in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_assigning_a_pricebook_or_promotion_specific.htm&type=5)
  With Store-Specific Pricing and Promotions, select a price book for each of your stores, up to 2,000. The assignments framework lets merchants and developers set qualifiers, such as a store that activates certain experiences, such as a promotion. You can also assign a promotion to a specific store. This feature is only supported via XML import. To use a site assignment, a developer must first edit the assignments XML to include a store assignment. Currently only stores can be listed as assignments.

- [Promotion Schedules in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_schedules.htm&type=5)
  Schedule campaigns, A/B tests, promotions, and content slots in B2C Commerce. A scheduled experience (promotion or content slot) has to coincide with a container (campaign or A/B test), or it can't run.

- [Tiered Discounts in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_tiered_discounts.htm&type=5)
  Tier discounts so that the discount amount increases as the shopper buys more products or spends more money. Configure tiered discounts in a promotion with multiple threshold levels for conditional parameters, where the discount varies by threshold and can't be combined.

- [B2C Commerce Promotion Compatibility](https://help.salesforce.com/s/articleView?id=cc.b2c_promotion_compatibility.htm&type=5)
  Use compatibility rules to control the application of promotions. Compatibility rules prevent a shopper from qualifying for every possible promotion. Use the rank and exclusivity system attributes to control your promotion compatibility.

- [Maximum Application for B2C Commerce Promotions](https://help.salesforce.com/s/articleView?id=cc.b2c_maximum_application_for_promotions.htm&type=5)
  Limit how many times a promotion can apply per order using the maximum application limit.

- [Specify Who Qualifies for an Experience in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_add_a_qualifier_to_an_experience.htm&type=5)
  Specify who qualifies for an experience and how the promotion is redeemed using qualifiers. A qualifier can be a customer group, a coupon, or a source code. Add a qualifier to a promotion in two ways: assign the qualifier to a campaign, which affects all included promotions, or assign the qualifier to a specific promotion.

- [Globally Excluded Products](https://help.salesforce.com/s/articleView?id=cc.b2c_globally_excluded_products.htm&type=5)
  Globally exclude products from all promotions, without configuring excluded products for every promotion. To qualify globally excluded products for a specific promotion, set the Disable Global Excluded Product flag. Global exclusions are enabled by default for new promotions.

- [Qualifying and Discounted Products in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_qualifying_and_discounted_products.htm&type=5)
  Define promotions that specify qualifying products, the products shoppers buy and how much to be eligible for a discount. Also specify which products are discounted.

- [Promotion Restrictions to Identical Products](https://help.salesforce.com/s/articleView?id=cc.b2c_restricting_promotions_to_identical_products.htm&type=5)
  The restrictions setting limits product selection to identical products. When you set restrictions for a product promotion rule, you configure a single product promotion that can apply to multiple products.

- [Qualify or Disqualify Promotions Based on Active Price Book](https://help.salesforce.com/s/articleView?id=cc.b2c_qualify_disqualify_promotions_based_on_active_price_book.htm&type=5)
  Include or exclude products from promotions using the price book condition.
