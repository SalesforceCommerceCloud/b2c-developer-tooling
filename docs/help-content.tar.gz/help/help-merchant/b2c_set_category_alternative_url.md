# Set a Category Alternative URL for B2C Commerce

_The Alternate URL category attribute is a 200 internal link that you use to redirect shoppers to categories throughout your site. Merchandise a category one time, and use the category alternative URL attribute with other categories to redirect shoppers to the merchandised category from anywhere on your site. This topic applies to B2C Commerce._

|  |
| --- |
| Available in: **B2C Commerce** |

For example, you create and merchandise a Women's Dresses category, and create but don't merchandise a What's Trending > Women's Dresses category. Using the alternate URL attribute, you redirect shoppers from What's Trending > Women's Dresses category to the already merchandised Women's Dresses category. An alternative URL redirect differs from a typical redirect in that the hover-over display shows the redirect URL. A typical redirect shows the category URL, and it redirects after the click.

You set up a category alternative URL attribute in the Category Alternative Attributes tab.

1. Click App Launcher _(image: App Launcher)_, and then select **Merchant Tools****Site****Products and Catalogs****Catalog**.
2. Select the catalog you want to edit.
3. Locate the category that you want to set an alternative URL attribute for and click **Edit**.
4. Select the **Category Attributes** tab.
5. Scroll to the Alternative URL attribute setting.
6. Set the redirect URL.

   Sample Alternative URL: `$url(‘Search-Show’,’cgid’,’womens-Dresses’)$`
7. Click **Apply**.
