# Generate an API Client ID for Tableau Connector

_To access the Tableau connector, set up an API Client ID in B2C Commerce._

[Which Salesforce Commerce Product Do I Have?](https://help.salesforce.com/s/articleView?id=commerce.comm_what_product.htm)

1. Log in to Account Manager.
2. Click **API Client**.

   The API Clients page lists the ID, display name, and state for each client.
3. Click **Add API Client**.
4. Complete the API Client information.

   1. In the Display Name field, enter the client display name.
   2. Optionally, enter a description for the API client.
   3. Enter a secure password.
   4. In the Confirm Password field, reenter the password.
   5. Under Organizations, select your organization.
   6. Under Roles, select **Salesforce Commerce API** and add your production instance as a filter.
   
      > **Note:** Data extraction is allowed only for production instances.
   7. Under OpenID Connect, in the Default Scopes field, enter the `tenantFilter` (1) and `roles` (2) literal strings on separate lines. The `tenantFilter` and `roles` entries are necessary when using the Authorization Code Flow or OpenID Connect. The Default Scopes field defines the baseline permissions that are granted if the client app makes an authorization request without explicitly specifying any scopes. For more information, see [../permissions/b2c_roles_and_permissions.xml](https://help.salesforce.com/s/articleView?id=cc.b2c_roles_and_permissions.htm&type=5).
   
      _(image: Default Scopes)_
   8. From Token Endpoint Auth Method, select **client_secret_post**.
   9. Click **Save**.
   
      The new API Client appears in the API client list for your organization.
5. To view the API Client ID, click the API Client.

   To log in to the Tableau Data Connector, use the new Client ID and password.
