# Value Calculation for Active Data

_Base product calculations ignore variations that 's null or stale data when calculating the value of an attribute. Sliced variation calculations ignore sliced variations that 's null or stale data when calculating the value of an attribute. This topic applies to B2C Commmerce._

### Value Calculation for Attributes with Null Values

Product sets ignore products in the set with null or stale data when calculating the value of an attribute. Null data isn't the same as a 0.0 value. If a 0.0 value is provided as current data, it's included in the calculation.

For example, to calculate the cost price for a base product with five variation products, where only four have data, divide the sum of those four variation products by four.

```
Base Product MP-1
Var-1: Cost Price = $40.00
Var-2: Cost Price = $40.00
Var-3: Cost Price = $40.00
Var-4: Cost Price = $0.00 
Var-5:  

Average online variation product for MP-1 =  
sum(CostPrice, varriation product) / count(variation products)
($40.00 + $40.00 $40.00 + $0.00) / 4 = $30.00 
```

### Active Data Attributes

B2C Commerce calculates active data attributes that 's not imported from other available attributes.

There are two exceptions to active data attribute calculations.

- B2C Commerce doesn’t compute values for custom attributes of active data system objects (ProductActiveData) that aren’t assigned to a category. Without the category assignment, the base product active data customer attribute value is set to value = 0.
- The active data custom attribute value for a base product isn’t calculated when its variation products have slicing configured. Including when the base product is assigned to a category. For example:
   
   - The variation product active data custom attribute has a value, but the base product has a value = 0
   - The variation product active data customer attribute has a value but slicing prohibits the value from showing on the storefront.

The following table shows the calculation formulas.

| Sorting Attribute | Type | Standard or Bundle | Main | Product Set | Slicing | Variation Group |
| --- | --- | --- | --- | --- | --- | --- |
| AvailableDate | Date | Active Data Value (user-provided) | Active Data Value (user-provided) | Active Data Value (user-provided) | Active Data Value from Main  (user-provided) | Active Data Value (user-provided) |
| AvgGrossMarginPercent | Double | AvgGrossMarginValue / AvgSalesPrice * 100.0 | AvgGrossMarginValue / AvgSalesPrice * 100.0 | AvgGrossMarginValue / AvgSalesPrice * 100.0 | Value from Main | AvgGrossMarginValue / AvgSalesPrice * 100.0 |
| AvgGrossMarginValue | Double | AvgSalesPrice - CostPrice | AvgSalesPrice - CostPrice | AvgSalesPrice - CostPrice | Value from Main | AvgSalesPrice - CostPrice |
| AvgSalesPrice | Double | Revenue / Units | Average online variation products sum(Revenue, variation products) / sum(Units, variation products) | sum(AvgSalesPrice, set_products) | Average all variation products in slicing group  sum(Revenue, variation products) / sum(Units, variation products) | Average online variation products sum(Revenue, variation products) / sum(Units, variation products) |
| Conversion | Double | Orders(product) / Visits(site) | Average online variations sum(Orders, variations) / (sum(Views, variations) + view(base product) (This is the same as LookToBookRatio.) | Average online set products sum(Conversion*Units, set_products) / sum (Units, set_products) | Average online variation products in slicing group  sum(Conversion*Units, variation products) / sum (Units, variation products) | Average online variation products sum(Orders, variation products) / (sum(Views, variation products) + view(variation group)) (This is the same as LookToBookRatio.) |
| CostPrice | Double | Active Data Value (user-provided) | Average online variation products sum(CostPrice, variation products) / count(variation products) | Sum of online set products sum(CostPrice, set_products) | Average online variation products in slicing group sum(CostPrice, variation products) / count(variation products) | Average online variation products sum(CostPrice, variation products) / count(variation products) |
| CreationDate | Date | System data | System data | System data | System data from Main | System data |
| DaysAvailable | Double | (CurrentDate - AvailableDate) / 24 h  or  (Current - CreationDate) / 24 h If there’s no availableDate set, creationDate is used instead. | sum(DaysAvailable, variations + base product)/count(variations + base product) | CurrentDate - (AvailableDate) / 24 h or Current - (CreationDate)/24h | Value from Main | sum(DaysAvailable, variations + variation group)/count(variations + variation group) |
| Impressions | Integer | Impressions(product/bundle) | Sum online variations + base product value sum(Impressions, variations) + Impressions(base product) | Impressions(product set) | Sum online variations in slicing group + base product value sum(Impressions, variations) + Impressions(base product) | Sum online variation products in variation group+ variation group value sum(Impressions, variation products) + Impressions(variation group) |
| LastModified | Date | Product Value | Product Value | Product Value | Value from Main | Product Value |
| LookToBookRatio | Double | Min(100, 100 * Orders/Views)  0 if Orders == 0  100 if Views == 0 | Average online variations sum(Orders, variation products) / (sum(Views, variation products) + view(base product)) | Sum of online set products sum(LookToBookRatio*Units, set_products) / sum (Units, set_products) | Average online variation products in slicing group sum(LookToBookRatio, variation products) / count(variation products) | Average online variation products sum(Orders, variation products) / (sum(Views, variation products) + view(variation group)) |
| Orders | Integer | Orders(product/bundle) | Sum all variation products sum(Orders, variation products) | Sum of online set products sum(Orders, set_products) | Sum all variation products in slicing group  sum(Orders, variation products) | Sum all variation products in variation group sum(Orders, variation products) |
| ReturnRate | Double | Active Data Value (user-provided) | Average all variation products sum(ReturnRate * UnitsYear, variation product) / sum(UnitsYear, variation products) | Average all set products sum(ReturnRate * UnitsYear, set_products) / sum(UnitsYear, set_products) | Average all variation products in slicing group  sum(ReturnRate * UnitsYear, variation product) / sum(UnitsYear, variation products) | Average all variation products in variation group sum(ReturnRate * UnitsYear, variation product) / sum(UnitsYear, variation products) |
| Revenue | Double | Revenue(product/bundle) | Sum all variation products  sum(Revenue, variation products) | Sum of online set products sum(Revenue, set_products) | Sum all variation products in slicing group  sum(Revenue, variation products) | Sum all variation products in variation group sum(Revenue, variation products) |
| SalesVelocity | Double | Units / (24.0 * min(1.0, DaysAvailable)) FeedImportDate + 24 h - AvailabilityDate or CreationDate | Sum online variation products  sum(SalesVelocity, variation products) | Maximum online set products max(SalesVelocity, set_products) | Sum online variation products in slicing group Sum(SalesVelocity, variation products) | Sum online variation products in variation group Sum(SalesVelocity, variation products) |
| Units | Double | Units(product/bundle) | Sum all variations Sum(Units, variation products) | Sum of online set products  Sum(Units, set_products) | Sum all variation products in slicing group Sum(Units, variation products) | Sum all variations in variation group Sum(Units, variations) |
| Views | Integer | Views(product/bundle) | Sum all variations + base product value  Sum(views, variations) + views(base product) | views(product set) | Sum all variations in slicing group + base product value sum(views, variations) + views(main prodcut) | Sum all variation products + variation group value sum(views, variations) + views(variation group) |

### Sorting Attributes

The following attributes are used in sorting rules. This table describes how they’re calculated for different product types.

| Sorting Attribute | Documentation | Product | Bundle | Main | Product Set | Slicing | Variation Group |
| --- | --- | --- | --- | --- | --- | --- | --- |
| String Attribute like name, description | Locale specific sorting of the string value. The locale of the index is used.  Null values are always last. | Product Value | Product Value (Bundle) | Value of the base product if it's defined.  Fall back to variations represented by search hit. | Value of the product set if it's defined. Fall back to set products represented by search hit. | Value of the base product if it's defined.  Fall back to variations at the group represented by search hit. | Value of the variation group if it's defined. Fall back to variations represented by search hit. |
| Date attributes | Sorting of date values. Null values are always last. | Product Value | Product Value (Bundle) | Value of the base product if it's defined.  Fall back to variations represented by search hit. | Value of the product set if it's defined.  Fall back to set products represented by search hit. | Value of the base product if it's defined.  Fall back to variations at the group represented by search hit. | Value of the variation group if it's defined. Fall back to variations represented by search hit. |
| Numeric attributes | Sorting of numeric values. Null values are always last. | Product Value | Product Value (Bundle) | Value of the base product if it's defined.  Fall back to variations represented by search hit. | Value of the product set if it's defined.  Fall back to set products represented by search hit. | Value of the base product if it's defined. Fall back to variations at the group represented by search hit. | Value of the variation group if it's defined. Fall back to variations represented by search hit. |
| Category-specific attributes (search rank and search placement) | Value of product in currently selected refinement category.  Null values are always last. | Product Value | Product Value (Bundle) | Value of the base product if it's defined.  Fall back to variations represented by search hit. | Value of the product set if it's defined.  Fall back to set products represented by search hit. | Value of the base product if it's defined.  Fall back to variations at the group represented by search hit. | Value of the variation group if it's defined. Fall back to variations represented by search hit. |

### Special Sorting Attributes

These sorting rule attributes are calculated differently than most attributes.

| Sorting Attribute | Documentation | Product | Bundle | Main | ProductSet | Slicing | Variation Group |
| --- | --- | --- | --- | --- | --- | --- | --- |
| Availability Rank | Creates two groups of search hits based on the attribute 'Availability' and a configurable threshold: "high availability" and "low or no availability". A search hit belongs to either the one or the other. Sorting direction is always descending and then group 'high availability' is shown before 'low availability'. | Product Value | Product Value (Bundle) | Highest Availability of all variation products represented by search hit. | Highest Availability of all set products represented by search hit. | Highest Availability of all variation products at the group represented by search hit. | Highest Availability of all variation products represented by search hit. |
| Category Position | Position of product in currently selected refinement category. Always ascending (highest positioned first). | Product Value | Product Value (Bundle) | Product Value (Main) | Product Value (Product Set) | Main Value | Product Value (VariationGroup) |
| Price | The price book price currently active. Either ascending or descending. | Product Value | Product Value (Bundle) | Lowest/highest price of all variation products represented by search hit. | Lowest/highest price of all set products represented by search hit. | Lowest/highest price of all variation products at the group represented by search hit. | Lowest/highest price of all variation products represented by search hit. |
| Text Relevance | The relevance based on search keyword. Always descending (most relevant first). | Product Value | Product Value (Bundle) | Most relevant variation represented by search hit. | Most relevant set product represented by search hit. | Most relevant variation at the group represented by search hit. | Most relevant variation at the group represented by search hit. |

### Product Attributes

This table lists these product attributes, used for active data, by product type.

| Sorting Attribute | Type | Product | Bundle all bundled products online bundled products | Main all variations online variations | Product Set   all set products  online set products | Slicing  all variations of group  online variations of group | Variation Group all variations of group online variations of group |
| --- | --- | --- | --- | --- | --- | --- | --- |
| ATS | BigDecimal | Product Value (Inventory Record) | Product Value (Bundle) if it's defined  Sum ATS of online bundled products (sum(ATS)) | Product Value (Main) if it's defined  Sum ATS of online variations (sum(ATS)) | Product Value (ProductSet) if it's defined   Sum ATS of online set products (sum(ATS)) | Main Value if it's defined  Sum ATS of online variations the group (sum(ATS)) | Product Value (VariationGroup) if it's defined Sum ATS of online bundled products (sum(ATS)) |
| Availability | double | Product Value (Inventory Record) | Product Value (Bundle) if it's defined and UseBundleInventoryOnly  Min Availability of bundle and all bundled products (min(Availability)) | Product Value (Main) if it's defined   Average Availability of online variations (avg(Availability)) | Product Value (ProductSet) if it's defined   Max Availability of online set products (max(Availability)) | Main Value if it's defined  Average Availability of online variations at the group (avg(Availability)) | Product Value (VariationGroup) if it's defined Average Availability of online variations (avg(Availability)) |
| Orderable | boolean | Product Value (Inventory Record) | Product Value (Bundle) if it's defined and UseBundleInventoryOnly true in case all bundled products are orderable (no online check) | Product Value (Main) if it's defined  true in case one variation is orderable, false otherwise (no online check) | Product Value (Product Set) if it's defined  true in case one set product is orderable, false otherwise (no online check) | Main Value if it's defined  true in case one variation at the group is orderable, false otherwise (no online check) | Product Value (VariationGroup) if it's defined true in case one variation is orderable, false otherwise (no online check) |
| SKUCoverage | double | Product Value (Inventory Record) | 1 in case all online bundled products are in stock, 0 otherwise | Average SKUCoverage of online variations (avg(SKUCoverage)) | The ratio of orderable SKUs in the product set over the total number of online SKUs in the product set. | 1 in case one of the online variations at the group is in stock, 0 otherwise | Average SKUCoverage of online variations (avg(SKUCoverage)) |
| TTOOS | double | Product Value (Inventory Record) | Product Value (Bundle) if it's defined  Min TTOOS of online bundled products (min(TTOOS)) | Max TTOOS of online variations (max(TTOOS)) | Max TTOOS of online set products (max(TTOOS)) | Max TTOOS of online variations at the group (max(TTOOS)) | Max TTOOS of online variations (max(TTOOS)) |

### Value Calculation Example

| Product Data | ​​ | ​ | ​ | Inventory Record | ​ | Active Data | ​ | ​ | Calculated (don’t change) | ​ | ​ | ​ |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| SKU | Color | Size | Online | Allocation | ATS | Orders | Views | Units | Availability | SKU Coverage | Sales Velocity | TTOS |
| Variation group | Red |  |  |  |  | n/a |  |  | 5 | 1 | 0.96 | 120 |
| 1234A | Red | s | 1 | 2 | 10 | 2 | 250 | 2 | 5 | 1 | 0.08 | 120 |
| 1234B | Red | m | 1 | 2 | 10 | 8 | 0 | 8 | 5 | 1 | 0.33 | 30 |
| 1234C | Red | l | 1 | 2 | 10 | 10 | 0 | 10 | 5 | 1 | 0.42 | 24 |
| 1234D | Red | xl | 1 | 2 | 10 | 3 | 0 | 3 | 5 | 1 | 0.13 | 80 |
