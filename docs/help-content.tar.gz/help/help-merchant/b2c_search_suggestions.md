# Search Suggestions

_When a shopper starts to enter a search term on the storefront, the storefront application shows terms that can help complete the search. Depending on the configuration, search suggestions can range from being a simple list of related terms to being more complex and providing extra details. This topic applies to B2C Commerce._

The ‘Search-As-You-Type’ feature isn’t controlled by a preference.

To enable Search Autocorrections: click App Launcher _(image: App Launcher)_, and then navigate to ** *site*  > Merchant Tools > Search > Search Preferences** and select **Search Autocorrections**.

When enabled, the spelling of the words in the user's search phrase are automatically corrected or completed before the actual search is executed. When disabled, the terms in the user's search phrase aren’t corrected or completed.

Obtain a corrected and completed version of the phrase using the `Did You Mean` option.

Set the minimum number of characters for the suggestion length at, ** *site*  > Merchant Tools > Search > Search Indexes > Language Options**.

### Search Suggestion Types

If the shopper selects a category or subcategory in the top or left pane of the storefront, the returned suggestions, spelling corrections, and completed terms are all specific to selected category or subcategory. Search filtering by category is available for product, brand, and category suggestions. Content and suggest phrases aren’t category-specific.

Your storefront application can suggest the following types of content:

- Additional phrases
- Categories
- Brand names
- Products
- Content

List suggestion types by group and link to specific landing pages. For example, when the shopper clicks a suggested category, the respective category landing page opens. When the shopper clicks a suggested phrase, a text search is performed using that phrase. When the shopper clicks a brand name, the brand landing page opens.

Show category, product, and content suggestions with additional information, such as an images, a product category, or a price.

The shopper's search phrase is matched anywhere in the searchable content. For example, when a shopper enters `shoe` into the search box, a product `red sport shoes` is suggested.

Linguistic search rules such as synonyms and stopwords are also considered when searching for relevant suggestions. Search phrases are automatically corrected and completed, resulting in suggestions that are more relevant.

### B2C Commerce Einstein Search Recommendations

B2C Commerce Einstein can improve searches with personalized type-ahead guidance.  When enabled, this feature provides AI-driven autocorrection and term completion.

For information about Einstein Search Recommendations and how to enable it, see [Commerce Cloud Einstein Search Recommendations](https://help.salesforce.com/s/articleView?id=cc.b2c_einstein_search_recommendations.htm&type=5).

> **Note:** The suggestion term blocklist does not affect Einstein search recommendations, and they aren’t guaranteed to yield results.

### Simple Search Suggestions 

For simple search term suggestions, the search field provides a list of up to 10 terms that help complete the query. The list of provided terms updates with each letter the shopper types into the search field. The search query uses any suggestion the shopper selects.

### Search Suggestions Terms

Search entries and suggestions are case insensitive. That is, entering a search term in either upper or lower case doesn’t affect what search suggestions appear. In addition, search suggestions always appear in lower case to avoid duplicates based on capitalization.

When creating suggestions, keep the following in mind:

- If both singular and plural values are added when creating suggestions, the singular value is treated as a duplicate and only the plural form of the suggestion appears. For example, even if you create `blouses` and `blouse` as search suggestions, only `blouses` appears as a suggestion.
- If the plural form of the word has a different stem, both words appear as suggestions. For example, `scarf` and `scarves`.
- If you add only the singular form of a word as a suggestion, only that form appears as a suggestion.

All characters are retained from category names for search suggestions, including hyphens and ampersands. The full name of categories and brands always appears in the search suggestion.

B2C Commerce automatically includes the following in the Suggest index:

- All brand names for all products in the storefront catalog
- All display names of all categories from the site's storefront catalog

You can also add terms or prevent terms from being suggested using the Search Suggestion feature in Business Manager. For example, add `fringe` as a suggestion for a new line of clothing, or add `Adult Videos` to the blocklist to prevent it from appearing in suggestions.

> **Note:** The suggestion term blocklist affects only suggested terms.

German umlaut and eszett characters (ü, ß) and standard replacement characters (ue, ss) are supported. Search suggestions appear as they’re stored in the product catalog. For example, whether you enter `träger` or `traeger,` you see `trägertops` and `träger-tops` as suggestions for both.

### Hit Count

Beside each search term, the shopper sees a hit count. The hit count indicates the number of products or articles that search has found in the storefront. Suggestions are sorted by hit count.The hit count doesn't consider the availability of the product, so it's possible for customers to click suggestions for products that are currently out of stock.If you take products that are unavailable offline and rebuild the Suggest Index, these hits disappear. You can also customize the no results page to indicate that the selected product is out of stock and suggest alternatives. If you don't want to show the hit count, a developer can alter the Internet Store Markup Language (ISML) template to remove the hit count.

### Search Suggestion Limitations

To help improve performance, the suggestion index includes these term limitations.

- Suggestions that don't provide results aren’t included.
- Query results with more than 50 characters aren’t included.
- When adding a custom search suggestion, the term must appear in indexed catalog data. Providing search suggestions for indexed content data is not currently supported.
- Term completion and auto correction is skipped if the search phrase includes wild-card phrases, negative phrases, or quoted phrases.

### Differences Between Simple and Enhanced Search

This table calls out differences between simple and enhanced search term completion.

| Term Completion Feature | Simple Search | Enhanced Search |
| --- | --- | --- |
| Category, brand, and extra phrase support | _(image: Checkmark)_ | _(image: Checkmark)_ |
| Product and content page support |  | _(image: Checkmark)_ |
| `Search as you type` support for products, content, categories, and brands |  | _(image: Checkmark)_ |
| Match support | Whole phrase matchFor example, suggests `digital camera` when shopper types `digit`, but not when shopper types `camera`. | Independent word matchFor example, suggests `digital camera` when the shopper enters `camera`. |
| Hit count provided Hit counts are precalculated and can be outdated. | _(image: Checkmark)_ |  |
| Autocorrection and autocompletion support For example, both terms of the input text, `digit cam` auto-complete to`digital camera`. |  | _(image: Checkmark)_ |
| All standard features used for storefront search are used for enhanced search suggest, such as compound words, stop words, and sorting rules. |  | _(image: Checkmark)_ |
