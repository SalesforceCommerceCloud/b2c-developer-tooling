# Keyword Searches for B2C Commerce

_Keyword searching is how most customers use your storefront to find the products they’re interested in buying. To create a large and accurate search index, specify the searchable product attributes and configure relationships using search dictionaries. When an item is searched for, B2C Commerce runs through a search process, gathers the results, and applies a sorting rule that defines how to display the respective results._

_(image: Keyword search processing)_
