# Configure a Hostname Alias

_A hostname alias is required to create short, meaningful URLs for external search engines to index. Assign at least one hostname alias that is the current hostname on which the instance is running._

|  |
| --- |
| Available in: **B2C Commerce** |

You can also create a simpler alias that reflects your store or brand name. Putting a simple Page URL in the alias list, such as "www.mystore.com", enables users to get to the storefront without typing in the full Salesforce B2C Commerce URL, such as:

`http://www.mystore.com/on/demandware.store/Sites-MYS-Site/default`.

Ideally, the long URL is only visible to search engines if someone posts a link containing the long URL.

> **Important:** If you don't assign an alias to your site, enabling search-friendly URLs causes the storefront to show a 404 error for all URLs besides the Welcome page.

1. Click App Launcher _(image: App Launcher)_, and then select **Merchant Tools > Site > SEO & Discoverability > Aliases**.
2. On the Aliases page, create a set of hostname alias rules.
3. To test that your rules are valid JSON, we recommend that you test them against a debugging tool. Remember to remove any comments from your mapping files and use colons (:) instead of equal signs (=) to separate property and value.

   Site URL aliases files are instance-specific, so site URL aliases are individually managed for each instance (Development, Staging, and Production). Because each instance has its own aliases file, these files are not included in data replication. This makes sure that a data replication of `Site URL Management` doesn't overwrite URL alias settings on Production with the Staging configuration.
   
   Individually edit the site URL aliases on each instance (Development, Staging, Production) to have the same aliases on all instances.
4. When you are satisfied that your alias file is valid, copy it into the editor and click **Apply**.
