# Use Explicit Sorting

_Consider creating a custom sort for a specific page or section of a page._

|  |
| --- |
| Available in: **B2C Commerce** |

> **Note:** Explicit Sort for *Product Index* is deprecated. Use the Sorting Rule framework for Product Search and Sorting only.

For example, if you have a custom table or grid and you want to enable sorting on any column of the grid, you might want to simply call the Search pipelet to sort the items. If this is the case, create a custom pipeline to do the sorting and configure the default sorting configuration to let you use explicit sortings.

To use explicit sorting:

1. Click App Launcher _(image: App Launcher)_, and then select **Search  > Searchable Attributes.**

   Unlike other sorting attributes, which are automatically indexed, but are separate from searchable attributes, sorting attributes passed by pipelines for explicit sorting aren’t automatically indexed. For this reason, make sure any attribute used to sort by in your explicit sorting is included in the searchable attributes for your storefront.
   
   > **Note:** Because sorting and searchable attributes don't use the same data types, the attributes used for explicit sorting are restricted to the ones common to searchable attributes and sorting attributes. This means, for example, that you can't sort by Date +Time. You can't use dynamic attributes in explicit sorting.
2. Check the attribute in the Product Index Attributes list to sort products, or the Content Index Attributes list to sort content items. If the attribute isn't in either list, click **New** to add it to the appropriate list.
3. In **Products and Catalogs > Catalogs**, find the name of the default sorting rule for the storefront catalog and for the category that includes the page where you want to perform the explicit sorting.
4. In **Search > Sorting Rules,** select each of these rules and make sure that they include the `Explicit Sortings (sorting.explicit-sortings)` attribute. This can be the last attribute used for the sorting rule, so that it's only used if no other sorting rule applies.

   > **Caution:** Include the Explicit Sortings attribute in the sorting rule.
5. To sort a search result by a defined sorting attribute, pass the attribute ID of the sorting attribute into the Search pipelet. This is a developer task.

   Specify that results are returned using a specific sorting rule, using the urlSort method for the SearchModel, ContentSearchModel, or ProductSearchModel class, depending on the type of search. You can also specify that results are returned without a sorting option, using the urlDefaultSort method. If you specify a specific sorting rule, such as Price or Product name (A-Z), this takes priority and no further sorting rules apply.
   
   > **Note:** Implementing this feature requires application changes.
