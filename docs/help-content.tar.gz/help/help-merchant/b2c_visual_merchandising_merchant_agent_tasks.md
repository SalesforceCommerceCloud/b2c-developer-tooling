# Complete Visual Merchandising Tasks with the B2C Merchant Agent

_Create boost or bury rules, sort categories, and add products to categories using natural language prompts. Describe the desired outcome and the agent creates the rule._

The Merchant Agent is available from the Visual Merchandising workspace.

## Related Content

- [Create Boost and Bury Rules with the B2C Merchant Agent](https://help.salesforce.com/s/articleView?id=cc.b2c_create_boost_bury_merchant_agent.htm&type=5)
  Use the Merchant Agent to create boost and bury rules with natural language prompts.

- [Create a Sort Rule with the B2C Merchant Agent](https://help.salesforce.com/s/articleView?id=cc.b2c_create_sort_rule_merchant_agent.htm&type=5)
  Use the Merchant Agent to create sorting rules based on sequential data attributes such as price or conversion rate to control how search results are displayed to customers.

- [Add Products to a Category with the B2C Merchant Agent](https://help.salesforce.com/s/articleView?id=cc.b2c_add_products_category_merchant_agent.htm&type=5)
  Use the Merchant Agent to add new products to a category all at once, making product categorization more efficient.
