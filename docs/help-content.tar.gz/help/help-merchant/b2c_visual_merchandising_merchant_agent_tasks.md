# Complete Visual Merchandising Tasks with the B2C Merchant Agent

_Create boost or bury rules, sort categories, and add products to categories using natural language prompts. Describe the desired outcome and the agent creates the rule._

The Merchant Agent is available from the Visual Merchandising workspace.
