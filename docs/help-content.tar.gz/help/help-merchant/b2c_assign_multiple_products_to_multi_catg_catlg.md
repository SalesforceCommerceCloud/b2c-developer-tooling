# Assign Multiple Products to Multiple Catalogs and Multiple Categories

_Assign products to categories in multiple catalogs, in a single step. This topic applies to B2C Commerce._

|  |
| --- |
| Available in: **B2C Commerce** |

1. Click App Launcher _(image: App Launcher)_, and then select **Merchandiser Tools > *site* > Products and Catalogs > Products**.
2. Search for and select the products you want to assign.

   Assigning a base product or variation group to a category assigns all variation products to that category. You can also assign a single variation product to a category without assigning the base product.
3. Click **Assign**.
4. In the dropdown list, select the catalog you want to add the products to.
5. In the category tree, select the categories you want to assign the products to.

   Review the listed catalog and category product assignments before confirming your changes.
6. When you’re finished assigning products, click **Next**.
7. Review and confirm your catalog, and category selections.

   Click **Previous** to make changes.
   
   Click **Cancel** to stop the process.
8. For each catalog, assign a primary category to the newly assigned products. Assigning a primary category replaces any previously set primary category for the products. To leave the primary category as is, select **None**.
9. Assign a classification category to the assigned products.

   Only one classification category can be assigned. To leave the classification category as is, select **None**.
   
   B2C Commerce assigns the first classification or category in the dropdown to products without a previously assigned classification category or primary category.
10. Click **Finish: Go to Batch Process** or **Finish: Go to Products**. Both selections start the batch process, and finalize the new assignments.
