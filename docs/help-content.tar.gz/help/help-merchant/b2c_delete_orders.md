# Delete Orders

_You can delete an order that has an order status of Created, Canceled, Replaced, or Failed, or that has an export status of Exported, and that has no associated replacement order. Deleting an order doesn't delete the data stored in Salesforce Order Management or in any external order management system. This topic applies to B2C Commerce._

|  |
| --- |
| Available in: **B2C Commerce** |

Deleting an order is useful when removing a customer's personally identifiable information.

To remove personal data, create a Business Manager extension that anonymizes attribute values.

1. Click App Launcher _(image: App Launcher)_, and then select **Merchant Tools > Site**** Ordering  >  Orders.**.
2. Locate the order you want to delete.

   - Use the search function.
   - To view a list of all orders, click **Find**.
3. Select the order.
4. Select the checkboxes of the orders you want to delete. You can also delete an order on its details page. If no orders are available to delete, the delete button does not appear.
5. Click **Delete**.

   B2C Commerce logs deleted order status and value changes sent for billing in the Order Journal table. This journal is anonymous and contains no personal data. To extract this order information, create an Order Journal.
