# Get Started with Agentic Commerce Search for B2C Commerce

_Agentic Commerce Search for B2C Commerce requires confirmed prerequisites and a multi-day provisioning period before it goes live on your storefront._

Complete the prerequisites before you turn on the service. After provisioning finishes, configure sort options, filters, and merchandising rules.
