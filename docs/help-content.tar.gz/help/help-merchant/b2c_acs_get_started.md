# Get Started with Agentic Commerce Search for B2C Commerce

_Agentic Commerce Search for B2C Commerce requires confirmed prerequisites and a multi-day provisioning period before it goes live on your storefront._

Complete the prerequisites before you turn on the service. After provisioning finishes, configure sort options, filters, and merchandising rules.

## Related Content

- [Prerequisites for Agentic Commerce Search](https://help.salesforce.com/s/articleView?id=cc.b2c_acs_prerequisites.htm&type=5)
  Confirm that your catalog data, event instrumentation, pricing, and inventory meet requirements for Agentic Commerce Search for B2C Commerce before provisioning. Incomplete or missing data reduces search relevance and keeps pricing sort options from working correctly.

- [Set Up Agentic Commerce Search](https://help.salesforce.com/s/articleView?id=cc.b2c_acs_enable.htm&type=5)
  When you turn on Agentic Commerce Search for B2C Commerce, provisioning starts automatically and takes approximately two to three days. After provisioning completes, configure search settings, rules, and sorting options from Merchant Tools in Business Manager.

- [Turn Off Agentic Commerce Search](https://help.salesforce.com/s/articleView?id=cc.b2c_acs_disable.htm&type=5)
  Your storefront reverts to native keyword search when you turn off Agentic Commerce Search for B2C Commerce. Your merchandising rules and configuration remain available if you turn it on again.
