# Create a Shared Library in B2C Commerce

_Create and delete libraries or change the assignment of libraries only on staging and sandbox instances._

|  |
| --- |
| Available in: **B2C Commerce** |

You must have the appropriate permission to create and delete shared libraries. See Content Libraries, the *Permissions* section. This functionality isn’t available on development or production instances. If you change libraries on staging instances, you can transfer the changes to development or production instances using data replication.

1. Click App Launcher _(image: App Launcher)_, and then select **Administration > Sites > Content Libraries**.

   If you see unavailable fields, you have read-only permission. You can browse libraries, search for content assets, and read content asset data. But you can't modify data in these modules. If you have mixed permission to access one module (via different roles), the higher-level access is granted. See your administrator if you require write access.
   
   Libraries, library folders, and content assets are organized in a hierarchy. The hierarchy prescribes that roles with Read or Write access for libraries, library folders, and content assets require the same access level.
2. On the Libraries page, click **New** or a library **Edit** link.
3. On the Library page General tab, enter or edit the information and click **Apply**.

   Don’t use the same ID for a shared library and a site. Doing so can cause unexpected errors.

When the Library page General tab reappears showing the Site Assignments section, you can now assign a site to your library.
