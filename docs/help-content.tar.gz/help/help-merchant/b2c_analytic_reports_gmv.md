# GMV

_This topic applies to B2C Commerce GMV is reportable in US dollars and is defined as the total dollar value of all transactions for goods and services in a calendar month generated through Salesforce B2C Commerce, after application of all applicable shopping cart discounts and promotions identified by the customer as part of the transaction. GMV includes all transactions regardless of order and shipping status. Shipping and handling charges and taxes, when identified by the customer as part of the transaction within the B2C Commerce, are excluded from GMV._

> **Note:** See Taxation Impact On Subscription Fees to understand how tax calculations can significantly impact the B2C Commerce subscription fees that you pay.

> **Note:** See Example GMV Calculation if you need basic instructions on how to recalculate a B2C Commerce invoice.

Some of the considerations taken into computing a bill based on GMV include:

| Concept | Description |
| --- | --- |
| Request | An HTTP request to B2C Commerce from an external system. |
| Order total | The total value of the order at order placement. If the order is changed in any way on the back end, B2C Commerce order analytics aren’t affected. |
| Visit start time | The time the visit begins. |
| Time Zones | The data provided in this report is calculated at a 0 timezone offset (Greenwich Mean Time (GMT)) because that is the standard offset B2C Commerce uses for all billing, regardless of customer, to ensure consistency. Thus, select start dates, but not start or end times. |
| Sales total | The amount of sales your site processes on a monthly basis. |
| Minimum | The minimum billing due. |
| Order origination | Assign values during basket creation that specify an order's creation source, such as its business type or channel.  Developer documentation and reference materials are available in English only. Refer to the English-language Infocenter to access this information. |

### GMV Reports

Business Manager provides four types of GMV reports in .csv format, which can be easily extracted to a spreadsheet for further sorting:

- Order journal
- GMV report per month
- GMV report per day
- GMV per order

See Running a GMV Report.

The following tables list the fields that appear in each report.

Order Journal Report

| Field | Description |
| --- | --- |
| POSITION | Orders the line items as steps within the transaction. |
| ACTION | The action represented by the transaction. CREATE is the most common action. |
| SOURCE | Where the action originated from. STOREFRONT is the most common source. |
| TIMESTAMP | The time of the transaction. |
| ORGANIZATIONID | The B2C Commerce organization ID, typically SITES. |
| SITEID | The Site ID, typically the name of the site, for example, *customers.* |
| ORDERID | The order ID. All line items in a transaction have the same order ID. |
| ITEMTYPE | The type of transaction for the line item. For example, PRODUCT (for a product line item), SHIPPING (for a shipping charge or adjustment), or ADJUSTMENT (for a discount). |
| ITEMID | The item ID, which is assigned (for example, 7.27474E+11) or STANDARD_SHIPPING, PRODUCT - PERCENTAGE, ORDER - AMOUNT, SHIPPING - FREE. |
| DESCRIPTION | Line item description. This can be a product (for example, Morris, Kacey or Banquo), a discount (for example, FALL4SLE, FSNOTHRE or FREESHP), or a shipping charge (for example, STANDARD_SHIPPING). |
| LINEITEMCOMMENT | Comments about a line item. For example, "final sale". |
| CURRENCY | Site currency, for example USD. |
| BEFOREQUANTITY | Quantity before the transaction. |
| BEFOREUNITPRICE | Unit price before the transaction. |
| BEFORETOTALPRICE | Total price before the transaction. |
| BEFORETAX | Tax before the transaction. |
| AFTERQUANTITY | Quantity after the transaction. |
| AFTERUNITPRICE | Unit price after the transaction. |
| AFTERTOTALPRICE | Total price after the transaction. |
| BUSINESSTYPE | B2B or B2C   Developer documentation and reference materials are available in English only. Refer to the English-language Infocenter to access this information.  See Order Organization Attributes. |
| CHANNELTYPE | Storefront, Call Center, Data Security Standard (DSS), Marketplace, or Store  Developer documentation and reference materials are available in English only. Refer to the English-language Infocenter to access this information.  See Order Organization Attributes. |
| AFTERTAX | Tax after the transaction. See Managing Site Taxes to learn how to configure taxes in B2C Commerce. |

GMV-Per-Month Report

| Field | Description |
| --- | --- |
| SITEID | The Site ID, typically the name of the site, for example, customers. |
| CURRENCY | Site currency, for example USD. |
| MONTH | The reported month. |
| SOURCE | Where the action originated from. STOREFRONT is the most common source. Another example is CALL CENTER. |
| ACTION | The action represented by the transaction. CREATE is the most common action. |
| TRANSACTIONS | The transactions included in the action. |
| ITEMTYPE | The type of transaction for the line item. For example, PRODUCT (for a product line item), SHIPPING (for a shipping charge or adjustment) or ADJUSTMENT (for a discount). |
| ITEMQTY | The number of items in the transaction. |
| TOTAL | Total price of the transaction. |
| TAX | Total tax of the transaction. See Managing Site Taxes to learn how to configure taxes in B2C Commerce. |
| BEFOREITEMQTY | Quantity before the transaction. |
| BEFORETOTAL | Total before the transaction. |
| BEFORETAX | Tax before the transaction. |

GMV-Per-Day Report

The math used for this report is *PRODUCT+ADJUSTMENT of the AFTERTOTALPRICE.* B2C Commerce bills for the *AFTERTOTALPRICE* of all line items except shipping. This report is used as the basis for B2C Commerce billing reports.

| Field | Description |
| --- | --- |
| SITEID | The Site ID, typically the name of the site, for example, *easyspirit.* |
| CURRENCY | Site currency, for example USD. |
| DAY | The reported day. |
| SOURCE | Where the action originated from. STOREFRONT is the most common source. Another example is CALL CENTER. |
| ACTIONS | The action represented by the transaction. CREATE is the most common action. |
| TRANSACTIONS | The transactions included in the action. |
| ITEMTYPE | The type of transaction for the line item. For example, PRODUCT (for a product line item), SHIPPING (for a shipping charge or adjustment) or ADJUSTMENT (for a discount). |
| ITEMQTY | The number of items in the transaction. |
| TOTAL | Total price of the transaction. |
| TAX | Total tax of the transaction. See Managing Site Taxes to learn how to configure taxes in B2C Commerce. |
| BEFOREITEMQTY | Quantity before the transaction. |
| BEFORETOTAL | Total before the transaction. |
| BEFORETAX | Tax before the transaction. |

GVM-Per-Order Report

| Field | Description |
| --- | --- |
| SITEID | The Site ID, typically the name of the site, for example, *customers.* |
| CURRENCY | Site currency, for example USD. |
| TIME | The time of the reported order. |
| SOURCE | Where the action originated from. STOREFRONT is the most common source. Another example is CALL CENTER. |
| ACTION | The action represented by the transaction. CREATE is the most common action. |
| ORDERID | The ID of the order. |
| ITEMTYPE | The type of transaction for the line item. For example, PRODUCT (for a product line item), SHIPPING (for a shipping charge or adjustment) or ADJUSTMENT (for a discount). |
| ITEMQTY | The number of items in the transaction. |
| TOTAL | Total price of the transaction. |
| TAX | Total tax of the transaction. See Managing Site Taxes to learn how to configure taxes in B2C Commerce. |
| BEFOREITEMQTY | Quantity before the transaction. |
| BEFORETOTAL | Total before the transaction. |
| BEFORETAX | Tax before the transaction. |

If a column is empty, it means that the information wasn’t available.

### Frequently Asked Questions

Q: Are order modifications taken into account after order placement?

A: No. B2C Commerce Analytics doesn't take into account any modifications made after order placement. All changes made to the order total on the back end have no effect on the order total used in calculating billing.

Q: Does GMV include orders not yet shipped?

A: Yes. GMV includes all orders placed during the billing period, regardless of order and shipping status.

Q: Are back-ordered items included in GMV billing?

A: Yes. GMV includes all sales transactions regardless of order and shipping status. As soon as the customer places the order, it appears in the billing analytics, regardless of whether any product has actually shipped to the customer.
