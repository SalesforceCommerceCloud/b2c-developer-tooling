# Aggregations Made with Fully Additive and Semi-Additive Measures

_This topic applies to B2C Commerce and Tableau. Most B2C Commerce measures are fully additive. To create reliable data views in Tableau, use both fully additive and semi-additive measures._

Fully additive measures are summable with any dimension in the dataset and are always the same. They can be further aggregated on a subset of dimensions.

Semi-additive measures are summable with some dimensions, but the inclusion of some dimensions can result in unexpected sums that can skew your data analysis.

In Tableau, only aggregate semi-additive B2C Commerce measures with certain dimensions.

### How Measures Affect Your Metrics

This scenario shows how fully additive and semi-additive measures affect your metrics. Using the tools in Tableau, we imported a simplified version of the productOrderItems subject area.

The productOrderItems subject area allows export of the orderPlacedDate and productId dimensions and the ordersPlaced, unitsSold, and GMV measures. To have all the data available to build a dashboard, we import all the fields (dimensions and measures) for the subject area.

**Semi-Additive Example**

Table 1 shows a simplified version of data from the productOrderItems subject area. The ordersPlaced and GMV measures are aggregated by the orderPlacedDate dimension. The sum of all orders placed on 9/10/2021 is 7. An order can contain multiple products.

Table 1

| orderPlacedDate | ordersPlaced | GMV |
| --- | --- | --- |
| 9/10/2021 | 7 | $2,943 |

Table 2 shows the same simplified data from the productOrderItems subject area. The ordersPlaced and GMV measures are aggregated by the orderPlacedDate and productId dimensions. The sum of all orders placed on 9/10/21 is 14, one count for each productId ordered. However, 14 orders is an error.

The ordersPlaced measure is semi-additive and isn’t summable by the productId dimension. The productId dimension caused the sum of ordersPlaced to count all the productId line items in each customer order rather than just the customer orders. The result in table 2 can’t be used as a metric for orders placed.

Table 2

| orderPlacedDate | productId | ordersPlaced | GMV |
| --- | --- | --- | --- |
| 9/10/2021 | product_1 | 2 | $247 |
| 9/10/2021 | product_2 | 1 | $83 |
| 9/10/2021 | product_3 | 3 | $1,087 |
| 9/10/2021 | product_4 | 1 | $298 |
| 9/10/2021 | product_5 | 4 | $975 |
| 9/10/2021 | product_7 | 1 | $148 |
| 9/10/2021 | product_9 | 2 | $105 |

**Fully Additive Example**

GMV is a fully additive measure. The sum of GMV in both Table 1 and Table 2 is $2,943. Because GMV is a fully additive measure, no matter which dimensions aggregate GMV, the sum is always the same.
