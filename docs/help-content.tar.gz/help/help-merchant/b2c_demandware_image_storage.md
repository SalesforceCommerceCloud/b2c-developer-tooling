# Salesforce B2C Commerce Image Storage

_B2C Commerce supports three static content locations where it stores images._

| Image Type | Examples | Location | Subfolder Structure | Staging/ Replication |
| --- | --- | --- | --- | --- |
| Catalog | product, category, option, and recommendation images | Within the catalog's own static content directory: sites/Sites-Site/(Version Directory(0\|1))/units/ (Your Catalog)/static/default/ | Arbitrary | Can be staged using the Replication Task "Replication Tasks > Sites > Catalogs > (Your Catalog)". |
| Non-catalog | custom object, slot (type HTML), promotion, and store images | Within the organization ("Sites") static content directory: sites/Sites-Site/(Version Directory(0\|1)) /units/Sites/static/default/ | Arbitrary | Can be staged using the Replication Task "Replication Tasks > Sites > Static Content". |
| Content | content assets | located within its own site-specific content library directory: sites/Sites-(Your Site)-Site/(Version Directory (0\|1)) /units/Sites-(Your Site)-Library/static/default/ | Arbitrary | Can be staged using the Replication Task "Replication Tasks > (Your Site) > Content Library". |
