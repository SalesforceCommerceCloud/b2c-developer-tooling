# Visit Tracking

_B2C Commerce enables you to track visits via B2C Commerce Analytics._

### What Is a Visit?

A visit is the sum of one or more requests coming from a certain human user or a machine. B2C Commerce distinguishes these requests by the session ID it assigns to the user. B2C Commerce groups all requests that share this session ID over a contiguous time period into a visit.

A session ID is a unique identifier that B2C Commerce passes to the requested client. The client must return this ID (mostly a cookie) to be able to browse the site in a contiguous manner. If the client doesn't pay attention to this ID, certain functionality isn't available, such as login and checkout.

If a client doesn't send a request for 30 minutes, the session is considered closed. Any request after this time is considered part of a new visit.

To distinguish human from machine, a set of predefined identifiers and IP addresses is used to filter the requests. B2C Commerce lists visits from robots/crawlers/spiders separately. All business calculations are done based on the determined real user visits. Definitions are updated regularly and on request by the customer.

### Scenarios and Exceptions

Email clients: email clients often show previews of embedded or linked html content without executing any JavaScript or loading of third-party content such as tracking images. B2C Commerce counts these previews as visits.

Browser background fetching: some modern browsers are using read ahead techniques. To improve the responsiveness of the browsing experience, these browsers load web content before it's explicitly requested. For instance, Firefox often follows the first link in Google search results and fetches this website because it assumes that this site is of interest and the user can click the link. B2C Commerce counts this background loading as a visit.

Short Visits: a user followed a link to a B2C Commerce based website and closed the browser after seeing the first page or doesn't pay attention to the loaded content for more than 30 minutes with a still open browser. This means that the user isn't requesting any additional pages. B2C Commerce counts this as a visit and most other Analytics packages do the same.

Interrupted Visits: a user visits a Web page, requests pages, and leaves the browsing session without closing the browser. After 30 minutes of inactivity, B2C Commerce considers this visit terminated. If the user later continues shopping, B2C Commerce counts it as a new visit.

Disabled Cookies: when a user agent doesn't accept cookies, B2C Commerce includes the session information in all URLs. Therefore, these requests can still be a single visit. If there is disabled JavaScript this does not affect the number of visits, because B2C Commerce Analytics doesn't require JavaScript and therefore always counts visits the same way.

### Advantages and Disadvantages

The B2C Commerce approach makes sure that all visits are counted independently from disabled JavaScript or blocked third-party sites whether they serve images or JavaScript for tracking purposes. The disadvantage on the other hand is, that unknown or new robots can be considered real users until the filter information has been updated. Also, not all client agents identify themselves correctly. Some of them are acting in a cloaked mode and pretending to be normal browsers. To detect these agents, exclude certain IP ranges known as spam traffic sources.
