# Edit Product Details

_Use Business Manager to edit the product details for an individual product. This topic applies to B2C Commerce._

|  |
| --- |
| Available in: **B2C Commerce** |

Edit products individually to change most attribute values. You can also edit multiple products at the same time.

> **Note:** If you see unavailable fields, you have read-only permission. You can search for products and view product data, but you can't change them. If you have mixed permission to access one module (via different roles), B2C Commerce grants the higher-level access. If you require write access, see your administrator.

1. Click App Launcher _(image: App Launcher)_, and then select **Merchant Tools > *site* > Products and Catalogs > Products**.
2. Click the product ID link or product name link.
3. On the Product Page General tab for a specific product, click **Lock** before editing a product.

   Lock a product if you have full permission or restricted permission (permission restricted to the site catalog of the currently selected site). This permission is independent from the selected locale.
   
   You can't lock a product when you have no permission at all.
4. Edit the general product details:

   - ID
   - Catalog
   - Tax class
   - Searchable
   - Searchable If Unavailable: Use this field to control on a product-level if a product is to appear in the search results when it's unavailable (that is, ATS=0).
   - Name
   - Brand
   - Manufacturer
   - Manufacturer product ID
   - Description
   - Product details
   - Images
5. Edit the other product details on the *General* tab:

   - Online status - B2C Commerce considers the default online from/to settings and site-specific values when showing the online status of a product. It calculates product availability status solely on the inventory record (without considering the product online status).
   - SEO support
   - Sitemap Attributes
   - Presentation attributes: images, rendering template, and CSS
   - Search ranking
   - Order attributes: sales unit, unit measurement, unit quantity, minimum order quantity, step quantity, tax class, European Article Number (EAN), Universal Product Code (UPC)
   - In-store pickup: Yes or No (default) - see *Product* system object type attribute
   - Storefront attributes: description, details, refinement color
   - Search Refinements:
6. If you have more than one site, Business Manager shows other files for site-specific attributes, enabling you to specify different values per site. You can edit attribute values as follows:

   - On the Product page General tab, edit the default values and site-specific values of the current site.
   - Click the **All Site Values** link. On the Site-Specific Values page, edit the default and all site-specific values of a single attribute.
   - Click the **Edit Site Specific** link. On the Edit Site-specific Attributes page, edit the site-specific values for all site-specific attributes for the site.
7. Click the **Options** tab if the product has options or you want to create them.
8. Click the **Variations** tab if the product has variations or want to create them.
9. To edit product pricing, click the Product page **Pricing** tab.

   When read-only price books are enabled, price editing is disabled. We recommend changing the price in the source XML and reimporting the price book. To edit a price without reimporting, create a new price book with only the product and updated price. Editable price books overrule read-only price books.
10. To edit product inventory details, click the Product page **Inventory** tab.
11. To edit category assignments, click the **Categories** tab.
12. Click the **Links** tab if the product uses linking.

   We recommend that you use recommendations instead. The linking feature, though still supported, is replaced the recommendations feature.
13. Click the Product page Recommendations tab if the product has recommendations or want to use them.
14. Click the **Bundles** tab if the product is part of a bundle or want it to be.
15. Click the **Product Sets** tab if the product is part of a product set or want it to be.
16. Click the **Active Data** tab if you are collecting active merchandising data on this product and want to see the results.
17. Click the **Page Meta Tag Rules** tab to create or manage page meta tags.
