# Set B2C Commerce Dashboard Filters

_For B2C Commerce storefronts, you can set different filter combinations to review a select set of data in each dashboard. The default dashboard filter settings are blank, and the default reports reflect realm-level data._

1. In Business Manager, click App Launcher _(image: App Launcher)_, and then go to **Merchant tools > Analytics > Reports & Dashboards**.
2. Click the **Filter by...** dropdown menu.
3. Select any combination of these filters. You can also select more than one option for a given filter.

   > **Note:** If you select all options in a filter category, no filtering applies.
   
   - Device Type
   - Customers
   - Customer Registration
   - Channels
   - Agent Assistance (controls whether the dashboard shows Shopping Agent data)
   - Locales
4. Click **Apply**.

To remove a filter, deselect the setting. To remove all settings at once, click **Clear All**.
