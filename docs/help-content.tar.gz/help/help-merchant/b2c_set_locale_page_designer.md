# Set the Locale for Page Designer Visual Editor

_Specify the locale for which you’re editing pages. This topic applies to B2C Commerce._

|  |
| --- |
| Available in: **B2C Commerce** |

1. From page edit mode, select a locale from the top dropdown menu.

   If you set the locale to default, the visual editor uses what is configured as the preferred data locale in your user profile, which is sometimes different from the default locale for your storefront.
