# Set Up a SLAS Client for Shopper Consents on PWA Storefront

_If you have a PWA storefront, set up a Shopper Login and API Access Service (SLAS) client for your B2C Commerce instance to request access tokens._

For information about how to set up a SLAS client to request access tokens for[ Shopper Consents APIs](https://developer.salesforce.com/docs/commerce/commerce-api/references/shopper-consents?meta=Summary), see [Authorization for Shopper APIs](https://developer.salesforce.com/docs/commerce/commerce-api/guide/authorization-for-shopper-apis.html). When you are setting up your client, make sure that the client has `sfcc.shopper-consents` and `sfcc.shopper-consents.rw` defined in custom shopper scopes.
