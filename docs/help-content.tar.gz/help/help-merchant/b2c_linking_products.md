# Link Products

_Use the Links tab in the Product Editor to create links between products. Link from or to products. This topic applies to B2C Commerce._

|  |
| --- |
| Available in: **B2C Commerce** |

Use the Links tab in the Product Editor to create links between products. You can link from or to products. For example, you might want to show the spare parts for a product on the product detail page and show "fits for..." at the spare parts detail page without having to maintain two relationships. For example, create two products Vacuum_cleanerX and NozzleX. Under Vacuum_cleanerX, list NozzleX as a product link to link them on the product detail page. Then list Vacuum_cleanerX as a product link for NozzleX, so that you can show all the nozzles on one "fits for..." page on the storefront showing links to each respective vacuum_cleaner.

Business Manager includes a product recommendations feature that enables you to link a product to another product or a category to a product. We encourage you to use this feature instead of product links.

1. Click App Launcher _(image: App Launcher)_, and then select **Merchant Tools > *site* > Products and Catalogs > Products > *product***.
2. Lock the product.
3. On the Product page Links tab, in the Linked From section, select a link type to view, from the Link type dropdown.
4. Select the Link type.

   | Option | Description |
   | --- | --- |
   | Replacement | Offer similar/substitute products to buyers |
   | Cross-Selling | To incite buyers to purchase more than originally intended, offer related products. |
   | Up-Selling | To incite buyers to purchase higher-priced products, offer alternative, higher-value products. |
   | Accessory | To incite buyers to purchase more than originally intended, for example, offer a matching handbag with a pair of shoes, offer complementary products. |
   | Follow-up | Refer to follow-up versions of the product. |
   | Different Order Unit | Refer to follow-up versions of the product with a different order unit. |
   | Spare Parts | Offer available spare parts for a product. |
   | Other | Provide a different type of link. |
5. Select or enter the products to which you want to link.

   1. Enter one or more product IDs (separated by semi-colons) and click **Create Link**.
   
      You select the link type first. You can't change the link type after you’ve created the link.
   2. Click **Search to Create>>,** select as many products as required, and click **Create Link**.
6. Click **Remove** to remove a selected link.
7. Click the **Hide** or **Show** links to hide or show the contents of each section, making the information more readable if you have many links.
8. To view help on the link types, click **Link Type**.
9. In the Linked To section, view the products that are linked to the product with which you are working. Only change the nature of the links from within each product you are linked to.
