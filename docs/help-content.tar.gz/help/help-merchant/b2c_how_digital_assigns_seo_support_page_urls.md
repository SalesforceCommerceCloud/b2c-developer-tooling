# How B2C Commerce Assigns SEO Support Page URLs

_B2C Commerce provides several layers of inheritance URL attribute values that can be set through page-specific values, category values, or default values._

B2C Commerce assigns URLs if the deprecated SEO Support module is enabled and you have chosen to use Page URL in your SEO support rule syntax. For example, the following syntax uses the values specified in the Page URL attribute:${pageURL||displayName}

For information on how B2C Commerce assigns URLs if the URL Rules module is enabled, see [How B2C Commerce Assigns Page URLs](https://help.salesforce.com/s/articleView?id=cc.b2c_how_digital_assigns_page_urls.htm&type=5).

### Product URLs

The order of precedence for a product item URL is:

1. The product's Page URL attribute. This is referred to elsewhere as the page-specific URL.
2. Then the classification category's Page URL attribute.
3. Then the primary category's Page URL attribute.
4. If there are no values supplied for the product's primary or classification category Page URL attribute, the default settings configured in the default URLs are used. For more information about global default URLs, see [Creating Search-Friendly URLs.](https://help.salesforce.com/s/articleView?id=cc.b2c_creating_search_friendly_urls.htm&type=5)

### Content URLs

The order of precedence for a content item is

1. The content item's Page URL attribute. This is referred to elsewhere as the page-specific URL.
2. The default settings configured in the default URLs are used. For more information about global default URLs, see [Creating Search-Friendly URLs.](https://help.salesforce.com/s/articleView?id=cc.b2c_creating_search_friendly_urls.htm&type=5)
