# View A/B Testing for B2C Commerce Results

_Run up to three A/B tests at a time in B2C Commerce. Each test can have multiple segments, with multiple user experiences. When you have gathered data from an A/B test, Deploy some or all of experiences for its test groups to the site._

|  |
| --- |
| Available in: **B2C Commerce** |

Typically, you want to deploy the experiences of the winning test group, but sometimes you want to deploy experiences for multiple groups. To deploy these experiences manually, create a campaign or add to an existing one.

1. Click App Launcher _(image: App Launcher)_, and then select **Merchant Tools > Site > Online Marketing > A/B Tests**.
2. On the A/B testing list page, click the tool icon to the left of a test and select **View Test Results** from the menu.
3. You can also open the A/B test first and then click Test Results. Double-click an A/B test.
4. On the A/B test details page, click the **Test Results** button.

   The A/B test Results page opens with the key metric at the top of the list.

## Related Content

- [Understanding A/B Test Results in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_ab_test_results.htm&type=5)
  After you draw conclusions from a B2C Commerce A/B test, deploy some or all the experiences for its test groups to the site.
