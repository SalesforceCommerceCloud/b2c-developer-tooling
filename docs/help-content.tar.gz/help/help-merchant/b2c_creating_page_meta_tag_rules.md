# Create Page Meta Tag Rules for B2C Commerce

_Using static and dynamic elements, define meta tags with a rule-based approach to create unique meta tag content and increase the SEO value across pages, products, and URLs._

|  |
| --- |
| Available in: **B2C Commerce** |

The rules B2C Commerce uses to generate meta tags inherit via a [lookup order](https://help.salesforce.com/s/articleView?id=cc.b2c_meta_tag_rules.htm&type=5).

1. Click App Launcher _(image: App Launcher)_, and then select **Merchant Tools > Site > SEO & Discoverability > Page Meta Tag Rules**.
2. To see a filtered view of all current meta tags within a scope, click the scope title, or the number in the middle of the scope tile.

   Scope defines the context in which the page meta page rule is evaluated. Each scope supports a specific list of operators. For example, Product scope defines rules for the product details page context.
   
   To switch between scopes from the filtered view, use the scope dropdown on the left or change the filter view settings on the right.
   
   > **Note:** To create a tag for a scope from the Page Meta Tag Rules homepage, click **New** on any tile.
3. Click **New**.

   1. Name the meta tag.
   2. Verify that the scope is correct. If not, change the scope.
   3. Select a Meta Tag ID.
   4. Choose a locale.
   5. Enter the meta tag rules following the [meta tag rule syntax](https://help.salesforce.com/s/articleView?id=cc.b2c_meta_tag_rule_syntax.htm&type=5).
   
      Each rule can contain up to 4000 characters.
   6. Enter a description.
   7. Click **Save**.
   
      The meta tag entry is now added. Refresh the Page Meta Tag Rules homepage.
4. To assign a meta tag, navigate to the respective filtered scope view.
5. Find the meta tag in the list and click the number in the Assignments column.

   To delete or edit a meta tag entry, click the dropdown icon for that meta tag.
6. Select an Assignment in the Assignments dialog.

   Be as broad or detailed as you want. All children inherit the assigned rules.
7. To save, click **Select**.

   No index rebuild is necessary to apply, but it can take up to 30 minutes to finalize.
