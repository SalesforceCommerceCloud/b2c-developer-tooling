# Create a Product Variation Group

_Import variation groups or create variation groups. This topic applies to B2C Commerce._

|  |
| --- |
| Available in: **B2C Commerce** |

1. Click App Launcher _(image: App Launcher)_, and then select **Merchant Tools > *site* > Products and Catalogs > Products**.
2. Search for the variation base product that you want to create a variation group for.
3. On the Products page General tab, click the **variations** tab.
4. Click **Lock**.

   > **Note:** It isn't possible to create variation groups unless the product is locked.
5. Add variation product and configure values for all variation attributes. Create these values before selecting them for variation groups.
6. Under Variation Groups, enter a unique ID for your variation group and click **Add**. Take note of any warnings that appear before clicking **OK** to continue.

   > **Note:** You can also click **Clone** to clone an existing variation group.
7. Select a value for at least one variation attribute.
8. Click **Apply**.
9. To display the list of SKUs assigned to the variation group. Click the group **ID**.
10. On the General Tab, click **Lock**.
11. Arrange your variation group in the order in which you want it to inherit properties. See the section on property inheritance for more information.
12. In the Searchable list, select the sites where you want to be able to search for the variation group.
13. In the Online list, select the site that contains the category where you want to see the variation group. Click **Apply**.
14. Click the **Categories** tab.
15. Click **Edit** and assign the variation group to the categories in which you want it to appear.
16. To save your changes. Click **Apply**.
17. Position the variation group order in the category using category position or drag the variation group to the desired position.
18. Reindex the product index.
