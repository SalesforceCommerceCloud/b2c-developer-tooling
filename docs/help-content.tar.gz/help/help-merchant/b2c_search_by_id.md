# Search by ID

_Search for a product by ID. This topic applies to B2C Commerce._

|  |
| --- |
| Available in: **B2C Commerce** |

The ID search is restricted to 10,000 IDs.

1. Click App Launcher _(image: App Launcher)_, and then select **Merchant Tools > *site* > Products and Catalogs > Products**.
2. Click **By ID**.
3. Enter a list of product IDs into the List of IDs field.

   - Separate IDs by white space, commas, or carriage returns (Enter).
   - You can't specify a range.
   - Search is case-sensitive.
4. Search for product IDs that contain a comma, semicolon, colon, or white space. Check **Use only newline as separator** and enter the IDs in the List of IDs field, with one product ID per line.
