# Historical Reports Metrics Definitions

_The B2C Commerce Business Manager Analytics reports are retired. As of January 1, 2021, the reports are no longer populated._

To access current data with advanced analytics and reporting capabilities, use the [b2c_reports_and_dashboards.xml](https://help.salesforce.com/s/articleView?id=cc.b2c_reports_and_dashboards.htm&type=5) Reports & Dashboards.

This page describes the metrics elements as defined and used in the Salesforce B2C Commerce Historical reports.

> **Note:** When a site supports multiple currencies, B2C Commerce collects active data raw values across all sessions, regardless of session currency. B2C Commerce converts currency values into the site's default currency. The legacy reports described on this page reflect the converted values.

### Terms and Definitions

These are general terns and their definitions.

| Term | Definition |
| --- | --- |
| A/B testing (visit-based) | A visit can take part in A/B testing with one or more tests. Each test has a name and several segments (for example, name *FastCheckout* and segments *one step* and *two step*).  The base number is the total number of visits. The A/B test result number is the sum of all visits that took part in a certain test and test segment.  A visit can be part of multiple segments within a test and can take part in multiple tests at once. The system counts it for all tests in which it took part. |
| Basket / Cart | A basket or cart is a shopping cart created by a user during an add to cart operation.  A visit can have zero or more carts (usually zero or one cart). Multiple carts occur when a user has checked-out a cart but continues to use the open visit and creates another cart. Each cart has a unique identifier, and the system counts it separately. The counting time is the start time of the visit. The system counts a cart multiple times when the cart spans two or more visits (persistent cart feature).  For example: A customer goes to iDemand.com, thus creating a visit or session. The session ID is 1234 with timestamp March 20, 2015 12:20:37. The customer adds a product to a cart. The new cart has Cart ID 99999 with timestamp March 20, 2015 12:24:19. The customer doesn't check out the cart but leaves the store, ending the visit/session. At 20:56:44 in the evening, the customer returns. Because the customer allows cookies, the cart still exists. The system detects this, counts the cart as a new cart, and sets the timestamp of the cart to the timestamp of the new visit/session, that is, March 20, 2015 20:56:44. The customer adds one more product, checks-out, and leaves. The result is two visits, two carts and one checkout. |
| Buyer | A customer who has an account in the store, and who has made at least one purchase. |
| Checkout | The process of ordering what is in the cart. This process can be stopped at any time and doesn't necessarily end with an order. A visit can have more than one checkout process for the same cart. The system counts each checkout separately. The counting starts from the start time of the visit. |
| Customer | A buyer; a visitor who registered an account in the storefront and who has or has not made a purchase. |
| External search | Any search that led to the storefront, regardless of source. Phrases aren’t separated or reordered. B2C Commerce maintains a list of recognized search engines. If you know of a search engine to add to the list, contact Commerce Cloud Support. |
| IP address | The IP address of the sender of the request. Proxies or network address translation can mask the real IP address of the sender. |
| Order | The final result of a completed checkout process. The system counts each order separately. The order time is the start time of the visit. A visit can have more than one order (that is, a new cart for each order). All reports use orders as B2C Commerce captured them at the time they were placed. Any subsequent changes to orders aren’t captured by B2C Commerce. |
| Page request | An `http-request` to the system. Only HTML requests are counted, no media requests (for example, images, CSS, or Flash) are counted. This is also called a page hit. |
| Product | An item with a unique ID (SKU). Each variation of a product is a product while individual options of a product aren’t a product. |
| Quantity | The number of items sold of a specific product. |
| Referrer | When visiting a web page, the referrer or referring page is the URL of the previous web page from which the user followed a link. More generally, it's the URL of a previous item, which led to this request. The referrer of an image, for example, is generally the HTML page on which it's to appear. |
| Registered buyer | A registered customer who has made at least one purchase. |
| Revenue | The sum of all merchandise totals, including shipping and tax. |
| Robot | Also known as a web crawler or spider; a program that browses the World Wide Web in a methodical, automated manner. Web crawlers create a copy of all the visited pages for later processing by a search engine that indexes the downloaded pages to provide fast searches. Crawlers can also be used for automating maintenance tasks on a website, such as checking links or validating HTML code. B2C Commerce maintains a list of recognized robots. |
| Runtime | Time needed to deliver a response back to the client. This includes the time needed by B2C Commerce to create and send the response. |
| Search | Any search performed in the storefront. A search can contain one or more search words. For example *Apple iPod* represents one search and one search phrase. Phrases aren’t separated into single words or reordered. For analytics, only the 10,000 most recent search phrases are used. |
| Unique page | A unique B2C Commerce URL, for example, /Link-Category?catalog=StandardCatalog&name=226. |
| Unregistered buyer | An unregistered user who makes a purchase. Given the nature of being unregistered, the system counts the same user for each purchase. |
| User agent/browser | The client application used with a particular network protocol. The phrase is most commonly used in reference to those that access the World Wide Web. web user agents range from web browsers to search engine crawlers (spiders), screen readers and Braille browsers. When internet users visit a website, a text string is sent to identify the user agent to the server. |
| Visit | A session by a registered/unregistered person or robot as indicated by a unique session ID that spans all requests.  The start time of the visit determines the time of the count. If a visit spans more than 1 hour or day, it's counted once for its start time (time and date). All registered and unregistered visits are listed separately in certain reports. All non-customer visits are listed separately in certain reports. The start time of a visit is also the start time for all subactivities, such as orders, checkout, and carts. For analytics, only the first 1000 requests are counted. The limit prevents robots from biasing reports. The maximal lifetime of a visit is determined by the session ID lifetime. The B2C Commerce Web Server session ID lifetime is set to 6 hours (security) and the session expiration (application server) session timeout is set to 30 minutes (resource and run-time performance). The session timeout is fired if a session is inactive for this period (there are no requests during this time). A session times out after 6 hours even if the session is active. A new session is automatically created and all active entities are recounted. |
| Visit duration | The time between the first request that started the visit and the full delivery of the last request of the visit. |
| Visitor | A visitor to the storefront, registered or unregistered. |

### Historical Conversion Report

Because carts and checkouts can occur multiple times, the conversion report can have unexpected values when using the B2C Commerce metrics. These metrics relate to the Conversion report:

Visits Conversions

- Visits to shopping carts: the percentage of visits that created at least one shopping cart.
- Visits to checkouts: the percentage of visits that started at least one checkout.
- Visits to orders: the percentage of visits that created at least one order.

Order Conversions

- Carts to orders: the percentage of carts that were ordered from the total cart count.
- Checkouts to orders: the percentage of checkouts that created at least one order.

Cart Conversion

- Carts to check out: the percentage of carts that started at least one checkout.

### Historical Purchase Report

These metrics relate to purchases:

Orders and Revenues

- Lists total orders and revenue (lead currency gross price).

Average Revenues

- Average revenue per order: the total revenue divided by the total number of orders.
- Average revenue per visit: the total revenue divided by the total number of visits.

Average Orders

- Average orders per visit: the total number of orders divided by the total number of visits
- Average orders per shopping cart: the total number of orders divided by the total number of shopping carts.

Ordered Products

- Lists the total products sold, total quantity sold and total revenue.

### Historical Catalog Report

This metric relates to the catalog.

- Ordered products: lists total products sold, total quantity sold and total revenue

### Historical Search and Navigation Report

These metrics relate to search and navigation.

Top Search Terms

- The total searches performed.
- Searches with results: the percentage of searches that returned one or more results.
- Searches without results: the percentage of searches that returned no results.
- Unique search phrases with results: the total number of unique search phrases within the total searches that returned one or more results.
- Unique search phrases without results: the total number of unique search phrases within the total searches that returned no results.
- Lists the top search phrases found and the top search phrases not found.

Search engine Hits

These metrics relate to search engine hits:

- The total external searches leading to the site.
- Unique external search phrases: the total number of unique external search phrases that led to the site.
- Unique count of external search engines: the total number of unique external search engines that led to the site.
- Lists the top external search phrases found and the top external search engines.

### Historical Customer Reports

These metrics relate to customers:

Customers and Buyers

- Number of new customers: the number of users (visitors) who have registered.
- Number of new buyers (customers): the number customers who are first time buyers.
- Number of unregistered buyers: the number of unregistered buyers. Given the nature of not being registered, each purchase is counted.
- Lists of total number of customers.

### Historical Traffic Reports

Traffic metrics relate to client navigation.

- Top pages: a list of all URLs relative to the pipeline start node.
- Top referrer by host and URL: a list of referrers to the storefront, excluding internal referrers (inside the domain) and robots.
- Top user agents: a list of the user agents used to access the system, excluding known robots.
- Top robots: a list of known robots that crawled the system.
- Top IP addresses: a list of IP addresses that sent requests to the system, including robots and user clients.
- Total requests: the number of requests to the system from robots and user clients.
- Request runtime: the average time the system required to deliver a response. The report lists this for robots and user clients separately.
   
   > **Note:** Runtime is defined as the time from receiving the request until delivery of the last byte.
- Total visits: the total count of visits listed for robots and user clients. Also listed is the total and average visit duration.
- Visit duration: a list of the total and average visit duration for user clients only.
   
   > **Note:** Visit duration is defined as the time from receiving the first request until full delivery of the last request for the visit.
- Filtered IP addresses: a list of the filtered IP addresses and the total count of requests coming from them. B2C Commerce Analytics can apply a filter to the IP addresses sending the requests, and you can define an IP range upon request. However, no filter is typically applied except to filter out the analytics testing requests.
   
   > **Note:** This filter is configured to filter out requests before any other statistic; this means that the requests and visits from these IP addresses are fully suppressed.

### Historical A/B Testing Report

This report is ordered by test and test segment name. This test lists:

- The total number of visits in the reported time period and afterwards, the number of visits in this test.
- Total column: the numbers of all visits in this test (visits caused by robots are excluded).
- Each segment column: the number of visits in a segment.
- Visits to shopping carts: the ratio between the total number of carts and the total number of visits. This number can be over 100%.
- Visits to orders: the ratio between the total number of orders and the total number of visits.
- Average revenue per order: the total revenue divided by the total number of orders.
