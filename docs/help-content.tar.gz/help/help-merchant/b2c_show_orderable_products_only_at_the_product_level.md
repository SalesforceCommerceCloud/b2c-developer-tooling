# Show Orderable Products Only

_Configure products so that only products that are available for order show in your storefront search results. This topic applies to B2C Commerce._

Control if a product appears in a search result when it's unavailable (ATS=0). Use the *Searchable If Unavailable* product attribute setting to control search results on a product-by-product basis.

Use the *Show Orderable Products Only* search preference to control at the site-level if unavailable products appear in search results. Also use the *Search* API pipelet *Show Orderable Products Only* parameter and the *dw.catalog.ProductSearchModel* to programmatically override both the site-level and product-level settings.

> **Note:** To use this feature, configure the corresponding site to use the *Availability Search Index.*

The Show Orderable Products Only search preference controls whether unavailable products appear in search results at the site level. When Shop the Store is enabled, the search results consider both site and store inventory. See [Shop the Store](https://help.salesforce.com/s/articleView?id=cc.b2c_shop_the_store.htm).

The *Searchable If Unavailable* product attribute is defined and can be viewed by clicking App Launcher _(image: App Launcher)_, and then selecting **Administration > Site Development > System Object Types > Product > Attribute Definitions**.

- If this attribute isn’t defined, B2C Commerce uses the site preference as the default behavior.
- If this attribute is set to *Yes,* the product appears in the search results even if it's unavailable.
- If this attribute is set to *No,* the product doesn’t appear in the search results if it isn't available.

Edit this attribute on the product page and via bulk editing (Update/Delete Product attribute > attribute selection). Use this attribute for an advanced product search (Search Result > By Attribute). Import and export this setting (*searchable-if-unavailable-flag*) in catalog.xsd.

### Examples

Here are some examples:

| Products | Site search Preference | Results |
| --- | --- | --- |
| Example 1 - Out-of-stock products appear in search results |  |  |
| *Men's Leather Luggage Fisherman Bag* has two colors *Black* and *Brown;* color *Brown* is *out-of-stock*   *Women's B-Flaps Shoulder Bag* has one color *Cognac;* color *Cognac* is *out-of-stock* | *Show orderable products only* is set to *No.* | When the customer searches for *bags, *B2C Commerce shows:   *Men's Leather Luggage Fisherman Bag* in the colors *Black* and *Brown*   *Women's B-Flaps Shoulder Bag* in the color *Cognac* |
| Example 2 - Out-of-stock products don't appear in search results |  |  |
| *Men's Leather Luggage Fisherman Bag* has two colors *Black* and *Brown;* color *Brown* is *out-of-stock*   *Women's B-Flaps Shoulder Bag* has one color *Cognac;* color *Cognac* is *out-of-stock* | *Show orderable products only* is set to *Yes.* | When the customer searches for *bags, *B2C Commerce shows:   *Men's Leather Luggage Fisherman Bag* in the color *Black* |
| Example 3 - Out-of-stock products don't appear in search results for some products |  |  |
| *Men's Leather Luggage Fisherman Bag* has two colors *Black* and *Brown;* color *Brown* is *out-of-stock*   *Women's B-Flaps Shoulder Bag* has one color *Cognac;* color *Cognac* is *out-of-stock* | *Show orderable products only* if set to *Yes.*  For product *Men's Leather Luggage Fisherman Bag,* attribute *Searchable If Unavailable* is set to *Yes* (on base product level). For product *Women's B-Flaps Shoulder Bag,* attribute *Searchable If Unavailable* is undefined. | When the customer searches for *bags, *B2C Commerce shows:   *Men's Leather Luggage Fisherman Bag* in the colors *Black* and *Brown* |
| Example 4 - Using new attribute to remove discontinued product from search |  |  |
| *Women's Silver Cloud Bracelet* is out-of-stock and back-ordered  *Women's Wrap Bracelet* is out-of-stock and discontinued | *Show orderable products only* if set to *No.*   *Searchable If Unavailable* is undefined for both products. | When the customer searches for *bracelet, *B2C Commerce shows:  Women's Silver Cloud Bracelet Women's Wrap Bracelet |
|  | *Show orderable products only* is set to *No.*  User sets *Searchable If Unavailable* to *No* for product *Women's Wrap Bracelet,* and then rebuilds the product search index. | When the customer searches for *gps*, B2C Commerce shows:  Women's Silver Cloud Bracelet |
| Example 5 - In-Store-Only products |  |  |
| *Women's New Rain Handbag* is only sold in stores, but merchandised on the website. Product has no inventory on the website. The custom attribute *In-Store Only* is set to *Yes* for product *Women's New Rain Handbag.* Custom code is in place to show a message for products flagged as *In-Store Only.* | *Show orderable products only* is set to *Yes.* | When the customer searches for *bags*, B2C Commerce shows:  Women's New Rain Handbag  The customer clicks the product to navigate to the product details page and a message appears: "In-store only!" |
