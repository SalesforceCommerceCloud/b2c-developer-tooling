# Historical Reports Set-Up

_The B2C Commerce Business Manager Analytics reports are retired. As of January 1, 2021, the reports are no longer populated._

To access current data with advanced analytics and reporting capabilities, use the [Reports & Dashboards](https://help.salesforce.com/s/articleView?id=cc.b2c_reports_and_dashboards.htm&type=5).

To capture the Historical Reports analytics, you add certain templates to your application. See Historical Analytics Reporting Integration.

B2C Commerce uses session IDs to capture web activities. While this doesn't distinguish between visits and visitors (unique visits), it does circumvent the issue with users blocking cookies or not allowing JavaScript and therefore not being counted. B2C Commerce also uses web logs, which are faster than pulling data from the database. The web logs represent all storefront web activities, for example, orders entered by consumers. They don't represent, for example, order cancellations, order modifications, and returns performed off-line by the merchant.

When using these reports, keep in mind the following:

- Due to the nature of the technology used, no report can be considered 100% accurate 100% of the time.
- Visits are ended for a single time period when necessary (for example, at the end of a day), but continue for the next larger time period (for example, the next day). Therefore, summing up the days in a report doesn't necessarily match the number of days in a given month.
- to run some of the reports, you must have *includes* in your storefront. See the SiteGenesis application for examples.

> **Caution:** For the analytics reports, all analytics are compiled in the *en_US* locale. Don't modify the reporting template locale for any reason. If you have questions, contact Salesforce Support.

> **Note:** The Analytics calendar widget uses the US standard for week number calculation. This means that Sunday is the first day of the week, while Saturday marks the end of a week.

> **Note:** The precision of the conversion and percentage values in reports is two decimal places, to show small conversion rates. For example, instead of reporting 0.0% for 250,000 visits and 95 orders (one decimal place), analytics reports 0.04%.
