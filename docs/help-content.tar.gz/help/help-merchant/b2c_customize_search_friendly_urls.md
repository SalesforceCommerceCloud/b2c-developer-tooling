# Customize Search-Friendly URLs

_Further customize search-friendly URLs using custom pipelines._

|  |
| --- |
| Available in: **B2C Commerce** |

> **Important:** B2C Commerce's implementation of search-friendly URLs, as described on this page, is now deprecated and replaced with the [URL Rules](https://help.salesforce.com/s/articleView?id=cc.b2c_configuring_seo_urls.htm&type=5) module. Salesforce recommends that you use this new methodology.

1. Click App Launcher _(image: App Launcher)_, and then select **Merchant Tools > Site > SEO  > URL Rules**.
2. Make sure **Enable Search Friendly URLs** is selected (this functionality is deprecated).
3. Deselect **Enable Storefront URLs** on the Storefront URL Preferences page. For more information, see [Enabling Search Friendly URLs](https://help.salesforce.com/s/articleView?id=cc.b2c_enabling_search_friendly_urls.htm&type=5).
4. Add values to the following fields:

   1. Default Page URL for Categories: If nothing is specified the default is `${pageURL||displayName}.` This uses the Page URL and Display Name attributes to construct the default URL. To create a custom URL, supported category attributes include pageURL, pageTitle, ID, and displayName.
   2. Default Page URL for Products: If nothing is specified the default is `${pageURL||name}.` This uses the Page URL and product Name attributes to construct the default URL. To create a custom URL, supported product attributes are pageURL, pageTitle, productID, name, brand, and shortDescription.
   3. Default Page URL for Content Pages: If nothing is specified the default is `${pageURL||name}.` This uses the Page URL and content Name attributes to construct the default URL. To create a custom URL, supported content attributes are pageURL, pageTitle, ID and name.
5. In the *Substitute blanks in the URLs with:* field, specify the value you want to use: `%20,+, _, -, .`.
6. Click **Apply**.

For information on other customizations, including alternative encodings for search-friendly URLs, see [URL Syntax](https://help.salesforce.com/s/articleView?id=cc.b2c_url_syntax.htm&type=5).
