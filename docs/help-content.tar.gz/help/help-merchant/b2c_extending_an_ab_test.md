# Extend an A/B Test in B2C Commerce

_Extend an A/B test to allow more time to collect results beyond the allotted time period._

If you extend a test on the end date, it can immediately take on new participants. Before the end date, the test continues to take on new participants for a longer time period.

If there are active customer sessions and you extend a test on the end date, B2C Commerce doesn’t evaluate them for participation. B2C Commerce evaluates only new sessions.

Salesforce recommends that you extend an A/B test in the production instance and in staging so that a subsequent replication doesn't override it. You can extend a test in staging, but it takes effect only if you replicate the test to production.

> **Note:** If the start or end dates of a test change, B2C Commerce doesn’t adjust A/B test statistics. You can schedule an A/B test to run up to 90 days.

1. Click App Launcher _(image: App Launcher)_, and then select **Merchant Tools > Site > Online Marketing > A/B Tests**.
2. On the A/B testing List page, select the test and click **Edit**.
3. Enter a new end date and time.
4. Save your changes.

   The test continues to run until the new end date.
