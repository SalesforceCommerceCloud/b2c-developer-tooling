# Delete a Large Number of Customers in B2C Commerce

_Use Business Manager to delete up to 1000 customers at once using the standard method._

|  |
| --- |
| Available in: **B2C Commerce** |

This can be a timely process if you want to delete a large number of customers. Using the Import & Export feature, delete as many customers as you need at once.

1. Click App Launcher _(image: App Launcher)_, and then select ***site* > Merchant Tools > Customers > Import & Export**
2. In the Customers section, click **Export**.
3. Select the customers you want to delete and click **Next**.
4. Select **Export Selected Customers**.
5. For Exported File, enter a file name, and click **Export**.
6. In the Customers section, click **Import**.
7. Select the file that you created and click **Next**.
8. After the system validates the file, click **Next**.
9. Click **DELETE**, and click **Import**.
