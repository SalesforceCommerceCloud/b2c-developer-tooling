# Categories and Storefront Navigation for B2C Commerce

_With the proper settings, categories also provide your storefront navigation structure. This topic applies to B2C Commerce._

For example, root categories configured for storefront navigation show on the top level in the navigation bar. Subcategories configured for navigation show when you click their parent category. The full navigation structure shows in the left side bar on the storefront window.

You can also create categories that are part of your catalog but aren’t part of your storefront navigation. For example, you have a Tent Accessories category that you link to from the Tents category but isn’t part of your storefront menu navigation. If your storefront isn't based on SiteGenesis, you can use a similar mechanism to control whether the category appears in the storefront.

Salesforce recommends that you use a category design strategy that helps your customers quickly find the products and services that they want. A well-designed category strategy also helps you effectively manage your products in Business Manager.
