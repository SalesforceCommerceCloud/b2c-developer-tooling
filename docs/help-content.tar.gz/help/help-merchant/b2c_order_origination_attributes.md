# Order Origination Attributes

_This topic applies to B2C Commerce. As part of your omni-channel strategy, you can get a detailed breakdown of how your orders originate in GMV reports._

Using order object attributes, assign values during basket creation that specify an order's creation source, such as its business type or channel, as follows:

| Order attribute | Attribute values | Comments |
| --- | --- | --- |
| `businessType` | B2C  B2B | Business to Consumer Business to Business |
| `channelType` | All None Storefront Call Center Marketplace Online Reservation Data Security Standard (DSS) Store Twitter Facebook Ads Instragram Commerce Subscriptions CSC | - - - - Affiliate - In-store Orders placed by in-store applications. Social media  " - - Orders placed from Customer Service Center |

Business Type Order Source

Use the `Business Type` order attribute to indicate the type of business from which an order originated (B2C or B2B). This attribute provides a level of granularity within order objects and GMV reports that can help determine how GMV rates apply.

Use the Salesforce B2C Commerce Script API `dw.LineItemCtnr.getBusinessType` and `dw.Basket.setBusinessType` methods to assign a `Business Type` attribute to an order during basket creation and then write the attribute to the order object.

Orders imported into B2C Commerce can include a `Business Type` attribute value. Exported orders contain this attribute and its corresponding value. If the `Business Type` value is Null, a Null value is exported. In the GMV reports, however, the attribute is assigned the default value of `B2C.`

GMV reports include a `Business Type` column, which shows `B2C` or `B2B.` (A Null `Business Type` appears as `B2C.`)

Business Manager includes the `Business Type` attribute as part of the search criteria on the Order Search page Advanced tab.

> **Note:** As of Release 14.8, the `Business Type` attribute was available and enabled for all customers. To see the specific values available via this order attribute within your application (for example, GMV reports, Business Manager, and order objects), change your application (via the B2C Commerce Script API) to assign and use the two supported values. You’ll automatically see a `Business Type` column on your GMV reports. If you don't change your B2C Commerce Script API calls to use the `Business Type` attribute, the `Business Type` value in your order objects is set to Null, and the value on the GMV reports is `B2C.`

Channel-Specific Order Source

Use the `Channel Type` order attribute to indicate the type of channel from which an order originated (Storefront, Call Center, DSS, or Marketplace). This attribute provides a level of granularity within order objects and GMV reports that can help determine how GMV rates apply.

Use the B2C Commerce Script API `dw.LineItemCtnr.getChannelType` and `dw.Basket.setChannelType` methods to assign a `Channel Type` attribute to an order during basket creation and then write the attribute to the order report.

Orders imported into B2C Commerce can include a `Channel Type` value. Exported orders contain this attribute and its corresponding value. If the `Channel Type` value is Null, a Null value is exported. In the GMV reports, however, the attribute is assigned the default value of `Storefront.`

GMV reports include a `Channel Type` column, which shows one of the attribute values (Call Center, DSS, Marketplace, or Storefront). (A Null `Channel Type` appears as `Storefront.`)

Business Manager includes the `Channel Type` attribute as part of the search criteria on the Order Search page Advanced tab.

> **Note:** As of Release 14.8, the `Channel Type` attribute was available and enabled for all customers. To see the specific values available via this order attribute within your application (for example, GMV reports, Business Manager, and order objects), change your application (via the B2C Commerce Script API) to assign and use the four supported values. You’ll automatically see a `Channel Type` column on your GMV reports. If you don't change your B2C Commerce Script API calls to use the `Channel Type` attribute, the `Channel Type` value in your order objects is set to Null, and the value on the GMV reports is `Storefront.`

Channel type "Customer Service Center" can't be set by Script API.
