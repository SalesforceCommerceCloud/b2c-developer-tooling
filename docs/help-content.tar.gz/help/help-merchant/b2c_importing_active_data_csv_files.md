# Import Active Data .csv Files

_Import Active Data .csv files to use production active data on your Sandbox instance or to test active data sorting rules. Download the daily active data feed from your Production instance and import it into your Sandbox._

Before importing Active Data, make sure that:

- **Active Data tracking is enabled.** Make sure products exist in the Product Active Data database (PalDB) before importing custom attributes for them. B2C Commerce creates PalDB entries when tracking is enabled and customers view or purchase products on your storefront.
- **Products exist in PalDB.** If tracking was recently enabled, allow time for customer activity to populate PalDB entries. To verify PalDB entries, view Active Data attributes in Business Manager.
- **Your CSV file contains all required data.** Active Data imports use REPLACE mode, which means any attributes not included in your CSV file are deleted. See the following warning.

You can't import active merchandising data exported through Site Import & Export or Active Data > Export.

> **Warning:** **Data Loss Risk:** Active Data imports always use REPLACE mode. This means:
> 
> - Existing attribute values not included in the CSV file are **permanently deleted**.
> - Importing a partial or sparse CSV file overwrites all existing Active Data for the products in the file.
> - Products not included in the CSV file are unaffected, but any product in the file has its Active Data completely replaced.
> 
> Always export your current Active Data as a backup before importing. Verify that your CSV file contains all attributes you want to retain.
> 
> For more information about import modes, see [Import Modes in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_import_modes.htm&type=5).

1. Click App Launcher _(image: App Launcher)_, and then select **Merchant Tools > Online Marketing > Active Data > Import & Export**.
2. On the Active Data Import & Export page, click **Upload**.

   You can't import a file into the Salesforce B2C Commerce database without first uploading it.
3. On the Manage Import Files page, click **Browse**.
4. On the upload window, select the .csv file to import and click **Open**.

   Select the .csv file that you downloaded from the Production instance or a test data file you created. If you modified a test file, make sure to use the correct naming convention.
   
   The active data feed name has the following format: activedata-product-*sitename*-YYYYMMDD.csv *For example: activedata-product-MySite-20250115.csv* When importing data, follow the naming convention exactly.
5. Click **Upload**.

   The file you uploaded appears in the list of import files.
6. On the Manage Import Files page, click **<< Back**.
7. Click **Import**.
8. On the Active Data Import Step 1 - Select File page, select the file you want to import and click **Next**.
9. On the Active Data Import Step 2 - Validate File page, if the validation finishes successfully, the Import File Content section appears beneath the Validation Status section.

   If you have errors or your file doesn't validate correctly, the page shows logging information to help you fix your file. If you need additional information, select **Administration > Site Development > Development Setup > Log Files** link to view log files.
10. Click **Import**.

   When your file has imported, the Import page opens, showing the import results.

Your file can import with data errors, as indicated in the Status column of the window. To view these errors, click the file name link.

To confirm that your data has imported successfully, check your active data attributes.
