# URL Redirects for B2C Commerce

_During the initial transition between an existing site and a new B2C Commerce store, consider creating 301 redirects from the old site to the new site. Over time, create redirects from one page or URL to another._

### When to Use the Alias, Mapping Rule, Static Mapping, and URL Redirect Features

**Redirecting host-only URLs**

Always click App Launcher _(image: App Launcher)_, and then go to **Merchant Tools > Site > SEO & Discoverability >  Aliases.** Hostname aliases generate 301 redirects for host-only URLs. They also let you redirect URLs to locale- or device-specific sites.

**Redirecting B2C Commerce URLs**

If the redirect from a B2C Commerece URL

- Click App Launcher _(image: App Launcher)_, and then select **Merchant Tools > Site > SEO & Discoverability > URL Redirects.**, which is used for redirects of obsolete pages hosted on B2C Commerce to current pages on B2C Commerce. For example, if you change the name of a category. This is the only feature that can be used to redirect B2C Commerce URLs. See [Creating a Redirect from a B2C Commerce URL](https://help.salesforce.com/s/articleView?id=cc.b2c_creating_a_redirect_from_a_digital_url.htm&type=5). For more information about how this feature works, see [URL Redirect Processing and Examples](https://help.salesforce.com/s/articleView?id=cc.b2c_url_redirect_processing_and_examples.htm&type=5).

**Redirecting legacy Platform URLs**

If the redirect is from a legacy platform different than B2C Commerce, mapping depends on the type of redirect URL.

- A content page or unique or unusual - in this case you want to click App Launcher _(image: App Launcher)_, and then select **Merchant Tools > Site > SEO & Discoverability > Static Mappings.**, which is used for specific pages, whether they are landing pages or searches that don't conform to a general pattern. See [Static Mappings.](https://help.salesforce.com/s/articleView?id=cc.b2c_static_mappings.htm&type=5)
- A product or category page or conforms to a pattern - in this case you want to click App Launcher _(image: App Launcher)_, and then select **Merchant Tools > Site > SEO & Discoverability >  Dynamic Mappings.** - mapping rules identify the pattern of an incoming URL and map it to a pattern for a B2C Commerce URL. Creating a few mapping rules can let you manage many URLs from a legacy site efficiently.
   
   Mappings can be maintained in B2C Commerce for as long as you wish. We don't recommend removing them, because it isn't possible to predict when other site owners or search engines update their links, and removing the mappings prematurely causes you to lose traffic. See [Dynamic Mapping](https://help.salesforce.com/s/articleView?id=cc.b2c_dynamic_mappings.htm&type=5).

### Legacy Platform URL Redirects and Site Rankings

Most merchants migrate from an existing site to B2C Commerce. Usually, the existing site has built up search rankings and links on other sites to their site that drive traffic to the merchant. Use B2C Commerce to create mappings between old links and new pages so that you don't lose traffic from other sites and search engines. If you don't create these mappings, the old links don't work, and your SEO rankings can be severely impacted.

To create redirects for these links, we have three features: B2C Commerce hostname aliases, B2C Commerce Site URL-Mapping Rules, and Site URL Static Mapping. See [Configuring 301 Redirects for Legacy URLs](https://help.salesforce.com/s/articleView?id=cc.b2c_configuring_301_http_redirects_for_legacy_urls.htm&type=5).

Links that become obsolete because you change a category name on B2C Commerce also need permanent redirects so as not to lose customers who have bookmarked products and to retain your rankings.

To create redirects for these links, use the URL redirect feature.

B2C Commerce reserves `sitemap*xml` as a redirect keyword for XML sitemaps used by search engines to crawl the site. This string can't be used when creating redirects using any of the B2C Commerce URL redirect features. However, if you are redirecting a legacy sitemap page that showed an overview of your old site, you can set up a redirect using the string `sitemap` or `SiteMap`. See [Sitemap Overview](https://help.salesforce.com/s/articleView?id=cc.b2c_sitemap_overview.htm&type=5).

### Automatic Redirects from Deprecated SEO Support Module to URL Rule Module URLs

If you created your storefront before 13.1 and used the SEO Support module to optimize your URLs, then if you upgrade to the URL Rule module to optimize your URLs, B2C Commerce automatically creates 301 redirects from your old URLs to your new URLs when you enable the URL Rules module.

### Error Pages

If a user mistypes a URL or attempts to reach a page that no longer exists, they see a 404 page. You can create custom 404 pages that let them enter the site successfully. See [Creating 404 Error Pages with Alternate Paths](https://help.salesforce.com/s/articleView?id=cc.b2c_creating_404_error_pages_with_alternate_paths.htm&type=5).

## Related Content

- [URL Redirect Processing and Examples for B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_url_redirect_processing_and_examples.htm&type=5)
  Use the URL Redirect module to create redirects from existing B2C Commerce URLs to new B2C Commerce URLs.

- [Create a Redirect from a B2C Commerce URL](https://help.salesforce.com/s/articleView?id=cc.b2c_creating_a_redirect_from_a_digital_url.htm&type=5)
  The URL redirects feature redirects obsolete or unavailable B2C Commerce pages to currently available pages, or to a specific URL outside B2C Commerce.

- [Create External URL Redirects](https://help.salesforce.com/s/articleView?id=cc.b2c_create_external_url_redirects.htm&type=5)
  B2C Commerce's site alias configuration doesn't allow for external URL redirects. The solution is to build a custom pipeline that sends the configured hostname to the `redirectpermanent` template. This extension shows how to build such a custom pipeline.

- [Create Canonical URL Tags for B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_creating_canonical_url_tags.htm&type=5)
  Canonical URLs help prevent duplicate content issues by specifying the "canonical", or "preferred", version of a web page as part of search engine optimization. Normally, search engines lower the rankings for pages that appear to be duplicates. Indicating that a page has a canonical URL helps preserve those rankings. This topic applies to B2C Commerce.

- [Automatic vs. Manual URL Redirects for B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_url_changes.htm&type=5)
  Consider the differences between automatic and manual redirects. This topic applies to B2C Commerce.

- [Dynamic Mappings for B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_dynamic_mappings.htm&type=5)
  Configure dynamic mapping rules that use a pattern to identify a URL from your legacy site and automatically redirect it to a B2C Commerce URL. It isn't possible to use mapping rules to redirect an existing or obsolete B2C Commerce URL to a different B2C Commerce URL, nor is it possible to create redirects for static resources like images.

- [Static Mappings for B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_static_mappings.htm&type=5)
  Create static mappings from existing legacy URLs to new URLs in B2C Commerce. The URLs can be either dynamic pipeline calls or static resources, however, make sure that source URLs are unknown to the system. Replicate static mappings from Staging to Production instances. The file size of the configuration in Business Manager is limited to 2 MB. If you exceed the limit, use the site import and export functionality to update the static mappings.

- [PPC Keywords for Landing Pages](https://help.salesforce.com/s/articleView?id=cc.b2c_trapping_ad_words_keywords_for_specific_landing_pages.htm&type=5)
  B2C Commerce provides an easy way to manage Pay Per Click (PPC) URLs. You don't have to specify a separate URL for each query made by Google or other search engines. Instead, you can map the query generated by Google to a relevant landing page in B2C Commerce automatically. Use the URL-mapping feature to pass the keyword in the Google query to the Search-Show pipeline, which directs the customer to a page with search results based on the query. The Search-Show pipeline also detects if you have created a search redirect for the term and shows the related landing page for that redirect.

- [Automatic 301 Redirects for B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_automatic_301_redirects.htm&type=5)
  A 301 redirect is the HTTP status code for a permanent URL redirection that also passes page ranking power to the redirected page. In most instances, a 301 redirect is the best method for implementing redirects in your storefront. This topic applies to B2C Commerce.

- [Create 404 Error Pages with Alternate Paths in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_creating_404_error_pages_with_alternate_paths.htm&type=5)
  Create error pages that let a customer get to the home page of your site, even if they experience a 404 error because they’re linking to an expired page or have a broken URL.

- [Configure 301 HTTP Redirects for Legacy URLs in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_configuring_301_http_redirects_for_legacy_urls.htm&type=5)
  301 Redirects are used for permanent URL redirection, sending users to a different URL than the one they originally typed into their browser or selected from search engine results. The 301 redirect is considered a best practice for upgrading users from HTTP to HTTPS.
