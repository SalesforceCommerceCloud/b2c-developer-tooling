# Analytics Reporting Integration in SGJC

_To record Analytics events in SGJC, add certain templates to your application. These templates call B2C Commerce processes that capture the data and report on it via the Business Manager user interface._

SGJC uses session IDs to capture web activities for the Analytics data. This approach doesn't distinguish between visits and visitors (unique visits). However, this approach does circumvent the issue with users blocking cookies or not allowing JavaScript and therefore not being counted.

To capture this information, include the appropriate reporting template on a page. This template triggers a request to the server (via a URL include statement) with the required parameters.

When you include the reporting template, it triggers a request to the server. A URL include statement triggers the server request and provides the required parameters.

There are two ways of reporting events to Reports &Dashboards. Depending on the event, you use either the `ReportingEvent-Start` pipeline or the `isobject` tag.

> **Note:** B2C Commerce ignores reporting (log) entries that originate from pages that are processed using the RedirectURL-Start pipeline (URL mappings).

> **Important:** Don't use the `ReportingEvent-Start` pipeline as a pipeline trigger. There are some explicit checks for it in the web adapter, and the requests for that pipeline don't propagate to B2C Commerce. See [A/B Test Participation Triggers](https://help.salesforce.com/s/articleView?id=cc.b2c_ab_test_participation_triggers.htm&type=5).

See [Analytics.](https://help.salesforce.com/s/articleView?id=cc.b2c_analytics.htm&type=5)

### Reporting Hooks

The following SiteGenesis templates include reporting hooks (SiteGenesis Storefront Core: `cartridge/templates/default/util/reporting`):

- `ReportABTesting.isml`: collects Analytics on A/B testing (the A/B testing functionality in the Business Manager Analytics Module, not in the Online Marketing > A/B Testing module).
- `ReportCheckout.isml`: collects Analytics on the checkout process.

Don't change the locale in these templates. These templates merely log the information into the Analytics log file. The customer never sees it, and the Analytics module expects *en_US.*

### ReportABTesting.isml

Reference this template via an include statement in a template that renders the result of the test segmentation or alternate page. For example:

```
<isinclude template="util/reporting/ReportABTesting.isml"/>.
```

Variables are passed in the SiteGensis application to the `ReportingEvent-Start.xml` pipeline that this template expects

### ReportCheckout.isml

This template logs a checkout event. It logs the step, depending on the parameters, and expects the step number and name as parameters in the scope of a page. The reporting funnel display uses the step value to show the steps in ascending order. Using the name improves the display. This template can be called using an include statement, for example:

<isinclude template="util/reporting/ReportCheckout.isml"/> Use the parameters in this template to collect checkout information.

You can give each step a meaningful name for the checkout funnel name by changing the pdict variable `checkoutname`. Report the steps in the correct sequence with the `checkoutstep` variable. For example, if you have three steps in your checkout, they must be reported with the values one, two, and three. If you report with values one, two, and five, the funnel report inserts steps three and four with the same values as in step five.

In SiteGenesis, the `modues.isml` template references the `ReportCheckout.isml` template directly. It doesn't use an include statement.

### Related Links

[Analytics](https://help.salesforce.com/s/articleView?id=cc.b2c_analytics.htm&type=5)

[Analytics Metrics Definitions](https://help.salesforce.com/s/articleView?id=cc.b2c_analytics_metrics_definitions.htm&type=5)

[Analytics Reporting Integration](https://help.salesforce.com/s/articleView?id=cc.b2c_analytics_reporting_integration.htm&type=5)

[Analytics Reporting Integration Events](https://help.salesforce.com/s/articleView?id=cc.b2c_analytics_reporting_integration_events.htm&type=5)

[Analytics Reporting Integration URL Patterns](https://help.salesforce.com/s/articleView?id=cc.b2c_analytics_reporting_integration_url_patterns.htm&type=5)

[Analytics Reporting Integration in Salesforce Reference Architecture (SFRA)](https://help.salesforce.com/s/articleView?id=cc.b2c_analytics_reporting_integration_sfra.htm&type=5)
