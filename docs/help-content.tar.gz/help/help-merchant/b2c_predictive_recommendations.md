# Product Recommendations

_Use the B2C Commerce Einstein Self Deployment tool to implicitly generate recommendation for products. This topic applies to B2C Commerce._

> **Note:** B2C Commerce considers this approach to be the best practice.

Product recommendations are dynamically generated using B2C Commerce Einstein. You can think of product recommendations as *implicit* recommendations―in contrast to *explicit* recommendations that directly link objects together. B2C Commerce Einstein collects data and uses machine learning models to analyze the data and generate product recommendations.

Product recommendations are presented to shoppers as lists of product IDs. Einstein uses business rules—called *recommenders*—to control how these lists appear.
