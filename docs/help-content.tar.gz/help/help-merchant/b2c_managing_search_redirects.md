# Search Redirects

_Use the B2C Commerce guided search redirect feature to direct a customer to a particular page, URL, or pipeline when they enter a search term. When the customer searches on a term, for example, the redirect returns a specific page, instead of returning product search results for the entered search keyword. With search redirects, you have more control over what customers see, enhancing their buying experience, and directing them to content or products that increase the likelihood of a purchase._

### Managing Search Redirects

> **Note:** Redirect functionality doesn’t support redirects for static resources, such as images, at this time.

> **Note:** You can also configure whether to use HTTP or HTTPS for the destination protocol.

The following table shows some examples of possible search redirects.

| The customer searches on... | The redirect that appears is a... |
| --- | --- |
| career | Specific landing page. This gives the customer exactly the information they’re looking for, instead of performing an irrelevant product search. |
| featured product | A microsite that has a different look and feel, content, or buyer's guide information.  For example, you want to create a microsite around a group of movie-related products. |
| a specific term | Category page with a wide variety of equivalent products. |

### Search Redirect Options

Search redirect syntax options give you fine-grained control over how B2C Commerce triggers search redirects.

When the Search Redirect setting is *Disabled,* B2C Commerce processes keywords using the *Exact* match type. When the setting is *Enabled,* B2C Commerce processes keywords using any or all of the following match types: *Exact,* *Phrase,* *Broad,* and *Negative*.

> **Important:** There can be up to 1500 redirects per site.

> **Note:** Each search redirect can be triggered by multiple, comma-separated keywords.

### Exact Match

When the keyword phrase is enclosed in brackets, as in `[mens shoes]`, the redirect rule triggers when the customer searches for the specific phrase *mens shoes*, in that order, with no other words in the search term, and with no variations in the keywords (that is, `[mens shoe]` singular doesn’t trigger the rule).

This table shows an example:

| Keywords | Search redirect trigger for... | Search redirect not triggered for... |
| --- | --- | --- |
| `[mens shoes]` | mens shoes | red mens shoes men's shoes |
| `[sandal]` | sandal | red sandal mens sandal sandals |

### Phrase Match

When the keyword phrase is enclosed in quotation marks, as in "mens shoes", the redirect rule triggers when the customer searches on the phrase *mens shoes*, with the words in that order. It can also appear for searches that contain other terms as long as it includes the exact phrase specified.

This table shows an example:

| Keywords | Search redirect trigger for... | Search redirect not triggered for... |
| --- | --- | --- |
| "mens shoes" | mens shoes red mens shoes mens shoes large | shoes men men shoes men's shoes |
| "sandals" | sandals red sandals mens sandals | sandal sandale |

### Broad Match

When the keyword phrase contains *mens shoes*, with no quotation marks, the rule triggers when the customer's search term contains both *mens* and *shoes* in any order. The rule also triggers for singular or plural forms based on stemming for the specific language. Synonyms or other variations aren’t considered.

This table shows an example:

| Keywords | Search redirect trigger for... | Search redirect not triggered for... |
| --- | --- | --- |
| mens shoes | mens shoes cheap shoes for men buy mens shoes | mens shoes cheap shoes |
| sandal | sandals red sandals sandales | red mens |

### Negative Match

When the keyword phrase is prefixed with a hyphen, the rule will not trigger for any searches containing those terms. Negative keywords can only be used with at least one *positive* keyword. A search redirect containing only negative keywords won’t be triggered for any keyword. For example, the keywords *mens shoes, -used* triggers search redirects for *mens shoes* and *cheap shoes for men,* but not *used shoes.*

This table shows an example:

| Keywords | Search redirect trigger for... | Search redirect not triggered for... |
| --- | --- | --- |
| mens shoes, -used, -"running shoes" -basketball shoes, | mens shoes cheap shoes for men buy mens shoes shoes running | mens basketball shoes running shoes men used shoes |
| -shoes | none | any |

### How Search Redirects Work

B2C Commerce uses the *SearchRedirectURL* pipelet to integrate redirect evaluation into your storefront search flow. The *SearchRedirectURL* pipelet must be placed before the *Search* pipelet to make sure that the standard search is bypassed in case the user searches for a redirect keyword.

If the term matches a search redirect, the SearchRedirectURL pipelet calculates the fully qualified target URL based on the configured redirect action. The calculated URL can then be used in an Internet Store Markup Language (ISML) template to issue the actual HTTP redirect to the client browser. For an example, see the *Search-Show* subpipeline in SiteGenesis.

> **Note:** To download the SiteGenesis pipelines, create a storefront cartridge in Studio.

### Localization

For each search redirect, a list of keywords can be specified per locale. If there are no keywords defined for a specific locale for a search redirect, the standard locale fallback mechanism applies, as shown in the following example.

In this example, some locales have defined keywords and some don’t. The locales that don't have defined keywords use the keywords provided via the fallback mechanism.

| Locale | Keywords |
| --- | --- |
| en_US |  |
| en |  |
| de_DE |  |
| de_AT |  |
| de | Männerschuhe, Damenschuhe, -gebraucht |
| es_ES | "Zapatos de los hombres", "Zapatos de mujer", -utilizado |
| es |  |
| default | mens shoes, womens shoes, -used |

Keywords for the *default* locale are used when a customer browses using the *en_US* locale. This is because *en_US* defaults to *en,* which defaults to *default.* Both locales, *en_US* and *en*, use the default keywords: *mens shoes, womens shoes, -used*

The *<de>* locale is used when a customer browses using the *de_DE* or *de_AT* locale because both locales, containing no keywords, default to the *de* locale. A search by a customer in the es_ES locale uses the es_ES keywords and no fallback.

## Create Search Redirects

_You create search redirects to return a specific page, category, or URL when a customer searches on a particular keyword._

|  |
| --- |
| Available in: **B2C Commerce** |

1. Configure how search redirects are processed in [Search Preferences.](https://help.salesforce.com/s/articleView?id=cc.b2c_setting_search_preferences.htm&type=5)
2. Click App Launcher _(image: App Launcher)_, and then select ** *site*  > Merchant Tools > Search > Search Driven Redirects** to edit existing search redirects or create one.
3. On the Search Driven Redirects page, enter the keyword (target) you want to create a redirect for and click **Find**.

   You can also click **Advanced** or **User Phrase** and search for more detailed options. Make sure that the redirect doesn't exist before continuing.
4. Click **New** to create a redirect, or **Edit** on the row of an existing redirect.
5. On the New (Edit) Search Redirect page:

   1. Select the language and click **Apply**.
   2. Enter one or more words, separated by commas, that you expect the customer to enter when searching for a product.
   3. Select **Online** if you want the redirect to be online and used by B2C Commerce.
   4. Select **Secure** to use https for the destination protocol. Otherwise, http is used. If Enforce HTTPS is enabled for the site, HTTPS is used even if this option isn’t selected.
   
      The destination type URL still returns the defined path without considering the secure setting.
   5. Select the action you want the redirect to take when a customer enters the keyword in the search field.
6. Depending on the action you’ve selected, enter the Product ID, Category ID, Content ID, URL, or the Pipeline name required to complete the action.
7. Click **Apply**.

   When you’ve created your search redirects, locate them in the Business Manager via simple, advanced, or user phrase search.
