# SEO Support URL Syntax

_The SEO Support module is deprecated and scheduled for removal in a future release. Use the URL Rules module to optimize your storefront URLs. This topic applies to B2C Commerce._

This topic is based on the following URL example:

```
http://www.mystore.com/Software/G,default,sc.html
```

The following table illustrates the SEO URL generation pattern if search-friendly URLs are enabled and the merchant does not specify a pattern:

| URL part | Example Description | Example |
| --- | --- | --- |
| Protocol | Protocol | `http` |
| Host name | Host or domain name which needs to be defined under **Merchant Tools > Site > SEO & Discoverability > Aliases** | `www.mystore.com` |
| URL pattern | The content or pattern you supply for the URL pattern. This example uses the Salesforce B2C Commerce default pattern for a Category page, which is the pageURL attribute or displayName attribute for the category. | `Software` |
| Identifier | Set by the pageID, categoryID, or contentID, depending on the URL. In this case, it refers to the category ID of G. | `G` |
| Locale | Defines the locale, such as default or EN_US | `default` |
| Mapping identifier | Describes the pipeline to be used to get the desired content | `sc` |
| Page file extension | html file extension | `.html` |

### Alternative URL Encoding for Search-Friendly URLs

To use an alternative to the standard UTF-8 encoding, specify the `_ie` parameter as part of a query string for the URL. For example:

http://shop.com/foobar/sch%F6rm,default,pd.html?_ie=iso-8859-1

In this example, the product ID includes an encoded German umlaut "ö", which is encoded using ISO-8859-1.
