# Search Checklist for B2C Commerce

_The search checklist contains the tasks that can be performed to customize search in B2C Commerce. Outside of the basic search setup, most of these are optional but recommended._

We also recommend reading the [B2C Commerce - Site Search Platform Adoption Playbook](https://resources.docs.salesforce.com/rel1/doc/en-us/static/pdf/Commerce_Cloud_Site_Search_Platform_Adoption_Playbook.pdf), designed to help you serve relevant side search results to increase revenue.

### Basic Search Setup

| Task | Role | Complete |
| --- | --- | --- |
| Configure the search pipeline and search templates.  If you’re using SiteGenesis as starting point of your application the search pipeline is already configured. See also [Understanding the Search Pipeline](https://developer.salesforce.com/docs/commerce/b2c-commerce/guide/b2c-understanding-the-search-pipeline.html) and [SiteGenesis Application Search Implementation](https://salesforcecommercecloud.github.io/b2c-dev-doc/docs/current/LegacyDeveloperDocumentation.pdf). | Developer |  |
| [Configure Searchable Attributes](https://help.salesforce.com/s/articleView?id=cc.b2c_configure_searchable_attributes.htm&type=5)  To find products by an attribute, such as product name, make sure that the attribute is indexed and searchable. | Merchant |  |
| [Configure Search Preferences](https://help.salesforce.com/s/articleView?id=cc.b2c_setting_search_preferences.htm&type=5) | Merchant |  |
| Create a No Results Found Page | Developer |  |
| [Update Indexes](https://help.salesforce.com/s/articleView?id=cc.b2c_updating_indexes.htm&type=5) | Merchant |  |
| [Configure Index Rebuild Schedule](https://help.salesforce.com/s/articleView?id=cc.b2c_creating_a_search_index_rebuild_schedule.htm&type=5) | Merchant |  |

### Configure How Products Are Found on the Site 

| Task | Role | COMPLETE |
| --- | --- | --- |
| [Configure Synonyms](https://help.salesforce.com/s/articleView?id=cc.b2c_synonyms.htm&type=5) | Merchant |  |
| [Configure Hypernyms and Hyponyms](https://help.salesforce.com/s/articleView?id=cc.b2c_hypernyms.htm&type=5) | Merchant |  |
| [Configure Common Phrases](https://help.salesforce.com/s/articleView?id=cc.b2c_common_phrases.htm&type=5) | Merchant |  |
| [Configure Compound Words](https://help.salesforce.com/s/articleView?id=cc.b2c_compound_words.htm&type=5) | Merchant |  |
| [Configure Stop Words](https://help.salesforce.com/s/articleView?id=cc.b2c_stop_words.htm&type=5) | Merchant |  |
| Exclude Specific Category Names from Indexing | Merchant |  |
| [Configure Keyword Search Refinements](https://help.salesforce.com/s/articleView?id=cc.b2c_configuring_catalog_level_search_refinement_definitions.htm&type=5) | Merchant |  |
| [Configure Category Navigation Search Refinements](https://help.salesforce.com/s/articleView?id=cc.b2c_creating_new_search_refinement_definitions.htm&type=5) | Merchant |  |
| [Customize Search Suggestions](https://help.salesforce.com/s/articleView?id=cc.b2c_search_suggestions.htm&type=5) | Merchant |  |
| Create a Stemming Exception List | Merchant |  |

### Configure How Products Are Sorted in the Search Results

| Task | Role | COMPLETE |
| --- | --- | --- |
| [Create Sorting Rules](https://help.salesforce.com/s/articleView?id=cc.b2c_creating_sorting_rules.htm&type=5) | Merchant |  |
| [Configure a Default Sorting Rule for Results Returned by Keyword Search](https://help.salesforce.com/s/articleView?id=cc.b2c_creating_sorting_rules.htm&type=5) | Merchant |  |
| [Configure a Default Sorting Rule for Results Returned by Navigating to Category Landing Pages](https://help.salesforce.com/s/articleView?id=cc.b2c_sorting_rules.htm&type=5) | Merchant |  |
| [Configure Storefront Sorting Rules that Customers Can Use to Sort the Search Results](https://help.salesforce.com/s/articleView?id=cc.b2c_creating_storefront_sorting_options.htm&type=5) | Merchant |  |

### Configure How Products Are Found by External Search Engines

| Task | Role | COMPLETE |
| --- | --- | --- |
| [Configuring Host Aliases](https://help.salesforce.com/s/articleView?id=cc.b2c_configuring_hostname_alias.htm&type=5)  Create short, meaningful URLs for external search engines to index by assigning a short alias to a long hostname. | Developer |  |
| [Creating SEO URLs](https://help.salesforce.com/s/articleView?id=cc.b2c_configuring_seo_urls.htm&type=5)  Use the URL Rules module to change the URLs for your site and add information that can improve your search rank. | Merchant |  |
| [Generating Sitemaps](https://help.salesforce.com/s/articleView?id=cc.b2c_generating_sitemaps.htm&type=5) Create sitemaps for external search engines to improve freshness and completeness of data indexed by search engines. | Developer |  |
| [Generating a Robots.txt File](https://help.salesforce.com/s/articleView?id=cc.b2c_generating_a_robots_txt_file.htm&type=5) Add a robots.txt file to control portions of the site you don't want search engines to index. This can include non-html resources that can cause problems with indexing. | Developer |  |
| [Creating URL Redirects](https://help.salesforce.com/s/articleView?id=cc.b2c_url_redirects.htm&type=5) Add redirects from a legacy platform or redirect from an old Salesforce B2C Commerce category to a new category. | Merchant |  |

### Improve and Troubleshoot Search

| Task | Role | COMPLETE |
| --- | --- | --- |
| [Troubleshoot Search](https://help.salesforce.com/s/articleView?id=cc.b2c_troubleshooting_search_results.htm&type=5) | Merchant |  |
| [Use Search Analytics](https://help.salesforce.com/s/articleView?id=cc.b2c_using_search_analytics.htm&type=5) | Merchant |  |
