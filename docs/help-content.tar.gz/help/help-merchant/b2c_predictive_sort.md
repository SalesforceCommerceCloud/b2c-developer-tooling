# Predictive Sort

_Use B2C Commerce Predictive Sort to deliver tailored and relevant search results to shoppers via the predictive intelligence powered by B2C Commerce Einstein._

This capability is available for the following types of search:

- Explicit searches (search via the search box)
- Implicit searches (browsing in the storefront catalog)
- Enhanced search suggestions
