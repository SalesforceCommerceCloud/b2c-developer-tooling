# Categories for B2C Commerce

_You create and organize categories and subcategories to organize and group products in your catalog and on your storefront. For example, an outdoors outfitter site uses Boots, Climbing Gear, and Outerwear categories to organize products on their storefront. This topic applies to B2C Commerce._

## Related Content

- [Categories and Storefront Navigation for B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_categories_and_storefront_navigation.htm&type=5)
  With the proper settings, categories also provide your storefront navigation structure. This topic applies to B2C Commerce.

- [Categories and Products for B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_categories_and_products.htm&type=5)
  Assign products to more than one category within and across catalogs. This topic applies to B2C Commerce.

- [Categorization Rule Sets for B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_dynamic_categories.htm&type=5)
  Categorization rule sets automatically assign products to specific categories. To create a rule set, use attributes, operators, and values to define the conditions a product has to meet to be included in a particular category. This topic applies to B2C Commerce.

- [Create and Manage Categories for B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_create_and_manage_categories.htm&type=5)
  You use Business Manager to create categories and subcategories, and assign products to categories. This topic applies to B2C Commerce.
