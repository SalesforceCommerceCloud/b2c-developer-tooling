# Categories for B2C Commerce

_You create and organize categories and subcategories to organize and group products in your catalog and on your storefront. For example, an outdoors outfitter site uses Boots, Climbing Gear, and Outerwear categories to organize products on their storefront. This topic applies to B2C Commerce._
