# Fully Additive and Semi-Additive Meausres

_This topic applies to B2C Commerce. The Data subject area tables list for each subject matter area the fully additive and semi-additive measures included in the subject area set. Dimensions don't work with a semi-additive measure appear as Incompatible._

**Promotions**

| Measure | Fully Additive | Semi-Additive | Incompatible |
| --- | --- | --- | --- |
| Units Sold | Yes | No |  |
| Revenue Impact | Yes | No |  |
| Orders Placed | No | Yes | `productId, productName, skuId, skuName, isBundle, isMain, promotionId, promotionName, promotionClass, campaignId` |
| Uses | No | Yes | `productId, productName, skuId, skuName, isBundle, isMain, promotionId, promotionName, promotionClass, campaignId` |
| Promotional Order Discounts | Yes | No |  |
| Promotional Shipping Discounts | Yes | No |  |
| Promotional Product Discounts | Yes | No |  |

**Sales and Product–Order**

| Measure | Fully Additive | Semi-Additive | Incompatible |
| --- | --- | --- | --- |
| Units Sold | Yes | No |  |
| GMV | Yes | No |  |
| Orders Placed | Yes | No |  |
| Tax | Yes | No |  |
| Shipping | Yes | No |  |
| Promotional Order Discounts | Yes | No |  |
| Promotional Shipping Discounts | Yes | No |  |
| Promotional Product Discounts | Yes | No |  |
| Total Promotional Discounts | Yes | No |  |
| Total Manual Discounts | Yes | No |  |
| Total Discounts | Yes | No |  |

**Sales and Product–Product**

| Measure | Fully Additive | Semi-Additive | Incompatible |
| --- | --- | --- | --- |
| Units Sold | Yes | No |  |
| GMV | Yes | No |  |
| Orders Placed | No | Yes | `productId, productName, skuId, skuName, isMain, isbundle` |
| Tax | Yes | No |  |
| Promotional Product Discounts | Yes | No |  |

**Search**

| Measure | Fully Additive | Semi-Additive | Incompatible |
| --- | --- | --- | --- |
| Searches | Yes | No |  |
| Visits | No | Yes | searchPhrase |
| Orders Placed | No | Yes | `searchPhrase` |
| GMV | Yes | No |  |

**Technical–Controller Requests**

| Measure | Fully Additive | Semi-Additive | Incompatible |
| --- | --- | --- | --- |
| Controller Requests | Yes | No |  |
| Controller Processing Time | Yes | No |  |

**Technical–Included Controller Requests**

| Measure | Fully Additive | Semi-Additive | Incompatible |
| --- | --- | --- | --- |
| Included Requests | Yes | No |  |
| Included Processing Time | Yes | No |  |

**Technical–Open Commerce API (OCAPI) Requests**

| Measure | Fully Additive | Semi-Additive | Incompatible |
| --- | --- | --- | --- |
| OCAPI Requests | Yes | No |  |
| OCAPI Processing Time | Yes | No |  |

**Traffic**

| Measure | Fully Additive | Semi-Additive | Incompatible |
| --- | --- | --- | --- |
| Visit Count | Yes | No |  |
| Visit Converted Count | Yes | No |  |
| Total Visit Duration | Yes | No |  |
