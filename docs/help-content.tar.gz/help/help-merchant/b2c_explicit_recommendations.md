# Explicit Recommendations

_Create explicit relationships between recommendation *sources* and recommendation *targets*. This topic applies to B2C Commerce._

Explicit recommendations provide one method for enabling product recommendations on a site. These recommendations are called "explicit" because they require you to explicitly link recommendation *sources* (categories, products, or product sets) to recommendation *targets* (products or product sets).

You manually configure explicit recommendations in Business Manager. However, an administrator can also create an import feed to input large numbers of recommendations for your site in a single job execution.

Explicit recommendations are often referred to as *cross-sells* (recommend related products) or *up-sells* (recommend more expensive products), though you can define recommendations more granularly. For example, implement multiple types of cross-sells, categorized as family products, complimentary or accessory products, and competing products. These product placements can appear in the storefront under labels such as *What's New,* *May We Also Recommend,* *You Might Also Like,* and *Best Sellers.* They can appear in various sections of the storefront, most commonly on the home page, category display pages, product detail pages, and the shopping cart.

An explicit recommendation is a link from one product to a different product within Salesforce B2C Commerce. The initial product, or *source*, is either a product or a category. The other product is called the *target.* This link has an extensible type (for example, *cross-sell* or *up-sell*), used in the storefront application to identify the recommendation type.

Explicit recommendations have a catalog scope and represent a typed link between catalog objects, specific categories, and products. Although explicit recommendations are related to these catalog elements, they exist independently. Explicit recommendations are sorted across types, not within types. B2C Commerce doesn't maintain a separate sort order for recommendation types such as *cross-sell* or *up-sell.*
