# Image Management

_Use B2C Commerce's Image Management System to create a matrix of images for each product._

You use images on your storefront to enhance the customer buying experience. The Image Management System supports:

- Multiple images per product, along with multi-dimensional access to individual images and image subsets for variation products and variation product attributes
- Image annotation with alt text and image title
- Images located both within B2C Commerce and externally

> **Note:** Product image management relies on the explicit assignment of images to products. There is no pattern-based image lookup.

The Image Management System accesses images, from B2C Commerce and external systems, by their URL reference. You specify the image location in the context of a catalog. A catalog can either specify an internal or an external image location. The default location (if you haven’t specified a location) points to the related internal catalog base directory.

| System | URL Address |
| --- | --- |
| Internal | The system knows the first part of the URL (server address, other URL parts). You specify a base image path, for example, "/images/foo/". |
| External | You provide the first part of the URL. Specify an http URL or an https URL (protocol, server address, other URL parts). For example:  `http url = "http://www.yourimagelocation.com/foobar/"`   `https url = "https://yoursecureimagelocation.com/foo/bar/"` |

B2C Commerce stores the image location and relative image path separately.

- B2C Commerce stores the image location with the catalog.
- B2C Commerce stores the relative image path with the product (for example, "bar/your_image.gif").

> **Note:** Configure a product image URL with a path up to 1800 characters. Together with the host path configured with a catalog's image settings, you can specify image URLs with up to 2056 characters. If you try to configure a longer path, Business Manager shows a warning and doesn't let you save the image settings of that product.

> **Note:** The API class dw.content.MediaFile provides a complete URL based on both parts. See the B2C Commerce API documentation for more information.

When assigning images to products, consider the following:

- View Types
- Image Variants
- Swatches
- Image Annotations
- Image Storage
- Image Transformation The image transformation service.

For additional information, see:

- [Dynamic Imaging Service Implementation Guide](https://resources.docs.salesforce.com/rel1/doc/en-us/static/pdf/DISImplementationGuide.pdf)
- [Dynamic Imaging Service FAQ](https://resources.docs.salesforce.com/rel1/doc/en-us/static/pdf/CommerceCloud_DynamicImagingService_FAQ.pdf)
