# Image Management

_Use B2C Commerce's Image Management System to create a matrix of images for each product._

You use images on your storefront to enhance the customer buying experience. The Image Management System supports:

- Multiple images per product, along with multi-dimensional access to individual images and image subsets for variation products and variation product attributes
- Image annotation with alt text and image title
- Images located both within B2C Commerce and externally

> **Note:** Product image management relies on the explicit assignment of images to products. There is no pattern-based image lookup.

The Image Management System accesses images, from B2C Commerce and external systems, by their URL reference. You specify the image location in the context of a catalog. A catalog can either specify an internal or an external image location. The default location (if you haven’t specified a location) points to the related internal catalog base directory.

| System | URL Address |
| --- | --- |
| Internal | The system knows the first part of the URL (server address, other URL parts). You specify a base image path, for example, "/images/foo/". |
| External | You provide the first part of the URL. Specify an http URL or an https URL (protocol, server address, other URL parts). For example:  `http url = "http://www.yourimagelocation.com/foobar/"`   `https url = "https://yoursecureimagelocation.com/foo/bar/"` |

B2C Commerce stores the image location and relative image path separately.

- B2C Commerce stores the image location with the catalog.
- B2C Commerce stores the relative image path with the product (for example, "bar/your_image.gif").

> **Note:** Configure a product image URL with a path up to 1800 characters. Together with the host path configured with a catalog's image settings, you can specify image URLs with up to 2056 characters. If you try to configure a longer path, Business Manager shows a warning and doesn't let you save the image settings of that product.

> **Note:** The API class dw.content.MediaFile provides a complete URL based on both parts. See the B2C Commerce API documentation for more information.

When assigning images to products, consider the following:

- View Types
- Image Variants
- Swatches
- Image Annotations
- Image Storage
- Image Transformation The image transformation service.

For additional information, see:

- [Dynamic Imaging Service Implementation Guide](https://resources.docs.salesforce.com/rel1/doc/en-us/static/pdf/DISImplementationGuide.pdf)
- [Dynamic Imaging Service FAQ](https://resources.docs.salesforce.com/rel1/doc/en-us/static/pdf/CommerceCloud_DynamicImagingService_FAQ.pdf)

## Related Content

- [Manage Images](https://help.salesforce.com/s/articleView?id=cc.b2c_managing_images.htm&type=5)
  Use the Image Management System to create a matrix of internal or external images that 's associated with products.

- [View Types](https://help.salesforce.com/s/articleView?id=cc.b2c_understanding_view_types.htm&type=5)
  Use *view types* to group images according to usage context, for example, by the image's size. This topic applies to B2C Commerce.

- [Image Variants](https://help.salesforce.com/s/articleView?id=cc.b2c_working_with_image_variants.htm&type=5)
  There are four standard view types: large, medium, small, and swatch. You can represent each product with multiple images per view type. This topic applies to B2C Commerce.

- [Swatches](https://help.salesforce.com/s/articleView?id=cc.b2c_working_with_swatches.htm&type=5)
  A swatch image typically shows the key difference between variation products in relation to a product variation attribute. This topic applies to B2C Commerce.

- [Annotate Images](https://help.salesforce.com/s/articleView?id=cc.b2c_annotating_images.htm&type=5)
  Explicitly annotate each image assignment with a combination of relative image path, view type or variation product, and a localizable *alt *description and image title. This topic applies to B2C Commerce.

- [Salesforce B2C Commerce Image Storage](https://help.salesforce.com/s/articleView?id=cc.b2c_demandware_image_storage.htm&type=5)
  B2C Commerce supports three static content locations where it stores images.

- [Dynamic Imaging Service](https://help.salesforce.com/s/articleView?id=cc.b2c_image_transformation_service.htm&type=5)
  The B2C Commerce Dynamic Imaging Service eliminates the need to upload different-sized images to meet your storefront requirements. After you upload a high-resolution source image, Dynamic Imaging formats the correct size for each image application—your product page, catalog page, recommended products, search results, and so on. Apply parameters to control image size, crop, overlay, format, background color, and quality settings.

- [Image Transformation URL Structure, Validation, and Order of Operations](https://help.salesforce.com/s/articleView?id=cc.b2c_image_transformation_url_structure.htm&type=5)
  Image transformation requests use a /dw/image/v2/ path and query string. The B2C Commerce Dynamic Imaging Service applies those parameters in a fixed order.

- [Responsive Images and Modern Image Formats (AVIF and WebP)](https://help.salesforce.com/s/articleView?id=cc.b2c_image_transformation_responsive_formats.htm&type=5)
  Load AVIF and WebP for smaller file sizes with modern browsers, and use JPEG (or PNG for lossless or transparency) as a fallback. Output formats, quality, and the URLUtils and MediaFile rules for DIS are in the Dynamic Imaging Service topic.

- [Optional community DIS product image wrapper](https://help.salesforce.com/s/articleView?id=cc.b2c_image_transformation_community_wrapper.htm&type=5)
  The optional open-source dis-product-image-wrapper project helps some Salesforce Reference Architecture (SFRA) and SiteGenesis projects centralize product image parameters and use JavaScript helpers. It isn't a required replacement for URLUtils and MediaFile from the B2C Commerce API.

- [Troubleshooting and migration](https://help.salesforce.com/s/articleView?id=cc.b2c_image_transformation_troubleshooting_and_migration.htm&type=5)
  When a B2C Commerce Dynamic Imaging Service image URL fails, times out, or looks wrong, check the source file, the full URL, and the limits documented in the Dynamic Imaging Service topic. This topic also helps you migrate from other hostnames and from Adobe Scene7 (Dynamic Media) query strings.

- [Related Dynamic Imaging Service Topics](https://help.salesforce.com/s/articleView?id=cc.b2c_dynamic_imaging_service_overview.htm&type=5)
  Find B2C Commerce Dynamic Imaging Service help on URL path structure, order of operations, responsive formats, an optional community project, and troubleshooting.
