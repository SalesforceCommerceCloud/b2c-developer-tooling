# Create a Library Folder in B2C Commerce

_Use Business Manager to define or edit a hierarchical folder structure for your content assets._

|  |
| --- |
| Available in: **B2C Commerce** |

The Library folder page shows the subfolders that exist in your site library, which can be either a private or a shared library.

> **Note:** Create pages that include a sorted list of content assets from a library folder. In this case, use a sorted list of assets from *ViewContentList-List,* which you can get on the Library Folders page. This sorted list is also useful when you create a content area in a project.

1. Click App Launcher _(image: App Launcher)_, and then select **Merchant Tools > *site* > Content > Libraries**. Click a library link.

   If you see unavailable fields, you have read-only permission. Browse libraries, search for content assets, and read content asset data. But you can't modify data in these modules. If you have mixed permission to access one module (via different roles), the higher-level access is granted. See your administrator if you require write access.
   
   Libraries, library folders, and content assets are organized in a hierarchy. The hierarchy prescribes that roles with Read or Write access for libraries, library folders, and content assets require the same access level.
2. On the Library Folders page, click **New** or a library folder **Edit** link.
3. On the General tab, enter or edit the information and click **Apply**.

   The custom CSS file loads for all content assets in the library folder (or its subfolders) when the content assets are returned as part of a content search.
4. On the Content Attribute Groups tab, define content attributes for all assets bound to a library folder.

   Use this feature, for example, to exclude some content assets from use by some sites. See Creating Custom Object Types.
5. On the Search Refinements tab, specify any search refinements.
6. On the Page Meta Tag Rules tab, create and manage page meta tags.
7. Click **Back to List** to return to the Library Folders page.
8. To create subfolders:

   1. Click the **ID** link of the folder where you want to create a subfolder.
   2. Click **New** under the Library Folders section:
   3. On the New Library Folder page, specify the new folder definition and click **Apply**.
   4. On the Library Folder page, click **<<Back to List** to view the parent folder page with the new subfolder listed.
   
   All folders can contain content assets. You can organize content assets in more than one folder or subfolder.
