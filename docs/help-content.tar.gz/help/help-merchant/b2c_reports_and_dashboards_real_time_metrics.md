# Reports & Dashboards: Real-Time Performance

_This topic applies to B2C Commerce Reports & Dashboards. All users can view live sales metrics, such as the number of orders and baskets created._

> **Note:** The Real-Time Performance dashboard is available only for production instances. It is not available for non-production instances such as on-demand sandboxes (ODS), Development instances, or Staging instances.

Sales Metrics

Metric Description   Basket Creations The number of baskets created across all sites per minute.   Basket Updates The number of basket updates (products added or removed) across all sites per minute.   Orders The number of orders created across all sites per minute. The report doesn’t update for failed or canceled orders.

Performance Metrics

Metric Description   Sessions The number of active sessions across all sites per minute.   Requests The number of main page requests made across all sites per minute. The report doesn’t track Includes or Open Commerce API (OCAPI) requests.   System Workload The percentage of realm resources utilization per minute.
