# Defining Feeds

_Create feeds for the *costPrice* and *returnRate* attributes to use all the system attributes calculated for *ProductActiveData.*_

Optionally feed in values for the *availableDate* attribute. If you don't feed in the *availableDate,* Salesforce B2C Commerce uses the *creationDate* attribute instead. The system created this attribute when you added a product. If you create additional custom active data attributes, you must feed those in as well.

You might want to create different feeds if the attributes you are importing require a different import frequency (daily versus weekly) or if they are being fed from different backend systems. Create a maximum of three feed definitions.

1. Click App Launcher _(image: App Launcher)_, and then select **Merchant Tools > Online Marketing > Active Data > Feed Definitions**.
2. On the Feed Definitions page, in the Product Active Data section, click **New**.
3. On the New Active Data Feed page, enter the details:

   | Option | Description |
   | --- | --- |
   | ID | You might want to include the name of the system or the frequency of the feed in the name. |
   | Fresh Period | The number of days before the data is considered stale. |
   | Column Allocation | Transfer the attributes you are importing to the In this feed list in the order they appear in the .csv feed file you want to import. |
   
   Any custom attributes you have created for the `ProductActiveData`and `CustomerActiveData` system objects are automatically available as well in the column list.
4. Click **Apply**.

   To copy a feed definition to another instance, use Site Import/Export.

As a next step, create the feed files that use this definition to import values for the attributes.
