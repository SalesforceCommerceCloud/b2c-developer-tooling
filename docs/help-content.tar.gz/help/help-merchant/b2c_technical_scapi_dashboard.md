# Technical Salesforce Commerce API (Shopper Commerce API (SCAPI)) Dashboard

_The B2C Commerce Reports & Dashboards Technical SCAPI Dashboard provides insight into your site’s SCAPI requests. The report metrics update daily. All times are in Greenwich Mean Time (GMT)._

**Average Response Time**

The Average Response Time report shows the trend of average response time per request. Response time appears in milliseconds. The graphs plots response time points for each day during the selected period. To see response times, hover over the plot line. Track controller response time to troubleshoot and identify your resource optimization.

**Cache Hit Ratio**

The Cache Hit Ratio report shows three ratios for the selected time period, cache hit, cache miss and store, and cache miss.

- The Cache Hit report is the percentage of responses retrieved from the web adapter page cache.
- Cache Miss and Store is the percentage of responses created by an appserver, marked as cacheable, and stored in the web adapter page cache.
- Cache Miss is the percentage of responses not retrieved from the web adapter page cache.

**Request Report**

The number of requests for filtered SCAPI resources per day.

**Non200-Level Responses**

The Non200-Level Responses report plots trended frequency as a percent of total requests that resulted in a non200-level response code during the dashboard time period. To see the number and type of non200-level response for a day, hover over a plot point on the graph.

**Response Time Distribution**

This report shows the number of requests by response time in 500-millisecond segments. For example, during the dashboard period, a site received 10 million requests. And, 7 million requests had a response time of 0-400 milliseconds. Also, 3 million requests had a response time of 500-999 milliseconds. The bar graph shows the number of requests in each response segment, and the percentage of total responses represented. Review the performance of your system and controllers. A peak in response time coupled with a high number of controller requests can indicate a controller issue.

**SCAPI Requests**

This report lists the SCAPI API request during the dashboard time period. Use the report to track SCAPI API use and response times.
