# Category Name Exclusions

_Excluded category names aren't indexed as keywords for the product and aren't included in search phrase suggestions. This is useful for combination categories with subcategories with distinct products._

For example, if your storefront has a kitchen and bath category and the customer searches for kitchen, you don't want bath items to be included in the search result because of the kitchen and bath category name that is inherited by all products in that catalog tree.When referencing catalog or category names that contain commas, prefix the comma with a backslash. For example, Shampoo\, Conditioner\, and Body Wash.

However, don't exclude categories if they contain products that aren't assigned to subcategories or additional categories that can be indexed. There can also be combination categories that you don't want to exclude, such as headphones and earbuds, where you want related products to appear. For example, if a customer searches for headphones, lower-cost earbuds can also appear in the search.

### Common Pitfalls

Lack of Exact Name Matching: Category name exclusions require an exact match of the category display name. The feature doesn't make inferences and there's no inheritance down the category chain.

Improper Formatting for Commas: For category names that contain commas (such as "Renew & Refresh, Skincare, Hair Care, and Body Care"), insert a backslash before each comma to "escape" it so the system reads the category name correctly.

Incomplete Index Rebuilding: To apply a category name exclusion, rebuild the entire product index. This differs from updating synonyms or hyponyms, which only require rebuilding the synonym index.

Category Path Behavior: The exclusion feature only prevents words from the specifically excluded category from being indexed against a product. If a product also exists in another similar, non-excluded category, it's still indexed and returned in those search results.
