# Configure Promotion Preferences for B2C Commerce

_Configure many of the promotion settings as site preferences, giving you much flexibility in how your promotions are handled. These settings include Buy X/Get Y promotion behavior, discount precision, and how the tax basis is calculated for line items with discounts._

|  |
| --- |
| Available in: **B2C Commerce** |

The steps explain each preference, how it works, and the difference between options.

1. Click App Launcher _(image: App Launcher)_, and then select **Merchant Tools > Site > Site Preferences > Pricing and Promotions**.
2. Configure Buy X/Get Y promotion behavior.

   | Option | Description |
   | --- | --- |
   | Discount Next Most Expensive Products (default) | Qualifying products are the X most expensive products satisfying the promotion's qualifying product rule. Products receiving the discount are the Y next most expensive (or same price) of the remaining products satisfying the promotion's discounted product rule. Discounted items must be less expensive than related qualifying item price. |
   | Discount Least Expensive Products | Qualifying products are the X most expensive products satisfying the promotion's qualifying product rule. Products receiving the discount are the Y least expensive of the remaining products satisfying the promotion's discounted product rule. Discounted items are less expensive than the related qualifying item price. |
3. Configure Buy X/Get Y discount eligibility.

   This setting only applies to Buy X/Get Y promotions and not Buy X and Y Get Z or other promotion types. For those promotions, the maximum price on the discounted products setting always describes the promotion discount behavior.
   
   | Option | Description |
   | --- | --- |
   | Maximum Price on Discounted Products (default) | Only products with a price less than or equal to the least expensive qualifying product are eligible to receive the discount. This setting prevents the creation of promotions that increase the price of the discounted product. |
   | All Products Eligible for Discounts | Products that satisfy the promotion discount rule are eligible to receive the discount. This setting is only relevant for promotions with discounted products that aren't identical to qualifying products. |
4. Configure price book discount behavior.

   | Option | Description |
   | --- | --- |
   | Discount Allowed To Increase Item Price (Default) | Discounts can increase the price of an item in the cart. This isn't a good idea. |
   | Discount Not Allowed to Increase Item Price | Prevents Price from Price Book discounts from increasing the price of an item in the cart. For example, your promotion uses two price books. The sales price for a product in one price book is greater than the standard price in the other price book. |
5. Configure bonus product positioning.

   Use this setting to control where bonus products appear in the cart. It only applies to product promotions `with number of qualifying products` that grant a `bonus` product discount.
   
   | Option | Description |
   | --- | --- |
   | Always at End of Cart (default) | Bonus products go to the end of the basket with a quantity of 1. |
   | After Qualifying Products | Bonus products appear after their qualifying products, and are consolidated together if their quantity is greater than 1. |
6. Configure discount precision.

   Half-way values, both positive and negative, are often rounded up. This practice is called half-up rounding, and it's commonly used. For example, the value 23.5 is rounded to 24, while the value −23.5 is rounded to −23.
   
   | Option | Description |
   | --- | --- |
   | Precision of Site Currency (default) | Discounts are calculated based on the precision of site currency. The rounding mode is half-up. |
   | No Fractions | Discounts are always rounded to the full amount and contain no fractions (that is, precision=0). The rounding mode is half-up. |
7. Configure discount taxation.

   | Option | Description |
   | --- | --- |
   | Tax Products, Shipping, and Discounts Based on Price (default) | All line items are taxed separately using net or gross price as tax basis. Product and shipping costs receive a positive tax, while price adjustments receive a negative tax. |
   | Tax products and Shipping Only Based on Adjusted Price | Price adjustments aren’t taxed. Instead, product line items use prorated price and shipping line items use adjusted price as the tax basis. Tax values are positive or zero. |
8. Configure multiple coupon codes per order promotion.

   | Option | Description |
   | --- | --- |
   | Coupon Code Stacking Prevented (default) | Prevent redemption of multiple coupon codes in an order promotion. |
   | Coupon Code Stacking Allowed | Allow multiple coupon codes to be redeemed in an order promotion. When this setting is enabled for a coupon, it is only validated at the coupon add-time. |
9. Configure Shop the Future.

   | Option | Description |
   | --- | --- |
   | Disabled (default) | Future promotions aren’t available for shoppers during checkout. |
   | Enabled | Shoppers can use promotions active on a future date. To retrieve promotions that are active within a particular time window, set an effective date. See [Shop the Future](https://developer.salesforce.com/docs/commerce/commerce-api/guide/shopper-context-api-future.html). |
10. Enter the Maximum Product Promotions Per Basket. Enter the default value 0, if there’s no limit on product promotions.
11. Enter the Maximum Order Promotions Per Basket. Enter the default value 0, if there’s no limit on order promotions.
12. Enter the Maximum Discount Amount Per Basket. Enter the default value 0, if there’s no limit on discounts.
13. Save your changes.
