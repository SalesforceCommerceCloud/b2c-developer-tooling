# SEO Best Practices for B2C Commerce

_Consider the following actions when optimizing your storefront for external search engines and AI-powered search and answer engines. This topic applies to B2C Commerce._

### URL Best Practices

- Create URLs that are 70 characters or less.
- Use name attributes, rather than ID attributes, as they're more meaningful.
- Use encoding to manage non-alphanumeric characters.
- Specify a trailing slash for all URLs, so that search engines don't penalize you for having URLs with and without trailing slashes that both point to the same content.
- Include the name of your business in all URLs.
- Use the description meta tag correctly so that Google can create search snippets for products. Descriptions should be:
   
   - unique
   - contain some keywords, but not overuse them
   - be relevant and specific to page content
   - be 156 characters or less
- Create canonical URLs for variation products.
- Don't use odd capitalization of URLs (lowercase preferred). This includes your company name, if it normally includes mixed case.
- Don't have pages from subdomains and the root domain access the same content. For example, don't have `domain.com/page.htm` and `sub.domain.com/page.htm` contain the same content.
- Create redirects if parts of the URL are removed.
- Make links in the page meaningful and unique.
- Have categories in the URL only nested two or three levels deep. This is accomplished by flattening your site navigation where possible.

### General SEO Best Practices

- Learn, understand, and stay current with SEO trends.
- Follow the recommended process for keyword maintenance.
- Continually create content in support of your merchandise.
- Give careful consideration to your site copy to ensure that relevant terms and keywords are well represented.
- Don't focus on just one search engine, take a multi-pronged approach.
- Take advantage of all the free tools on the market.
- Identify where paid-for subscriptions and tools can provide real value and time savings.
- Don't forget PPC in your search marketing strategy.
- Ensure that key content is present in server-rendered HTML. AI crawlers and some traditional search engine crawlers don't execute JavaScript, so content that loads only on the client side is invisible to them. Verify that product names, descriptions, and prices appear in the initial HTML response.
- Use HTML tags correctly. Google and other search engines prefer you use semantically meaningful code, such as h1 or other heading tags that are used to present important information, rather than to create style effects. If you use headings, lists, and other HTML tags to convey information about the significance of the text and confine styling to your CSS, you produce cleaner code with a better SEO ranking.
- Generally, construct URLs that are brief and meaningful.
- Consider adding canonical URLs.

See also [Common SEO Pitfalls](https://help.salesforce.com/s/articleView?id=cc.b2c_common_seo_pitfalls.htm&type=5).

### Content-Creation Best Practices

Use a CSS file for a consistent and sophisticated look and feel. CSS along with clean tagging also has SEO benefits, which are described below. The toolbar adds formatting through span styles, which aren't optimal for SEO. The following recommendations for how you tag content can improve SEO results and create cleaner, more maintainable code.

Use the following recommendations for coding content:

- Control the look and feel of your content through CSS, not through the selection of HTML tags. The HTML tags should reflect how important content is, not how it should look. External search engines use tags to determine what content is most important for your page, so if you use tags in a meaningful way, your SEO results improve.
- Use tags in the following ways:
   
   | Tag | Usage |
   | --- | --- |
   | b | Text that should stand out, but has no greater importance than the rest of the text. |
   | cite | Book titles or other published media. |
   | em | Text in an alternate voice or mood that should be emphasized by screen readers or other interpretive devices. This improves the experience for visually impaired customers or other customers that must use screen readers to access your storefront. |
   | i | Text that is in an alternate voice or mood, but has no greater importance than the rest of the text. For example, a phrase in a foreign language or the Latin taxonomy of a plant or animal. |
   | strong | Text that should stand out, and which has greater significance than other text. For example, the name of a sale, the name of a product or brand, or a keyword for the page. |

### AI Discoverability Best Practices

AI-powered search and answer engines crawl your storefront to generate responses for shoppers. The following practices help ensure your content is accurately interpreted and cited by these systems.

- Write product descriptions in clear, natural language as if describing the product to another person. Avoid relying solely on technical specifications or keyword lists.
- Use a logical heading hierarchy on every page. Each page should have a single `h1` for the primary subject (for example, the product name on a PDP). Use `h2` and `h3` tags to organize supporting content such as features, specifications, and reviews.
- Add descriptive `alt` text to all product images so that crawlers can interpret visual content.
- Use internal crosslinks between related pages (for example, linking from a product page to its category, related products, or buying guides) to help crawlers discover and contextualize your content.
- Consider adding FAQ or Q&A sections to product and category pages. AI models favor content structured as direct question-and-answer pairs because it maps naturally to user queries.
- Add structured data markup (such as JSON-LD using `schema.org` types like `Product`, `Offer`, and `AggregateRating`) to help both traditional search engines and AI crawlers interpret your page content accurately.
- Review your robots.txt configuration to ensure that AI crawlers can access the content you want to be discoverable. See [Generate a Robots.txt File with Business Manager](https://help.salesforce.com/s/articleView?id=cc.b2c_generating_a_robots_txt_file.htm&type=5).
