# Localize a Content Block

_Create locale-specific versions of a content block so that localized content appears on your storefront for each target locale._

|  |
| --- |
| Available in: **B2C Commerce** |

To localize content blocks, your role must include the Manage_All_Libraries functional permission in the organization context, or Manage_Site_Library in the context of the site.

Content blocks support localization through locale settings. You start with a base-language version and then add localized versions for each target locale.

1. Open the page containing the content block in Page Designer.
2. Select the locale from the locale selector.
3. Select the content block you want to localize.
4. In the right pane, click the dropdown menu next to the content block name.
5. Select **Localize**.
6. Edit the content block attributes for the selected locale.

   Update only the content that requires translation or locale-specific changes. The content block retains the styling and layout attributes from the original.
7. Click **Apply**.

The content block now has a locale-specific version. Changes to this version affect only storefront pages using the selected locale.
