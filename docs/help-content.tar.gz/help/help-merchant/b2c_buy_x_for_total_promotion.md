# Buy X for Total Promotion in B2C Commerce

_Use the Buy X for Total promotion type for products with the same retail value or different prices. This topic applies to B2C Commerce._

For products with the same retail value, an example is Buy any two gifts that cost $5 each for only $8 (save $2). For products with different values, an example is Product A is $6, product B is $5 and product C is $5.50. The shopper can buy any two items for $8 to save $2 to $4.

> **Note:** Separate qualifying and discounted products aren’t supported. Tiering is supported for discounted products, not qualifying products.

### Discount Processing

Salesforce B2C Commerce prorates the savings across multiple products and distributes them evenly across all discounted products.

- For product discounts, the price adjustments display beneath product line items, representing a negative amount calculated for the specific discount.
- For order discounts, the price adjustment is the amount of the order discount, prorated based on individual units, features, and other quantity fields.

The actual discount is the difference between the original price and the price defined by the promotion.

- For a standard fixed-price discount, the fixed price applies per product item.
   
   For example, the product unit price is $10 and the fixed-price discount amount is $8. The price adjustment is the $2 difference between the two prices.
- For a Buy X for Total fixed-price promotion with multiple prices, B2C Commerce calculates the savings based on multiple products. It then distributes the savings evenly across all discounted products.

If the non-discounted price of the total group of items is less than the discounted price, the price doesn't raise to the discounted price.

### Example

You' run the promotion Buy 3 shirts for $22.

The shopper's cart has:

| Shirt color | Number ordered | Unit price |
| --- | --- | --- |
| Red | 2 | $13 |
| Blue | 2 | $12 |

The price adjustments are as follows:

| Shirt color | Number ordered | Unit price | Adjusted price | Discount per item |
| --- | --- | --- | --- | --- |
| Red | 2 | $13 | $10.95 | $5.47 |
| Blue | 1 | $12 | $5.05 | $5.05 |

Here's a breakdown of the discount calculation:

1. Discount fixed-price: $22
2. Applicable discounted products: 2 x Red Shirt, 1 x Blue Shirt
3. Total price applicable discounted products: 2 x $13 + 1 x $12 = $38
4. Total savings: $38 - $22 = $16
5. % savings: 16/38 = 0.421 (that is, 42.1%)
6. Price adjustment per red shirt item: $13 * 0.421 = -$5.47
7. Price adjustment per blue shirt item: $12 * 0.421 = -$5.05

The promotion applied on two red shirts, but only one blue shirt, because the red shirt is more expensive and discounting it gives the better deal.

### Tiering Example

A tiered Buy X for Total Fixed-Price promotion differs from other tiered promotion types. Usually, only the highest applicable tier applies. For example, Buy 2 or more, get them for $10 each. Buy 4 or more, get them for $9 each.

For Buy X for Total fixed-price promotions, all tiers can apply, depending on the number of items in the cart.

For example, a merchant offers a promotion: Buy 2 shirts for $20, 3 shirts for $22, with no application limit. The basket contains five discounted products.

| Shirt color | Number ordered | Unit price |
| --- | --- | --- |
| Red | 3 | $14 |
| Blue | 2 | $12 |

The three red shirts qualify for the second tier. The remaining two blue shirts qualify for the first tier.

| Shirt color | Number ordered | Promotion | List price | Adjusted price | Discount |
| --- | --- | --- | --- | --- | --- |
| Red | 3 | 3 for $22 | $42 | $22 | $20 |
| Blue | 2 | 2 for $20 | $24 | $20 | $4 |
