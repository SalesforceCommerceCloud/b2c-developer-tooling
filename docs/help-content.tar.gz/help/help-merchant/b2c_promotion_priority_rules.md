# B2C Commerce Promotion Priority Rules

_Promotion priority rules exist to prevent unpredictable or undesirable effects when multiple promotions are applicable for a basket. These rules are hardcoded but you can adjust certain promotion attributes, such as exclusivity and rank, to manipulate promotions application. B2C Commerce doesn't evaluate all sequences of promotions. The sequencing resulting from prioritization doesn't always provide the best value to shoppers. This topic applies to B2C Commerce._

### External

B2C Commerce applies promotions entered programmatically through APIs, that aren't represented by promotions in the system, before promotions entered through Business Manager.

### Default Priority Order

Promotions are categorized by exclusivity. The exclusivity categories are processed in the following order:

1. Global Exclusive
2. Class Exclusive Product
3. Non-Exclusive Product
4. Class Exclusive Order
5. Non-Exclusive Order
   
   > **Note:** Order promotions are calculated based on merchandise total. After order promotions apply, order-level discounts are prorated across all products in the order.
6. Class Exclusive Shipping
7. Non-Exclusive Shipping

Within each category, promotions are prioritized in the following order:

1. Promotions part of AB tests (starting with the lowest rank)
2. Promotions part of campaigns (starting with the lowest rank)
   
   > **Note:** Rank is an optional, numeric attribute that you can specify to determine application priority. Ranked promotions are calculated before unranked promotions. If two promotions have a rank, the promotion with the lowest rank is calculated first.
3. By discount type
4. By discount amount
5. Alphabetically by ID

### Discount Type and Value

In general, promotions are sorted by discount type in the following order:

1. Fixed price
2. Total fixed price
3. Free
4. Price book price
5. Amount-off
6. Percent-off
7. Bonus-product
8. Choice of bonus products
9. Free product-shipping
10. Fixed price product-shipping

If there are multiple promotions of the same discount type, they’re sorted so that promotions providing the best value to the shopper are evaluated first. Promotions can be tiered and offer multiple discounts. When B2C Commerce prioritizes two promotions by discount, it pre-evaluates the discount tiers of each and determines which tier, if any, apply for each. For example, a promotion had two tiers, buy 3 or more of product PXget $5 off and Buy 5 or more of product X and get 30% off.

A basket has four of product X. The lower discount tier ($5 off) is the pre-evaluated discount, so the discount type is amount-off. After this pre-evaluation process, each promotion is associated with zero or one discounts.

Promotions are then sorted by discount type according to the following sequence.Simple discounts apply in the following order: fixed, amount-off, percent-off. If two promotions have the same pre-evaluated discount type, the promotion that offers the shopper the best value is prioritized first. For example, a promotion offering 20% off takes priority over a promotion offering 10% off.

> **Note:** If there are multiple fixed-price (or total fixed price or free) promotions, the order of application is irrelevant because fixed-price promotions don't stack. B2C Commerce has special logic so that if multiple fixed-price promotions qualify, only the best value promotion applies.

### Maximum Application

Setting a maximum application affects the order that product promotions apply and when the discount calculation occurs. When a promotion with a maximum application applies, the most expensive product is discounted first, followed by the second most expensive, until the maximum application limit is reached.

For example, you have two promotions.

- Promotion 1 - Buy three shirts and get a free silk tie - maximum application 2
- Promotion 2 - Buy three shirts and get 20% off - maximum application 1

The customer buys six shirts: two of Shirt A costing $100 each, two of Shirt B costing $75 each, and two of Shirt C costing $50 each.

According to promotion priority rules, percent off applies first, followed by bonus - so Promotion 2 applies first. It discounts the most expensive shirts to give the shopper the best deal.

```
3 shirts (2 at $100 and 1 at $75) for 20% off, with one application.
$275 - $55 (discount) = $220
```

If exclusivity is None, per Promotion 1, the customer also receives two silk ties. If exclusivity is Class or Global, Promotion 1 doesn't apply.

Percent off contrasts with buy x get y discount, where if the same products are eligible as qualifying and conditional products, the promotion sorts the products based on price. The promotion uses the most expensive products to satisfy the condition. The discount applies to the next product in the list that is of equal or lesser value to the conditional products, depending on the site promotion preference setting. See [Buy X Get Y Promotions.](https://help.salesforce.com/s/articleView?id=cc.b2c_buy_x_get_y_promotions.htm&type=5)

### Example

In this example, a merchant has ranked promotions as follows:

| Promotion Name | Description | Rank |
| --- | --- | --- |
| Prod1 | 10% off product | 60 |
| Prod2 | $2 off product | 0 |
| Prod3 | $1 off product | 0 |
| Prod4 | $2.99 product fixed price | 30 |
| Ord1 | 15% off order | 70 |
| Ord2 | 20% off order | 65 |
| Ord3 | $5 off order | 0 |

The basket with applied discounts shows the discounts applied in the following order:

1. Product:
   
   1. Prod4: $2.99 product fixed price
   2. Prod1: 10% off product
   3. Prod2: $2 off product
   4. Prod3: $1 off product
2. Order
   
   1. Ord2: 20% off order
   2. Ord1: 15% off order
   3. Ord3: $5 off order
