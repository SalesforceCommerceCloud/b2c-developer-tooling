# Active Merchandising Scenarios

_These scenarios demonstrate how you can use active merchandising data to facilitate your searchanding and personalize merchandising activities. Searchandising is where you configure sorting rules to rank search results, while personalized merchandising is where you show slot content that targets specific customer groups. Both are based on an analysis of active data metrics. This topic applies to B2C Commmerce._

### Scenario 1: Overstock

A merchant is overstocked on power drills. The merchandiser wants to make sure that any search or browse that includes power drills elevates those products, by order of their level of overstock.

The merchant creates a sorting rule that sorts products in descending order of TTOOS (time to out of stock). Because B2C Commerce calculates this order in real time, based on inventory levels, the merchant can skip creating a feed.

### Scenario 2: Hot Items

A bookseller wants to control the balance of search results shown between New Arrivals and Bestsellers.

The merchant creates a rule that sorts using a dynamic attribute, hotItem. HotItem blends Sales Velocity (descending, average, 60% weighting) and Age (ascending, minimum, 40% weighting). Because the Sales Velocity and Age are both calculated by B2C Commerce, the merchant can skip creating a feed.

The resulting search results show a blend of New Arrivals and Bestsellers.

### Scenario 3: Smart Selling

A merchant wants to elevate results based on the average order value of a product, the views to purchases conversion, or the margin of the product. The margin of profit can be either book margin, or actual margin based on promotion discounts.

The merchant creates custom active data attributes (AOV and ActualMargin) for the ProductActiveData system object. The merchant adds a feed definition and creates a feed file to import this data. The merchant creates a rule based on both the custom attributes and the Average Gross Margin Percent(30 Days) attribute.

### Scenario 4: Selling by Availability

Bras are running low at an intimate apparel merchant. Only size 34C is available because the base product has low SKU coverage. The merchant wants to move products with low SKU coverage lower in the search results based on real-time availability. However, if the shopper has already *drilled down* to size 34C, then ignore the SKU coverage.

The merchant creates a rule based on SKU coverage (descending) and sets it as the default sorting rule for keyword searches. Because the category that includes bras has a different default sorting rule, the SKU coverage doesn't affect any category navigation pages.

### Scenario 5: Sort by Brand

A high-end fashion retailer must highlight products based on brand. For example, Diesel Jeans by margin, Hugo Boss by bestsellers, and Armani by conversion rate (impressions to order or visits to order). Assuming that each brand is a category, the merchant can specify a default sorting rule for each brand. If each brand isn't a category, alter your search pipeline to determine if there’s a brand refinement. Then apply specific sorting rules if a customer refines by a specific brand.

### Scenario 6: Reselling Promotions

A large retailer also serves as a marketplace for third-party merchant products. This retailer must adjust the merchants' products either up or down depending upon the agreed contract. The merchant can create a sorting rule for a custom product attribute with an explicit search rank. See [Search.](https://help.salesforce.com/s/articleView?id=cc.b2c_search_overview.htm&type=5)

### Scenario 7: Promoting Quality

An electronics merchant is concerned about return rates on a high-defect category, such as flat-panel televisions. To provide customers with low-return-rate items first in a search, create a dynamic attribute with a partial weighting to the attribute returnRate. Import the returnRate attribute value in a feed, because it isn't collected in B2C Commerce. Use a dynamic attribute to include quality as a factor in your product sorting without making quality the sole determinant.

### Scenario 8: Customer Segmentation

An apparel merchant wants to be able to provide loyal female customers with information on new spring arrivals and a 20% discount on new suits. To target both slots and promotions to the appropriate customers, create a dynamic customer group defined by data and metrics derived from customer profiles.

### Scenario 9: Geographical Promotions

An apparel merchant wants to increase sales in an area where they’re planning a new store. To target promotions to customers from a specific city or area, create a dynamic customer group based on login location.
