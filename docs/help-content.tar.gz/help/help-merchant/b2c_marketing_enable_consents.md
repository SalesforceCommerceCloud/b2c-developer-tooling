# Enable or Disable a Consent

_After you enable a consent, it appears on your site in the consent components that you’ve configured._

> **Important:** If you delete a consent, it’s removed from the storefront and you can’t restore it. The subscription in Agentforce Marketing is also deleted, so you can't notify shoppers who have subscribed via the consent. To keep running any campaigns for consent subscribers, disable the consent instead.

1. In the B2C Commerce navigation sidebar, select **Merchant Tools > Site > Online Marketing > Consent Management**.
2. Select a consent.
3. Select or deselect the Enabled option.
4. Click **Save**.
