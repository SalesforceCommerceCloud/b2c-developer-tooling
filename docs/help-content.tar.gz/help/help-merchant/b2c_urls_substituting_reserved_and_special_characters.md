# Substituting Reserved and Special URL Characters

_When generating your storefront URLs, Eliminate or substitute certain characters. This topic applies to B2C Commerce._

For example, a merchant's category titles typically contain an ampersand, as follows:

`On the Go & Gear`

`Nursing & Feeding`

`Gifts & Keepsakes`

This URL has an encoded ampersand (and '-' as blank replacement):

`http://dev04.web.customer.demandware.net/s/customer/nursing-%26-feeding/mealtime/`

The merchant wants the ampersand to render as a hyphen in the URL, instead of the encoded %26. Using Business Manager, they can define the characters to be removed or replaced when generating URLs. They can also control how leading and trailing blanks are handled (usually removed), and how umlauts are handled.

In the earlier example, the merchant creates the following rule:

| Character | Replacement |
| --- | --- |
| & | - |

As a result, the URL is as follows:

`http://dev04.web.customer.demandware.net/s/customer/nursing-feeding/mealtime/`

During URL generation, the character on the left side of a mapping rule is replaced with the characters on the right side of the mapping rule.

### Mapping Rules

The following special rules apply when creating search character replacement rules:

- The left side of the mapping rule can be any character other than the following: `[a-z, A-Z, 0-9] ['-','_','.','~'].`
- The right side of the mapping rule can be 0–5 characters long, and consist of any of the following: `[a-z, A-Z, 0-9] ['-','_','.','~'].`
- To remove a character (instead of replacing it), leave the right side of the mapping rule empty.
- When replacing any character with `['-','_','.','~'],` and the character is surrounded by blanks (for example, *shirts & sandals*), the blanks are removed (for example, *shirts-sandals*).
- When removing a character, and the character is surrounded by blanks (for example, *shirts & sandals*), the character and all surrounding blanks are replaced with one blank (for example, *shirts sandals*).

### Localization

Mapping rules are localized. For example, define a replacement of an umlaut for the default (ö -> o) locale, and override the mapping for the "de_DE" (ö -> oe) locale. During a locale-specific URL generation, Salesforce B2C Commerce uses the mapping defined for the current locale (for example, "de_DE"), and then falls back to the corresponding language locale (for example, "de"), and then to the default locale.

The selectable locales to manage (create/update/delete) your character replacements are the active instance locales. Rules that are defined in a locale that isn't active for the site will also clean the URL* (. This enables you to select more locales when the global locales are greater than the site locales. The ability to create character replacements in locales that are not active for a site to develop a complex character replacement strategy. With this fallback scheme, for example, 'en_US' > 'en' > 'default', every fallback locale can extend the rules. The possible replacements for a site with one active locale, for example, 'en_US' is 150 character replacements because replacements in 'en' or 'default' can extend the rules if activated for the instance.

> **Tip:** Look for the configured character replacements in another locale if the character replacements were saved in the user's preferred locale.

> **Note:** *Clean URLs improve the usability and accessibility of a website or web service. They are immediately meaningful to non-expert users (Wikipedia).
