# How Agentic Commerce Search Affects Native B2C Commerce Search Features

_When you turn on Agentic Commerce Search for B2C Commerce, an AI model powers all standard product searches on your storefront. Some native B2C Commerce Search capabilities continue to operate independently and remain unchanged._

After you turn on Agentic Commerce Search, these native B2C Commerce search features continue to work:

- Searches for pages or articles continue to use B2C Commerce's native content search.
- Redirect rules configured in Business Manager remain in place.
- Facet definitions for category pages continue to use your existing B2C Commerce refinement structure. On search results pages, Agentic Commerce Search automatically generates filters based on the returned results. You don't configure these filters separately.

After you turn on Agentic Commerce Search, these native B2C Commerce search features no longer apply to search and browse results.

- Agentic Commerce Search doesn’t use synonym lists, stop word lists, compound words, hypernyms, or stemming exceptions configured in Merchant Tools. The AI model handles these behaviors automatically.
- Einstein Search Dictionaries and Einstein Predictive Sort.
   
   Sort rules and storefront sorting options configured in Merchant Tools don’t apply to search or browse results. Instead, configure sort options in Agentic Commerce Search in Merchant Tools. See [**Sort Options in Agentic Commerce Search**](http://sort-rules-overview.md).
- You can’t import or export Agentic Commerce Search search settings.

- Merchandising rules that you configured in B2C Commerce native search don't carry over to Agentic Commerce Search. After provisioning, you can create rules in the Agentic Commerce Search Rules dashboard. See [**Merchandising Rules in Agentic Commerce Search**](http://merchandising-rules-overview.md).

### Feature Support Comparison

This table shows which search capabilities B2C Commerce native search and Agentic Commerce Search each support.

| Feature | B2C Commerce Native Search | Agentic Commerce Search |
| --- | --- | --- |
| Keyword search | Supported | Supported |
| Natural language search | Not supported | Supported |
| Category navigation | Supported | Routed to B2C Commerce native search |
| Content search | Supported | Routed to B2C Commerce native search |
| Sorting | Supported; custom sort rules available | Three preconfigured sort rules. Custom sort rules not supported |
| Variation display mode | Supported | Supported |
| Slicing groups | Supported | Not supported |
| Bundle and set availability | Supported | Supported |
| Autocorrection | Supported | Not applicable. The AI model handles misspellings automatically |
| "Did you mean?" suggestions | Supported | Not applicable. The AI model returns relevant products through fuzzy matching |
| Fuzzy matching | Supported | Supported |
| Relevance scores | Supported | Not applicable. The AI model uses its own scoring |
| Search Index Query Tool | Supported | Not supported |
| Value-type refinement buckets | Supported | Supported |
| Threshold-type refinement buckets | Supported | Supported |
| Period-type refinement buckets | Supported | Not supported |
| Product suggestions | Supported | Supported |
| Category suggestions | Supported | Supported |
| Einstein personalized suggestions | Supported | Not supported |

Agentic Commerce Search doesn’t include a separate analytics dashboard. To track search and browse performance metrics for your storefront, use [B2C Commerce Reports and Dashboards](https://help.salesforce.com/s/articleView?id=cc.b2c_reports_and_dashboards.htm&type=5).
