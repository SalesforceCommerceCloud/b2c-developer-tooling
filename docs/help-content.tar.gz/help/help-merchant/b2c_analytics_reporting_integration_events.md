# Analytics Reporting Events

_Salesforce B2C Commerce supports 2 Analytics reporting events._

The following table describes the supported Analytics reporting events:

| Event Name | Description |
| --- | --- |
| `ABTest` | AB test started |
| `Checkout` | Checkout operation started |

> **Note:** The `ABTest` event is not used in either reference application―Salesforce Reference Architecture (SFRA) and SGJC.
> 
> For other events, captured for Reports & Dashboards, the [ `isobject` tag](https://developer.salesforce.com/docs/commerce/b2c-commerce/guide/b2c-tagging-pages-for-data-collection.html#add-isobject-tags) is used.
