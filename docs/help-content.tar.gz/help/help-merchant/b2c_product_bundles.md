# Product Bundles

_Use product bundles as a common marketing strategy to group multiple products into one orderable product for customer convenience, product completion, or visualization. This topic applies to B2C Commerce._

For example, a cosmetics merchant wants to bundle five separate skin care products into a comprehensive beauty regime; or a software provider wants to bundle separate software packages that together, provide a complete solution.

B2C Commerce product bundles:

- Are a separate product with its own SKU and price
- Are unaffected by the price of the individual products
- Contain specified products in specified numbers

Customers can purchase the individual products included in a bundle. Create a bundle within a bundle and include in the bundle a base product with variations.
