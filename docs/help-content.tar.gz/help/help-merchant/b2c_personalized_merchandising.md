# Personalized Merchandising

_Personalized merchandising is when merchants offer customers promotion and content information via content slots based on past customer behavior. This past behavior is derived from active merchandising data._

Use Salesforce B2C Commerce to define content slot configurations. These content slot configurations can dictate how page slots are populated with promotional content based on which customer group a customer belongs to. Your configurations also support static content assets, products, categories, or free-form (HTML).

You can also create dynamic customer groups that target specific types of customers for targeted campaigns, micro-sites, and product lines. For example, you show a *Happy Birthday discount* banner on the home page for logged in customers for their entire birthday month.

- If no customer groups are defined for a slot configuration, then slot configuration during rule evaluation is done as part of the Everyone group.
- If a slot configuration rule includes a customer group, the slot configuration is only valid for customers in that group.
- If a customer group is defined as part of the slot configuration rule, only customers of that group are included with other parts of the rule.

To implement this functionality, click App Launcher _(image: App Launcher)_ and specify settings in these locations:

- **Merchant Tools > Site > Online Marketing > Content Slots**
- **Merchant Tools > Site > Customers > Customer Groups**
