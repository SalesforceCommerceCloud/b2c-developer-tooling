# Account Manager Workflow

_Learn how data flows through the configurations when you integrate B2C Commerce Account Manager and other Salesforce applications with your identity provider._

[Which Salesforce Commerce Product Do I Have?](https://help.salesforce.com/s/articleView?id=commerce.comm_what_product.htm)

Single sign-on (SSO) is an authentication method that enables users to access multiple applications with one login and one set of credentials. You can set up your Salesforce org to trust an external identity provider to authenticate users.

_(image: A diagram that illustrates the workflow for integrating B2C Commerce with SSO.)_

This diagram illustrates the workflow for integrating B2C Commerce with SSO.

1. A third-party management system manages identities and user accounts
2. Salesforce Identity authenticates users and identities.
3. Customers access B2C Commerce tools and applications.
4. SSO works across Salesforce Clouds.

### Login Flow with Salesforce Identity

Use this guided flow chart to understand how Salesforce Identity authenticates Account Manager users.

_(image: A diagram that illustrates the sequence of steps for login with Salesforce Identity.)_
