# Network Access Restrictions in B2C Commerce

_The network level is the first line of defense against attackers trying to access your assets. Salesforce B2C Commerce uses two mechanisms: one for storefronts and one for Business Manager._
