# Network Access Restrictions in B2C Commerce

_The network level is the first line of defense against attackers trying to access your assets. Salesforce B2C Commerce uses two mechanisms: one for storefronts and one for Business Manager._

## Related Content

- [Storefront Network Access in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_storefront_network_access.htm&type=5)
  To limit network access to a storefront, enable the embedded Content Delivery Network (eCDN) that comes with B2C Commerce. To enable the eCDN for your organization, contact Salesforce Customer Support.

- [Business Manager Network Access in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_business_manager_network_access.htm&type=5)
  To limit network access to Business Manager, configure security controls to restrict access to specific IP addresses or ranges. The intent of setting these network access restrictions is to lock out attackers who obtained valid credentials through illegitimate means. To enable this functionality, you can specify a range of allowlisted IP addresses allowed to access Business Manager and a range of blocklisted IP addresses not allowed to access Business Manager. If an IP address is blocklisted and allowlisted, it’s denied access.
