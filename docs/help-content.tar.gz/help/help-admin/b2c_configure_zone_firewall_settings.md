# Configure Firewall Settings for an eCDN Zone

_Configure firewall settings for an eCDN zone using the Configure Zones interface in Business Manager._

|  |
| --- |
| Available in: **B2C Commerce** |

> **Important:** The legacy Firewall Settings section is being retired as customers are migrated to the new Configure Zone experience through July 28, 2026. In the new UI, firewall behavior is managed through the single **Under Attack Mode** control. For current instructions, see [Configure an eCDN Zone in Business Manager](https://help.salesforce.com/s/articleView?id=cc.b2c_configuring_a_zone.htm&type=5).

1. In Business Manager, click the App Launcher, and then select **Administration > Sites > Embedded CDN Settings**.
2. Locate the zone you want to configure and select **Configure Zone** from the dropdown menu.
3. Select the **Firewall** tab.
