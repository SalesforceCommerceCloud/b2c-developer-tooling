# Create a PagerDuty Channel for Log Center Alerts

_For on-call escalation and incident management, set up PagerDuty notifications in B2C Commerce. When you route Log Center notifications in B2C Commerce to PagerDuty, the alert's state lifecycle is mapped to a specific PagerDuty action and severity. Each alert monitor uses a unique deduplication key, so repeated triggers update the existing open incident instead of creating duplicate incidents._

1. Set up PagerDuty.

   1. From Services, select your target service.
   
   1. Select **Integrations**
   
   1. Add **Events API v2**.
   
   1. Copy the integration key.
2. In the Log Center, create a notification channel.

   1. On the Alerts tab, go to **Notification Channels**.
3. Click **Create Channel**.
4. For Type, select** PagerDuty**.
5. Select the applicable realms, or leave the field empty to create a channel that’s visible only to admin and support roles.
6. Enter your routing key.

   The PagerDuty endpoint is configured automatically.
7. Click **Create Channel**.
