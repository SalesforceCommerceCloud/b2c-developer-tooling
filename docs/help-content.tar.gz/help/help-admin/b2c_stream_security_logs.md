# Stream Security Logs

_To set up B2C Commerce security logs streaming, configure the Enable Security Logs option._

1. Log in to Log Center.
2. Select **Log Streaming**.
3. Check **Enable Security Logs**.
4. Enter a name for the log stream
5. Fromthe Destination Type drowdown, select a third-party integration too.
6. Configure the Endpoint URL, API Token, and Realm
7. (Optional) Add user ids to the Edit Permissions List.
8. Configure filter criteria.
9. Save your configuration.

_(image: Security Logs Settings)_

See Also:

- [Set Up Log Streaming](https://help.salesforce.com/s/articleView?id=cc.b2c_set_up_log_streaming.htm&type=5)
