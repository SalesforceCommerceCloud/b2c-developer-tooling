# Job Flow Scope

_Each flow has a scope, either the entire organization, all storefront sites, specific storefront sites, or sites that you pass to the job at execution time using the Open Commerce API (OCAPI) data API. Some job steps, such as CreateSitemap, can execute only in the context of a site. Other job steps, such as ExecuteDataReplication, can execute only in the context of the organization. If you try to assign a job step to a flow that has a scope the step doesn't support, the step shows an error. This topic applies to B2C Commerce._

When you create a job flow, select one of the following scope options:

- **Organization**: Flow executes for the instance.
- **All Storefront Sites**: Flow executes on all storefront sites available at the time the job executes. Flow doesn’t execute on the Business Manager site or on sites with a to-be-deleted status.
- **Specific Sites**: Flow executes only on the storefront sites you select.
- **Site Parameter:** Flow executes on the sites you pass to it using the OCAPI Data API. You can't execute the job from Business Manager, and you can't schedule the job to run automatically. The Run Now button and scheduling options in Business Manager are disabled. If you select this option, B2C Commerce adds a SiteScope parameter with an empty value to the job. Using the OCAPI Data API, specify one or more specific sites or all storefront sites for SiteScope.

When you configure a sequential flow to run for more than one site, B2C Commerce executes the flow in parallel for the different sites, as long as there are enough system resources to accommodate parallel execution.
