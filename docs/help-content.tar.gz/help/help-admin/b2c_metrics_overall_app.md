# Overall Application Metrics

_All users can view traffic and performance metrics for their B2C Commerce sites, such as requests, sessions, and system workload. These metrics help website administrators and DevOps monitor performance of all sites._

Check out these traffic-related metrics.

### Total Platform Requests

The Total Platform Request Metric is a per-minute count of all platform and storefront requests.

Use cases:

- Monitor request traffic during sale events or campaign launches. Look for unexpected spikes or drops in request counts.
- Validate change management. Validate success of a deployment or change, including code replication, data replications, promotions, or campaigns. Monitor unexpected request drops after a change is made.
- To monitor performance and availability, analyze traffic patterns.
- Correlate request metrics with other Log Center metrics. Requests metrics are initial indicators and are most useful when viewed in conjunction with other Log Center metrics, logs, and events. For example, a code replication storefront regression happens when these indicators are true.
   
   - Total Platform Request drop.
   - Sales Order rate drops.
   - System Workload spikes to 100%.

### Storefront Requests

The Storefront Requests metric is the number of main page requests made across all sites per minute. The report doesn’t track Includes or Open Commerce API (OCAPI) requests. The Storefront Request metric differs slightly from Total Platform Requests, showing only the main page request rate.

Use case:

- Analyze small spikes or drops in request rates that can be masked by the larger total number of requests to the platform.

### Sessions

The Sessions metric is the number of active sessions across all sites per minute.

Use cases:

- To monitor sale events, analyze session spikes and drops. The pattern is generally in line with the pattern of the requests metrics.
- Correlate session metrics with other Log Center metrics.
   
   - Storefront requests and storefront sessions: Monitor the ratio of active sessions and storefront requests to get a high-level view of user behavior and how many requests are made per user session. A 1:1 session/request rate indicates a problem, which can be related to high bot traffic or a problem in code.
   - System workload and storefront sessions: Monitor the relationship between sustained high System Workload and storefront sessions (all traffic).

Check out these platform-related metrics.

### Response Time

The Response Time metric is the per minute response time latency averaged across all requests, shown in milliseconds.

Use cases:

- Use Response Time as an initial indicator. Correlate with other Log Center metrics to deep-dive using Business Manager Code Profiler.
- Use the [Commerce Analytics Center (CCAC) Technical Report](https://ccac.analytics.commercecloud.salesforce.com) to check the historical trend of response times. For more information, see [../analytics/b2c_technical_dashboard.xml](https://help.salesforce.com/s/articleView?id=cc.b2c_technical_dashboard.htm&type=5).

### Emails Sent

The Emails Sent metric is a per-minute count of all emails sent through the platform.

Use case:

- Get general visibility of emails sent, and monitor expected increases or unexpected decreases.

### System Workload

The System Workload metric is the percentage of realm resource utilization per minute. System Workload is an aggregate of your system resource utilization on the platform and the most critical performance indicator metric.

Use cases:

- Monitor system resource utilization. If sustained system workload levels are greater than 30%, this indicates controller pipeline latency.
   
   - Slow controller times in search, checkout, and product impact conversion rates.
   - Slow controllers don’t scale well under increased traffic load.
- Monitor spikes in system resource utilization. Here are some troubleshooting tips for investigating sudden spikes in System Workload.
   
   - To understand what changed, try to find answers to these questions.
      
      - Was there a code deployment or data replication?
      - Is there an unexpected traffic spike?
      - Is there a third-party service slow down without circuit breaker or rate limiting?
   - If there’s a spike greater than 70% for 10+ minutes and a correlating drop in traffic or orders, open a Support Case to help investigate the issue.
   - If there are short spikes or intermittent spikes, investigate further using Log Center events, logs, and Code Profiler to derive the root cause.
