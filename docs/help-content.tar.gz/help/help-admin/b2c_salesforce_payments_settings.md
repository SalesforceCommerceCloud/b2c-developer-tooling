# Salesforce Payments Advanced Settings for B2C Commerce

_Use the Salesforce Payments advanced settings for your site to configure the instance status, payment card capture timing, payment card credential storage, and customer statement descriptor._

## Related Content

- [Set the Payments Instance Status for B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_set_instance_status.htm&type=5)
  Choose whether your B2C Commerce instance processes test or live payments.

- [Set the Payment Capture Timing for B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_payment_card_capture_timing.htm&type=5)
  Choose when to capture and disburse a payment from the payment issuer to the merchant acquirer for your B2C storefront.

- [Set the Saved Payment Credentials for B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_payment_card_credential_storage.htm&type=5)
  Choose how Salesforce Payments uses stored credit card credentials.

- [Statement Descriptor Settings for B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_statement_descriptor_settings.htm&type=5)
  A statement descriptor provides banks and credit card networks with a description of the credit card transaction charge. Salesforce Payments adds the description to the shopper’s bank or card statement to identify the source of the charge. When shoppers know the origin of a charge, it reduces payment disputes and chargeback requests. Salesforce Payments supports three statement descriptor settings.
