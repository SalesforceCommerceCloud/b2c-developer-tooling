# Salesforce Payments Settings for B2C Commerce

_Use the B2C Commerce Salesforce Payments Settings to configure instance status, payment card capture timing, and payment card credential storage for your site._
