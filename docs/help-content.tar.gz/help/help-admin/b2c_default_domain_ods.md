# Default Domain on On-Demand Sandboxes (ODS)

_B2C Commerce On-Demand Sandboxes (ODS) are served exclusively through the Salesforce-managed Default Domain. Custom (vanity) domains on ODS via eCDN aren't supported and aren't planned._

Starting with the 26.6 release, eCDN Default Domain is available on all ODS instance types (dev, prd, partner) and is automatically provisioned when a new ODS instance is created. No DNS changes or certificate management is required.

> **Important:** With the 26.6 default-domain auto-routing, the storefront host for ODS sandboxes changes from `<realm>-<NNN>.dx.commercecloud.salesforce.com` to `<realm>-<NNN>.my.commercecloud.salesforce.com`, including for already-provisioned sandboxes. Business Manager, WebDAV/code upload, jobs, and the Sandbox API remain on the `.dx` host—only the storefront moves to `.my`.

> **Note:** The current ODS Default Domain support is scoped to Storefront Next use cases.

_(image: Embedded CDN Settings page for an ODS sandbox showing the auto-provisioned Default Zone zzpq.sbx.my.commercecloud.salesforce.com with Add Hostname and Configure Zones buttons.)_

_(image: Embedded CDN Settings dropdown for an ODS sandbox showing the Configure Zone and Configure Routing Rules options.)_

_(image: Configure Zones Security Rules view for ODS zone zzpq.sbx.my.commercecloud.salesforce.com showing Custom Firewall Rules and Rate Limiting Rules sections.)_

_(image: Embedded CDN Settings page for an ODS sandbox showing a registered hostname with the Configure Zone and Configure Routing Rules dropdown open.)_

### Vanity Domains on ODS

Custom/vanity domains on ODS via eCDN aren't supported and aren't planned. ODS is served exclusively through the Salesforce-managed Default Domain, by design. The Default Domain provides a unique hostname with Salesforce-managed certificates and no certificate management.

If a true custom domain is required, use a Development or Staging (PIG) instance, where custom domains via eCDN are supported.
