# Default Domain on On-Demand Sandboxes

_B2C Commerce On-Demand Sandboxes (ODS) are served exclusively through the Salesforce-managed Default Domain starting with the 26.6 release. When you create a development, production, or partner ODS instance, B2C Commerce provisions the Default Domain automatically and handles DNS and certificates for you._

[Which Salesforce Commerce Product Do I Have?](https://help.salesforce.com/s/articleView?id=commerce.comm_what_product.htm)

> **Important:** With the 26.6 default-domain auto-routing, the storefront host for ODS sandboxes changes from `<realm>-<NNN>.dx.commercecloud.salesforce.com` to `<realm>-<NNN>.my.commercecloud.salesforce.com`, including for already-provisioned sandboxes. Business Manager, WebDAV/code upload, jobs, and the Sandbox API remain on the `.dx` host—only the storefront moves to `.my`.

> **Note:** The current ODS Default Domain support is scoped to Storefront Next use cases.

This table describes the hostnames, zone model, and required actions for the ODS Default Domain.

_(image: Embedded CDN Settings page for an ODS sandbox showing the auto-provisioned Default Zone zzpq.sbx.my.commercecloud.salesforce.com with Add Hostname and Configure Zones buttons.)_

_(image: Embedded CDN Settings dropdown for an ODS sandbox showing the Configure Zone and Configure Routing Rules options.)_

_(image: Configure Zones Security Rules view for ODS zone zzpq.sbx.my.commercecloud.salesforce.com showing Custom Firewall Rules and Rate Limiting Rules sections.)_

_(image: Embedded CDN Settings page for an ODS sandbox showing a registered hostname with the Configure Zone and Configure Routing Rules dropdown open.)_

### Feature Parity with Production

All standard eCDN capabilities are available on ODS Default Domain zones, including edge caching, web application firewall (WAF) (OWASP ruleset, eCDN Managed ruleset, and custom rules), bot protection, DDoS mitigation, rate limiting, real-time analytics, Log Center metrics (HTTP status codes 502–530), PCI 4.0 / Page Shield, IP/ASN/geo blocking, MRT routing rules, image optimization (DIS), and log export (LogPush).

The following features aren't available or are out of scope for ODS:

- **Custom domains:** Not supported via eCDN, and not on the roadmap. ODS is served exclusively through the Salesforce-managed Default Domain.
- **Per-instance eCDN configuration isolation:** Out of scope. All ODS instances in a realm share the same eCDN configuration.
- **Video optimization:** Not supported. Use an external CMS or partner solution.

### Custom Domains on ODS

Custom domains on ODS via eCDN aren't supported. ODS is served exclusively through the Salesforce-managed Default Domain, by design. The Default Domain provides a unique hostname with Salesforce-managed certificates and no certificate management.

Existing vanity hostnames on ODS (for example, CNAMEd to `dx.commercecloud.salesforce.com`) aren't auto-migrated to eCDN and remain on the legacy path. If you rely on them, move to the Default Domain. A blanket migration isn't feasible because accounts commonly mix unique, non-unique, and unowned aliases, and any account with non-unique or unowned hosts can't be migrated to eCDN.

If a true custom domain is required, use a Development or Staging (PIG) instance, where custom domains via eCDN are supported.
