# Store Information Import/Export in B2C Commerce

_Use the store.xsd schema file to import store information._

### Business Manager Import Location

*Granularity:* selected stores.

**Online Marketing  >  Import & Export**

### Pipelets

ImportStores

ExportStores

*Granularity:* passed stores
