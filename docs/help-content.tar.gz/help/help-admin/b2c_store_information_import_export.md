# Store Information Import/Export in B2C Commerce

_Use the store.xsd schema file to import store information. This topic applies to B2C Commerce._

### Business Manager Import Location

*Granularity:* selected stores.

**Online Marketing  >  Import & Export**

### Pipelets

ImportStores

ExportStores

*Granularity:* passed stores
