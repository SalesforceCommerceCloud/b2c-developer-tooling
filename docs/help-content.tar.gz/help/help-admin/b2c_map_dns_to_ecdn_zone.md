# Map DNS to an eCDN Zone for B2C Commerce

_After a hostname is active, map DNS at your provider so that the hostname's traffic routes to its embedded CDN (eCDN) zone. Use this procedure whenever you add or update a certificate for a zone._

Complete this procedure after the hostname is active and its certificate is validated. For the mapping rules and validation methods, see [DNS Mapping for eCDN Zones](https://help.salesforce.com/s/articleView?id=cc.b2c_dns_mapping_for_ecdn_zones.htm&type=5).

When the hostname is active, create a CNAME record that points traffic, by SSL for SaaS V2, to the new zone.

1. In Business Manager, click App Launcher _(image: App Launcher)_, and then select **Administration > Sites > Embedded CDN Settings**.
2. Find the hostname that you want to map, and copy its CNAME value.
3. Log in to your DNS provider account.

   These steps use Cloudflare as an example DNS provider. If you use a different provider, the labels and options can differ.
4. Search for your zone and select it from the list.
5. On the DNS tab, locate the hostname that you want to map.
6. Replace all text after "is an alias of" with the DNS CNAME from Business Manager in step 2.

   Point the CNAME directly to the eCDN zone hostname. Don't point it to `dx.commercecloud.salesforce.com`.
7. In the hostname's row, set **Proxy status** to **DNS only** (gray cloud).

> **Note:** If you already have the same root domain with your DNS provider in a separate account, point the DNS to the new zone and not the standard or root zone. This proves intent that you want traffic to come to the new zone rather than the standard or root zone.
