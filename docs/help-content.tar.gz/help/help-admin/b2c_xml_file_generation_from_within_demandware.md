# XML File Generation from Within B2C Commerce

_Standard exports use the B2C Commerce-defined XML schema files. B2C Commerce provides a set of schema files that can be used to create the most common export files._

You can also import product and content images in a .zip file and export Analytics data in xls format.

The typical B2C Commerce implementation includes generating XML documents for data transfer to a backend system.

To create an XML document from data in the system, the standard practice is to create code that iterates over data in B2C Commerce and outputs this data to an XML file.

If you must write custom code, think about how many objects or how much XML to read into memory. Consider how many objects to read before committing the transaction, and consider other constraints taken care of automatically with the standard feeds.

For example, if you’re post-processing an order export into a proprietary XML format for a backend system, consider whether it makes sense to use a B2C Commerce script. It can be faster and more efficient to transform a file using a pure .NET or a Java platform with a large amount of memory allocated to the processing.

However, to use a B2C Commerce script, use the XMLStreamReader and getXMLObject() method to get a specific order within the export file. Then use nextTag() to iterate through elements in the order and XMLStreamWriter to write out the order to the new file.

It isn't a good idea to read an entire export file or entire order into memory before writing it out using the XMLStreamWriter, as it can cause an out of memory error.

## Examples of Import/Export in B2C Commerce

_We have provided examples of import and export code._

The following code example iterates over the products currently configured in the site and creates an XML document (object). The XML document can be used to pass data to another system.

This code performs the iteration:

```
var it : SeekableIterator = ProductMgr.queryAllSiteProducts(); 
var rootXML : XML = new XML(<products></products>); 
var pXML : XML = new XML(<product></product>); 
while(it.hasNext()){ 
  var product : Product = it.next(); 
  pXML.brand = product.getBrand(); 
  pXML.name = product.getName(); 
  pXML.id = product.getID(); 
 rootXML.product+=pXML; 
} 
```

The process is as follows:

1. Create the product iterator that captures all the product data needed for the XML document.
2. Create the root XML element products (object).
3. Create an XML element (product) to add to the document. Create this XML object only one time.
4. Iterate over the product object, creating and adding to the product element.
5. Add the complete product element to the root element with the following line:

```
rootXML.product+=pXML
```

This line adds a product element to the root element after each iteration.

If you wanted to add another element to the XML, use this code:

```
var it : SeekableIterator = ProductMgr.queryAllSiteProducts(); 
var rootXML : XML = new XML(<products></products>); 
var pXML : XML = new XML(<product></product>); 
var paymentXML = new XML(<payment></payment>); 
while(it.hasNext()){ 
  var product : Product = it.next(); 
  pXML.brand = product.getBrand(); 
  pXML.name = product.getName(); 
  pXML.id = product.getID(); 
 paymentXML.allowed =product.custom.allowed; 
 paymentXML.bml = product.custom.bml 
 rootXML.product+=pXML; 
 rootXML.payment+= paymentXML; 
 } 
```

In the previous code, the payment object acts as a custom attribute that must be in its own XML element.

In addition to adding new elements, you can also outline what data elements the document element allows, as shown in the following code example:

```
var it : SeekableIterator = ProductMgr.queryAllSiteProducts(); 
var rootXML : XML = new XML(<products></products>); 
var pXML = <product> 
          <brand></brand> 
          <name></name>     
          <id></id> 
          </product> 
var paymentXML = new XML(<payment></payment>); 
while(it.hasNext()){ 
  var product : Product = it.next(); 
  pXML.brand = product.getBrand(); 
  pXML.name = product.getName(); 
  pXML.id = product.getID(); 
  paymentXML.allowed =product.custom.allowed; 
  paymentXML.bml = product.custom.bml 
 rootXML.product+=pXML; 
 rootXML.payment+= paymentXML; 
} 
```

The following example code shows how to add a namespace to the XML document.

```
var nsg : Namespace = new Namespace("g","http://base.google.com/ns/1.0"); 
var it : SeekableIterator = ProductMgr.queryAllSiteProducts(); 
var rootXML : XML = new XML(<products></products>); 
var pXML = <product> 
          <brand></brand> 
          <name></name>     
          <id></id> 
          </product> 
var paymentXML = new XML(<payment></payment>); 
pXML.addNamespace(nsg); 
while(it.hasNext()){ 
  var product : Product = it.next(); 
  pXML.nsg::brand = product.getBrand(); 
 pXML.nsg::name = product.getName(); 
 pXML.nsg::id = product.getID(); 
 paymentXML.allowed =product.custom.allowed; 
 paymentXML.bml = product.custom.bml 
 rootXML.product+=pXML; 
 rootXML.payment+= paymentXML; 
} 
```
