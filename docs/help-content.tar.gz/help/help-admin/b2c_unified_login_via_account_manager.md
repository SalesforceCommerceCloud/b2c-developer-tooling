# Migration to Unified Authentication Via Account Manager

_When you migrate to unified authentication, your users can log in to their Business Manager instances through Account Manager. Unified authentication streamlines the login process. Users receive a single set of login credentials to access all Business Manager instances. As a result, your users have fewer credentials to remember. This applies for administrators who are manually migrating users to unified authentication. This doesn’t apply to administers who started using B2C Commerce after October of 2019 because their organizations automatically use unified authentication._

Unified login also increases security because you can use the two-factor authentication already supported on Account Manager accounts. Unified authentication simplifies user management. Account Manager becomes the one stop shop for creating and deleting users.

> **Note:** You still manage permissions and preferences for users through Business Manager, including all users migrated to or created in Account Manager.

Before migrating your users to Unified Authentication, [allowlist](https://developer.salesforce.com/docs/commerce/b2c-commerce/guide/b2c-managing-sites-for-dev.html#create-a-hostname-allowlist) all hostnames used for Business Manager. Allowlist all hostnames, even if the Permit allowlisted Hostnames Only setting is disabled in the security page.

Migrating users to Unified Authentication has five stages to prepare users for the change and minimize disruption. Not every stage is required. Skip Unified Authentication Encouraged and go straight to Unified Authentication Mandatory. However, we recommend that you use every stage to avoid business disruption.

> **Note:** As of 19.5, all new instances are linked to the Account Manager login.

- Stage 1: No Unified User Authentication
   
   All users log in to their instance using login credentials specific to that instance. Once you progress past this stage, it becomes unavailable. To revert to local authentication, contact support.
- Stage 2: Unified User Authentication Supported
   
   Set up power users with a link to connect their instance and Account Manager accounts.
- Stage 3: Unified Authentication Encouraged
   
   When users log in to their instance, Business Manager prompts them to link their instance and Account Manager accounts. Users can still log in without linking their accounts.
- Stage 4: Unified Authentication Mandatory
   
   When users log in to their instance, Business Manager prompts them to link their instance and Account Manager accounts. Users can't log in until they've linked their accounts.
- Stage 5: Unified Authentication Only
   
   Users can only log in to their instance with their Account Manager login credentials. At this point, manually provide a link to users who haven't yet migrated. Before moving on from this stage, make sure that most your users have migrated. Users that haven't migrated are locked out of their instances. See how many users have migrated on the User Authentication tab (go to Administration > Preferences > Security).

### Unified Authentication Best Practices

For increased security and ease of use, start your migration as soon as you can. Set a schedule for each stage.

Back up all affected users.

Inform your users before enabling Unified Authentication Encouraged so that they understand the benefits of switching. We provide an email template that you can use:

We are moving to unified login via Account Manager. Unified login lets you log in to all Business Manager instances using your Account Manager login credentials. This change lets us unify login credentials across all instances, making logging in to Business Manager easier. Additionally, because Account Manager uses two-factor authentication, this adds a new level of security. Starting on xx.xx.xxxx, we will provide the option to link your Business Manager login credentials with your Account Manager account. On xx.xx.xxxx, the migration will become mandatory. Please link your accounts as soon as possible. If you have multiple accounts, only link the account that is supposed to remain, since only one will be used going forward. Thank you,

## Related Content

- [Create an Access Key for Logins for B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_access_keys_for_business_manager.htm&type=5)
  For organizations using unified authentication, B2C Commerce offers an alternative form of authentication when logging into to Business Manager via external applications: WebDAV File Access, UX Studio Agent, User Login, Open Commerce API (OCAPI), and Protected Storefront Access These access keys act as a substitute for your unified authentication password. Access keys expire after a year. If you enter an access key incorrectly six times, you can't use that access key or your password to log in to that authentication scope.
