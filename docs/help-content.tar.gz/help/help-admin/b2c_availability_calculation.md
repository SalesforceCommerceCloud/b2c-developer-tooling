# Availability Calculation

_A product's availability is calculated from its inventory and the stock update mechanism. If you use Salesforce Omnichannel Inventory, then Omnichannel Inventory calculates the availability of individual products, and the integration sends the data to B2C Commerce._

> **Note:** Omnichannel Inventory doesn’t perform availability model calculations for main, variation, bundle, and kit products. When integrated with Omnichannel Inventory, B2C Commerce handles those calculations using individual product availability data from Omnichannel Inventory.

Each product has a product record. If a product isn't orderable, it doesn't appear in search results. For search availability ranking, the product is ranked high or low based on its available to sell (ATS) value.

### Base Product and Variation Availability Calculation

- A base product can't be ordered. Its availability status is the availability of its variation products.
- A base product can have an inventory record, but that isn’t best practice. Instead, assign inventory records to its variation products, because customers can order them.
- If at least one of the variation products of a base product is orderable or in-stock, the base product is considered orderable or in-stock. If you’ve enabled the *Show Orderable Products Only* search preference (site or product level), a base product can appear in search results but can't be ordered directly. Also, if you have sorting rules that sort by availability, whether a base product is orderable controls where it appears in the search results.
- if none of a base product’s variations appear in search results, the base product doesn't appear in them either.
- If a base product contains a bundle, determine availability in a recursive manner.
- A base product’s search availability ranking is based on the ATS of its variation products in the current search result. For example, if it represents at least one variation product with good availability, it’s ranked high.

### Product Bundle Availability Calculation

- Products in a bundle can have inventory records.
- If one item in the product bundle is unavailable, the entire bundle is unavailable.
- If a product bundle has an inventory record, Salesforce B2C Commerce uses the inventory record in the calculation of the availability of the product bundle.
- A bundle can have its own inventory record. Use the bundle inventory record to control availability of bundles independently from the availability of the bundled products. If bundle availability is "perpetual", You don't need a bundle inventory record.
   
   - If a bundle has its own inventory record and the *Use Bundle Inventory Only* option isn't selected, this record and the records of the bundled products determine availability. Therefore, both the bundle and the bundled products must be available.
   - If a bundle has its own inventory record and the *Use Bundle Inventory Only* option is selected in the inventory list, only the availability of the bundle is used to calculate availability. In this case, even if bundled products aren’t available, the bundle remains available. This strategy is useful if the inventory of the bundle and the individual products is tracked separately in your backend ordering or inventory system.
   - If a bundle has no inventory record and the *Use Bundle Inventory Only* option isn't selected, only the records of bundled products are used to determine availability. For example, if a product bundle contains two products, one of which has 10 in stock, and the other of which has five in-stock and 10 on backorder, there are five bundles in stock and five on backorder. In this case, product bundles are unaffected by the *default in-stock* setting of the site inventory list.
   - If a bundle has no inventory record and the *Use Bundle Inventory Only* option is selected, the inventory list *default in-stock* option defines whether the bundle is available. If this option is set, the bundle is always available, otherwise is it never available.
      
      > **Note:** Use getAvailabilityModel().isInStock(). The `in-stock` flag has been deprecated.
- If a bundle contains other bundles or base products, availability is determined in a recursive manner.
- A bundle doesn't appear in search results if it isn't orderable.
- For search availability ranking, the bundle is ranked high or low based on the lowest ATS of all bundled products and the bundle itself (if bundle has a record).

### Product Set Availability Calculation

- A product set can't be ordered. Its availability status is the availability of the set products.
- If a product set has an inventory record, the record isn't used. A product set can't have an inventory record.
- If at least one of the set products is orderable or in-stock, a product set is 'orderable' or 'in-stock'.
- If a product set contains bundles or base products, availability is determined in a recursive manner
- If none of the set products that the product set represents in the current search result is orderable, a product set isn't shown in search results.
- For search availability ranking, the product set is ranked high or low based on the ATS of the set product it represents in the current search result. For example, if it represents at least one set product with good availability, it’s ranked high.

## Related Content

- [Available to Sell (ATS) Calculation](https://help.salesforce.com/s/articleView?id=cc.b2c_available_to_sell_ats_calculation.htm&type=5)
  In B2C Commerce, the product availability presented to storefront customers is defined as the available to sell (ATS) quantity.
