# Invalidate the Static Cache

_To enforce protection on your B2C Commerce site, invalidate the static content cache. Otherwise unprotected content that was already delivered is valid until it expires. If you change the password, invalidate the static content cache to enforce the use of the new password._

1. Click App Launcher _(image: App Launcher)_, and then select **Administration > Sites > Manage Sites > *site* > Cache**.
2. On the Cache tab, set the Instance Type to your instance type.
3. Click the top **Invalidate** button in the Cache Invalidation section.

   If you click the second invalidate button, only the pipeline page cache clears, and unprotected content continues to be delivered.
4. Click **Apply**.
