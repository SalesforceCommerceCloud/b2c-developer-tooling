# General Security Best Practices in B2C Commerce

_At Salesforce, we understand that the confidentiality, integrity, and availability of your data is vital to your business. We want you to implement maximum protection for your sites against security threats and recommend using the following core best practices as you set up your Salesforce B2C Commerce environments._

## Related Content

- [Use 2FA on All Privileged Accounts](https://help.salesforce.com/s/articleView?id=cc.b2c_use_2fa_on_all_privileged_accounts.htm&type=5)
  Two-factor authentication (2FA) is an extra layer of protection beyond a single password. The extra protection can be knowledge (something you know), possession (something you have), or biometrics (something you are). Using a second authentication factor, such as a mobile phone (something you have), provides additional protection against common security threats such as account takeover, fraud, data loss, malicious code, and phishing attacks.

- [Follow the Principle of Least Privilege](https://help.salesforce.com/s/articleView?id=cc.b2c_follow_the_principle_of_least_privilege.htm&type=5)
  The principle of least privilege is a core zero trust concept. Implementing least privilege means that you give users, applications, systems, and other components only the minimum privilege level required to do their job.

- [Apply Defense in Depth](https://help.salesforce.com/s/articleView?id=cc.b2c_apply_defense_in_depth.htm&type=5)
  Defense in depth means using multiple layers of security within your environment instead of just one. If an attack causes one security mechanism to fail, other mechanisms can still provide the necessary security to protect the system. Think of creating a security onion and not a security egg. When dropped, an egg smashes everywhere, while an onion just gets a little bruised because it has multiple layers.

- [Use a Positive Security Model](https://help.salesforce.com/s/articleView?id=cc.b2c_use_a_positive_security_model.htm&type=5)
  A positive security model, also known as a safelist approach, defines what is allowed and rejects everything else. Use this approach to make sure that you can allowlist only the known good input instead of trying to disallow all possible bad input.

- [Fail Securely](https://help.salesforce.com/s/articleView?id=cc.b2c_fail_securely.htm&type=5)
  Fail securely means implementing decision logic that puts systems into a secure state when errors occur. Handling errors securely ensures that the error path, such as exceptions, doesn’t disclose additional information that wouldn’t be available otherwise. Attackers can use this additional information to learn how to attack the system.

- [Make Security Usable](https://help.salesforce.com/s/articleView?id=cc.b2c_make_security_usable.htm&type=5)
  A difficult-to-use security feature is one that's turned off. Write security features in a way that makes them easy for users to understand. To help users understand the security decisions they make, give them visibility into and control of their security settings.

- [Use Secure Defaults](https://help.salesforce.com/s/articleView?id=cc.b2c_use_secure_defaults.htm&type=5)
  As an administrator, you want to make the user experience secure and reduce the number of default security settings. Configure security settings so that users must opt out of default security settings rather than opt in. If there's a security risk, clearly label insecure functionality in APIs or the user interface to discourage use.

- [Minimize the Attack Surface](https://help.salesforce.com/s/articleView?id=cc.b2c_minimize_the_attack_surface.htm&type=5)
  To reduce overall risk in secure development, reduce the attack surface that’s exposed to potential attackers. Every port you open, every external library you use in your code, and every user you give access to your data creates a new attack surface. To reduce the overall risk to the system, minimize the attack surface.

- [Prevent Ecommerce Fraud](https://help.salesforce.com/s/articleView?id=cc.b2c_prevent_ecommerce_fraud.htm&type=5)
  Ecommerce fraud is a growing security challenge. Cyber attackers use lists of stolen credentials to gain access to user accounts and conduct brute force attacks to make unauthorized transactions.
