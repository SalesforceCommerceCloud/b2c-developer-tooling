# General Security Best Practices in B2C Commerce

_At Salesforce, we understand that the confidentiality, integrity, and availability of your data is vital to your business. We want you to implement maximum protection for your sites against security threats and recommend using the following core best practices as you set up your Salesforce B2C Commerce environments._
