# Managing Jobs

_After you create jobs, use Business Manager to manage them. This topic applies to B2C Commerce._
