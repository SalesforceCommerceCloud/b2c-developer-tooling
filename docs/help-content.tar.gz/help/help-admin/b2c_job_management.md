# Managing Jobs

_After you create jobs, use B2C Commerce Business Manager to manage them._

## Related Content

- [View Job History](https://help.salesforce.com/s/articleView?id=cc.b2c_view_job_history.htm&type=5)
  View the B2C Commerce job history page to see information about jobs, including status, end time, and duration.

- [Monitor Job Statistics](https://help.salesforce.com/s/articleView?id=cc.b2c_monitor_job_stats.htm&type=5)
  Monitor the duration and number of executions for B2C Commerce jobs. Filter and sort the statistics.
