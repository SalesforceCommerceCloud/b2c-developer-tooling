# General Secure Coding Practices in B2C Commerce

_Even with all the security controls that Salesforce B2C Commerce provides, poor coding practices can negate these controls and introduce weaknesses. Refer to the OWASP Secure Coding Practices - Quick Reference Guide for general recommendations._
