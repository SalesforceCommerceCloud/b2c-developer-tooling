# Customer List Object Import/Export in B2C Commerce

_The customerlist2.xsd contains the meta information and security preferences of the list itself, and all the customers. Each file represents one customer list if you perform a site export and select all the lists. Each file takes the name of the list itself, for example, SiteGenesis.xml for the SiteGenesis customer list. This topic applies to B2C Commerce._

The XML format for customer lists, customerlist2.xsd, is similar to the previous customerlist.xsd with added customer.xsd data. Site assignments to a customer list are imported as a site preference, similar to catalog, inventory list, and price book assignments. B2C Commerce exports the same customers for all sites assigned to the same customer list.

B2C Commerce exports assignments between customer lists and customers as part of customergroup.xsd. See the schemas for additional details.

The customer import logic verifies that an imported customer number isn’t identical to an existing buyer number. The system rejects a customer number that matches an existing buyer number. This behavior makes sure that customers can’t view orders not belonging to them. Salesforce recommends importing customers before importing orders.

### Business Manager Import Location

** *site*  >  Merchant Tools  > Customers  >  Import & Export  >  Customer Lists**

** *site*  > Administration  > Site Development > Site Import/Export  >  Customer Lists**

### Pipelets

ImportCustomerList

ExportCustomerList

*Granularity:* customer list

## Customer Object Import/Export in B2C Commerce

_Use the elements in the customer.xsd and considerations when creating values for them. This topic applies to B2C Commerce._

#### Business Manager Import Location

** *site*  >  Merchant Tools  >  Customers  >  Import & Export  >  Customer**

#### Pipelets

ImportCustomers

ExportCustomers

*Granularity:* passed customers.

#### Element: Customer Address

Customer import never sets an address as the customer's default address if it's explicitly marked as `preferred='false'`. To import customers with no default address, set `preferred` to `false` for all addresses.

#### Element: Customer Number

When importing customers, the customer number is optional.

If the import file provides the customer number, the import creates a customer using it and identifies that customer by the number when updating the record.

If the import file doesn't provide a customer number, the system identifies the customer by their login. Make sure customer login is unique and case-sensitive if password encryption isn’t in "scrypt" format.

If the system doesn't find the customer, it creates a customer record using a system-generated customer number.

#### Data Group: Customer Lists

Site Import/Export supports the data group customer lists. B2C Commerce imports site assignments to a customer list as a site preference, similar to catalog, inventory list, and price book assignments. B2C Commerce exports the same customers for all sites assigned to the same customer list.

#### Element: Gender

If the gender element isn't present in the import file, gender isn't updated in the database. If gender is empty, gender is set to null in the database. If the gender element has the value of male or female in the import file, B2C Commerce stores male as one in the database and female as two. If the gender attribute has a numeric value, B2C Commerce stores the value in the database as is.

#### Element: Country-Code

The `country-code` child element of the `address` complex type allows the import or export of country codes with one or two characters. Previous to version 12.2, B2C Commerce imported or exported only two character country codes. Country codes aren’t exported if they contain only whitespace. However, even though the country codes aren’t included in the exported XML file, the address is still exported.

Customer addresses including an address ID with leading or trailing whitespace are properly exported. Previous to version 12.2, it wasn’t possible to export a customer address that included leading or trailing whitespace.
