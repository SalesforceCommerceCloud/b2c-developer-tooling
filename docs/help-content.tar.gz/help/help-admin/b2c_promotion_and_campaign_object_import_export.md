# Promotion and Campaign Object Import and Export in B2C Commerce

_Use the promotion.xsd schema file to import campaigns and promotions. Promotions can be assigned to multiple campaigns. This topic applies to B2C Commerce._

| Object Information | Details |
| --- | --- |
| Schema file | promotion.xsd |
| Granularity | Selected promotion. |
| Business Manager import location | ***site* > Merchant Tools > Online Marketing > Import & Export** and ***site* > Administration > Site Development > Site Import & Export** |
| Pipelets | ImportPromotions ExportPromotions |

## Globally Excluded Products Import and Export in B2C Commerce

_The promotion import includes Global Product Exclusions rules. This topic applies to B2C Commerce._

When configuring Global Product Exclusions rules, keep the following in mind:

- An empty Global Product Exclusions rule isn't exported.
- Global product exclusion rules are replicated with the campaigns and promotions of the site.
- Global product exclusion rules are replicated with the campaigns and promotions of the site.
- New promotion-level settings are replicated with the promotion.
- The `promotion.xsd` top-level element <promotions> contains the element <global-promotion-settings> of complex type PromotionSettings. This element is the container of the <global-excluded-products> rule.
- The <global-promotion-settings> element is optional and can occur at most one time. The complex types ProductPromotionRule and OrderPromotionRule support the flag <disable-global-excluded-products>.

A site always owns a PromotionSettings instance. This instance can never be deleted, but only reset. The following is how the different modes behave:

| <promotion-settings> | Update or Merge | Replace | Delete |
| --- | --- | --- | --- |
| with <global-excluded-products> | Global excluded product rule is created or updated. | PromotionSettings instance is reset to its initial state (meaning that all of its values are removed), after that global excluded products rule is created. | PromotionSettings instance is reset to its initial state (meaning that all of its values are removed). |
| with <global-excluded-products/> empty | If it exists, the global excluded product rule is removed. | PromotionSettings instance is reset to its initial state (means all of its values are removed), after that global excluded products rule is NOT new created. | PromotionSettings instance is reset to its initial state (means all of its values are removed). |
| empty | PromotionSettings instance isn't touched. | PromotionSettings instance is reset to its initial state (means all of its values are removed). | PromotionSettings instance is reset to its initial state (means all of its values are removed). |
| undefined | PromotionSettings instance isn't touched. | PromotionSettings instance isn't touched. | PromotionSettings instance isn't touched. |

> **Note:** If the import creates promotions with no <disable-global-excluded-products> flag, it sets the default value to FALSE. The import always updates the global-excluded-products rule completely. There’s no partial update of the rule.

## Attribute Operators in B2C Commerce

_Promotion product and shipping product rules support operators for system and custom attributes. This topic applies to B2C Commerce._

This table lists the system attribute operators.

| Attribute | Operators |
| --- | --- |
| ID | is equal  is not equal  starts with ends with |
| Brand | exists  doesn't exist is equal  is not equal  starts with ends with |

This table lists the operators available for any custom attributes you choose to create. Which operators are available differs by the data type of the attribute.

| Data Type | Operators |
| --- | --- |
| String and Set-of-String | exists  doesn't exist is equal  is not equal  starts with ends with |
| Enum-of-String | is equal  is not equal  starts with ends with |
| Integer, Set-of-Integer, and Enum-of-Integer | exists  doesn't exist is equal  is not equal  is greater than or equals is less than or equals |
| Boolean | exists  doesn't exist is equal |

## Promotion_Campaign_Assignent Element in B2C Commerce

_The <promotion-campaign-assignment> element is at the top level in the XML for assignment of promotions to campaigns. This topic applies to B2C Commerce._

When using the <promotion-campaign-assignment> element, keep the following in mind:

- Each <promotion-campaign-assignment> element requires a <promotion-id> and <campaign-id>matching a valid promotion and campaign. If a promotion or campaign isn't found, an error message is logged and the element is skipped.
- All contained elements are optional. When optional elements aren’t provided for existing assignments in MERGE or UPDATE modes, the corresponding values aren’t changed. When optional elements aren’t provided for new assignments in MERGE and REPLACE modes, default values are used.
- Deletes are supported for the <promotion-campaign-assignment> element using mode="delete".
- When only <promotion-id> or <campaign-id> is provided with a delete, it acts as a wildcard delete. The delete can be for assignments of a specified promotion to all campaigns, or the assignments of all promotions to a specified campaign.
- When both <promotion-id> and <campaign-id> are provided, it's a delete of the assignment of the specified promotion to the specified campaign.
- A warning message is logged if the wildcard delete can't be performed because no assignments match the criteria.

## Trimmed Whitespace in B2C Commerce

_Learn how leading and trailing white spaces are managed when editing product rules. This topic applies to B2C Commerce._

When editing promotions and shipping methods product rules, it's possible to accidentally enter leading and trailing whitespace for some IDs. These IDs can include Products, Price Books, Brands, or Catalog Categories. The system trims leading and trailing white spaces in the following ways:

- Business Manager trims IDs of whitespace when saving a product rule.
- IDs contained in the product rules of existing promotions or shipping methods are also trimmed of whitespace during promotion and shipping method export.
