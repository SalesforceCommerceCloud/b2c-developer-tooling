# Configure an External CDN or Third-Party Proxy

_Use your own content delivery network (CDN) with Salesforce B2C Commerce's embedded CDN to deliver static and dynamic content to your customers. Deploy your CDN (or a reverse proxy) in front of B2C Commerce to improve performance and security, or to provide extra functionality._

Layer your CDN or third-party proxy in front of B2C Commerce. Shopper requests go to your CDN first, then to the embedded CDN, and then to your B2C Commerce instance. To set up this configuration, specify the client IP header and site aliases in Business Manager, and then configure your CDN and DNS.

[Which Salesforce Commerce Product Do I Have?](https://help.salesforce.com/s/articleView?id=commerce.comm_what_product.htm)

> **Note:** When fronting wildcard custom hostnames with an external CDN, make sure TXT-based validation is supported and records are propagated. See [Wildcard Custom Hostnames](https://help.salesforce.com/s/articleView?id=cc.b2c_add_wildcard_custom_hostname.htm&type=5).

1. In Business Manager, click App Launcher _(image: App Launcher)_, and then select **Merchant Tools >  *site*  > SEO & Discoverability > Customer CDN Settings**.

   The Customer Content Delivery Network Settings page opens. Customer CDN settings are instance-specific. They aren't transferred to other instances with the Data Replication process.
2. In the Dynamic Content section, enter the Client IP Header Name.

   The CDN uses the Client IP Header value to transfer the client's IP address to enable client IP-based services, such as geo-location. B2C Commerce uses this setting to retrieve the client IP address from a request header instead of the network connection source address. If the request header isn't provided, B2C Commerce uses the connection source address. If a CDN terminates client requests, B2C Commerce continues to use the client IP header name functionality.
   
   > **Note:** B2C Commerce prohibits use of the following header names, regardless of capitalization or if you replace the dashes with underscores:
   > 
   > - `cf-connecting-ip`
   > - `true-client-ip`
   > - `x-forwarded-for`
3. Click **Save**.
4. To configure the site name, select **Merchant Tools >  *site*  > SEO & Discoverability > Aliases**, and configure the site name.
5. Click **Save**.
6. To use an external CDN with B2C Commerce, after you define the Client IP Header Name and site aliases, complete the configuration on your third-party proxy and DNS.

   1. Enter the B2C Commerce instance as the origin server, for example, `your-domain.cdn.cloudflare.net`.
   2. Pass the host header (for example, www.customer.com) back to the eCDN.
   
      > **Note:** Don't send the entire B2C Commerce instance (www.customer.com.cdn.cloudflare.net) back to the eCDN.
   3. Configure the client IP header name that you entered in step 2.
   4. Make sure that responses are only cached in the CDN if the origin sends a cache header.
7. In your DNS, point the DNS entry for your site to your `CDN CNAME`.

> **Note:** The eCDN security feature can incorrectly identify a third-party proxy as an offending IP address or server and block it, affecting more users than intended. To prevent this, see [Trusted Proxies and eCDN Request Blocking](https://help.salesforce.com/s/articleView?id=cc.b2c_verify_third_party_requests.htm&type=5), which describes the recommended options (eCDN custom rules and secret headers) and the not-recommended option (adding a trusted proxy to the firewall allowlist). For allowlist steps, see [Manage IP Address Lists for eCDN Zones](https://help.salesforce.com/s/articleView?id=cc.b2c_manage_trusted_ip_address_lists.htm&type=5).

## Related Content

- [Trusted Proxies and eCDN Request Blocking](https://help.salesforce.com/s/articleView?id=cc.b2c_verify_third_party_requests.htm&type=5)
  When you stack a third-party CDN or proxy in front of B2C Commerce eCDN, the eCDN security feature can mistake the proxy for an attacker and block it. Verify trusted proxy traffic so that legitimate requests aren't blocked.
