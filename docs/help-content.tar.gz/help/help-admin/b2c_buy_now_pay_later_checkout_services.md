# Buy Now and Pay Later Payment Services for B2C Commerce

_The buy now, pay later payment option for B2C Commerce makes it convenient for shoppers to purchase items in all price ranges. Salesforce Payments offers Buy Now, Pay Later payment through Klarna and AfterPay._
