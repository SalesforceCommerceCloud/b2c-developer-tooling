# Request eCDN-web application firewall (WAF) Logs with an Open Commerce API (OCAPI) Call for B2C Commerce

_Use an OCAPI call to request the eCDN-WAF log. A minimum period of five minutes is now enforced for retrieving WAF logs._

The current time is 11 am. To retrieve a 60-minute increment log file, set the start time at 09:55 pm and the end time at 10:55 pm. The setting is for a 60-minute increment and the end time isn’t within 5 minutes of the current time (2 pm). This prevents setting the end time for log requests within 5 minutes of the current time.

| OCAPI Call Example |
| --- |
| POST https//<yourvanityhostname>/s/-/dw/data/v18_8/log_requests/ecdn HEADER Authorization: Bearer aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa REQUEST BODY {zone_name: "redcliff.de", start_time: "2024-04-04T09:55:00.000Z", end_time: "2024-04-04T10:55:00.000Z"} |
