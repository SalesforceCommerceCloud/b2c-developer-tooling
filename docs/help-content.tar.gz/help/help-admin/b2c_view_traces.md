# View Traces (Beta)

_Open the Traces page in Log Center to see traces for your B2C Commerce realm._

Your realm must be participating in the Traces Beta. See [b2c_traces.xml](https://help.salesforce.com/s/articleView?id=cc.b2c_traces.htm&type=5).

1. Open Log Center.

   See [b2c_start_log_center.xml](https://help.salesforce.com/s/articleView?id=cc.b2c_start_log_center.htm&type=5).
2. In the header navigation bar, click **Traces**.

   _(image: The Log Center header navigation bar with the Traces tab highlighted.)_
3. Select your realm from the realm filter in the upper-right corner of the page.

The Traces page opens and shows traces for your realm.
