# Security Event Auditing in B2C Commerce

_Salesforce B2C Commerce provides various log files, including a security log. The security log contains log entries for Business Manager logins._

All Salesforce systems used to provision B2C Commerce Services—including firewalls, routers, network switches, and operating systems—log information to your respective system log facility or a centralized log collection server. This enables security reviews and analysis. Security logs give you security situational awareness. To better investigate and share information in the event of a security-related issue, including fraud, abuse, or other suspicious behavior, download and collect logs available on your instances. Security log information can help you determine who, what, when, and how a cyber attack occurred.

Security log files are located here: `https://<instance-name>/on/demandware.servlet/webdav/Sites/Securitylogs`

Security log entries can look like the following sample entry.

```
[2015-10-28 02:23:19.139 GMT] [DW-SEC] (User: 'username' (Sites), IP: 100.100.10.100 [LOGIN] : logged in.)
```

The security log also includes the following information.

- The session ID to the log entry for Business Manager logins.
- Log entries for re-logins when Business Manager requires the password due to inactivity. These log entries log the old and the new session ID.

Security log files are automatically deleted after 90 days. Users and clients can't delete security logs, or turn off security logging. To retain log files longer than 90 days, you must download the files and store them locally or in a dedicated storage.

### WebDAV

B2C Commerce logs file and folder access through WebDAV in the security log for all users. Each file and folder access log message has the same construction. The message contains the used WebDAV method and the accessed or requested file or folder path within the accessible directory structure. The following are examples of messages for WebDAV methods:

- Create directory (MKCOL)
   
   ```
   [DW-SEC] User: 'support' (Sites), IP: 100.100.10.100, [MKCOL] : /src/myfolder - starting (inIMPEX)
                        
   [DW-SEC] User: 'support' (Sites), IP: 100.100.10.100, [MKCOL] : /src/myfolder - finished successfully (in IMPEX)
   ```
- Upload file (PUT)
   
   ```
   [DW-SEC] User: 'support' (Sites), IP: 100.100.10.100, [PUT] : /src/myfolder/my-testfile.pdf - starting (in IMPEX)
   
   [DW-SEC] User: 'support' (Sites), IP: 100.100.10.100, [PUT] : /src/myfolder/my-testfile.pdf - finished successfully (in IMPEX)
   ```
- Move file to another location (MOVE)
   
   ```
   [DW-SEC] User: 'support' (Sites), IP: 100.100.10.100, [MOVE] : /src/myfolder/my-testfile.pdf --> /src/myfolder2/my-testfile.pdf - starting (in IMPEX)
   
   [DW-SEC] User: 'support' (Sites), IP: 100.100.10.100, [MOVE] : /src/myfolder/my-testfile.pdf --> /src/myfolder2/my-testfile.pdf - finished successfully (in IMPEX)
   ```
- Download file (GET)
   
   ```
   [DW-SEC] User: 'support' (Sites), IP: 100.100.10.100, [GET] : /src/myfolder2/my-testfile.pdf - starting (in IMPEX)
   
   [DW-SEC] User: 'support' (Sites), IP: 100.100.10.100, [GET] : /src/myfolder2/my-testfile.pdf - finished successfully, downloaded 425 kb of 425 kb (in IMPEX)
   ```

For each WebDAV method, the begin and end is logged.

### Folder Browser

B2C Commerce logs file access through folder browser in the security log for all users. Folder browsing is intentionally not logged. The log message for viewing and downloading a file is the same:

```
[DW-SEC] User: 'support' (Sites), IP: 100.100.10.100, [GET] : /src/myfolder2/my-testfile.pdf - starting (in IMPEX) 

[DW-SEC] User: 'support' (Sites), IP: 100.100.10.100, [GET] : /src/myfolder2/my-testfile.pdf - finished successfully, downloaded 425 kb of 425 kb (in IMPEX)
```

### Tracking Internal User Access

The B2C Commerce Security model regarding actions taken by Salesforce employees on customer realms include transparent logging of all sensitive areas. When any read or write action is taken on a sensitive area, B2C Commerce records the Business Manager username of the Salesforce employee, the area, and the action in the security log available for customer use. The goal of the security control is to make the actions of Salesforce employees more apparent via observation or through changes of realm-specific customer information.

- Salesforce defines sensitive areas at this time. They include, but aren’t limited, to security settings, access to shopper or order data, and access to campaigns or coupons.
- All access (regardless of read or write action) is logged.
- All modifications to user roles and permissionss are logged.
- All access to any custom module the merchant has installed in Business Manager is logged.
- Access is recorded and stored in the Business Manager security log.
- The Business Manager username of the Salesforce employee (email address) is logged.

The following are not covered by security logging:

- Folder browsing through folder browser
- File access through Import and Export
- File access through script API

The following list is an example of some, but not all, of the Sensitive areas that are logged:

- site-urls_aliases
- site-prefs_apple-pay
- orders_paymethods
- orders_paymentmethods
- marketing_coupons
- marketing_giftcert
- marketing_campaigns
- customer_groups (effectively read-only because API permissions are restricted)
- customers_gdpr
- customers_batchprocs
- customer_service_center_module
- content_pages
- content_impex
- sourcecode
