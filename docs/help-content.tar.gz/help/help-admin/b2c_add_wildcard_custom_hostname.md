# Configure Wildcard Custom Hostnames

_Use a single wildcard custom hostname (for example, `*.merchantsite.com`) to cover multiple subdomains and reduce onboarding and management overhead in eCDN via Business Manager._

Guidelines for Wildcard Custom Hostname Usage

Customers can leverage wildcard custom hostnames in eCDN, accessible through Business Manager, to streamline custom hostname management with wildcard configurations. Use this approach to create a single wildcard custom hostname, such as `*.merchantsite.com`, which automatically covers multiple subdomains like `shop.merchantsite.com` and `blog.merchantsite.com`. The key benefit is a significant reduction in overhead when onboarding and managing new hostnames because additional individual configurations are no longer necessary.

| Requirement | Details |
| --- | --- |
| Zone Type | Wildcard custom hostnames are only supported for **Proxy V2** zones. |
| Unique hostname across instances | Only one instance of a specific wildcard custom hostname is allowed across all e-commerce instances (for example, development, staging, production). If you use `*.merchantsite.com` in production, use a different hostname like `*.dev-merchantsite.com` or `*.stg-merchantsite.com` for other instances to avoid conflicts. |
| Certificates | Customers can choose between **eCDN Managed Certificate** (handled and renewed by eCDN, reducing overhead) or **Self-Managed Certificate** (customers upload their own certificate). |
| SAN coverage (self-managed) | For self-managed certificates, Subject Alternative Names (SANs) cover both the wildcard hostname (for example, `*.merchantsite.com`) and the root domain (for example, `merchantsite.com`). Failure to cover both results in an error during upload in the Business Manager (BM) UI. |
| SAN coverage (eCDN managed) | For eCDN managed certificates, SAN values automatically include both the wildcard and root domain. |
| Legacy/O2O conflict | If a customer already has an active legacy zone (via eCDN or as an existing Cloudflare customer/O2O) for the fully qualified domain name (FQDN) (for example, `merchantsite.com`), the legacy zone takes priority over the Proxy zone. In this scenario, wildcard custom hostnames do not work. See [Hostname priority](https://developers.cloudflare.com/ssl/reference/certificate-and-hostname-priority/#hostname-priority). |
| Certificate validation method | When using eCDN managed certificates for wildcard hostnames, certificate validation uses the **TXT** method. Activating the certificate requires adding the necessary CNAME/TXT DNS records to your authoritative DNS. |

1. Make sure that your aliases include all hostnames associated with the domain:

   _(image: Configure aliases to include all hostnames associated with the domain.)_
2. After you configure the proxy zone it is active, verify that all hostnames added to the alias file appear on the eCDN settings page:

   _(image: Verify hostnames appear with eCDN settings.)_
3. Select **Settings/Certificates** next to the proxy zone to open the SSL configuration window:

   _(image: Upload Custom Certificate dialog with eCDN Managed Certificate selected and Enable Wildcard Hostname highlighted)_
4. Select **Add Certificate** to open the certificate dialog and locate the **Enable Wildcard Hostname** toggle.

   _(image: Upload Custom Certificate dialog with TXT Validation and wildcard hostname enabled)_
5. Select a certificate type:

   - **Self-Managed Certificate**
   - **eCDN-Managed Certificate**
   
   > **Tip:** Use an **eCDN-managed certificate** to reduce renewal and expiration management overhead.
   
   If you select an eCDN-managed certificate and enable **Enable Wildcard Hostname**, all hostnames are auto-selected and disabled (greyed out). Wildcard hostnames require the validation method to be **TXT**.
   
   For the eCDN-managed certificate, **TXT validation** is required to activate the certificate. We strongly recommend managing TXT validation by adding the DCV delegation CNAME record and its corresponding value to your authoritative DNS. These appear in the certificate summary pane.
   
   _(image: Certificates table showing wildcard hostname in Pending Validation with DNS records required for verification)_
   
   When using DCV delegation, eCDN handles both initial certificate activation and subsequent renewals automatically. If you don't use DCV delegation, activate the certificate by adding both the certificate and wildcard TXT records to your authoritative DNS. For renewals, refer to the important note.
   
   It takes a few minutes for DNS propagation to complete and activate the certificate.
   
   > **Tip:** If you don't add the DCV delegation CNAME, you are responsible for manually renewing the TXT validation records in your authoritative DNS after every certificate renewal.
   
   The certificate's status changes to **Active** on the Certificate tab when the process is complete, and eCDN removes the activation records from display.
   
   Complete a validation process to activate the hostname.
   
   Upon completion of all steps, all hostnames configured in the initial step serve traffic.
   
   Create a specific hostname certificate (for example, `shop.merchant.com`) even if a wildcard certificate (`.merchant.com`) already exists. When both are present, the specific hostname certificate takes precedence over the wildcard per established hostname priority rules.
