# Validate Adyen Payments for B2C Commerce

_Set up and validate test payments in a test or live Adyen merchant account for your B2C Commerce instance. Use an Adyen merchant account associated with your B2C Commerce instance to create test payments._

- Test merchant account: Doesn’t use actual authorizations or captures. Uses test cards and bank accounts.
- Live merchant account: Uses actual authorizations and captures for credit cards and bank accounts. Uses only valid credit cards and bank accounts.

|  |
| --- |
| Available in: **B2C Commerce** |

Associate an Adyen merchant account with your B2C Commerce instance. See [Associate an Adyen Merchant Account with B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_associate_adyen_merchant_account.htm&type=5).

1. From Business Manager, go to the Storefront.
2. Add items to your cart.
3. Checkout using multi-step checkout, Pay Now, or Buy Now (Google Pay for Chrome or Android and Apple Pay for Safari or IOS).

View the order from the storefront or from the Adyen Customer Area to confirm that Salesforce Payments processed the payment using the Adyen processor. An Adyen Payment Service Provider (PSP) reference is listed for the order.
