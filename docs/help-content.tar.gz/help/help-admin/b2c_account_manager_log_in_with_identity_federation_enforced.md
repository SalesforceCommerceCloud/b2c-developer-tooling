# Log In with Identity Federation Enforced

_Before logging in for the first time, you receive an email with a login link. This topic applies to Account Manager and B2C Commerce._

[Which Salesforce Commerce Product Do I Have?](https://help.salesforce.com/s/articleView?id=commerce.comm_what_product.htm)

1. In the email, click **Log in with Single Sign-on**.
2. Enter the email address associated with your Salesforce ID or third-party identity provider and authenticate your account.

   If your username is different from your email address, enter the username associated with your Salesforce ID or third-party identity.
