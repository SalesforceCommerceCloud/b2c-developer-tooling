# Use 2FA on All Privileged Accounts

_Two-factor authentication (2FA) is an extra layer of protection beyond a single password. The extra protection can be knowledge (something you know), possession (something you have), or biometrics (something you are). Using a second authentication factor, such as a mobile phone (something you have), provides additional protection against common security threats such as account takeover, fraud, data loss, malicious code, and phishing attacks._

By using the Salesforce Authenticator app, Account Manager uses the possession metric as the secondary form of authentication. Push notifications and verification codes for 2FA are supported.
