# Limit Storefront Order Allowlist FAQ

_Unauthorized access to storefront orders happens when an order is accessed through a storefront session using a different customer ID than the one it was created with. This makes it possible for unauthorized users to view the order’s details._

**Are my orders insecure in B2C Commerce without this feature?**

Trust is our #1 value. We protect our customers’ orders and with this feature we provide our customers with a tool to also secure the orders handled with customizations.

**Can we test this feature in advance?**

The allowlist will be fully functional in 24.8. In the meantime, you can switch your production instance to use the allowlist without any impact on your business. After you enabled the allowlist, Business Manager Alerts identify unauthorized storefront order access. Users with access to the Order Preferences module will see these alerts and can review whether all of these controllers are required. Controllers that need access can be copied and pasted from the alert into the allowlist. Access to orders won’t be blocked until the 24.8 release. This is a temporary testing period for you to test and configure the feature for your instance.

**Do I add jobs that access orders to the allowlist?**

This feature only applies to order access from the storefront. Order access in custom jobs or in Business Manager isn't restricted and doesn't require addition to the allowlist.

**What format do I use to add controllers or hooks to the allowlist?**

The easiest way to add your controllers to the allowlist is to copy and paste them from the Business Manager Alert highlighting unauthorized storefront order access. Alternatively you can add the controllers or hooks proactively as comma-separated list.

- Add controllers. For example: `product-show`, `cart-show`
- Add all controllers under a controller base name use the base name, for example: `product`
- Add hooks, use the name of the hook, for example: `dw.order.requiredHook`

Wildcards are not supported.

**How do I know which controllers to allowlist?**

In Business Manager > Order Preferences, set Limit Storefront Order Access Allowlist. Any storefront controller or hook that tries to access storefront orders using a customer ID that doesn't belong to the current session ID is flagged as a Business Manager alert. Users with permission for the Order Preferences Module can review the controller and hook list to identify which controllers can access storefront orders. The user can copy and paste the required controllers into the allowlist.

**What type of order access is being checked for?**

This feature applies to fetching the order (searchOrders, getOrder) but doesn't apply to getting/setting a property of an order.

**Which is the most secure option for storefront order access?**

To best protect your orders from unauthorized access from the storefront, select Yes from the Limit Storefront Order Access dropdown. This setting can block controllers that need storefront order access. To continue granting access to those controllers, select Allowlist.

**Can I add pipelines to the allowlist?**

No, this feature doesn't support pipelines. They aren’t blocked.

**Does the allowlist apply to order access in general?**

No, the allowlist only applies to attempts to retrieve an order in the storefront. Order access isn’t restricted during custom jobs, in Business Manager, or in agent use cases.

**What happens if I don’t want to use this feature and keep Limit Storefront Order Access to No?**

To protect your shoppers’ privacy, Salesforce highly encourages securing storefront order access. The No option will be deprecated in a future release (advanced notice will be provided). For the 24.8 release, the No option remains functional and you see no disruption. Business Manager alerts remind users with access to the Order Preferences module to move to a more secure option.
