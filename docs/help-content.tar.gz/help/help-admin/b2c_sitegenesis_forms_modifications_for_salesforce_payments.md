# SiteGenesis Forms Modifications for Salesforce Payments

_Forms can persist form data during a session and store it in system objects or custom objects. Localize the shippingaddress.xml forms to support PayPal on B2C Commerce SiteGenesis._

Form Modifications

- `shippingaddress.xml`
   
   - Change the value of the United States option in the country picklist from “us” to “US”
      
      > **Note:** PayPal rejects lowercase country codes. The platform includes shopper shipping address information in the PayPal order as-is. To support SiteGenesisGlobal in other locales, you update the forms for those locales.
