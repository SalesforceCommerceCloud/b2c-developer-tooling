# Additional Embedded CDN Resources

_We've prepared some resources to help you optimize your B2C Commerce experience with Embedded CDN._

- [Understanding the Cloudflare Cookies](https://support.cloudflare.com/hc/en-us/articles/200170156-Understanding-the-Cloudflare-Cookies): Use this page to learn more about Cloudflare cookies and how they are used.

## Related Content

- [eCDN Proxy Zone FAQ for B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_ecdn_proxy_zone_faq.htm&type=5)
  Find answers to your eCDN proxy zone questions.

- [eCDN on On-Demand Sandboxes – FAQ](https://help.salesforce.com/s/articleView?id=cc.b2c_ecdn_ods_faq.htm&type=5)
  Find answers to common questions about eCDN on B2C Commerce On-Demand Sandbox (ODS) instances, including what's auto-provisioned, the shared zone model, vanity domain support, and feature parity with production environments.
