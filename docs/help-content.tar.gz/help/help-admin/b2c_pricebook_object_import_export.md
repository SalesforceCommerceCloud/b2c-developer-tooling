# Price Book Object Import/Export in B2C Commerce

_Use the pricebook.xsd schema file to import price books. This topic applies to B2C Commerce._

*Granularity:* selected price book.

### Deleting Price Tables

The price book import supports two deletion modes with different behaviors:

- **delete mode**: Removes only continuous price entries (price entries without an "online from" or "online to" date range). To delete scheduled price entries using this mode, explicitly pass the `online-from` and `online-to` date values in the XML.
- **delete-all mode**: Removes all price entries for a SKU, regardless of whether they are continuous or scheduled. This mode doesn’t require date parameters.

To delete all price tables associated with a specific SKU with a single line, use the `delete-all` attribute, as follows:

```
<price-table product-id="xyz" mode="delete-all" /> 
```

To delete a continuous price entry using `delete` mode:

```
<price-table product-id="xyz" mode="delete" /> 
```

To delete a scheduled price entry using `delete` mode, include the date range:

```
<price-table product-id="xyz" mode="delete" online-from="2026-01-01T00:00:00.000Z" online-to="2026-12-31T23:59:59.999Z" /> 
```

### Import Mode and Storefront Visibility

If you import your price book in UPDATE mode, you update each row in the price book table in one transaction and the new price is visible in the storefront after the transaction commits.

When updating price tables, remember that a product can have only one active price table at a time. Don’t update a price table’s online dates to overlap the online dates of another price table for the same product.

If you import in REPLACE mode, you load the whole price book in one transaction and the new prices shown after transaction commit. The prices for the cart aren’t cached but the script calculateCart.ds loads the price for a line item. Price book changes made in this mode are visible in the storefront after the transaction has been committed. If a line item price changes after the price book load, the new price is visible in the cart as well.

If you import a [read-only price book](https://help.salesforce.com/s/articleView?id=cc.b2c_optimized_price_books.htm&type=5), the time it takes to complete the import decreases by 60%. However, the prices can't be manually edited in Business Manager. Read-only price books can be imported in REPLACE mode for the fastest import times and fewest import failures. To use read-only price books, contact Salesforce Customer Support to have the High Scale Price Books feature enabled.

You can't change the currency of a price book using import in MERGE or UPDATE mode. However, you can change the currency of a price book in REPLACE mode.

If you import your price book in DELETE mode, you delete the complete price book, instead of just the price assignments of SKUs listed in the XML.

If you don't plan to reuse the price book, we recommend creating a custom job calling script API PriceBookMgr.unassignPriceBookFromAllSites(PriceBook). This API removes all price book site assignments for that price book after you delete the price book.

Price book import ignores price books containing a negative amount or quantity value. The import log reports the problem.

Price book import rejects price books with unknown currencies. The system reports a data warning.

### Read-Only Price Books

`Delete` and `Delete-all` are the only mode attributes supported for read-only price books. If you import a read-only price book in REPLACE mode with any mode attribute, the import succeeds but ignores the mode attribute. If you import a read-only price book in MERGE or UPDATE mode with the `delete` attribute, it behaves the same as an editable price book.

Read-only price books process Delete-all imports first. For example, you’re selling scarves with a tiered pricing structure. If a shopper buys one, they cost three dollars each. If the shopper buys five scarves, they cost two dollars each. You want to update your pricing for the scarves so that they cost two dollars and fifty cents regardless of how many a shopper purchases. You can update the price table using the Delete-all import mode.

When importing a read-only price book, you can’t specify a <targetNamespace> value.

| Price Table Name | Price Table Value |
| --- | --- |
| Original Price Table | <price-table product-id="scarf">  <amount quantity="1">3.00</amount>  <amount quantity="5">2.00</amount> </price-table> |
| Imported Price Table | <price-table product-id="scarf">  <amount quantity="1">2.50</amount> </price-table> <price-table product-id="scarf" mode="delete-all"> </price-table> |
| New Price Table | <price-table product-id="scarf">  <amount quantity="1">2.50</amount> </price-table> |

After the import, only the price in the new price table takes effect. All scarves cost two dollars and fifty cents, regardless of quantity purchased.

### Pipelets

ImportPriceBooks

ExportPriceBooks

*Granularity:* passed price books.
