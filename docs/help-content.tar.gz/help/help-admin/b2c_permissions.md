# Permissions, Users, and Roles in B2C Commerce

_To facilitate efficiency of operation and security when using B2C Commerce, assign and restrict access based on your defined roles. Only a user with the administrator role can control users and permissions._

To restrict access during storefront testing and development configure your storefront password protection.
