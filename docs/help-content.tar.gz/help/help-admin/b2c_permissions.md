# Permissions, Users, and Roles in B2C Commerce

_To facilitate efficiency of operation and security when using B2C Commerce, assign and restrict access based on your defined roles. Only a user with the administrator role can control users and permissions._

To restrict access during storefront testing and development configure your storefront password protection.

## Related Content

- [Define Your Organization Profile](https://help.salesforce.com/s/articleView?id=cc.b2c_organization_profile.htm&type=5)
  Before adding users to B2C Commerce, define your organization and all its storefronts at the highest level, including setting the default language for all storefronts.

- [Manage Salesforce B2C Commerce Users](https://help.salesforce.com/s/articleView?id=cc.b2c_managing_demandware_platform_users.htm&type=5)
  When you add new B2C Commerce users (for example, Business Manager users), assign roles that restrict access to only the modules they need. When an administrator views the list of users, they can see when a user last logged in and the number of days since then. This information appears in the instance's timezone.

- [Roles and Permissions in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_roles_and_permissions.htm&type=5)
  We recommend limiting access to modules to only users who use the module. To restrict and grant access to modules, use roles and permissions. When properly configured, a user who logs into B2C Commerce sees only the modules required for their job. This eliminates confusion and increases the security of the organization.

- [Import and Export Roles and Permissions](https://help.salesforce.com/s/articleView?id=cc.b2c_importing_and_exporting_roles_and_permissions.htm&type=5)
  Import and export access roles and users through the Site Import & Export module in Business Manager. This topic applies to B2C Commerce.

- [Storefront Password Protection and Login](https://help.salesforce.com/s/articleView?id=cc.b2c_storefront_password_protection.htm&type=5)
  To prevent shoppers from finding your storefront during development and testing, restrict access. Limit storefront access to merchants and other people involved in the project. This limit prevents crawlers and search engine robots from indexing your storefront and making it available to search engines. Both dynamic content, such as pages, and static content, such as images, are protected. This topic applies to B2C Commerce.
