# eCDN WAFv2 Exposed Credentials Check

_Exposed Credentials Check is a deprecated B2C Commerce eCDN WAFv2 managed ruleset that doesn’t work with Leaked Credentials Detection. To act on leaked credentials, create a custom firewall rule or a rate-limiting rule that uses the Leaked Credentials Detection fields._

> **Important:** Exposed Credentials Check is deprecated and isn’t recommended for new configurations. Leaked Credentials Detection is a separate capability, and Exposed Credentials Check doesn’t work with Leaked Credentials Detection. If you use Exposed Credentials Check, create a custom firewall rule or a rate-limiting rule that uses the Leaked Credentials Detection fields. See [Create a Custom Firewall Rule for an eCDN Zone](https://help.salesforce.com/s/articleView?id=cc.b2c_create_eCDN_firewall_rule.htm&type=5) and [Create a Rate Limiting Rule for an eCDN Zone](https://help.salesforce.com/s/articleView?id=cc.b2c_eCDN_create_rate_limiting_rule.htm&type=5).

The exposed credentials check ruleset is turned off by default.

- Select the action to perform. When you define an action for the ruleset, you override the default action defined for each rule. To remove the action override, set the ruleset action to Default. The available actions are:
   
   - Default
   - Managed challenge
   - Block
   - JS challenge
   - Log
   - Legacy captcha

_(image: Embedded CDN Settings)_

_(image: WAFv2 Managed Ruleset Settings)_
