# Peer To Peer Trust for B2C Commerce

_Use the Peer to Peer tab to review the tenants and application that your B2C Commerce instance trusts._

To access the tab in Business Manager, click App Launcher _(image: App Launcher)_, and then select **Administration > Global Preferences > Cross Cloud Trust**. The table is read only.
