# System Resource Locks for B2C Commerce Jobs

_When you create a B2C Commerce job, prevent another job from modifying system resources while your job is executing._

[Which Salesforce Commerce Product Do I Have?](https://help.salesforce.com/s/articleView?id=commerce.comm_what_product.htm)

Before you can set system resource locks, create the job and add its flows and steps. See [Create and Schedule a B2C Commerce Job](https://help.salesforce.com/s/articleView?id=cc.b2c_create_job.htm&type=5) and [Add Flows and Steps for B2C Commerce Jobs](https://help.salesforce.com/s/articleView?id=cc.b2c_add_job_flows_and_steps.htm&type=5).

Assign the system resource for each entity the job changes. For example, a job that changes customers assigns the profile resource, because customers are related to profile. While the job runs, another job can't change that resource. A lock is re-entrant, so a step in the job can lock a resource that the job already holds.

Use this table to match an entity to its system resource. If the job changes the entity, assign the resource in that row.

| Entity | System Resource |
| --- | --- |
| Content Library | content, folder, and library |
| Customer | profile |
| Customer List | customerlist |
| Product List | productlist |
| Customer Group | customergroup and profile |
| Custom Objects | customobject |
| Catalog | catalog, product, and metadata |
| Price Book | pricebook |
| Inventory List | inventory |
| Order | address and order |
| Tax Table | taxation |
| Shipping Method | shipping |
| Payment Method | paymentmethod |
| Search Settings | searchindex |
| Gift Certificate | giftcertificate |
| Source Code Group | sourcecode |
| Store | store |
| Content Slot | slot |
| Meta Data | metadata |
| Job Schedules | schedule |
| Services | service, servicecredential, and serviceprofile |
| Site | site Site import also affects resources for each element of the site that is imported. For example, a site import that contains stores locks the store resource. |

The product index Rebuild task locks only itself. The product index update task locks Product, Catalog, and Category.
