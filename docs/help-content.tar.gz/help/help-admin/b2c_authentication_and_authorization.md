# Authentication and Authorization in B2C Commerce

_Authentication and authorization are key security concepts. To configure security controls, you need access to Business Manager._
