# Authentication and Authorization in B2C Commerce

_Authentication and authorization are key security concepts. To configure security controls, you need access to Business Manager._

## Related Content

- [Introduction to Roles in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_introduction_to_roles.htm&type=5)
  In Business Manager, you can perform authentication to determine if the user is who they claim to be. You can also perform authorization to determine if the user has permission to perform the specific action they’re attempting.

- [Shopper Authentication in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_shopper_authentication.htm&type=5)
  Shoppers can register and create accounts on your storefront or they can remain anonymous. For example, to browse your storefront, shoppers aren’t required to log in to their account or even have an account. However, when a shopper creates an account, you now have their information, such as billing address, credit card, and previous orders. Authenticated shoppers can also access certain functionality that’s not available to anonymous shoppers, such as a gift registry and wishlist.

- [User Authentication and Authorization in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_user_authentication_and_authorization.htm&type=5)
  As an administrator, you configure security controls in Business Manager. You must perform authentication to determine if the Business Manager user is who they claim to be. You can also perform authorization to determine if the user has permission to perform the specific action they’re attempting.

- [OCAPI Client Authentication and Authorization in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_ocapi_client_authentication_and_authorization.htm&type=5)
  Open Commerce API (OCAPI) provides a RESTful interface that OCAPI clients consume (custom code). So, what about client authentication and authorization for OCAPI?

- [WebDAV Authentication and Authorization in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_webdav_authentication_and_authorization.htm&type=5)
  WebDAV is a protocol that enables you to upload and download data or code files. A merchant sends WebDAV requests to your instance’s WebDAV server. The merchant’s WebDAV client can be a Business Manager user or an API client for machine-to-machine interaction.
