# Set the Saved Payment Credentials for B2C Commerce

_Choose how Salesforce Payments uses stored credit card credentials._

1. In Business Manager, click App Launcher _(image: App Launcher)_, and then select **Merchant Tools > Site > Commerce Apps > App Catalog**.
2. In the Installed Apps section, for Salesforce Payments, click **Manage**.
3. In the Advanced Settings card, for Saved Payment Credentials, click **Change**.

   _(image: Change whether stored credit card credentials are used off-session or on-session.)_
4. Select the save payment credentials.

   - **Save for future off-session use**–During checkout, Salesforce Payments saves the shopper’s credit card credentials, and the credentials can be reauthorized for off-session use. For example, use the off-session setting and standard APIs to authorize recurring subscription payments or reauthorize payment when order fulfillment is delayed.
   - **Save for future on-session use**–During checkout, Salesforce Payments saves and uses the shopper’s credit card for only the current checkout session.
5. Save your changes.
