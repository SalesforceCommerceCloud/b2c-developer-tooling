# Create a Legacy Job

_Legacy B2C Commerce jobs use pipelines that a developer creates using the UX Studio plug-in to the Eclipse IDE. This functionality is deprecated. We recommend creating jobs using the new job framework._

To complete this procedure, you must know:

- Pipeline and start node for the job.
- Parameters required for the pipeline.
- System objects updated during job execution.

For jobs defined for the entire Organization, the cartridge containing the pipeline must be included in the cartridge path for the Business Manager Site. Click App Launcher _(image: App Launcher)_, and then select **Administration > Site > Manage Sites > Business Manager Site > Manage the Business Manager Site**. For jobs defined for a site, the cartridge containing the pipeline must be included in the cartridge path for the site. Click App Launcher _(image: App Launcher)_, and then select **Administration > Site > Manage Sites > *site* **.

1. Click App Launcher _(image: App Launcher)_, and then select **Administration > Operations > Jobs (deprecated)**.
2. Click **New**.
3. Enter a name and description.
4. Specify the execution scope.
5. Enter the pipeline name and start node.
6. Enter a date for the job to run once, or specify a recurring interval.
7. Click **Apply**.
8. For jobs with a site execution scope, click **Sites** and select one or more sites.

   Jobs with a scope of multiple sites are split into one job per site at run time. If one of the separate jobs fails, that job handles retries and failure notifications individually. The separate jobs also appear separately in the job history.
9. Click **Resources**.
10. Select the objects that the job changes or updates and then click **Assign**.

   Assigning a resource to the job prevents another job or user from changing that resource while this job operates on it. For example, while a job is updating the catalog, you don't want other jobs or users to change the catalog, categories, or products.
11. To send or receive email notifications about job status, click **Notifications** and configure email addresses and notification settings.
12. If the job pipeline requires parameters, click **Parameters** and enter the name and value for each parameter.
