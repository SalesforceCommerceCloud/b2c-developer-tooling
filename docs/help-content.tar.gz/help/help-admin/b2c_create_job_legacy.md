# Create a Legacy B2C Commerce Job

_Legacy B2C Commerce jobs use pipelines that a developer creates using the UX Studio plug-in to the Eclipse IDE. This functionality is available but is deprecated. Create jobs with the new job framework._

[Which Salesforce Commerce Product Do I Have?](https://help.salesforce.com/s/articleView?id=commerce.comm_what_product.htm)

In B2C Commerce, collect the pipeline details before you create a pipeline job.

To complete this procedure, collect:

- Pipeline and start node for the job.
- Parameters required for the pipeline.
- System objects updated during job execution.

Get the pipeline name, start node, and parameters from your developer.

**Add the Pipeline Cartridge**

Include the cartridge that contains the pipeline in the cartridge path for the Business Manager site. From the App Launcher _(image: App Launcher)_, find and select **Administration > Site > Manage Sites > Business Manager Site > Manage the Business Manager Site**. For a site job, include that cartridge in the site's cartridge path. From the App Launcher _(image: App Launcher)_, find and select **Administration > Site > Manage Sites >  *site* **.

In B2C Commerce Business Manager, create the pipeline job.

1. From the App Launcher _(image: App Launcher)_, find and select **Administration > Operations > Jobs (Deprecated)**.
2. Click **New**.
3. Enter a name and description.
4. Specify the execution scope.
5. Enter the pipeline name and start node.
6. Enter a date for the job to run once, or specify a recurring interval. For **Run Once**, enter **At**. For **Recurring Interval**, enter **Active**, **To**, **Run Time**, and **Every**. For **Every**, select **Minutes**, **Hours**, **Days**, **Weeks**, or **Months**.
7. Click **Apply**.
8. For jobs with a site execution scope, click **Sites** and select one or more sites.

   Jobs with a scope of multiple sites are split into one job per site at run time. If one of the separate jobs fails, that job handles retries and failure notifications individually. The separate jobs also appear separately in the job history.
9. Click **Resources**.
10. Select the objects that the job changes or updates and then click **Assign**.

   Assigning a resource to the job prevents another job or user from changing that resource while this job operates on it. For example, while a job is updating the catalog, you don't want other jobs or users to change the catalog, categories, or products.
11. To send or receive email notifications about job status, click **Notification** and configure email addresses and notification settings.
12. If the job pipeline requires parameters, click **Parameters** and enter the name and value for each parameter.
