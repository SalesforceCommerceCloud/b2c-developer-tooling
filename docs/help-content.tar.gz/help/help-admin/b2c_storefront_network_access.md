# Storefront Network Access in B2C Commerce

_To limit network access to a storefront, configure the embedded Content Delivery Network (eCDN) that comes with B2C Commerce. eCDN is self-service in Business Manager._

The eCDN includes Web application firewall (WAF) and IP firewall features to protect against denial of service attacks. The eCDN organizes its configuration around zones. Configure eCDN for a specific zone or globally for all zones.

Salesforce auto-provisions a SCAPI zone (`<shortcode>.api.commercecloud.salesforce.com`) with eCDN. There's no separate enablement step, and you can't create, remove, or add hostnames to a SCAPI zone. There's one SCAPI zone for Development, Staging, and Production. Configure it only from the Production instance. It doesn't appear in Business Manager or the CDN API on Development or Staging. A network-access control applied on Production affects all three environments unless you scope it by org ID. See [SCAPI Zone Support for B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_scapi_zone.htm&type=5).

In either case, you can configure firewall allowlists and blocklists for specific IP addresses and ranges. You can also configure an IP security level that uses a visitor’s IP reputation, calculated using an internal algorithm, to decide whether to require the user to solve a Completely Automated Public Turing test to tell Computers and Humans Apart (CAPTCHA) challenge before logging in. A CAPTCHA challenge is especially useful against automated attacks. At the highest security level, all visitors must respond to a CAPTCHA challenge before proceeding.

The eCDN WAF analyzes and interprets your HTTP/S traffic to protect your storefront. WAF stops application-level attacks that attempt to exploit code-level vulnerabilities. These types of attacks include cross-site scripting (XSS) and SQL injection.

You can configure action modes, including Simulate, Challenge, and Block, to determine how to respond to an OWASP threat. Similar to IP firewall settings, the Challenge action presents a CAPTCHA challenge to the suspected attacker before they can proceed to your storefront.
