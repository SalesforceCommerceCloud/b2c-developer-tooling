# Storefront Network Access in B2C Commerce

_To limit network access to a storefront, enable the embedded Content Delivery Network (eCDN) that comes with B2C Commerce. To enable the eCDN for your organization, contact Salesforce Customer Support._

The eCDN includes Web application firewall (WAF) and IP firewall features to protect against denial of service attacks. The eCDN organizes its configuration around zones. Configure eCDN for a specific zone or globally for all zones.

In either case, you can configure firewall allowlists and blocklists for specific IP addresses and ranges. You can also configure an IP security level that uses a visitor’s IP reputation, calculated using an internal algorithm, to decide whether to require the user to solve a Completely Automated Public Turing test to tell Computers and Humans Apart (CAPTCHA) challenge before logging in. A CAPTCHA challenge is especially useful against automated attacks. At the highest security level, all visitors must respond to a CAPTCHA challenge before proceeding.

The eCDN WAF analyzes and interprets your HTTP/S traffic to protect your storefront. WAF stops application-level attacks that attempt to exploit code-level vulnerabilities. These types of attacks include cross-site scripting (XSS) and SQL injection.

You can configure action modes, including Simulate, Challenge, and Block, to determine how to respond to an OWASP threat. Similar to IP firewall settings, the Challenge action presents a CAPTCHA challenge to the suspected attacker before they can proceed to your storefront.
