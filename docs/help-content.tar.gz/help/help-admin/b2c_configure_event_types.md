# Set Up Eventing in B2C Commerce (Pilot)

_Use eventing in B2C Commerce to receive notifications when certain data or processing events occur in your Commerce Cloud environment. You enable event types and configure connectors in Business Manager; B2C Commerce routes events directly to your configured connectors._

> **Note:** The B2C Commerce eventing framework is a pilot or beta service that is subject to the Beta Services Terms at Salesforce.com or a written Unified Pilot Agreement if executed by Customer, and applicable terms in the Product Terms Directory. Use of this pilot or beta service is at the Customer's sole discretion.

Eventing provides notifications when specific changes occur in B2C Commerce so you can trigger business processes in external systems, for example, invalidating cache outside the platform, syncing data to external search or order systems, or running downstream order or marketing workflows. It helps keep storefronts accurate, reduces manual tracking of when platform operations complete, and decouples your business logic from platform operations. This is especially useful for hybrid or headless storefront implementations. Eventing is intended for customer developers and merchandisers who react to platform events.

Eventing supports two main use cases: notifying your own systems (or external services) when data or processing events occur in B2C Commerce, and notifying other Commerce Cloud services. B2C Commerce delivers events only to destinations that you configure. For the pilot, there's no separate event bus; B2C Commerce routes events directly to your configured connectors (such as webhooks) from within the platform.

You enable the event types that you care about for your tenant, then configure one or more connectors, for example, a webhook URL, in Business Manager. When an enabled event occurs, B2C Commerce sends it asynchronously to each configured connector. Only enabled event types are sent, and only to the connectors you set up. If you don't configure any connector for an event type, no notifications are sent for that type.

**Event types**: the framework supports data events and processing events. For the current pilot scope, the supported event types cover replication processing and shopper registration. For the full catalog of supported events, their HTTP headers, payload fields, and example payloads, see [B2C Commerce Event Types Reference](https://help.salesforce.com/s/articleView?id=cc.b2c_event_types_reference.htm&type=5).

**Connectors**: Connectors are the destinations to which B2C Commerce sends event notifications (for example, an HTTP webhook to a URL you provide). Delivery is asynchronous via an internal event-dispatch component in near real time. For the pilot, the platform guarantees best-effort delivery. Beyond the pilot, Salesforce plans to add mechanisms for retries and more robust error handling. Authentication and security controls govern access to events. Only enabled event types generate notifications, and events are sent only to connectors you’ve configured. The current design uses a push model: B2C Commerce initiates the HTTP request to your endpoint. Confirm your endpoint returns a successful response (for example, HTTP 200) when you've accepted and processed the event. For more information about the B2C Commerce Connector, see [B2C Commerce Connector](https://help.salesforce.com/s/articleView?id=data.c360_a_commerce_cloud_connector.htm&type=5).

To set up eventing, perform the following steps:

1. In Business Manager, open the eventing or integrations area (path can vary by release).

   Add the required information for a connector (webhook) where you want B2C Commerce to deliver event notifications. Configure more than one connector so that the different events are sent to different systems:
   
   1. **URL** — URL — Enter the full endpoint URL (for example, ). Commerce Cloud requires access to the endpoint; configure firewall rules to allow Commerce Cloud to call your URL. Placeholder: example HTTP request that your webhook receives. Replace with actual sample when available. POST /events HTTP/1.1 Host: your-system.example.com Content-Type: application/json
   2. **Authentication** — If your endpoint requires authentication, configure the method (for example, API key, OAuth, or mutual Transport Layer Security (TLS)) and credentials or tokens as provided by the Business Manager UI. Store credentials securely. Do not share them.
   3. **Headers** — If your endpoint expects specific HTTP headers (for example, a custom API key header), configure them in the connector settings. The platform can automatically add standard headers (for example, `Content-Type: application/json`).
   
      _(image: Connector Event URL)_
2. Review the list of available event types and their descriptions.

   For details on each event type — including HTTP headers, payload fields, and example payloads — see [B2C Commerce Event Types Reference](https://help.salesforce.com/s/articleView?id=cc.b2c_event_types_reference.htm&type=5).
   
   _(image: Event Types and Descriptions)_
3. For each event type you want to use, enable it for your tenant.

   Only enabled event types generate notifications; disabled types do not send events. Enable or disable event types at any time. Simply specify the desired existing connector (webhook) for your interested event type. Note: You can only choose from an existing webhook when enabling an event type, so make sure that Step 1 is complete before this.
   
   Save your changes.

Use the B2C Commerce Log Center to monitor and diagnose delivery or endpoint issues. See [Log Center](https://help.salesforce.com/s/articleView?id=cc.b2c_log_center.htm).

## Related Content

- [B2C Commerce Event Types Reference](https://help.salesforce.com/s/articleView?id=cc.b2c_event_types_reference.htm&type=5)
  Find the event you want to subscribe to. Each row links to the page that documents the headers, payload, and example for that event.

- [Common HTTP Headers for B2C Commerce Events](https://help.salesforce.com/s/articleView?id=cc.b2c_event_common_headers.htm&type=5)
  Every B2C Commerce event includes the same set of standard `x-sf-cc-*` headers, so your connector can identify and correlate events consistently regardless of the event type.

- [Process-Level Replication Events](https://help.salesforce.com/s/articleView?id=cc.b2c_event_replication.htm&type=5)
  Process-level replication events fire when a B2C Commerce replication process reaches a terminal state. Use them to track when bulk replication jobs complete or fail.

- [Granular Replication Events](https://help.salesforce.com/s/articleView?id=cc.b2c_event_replication_granular.htm&type=5)
  The B2C Commerce system fires granular replication events when the granular replication job completes, partially fails, or fully fails. Granular replication operates at the per-object level (products, price tables, content assets) rather than the bulk replication-process level, so its events report which individual object IDs succeeded and which failed.

- [Shopper Registered Event](https://help.salesforce.com/s/articleView?id=cc.b2c_event_shopper_registered.htm&type=5)
  The system fires a B2C Commerce shopper registered event when a new customer profile is successfully created and committed. This event contains core customer information needed by external systems. Unlike replication events, which operate at the organization level, the shopper registered event is site-specific, so you can register and route it independently per site.
