# Set Instance Time Zone in B2C Commerce

_Set the time zone for tasks that aren’t site-specific._

For example, set a time zone for all scheduled and automated processes. Use the preferences to define your instance time zone:

The *instance* time zone for all new Salesforce B2C Commerce instances is *UTC.*

> **Note:** Existing sites are not affected.

1. In Business Manager, click App Launcher _(image: App Launcher)_, and then select **Administration > Global Preferences > Instance Time Zone**.
2. Select the continent or ocean for the geographical area (for the available instance time zones).
3. Select the time zone under which you want to operate (for the instance).
4. Click **Apply** to save the changes. The changes are effective immediately.
