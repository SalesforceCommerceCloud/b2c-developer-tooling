# Business Manager Import and Export Privileges in B2C Commerce

_Business Manager provides many levels of system privileges, and with that comes many separate importing and exporting modules. However, the functionality presented in the Business Manager is similar for each module. This topic applies to B2C Commerce._

Give a user permission for:

- Site Import/Export, which includes all site information.
- Import/Export for Operations information, such as job schedules.
- Import/Export of site information, such as products and content.
- WebDAV access to log files and import/export directories on the server
- WebDAV access to custom cartridges.

Request access to an FTP port from B2C Commerce Support if you want to use the FTPClient scripts.

Make sure that users have the appropriate permissions to run the file transfer and import/export jobs.

To set permissions, click App Launcher _(image: App Launcher)_, and then navigate to **Organization > Roles and Permissions**.
