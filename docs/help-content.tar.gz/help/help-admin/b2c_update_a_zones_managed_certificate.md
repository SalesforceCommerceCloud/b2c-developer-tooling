# Update an eCDN Zone's Managed Certificate

_When your managed SSL certificate expires, or you update the hostnames assigned to a managed SSL certificate, update the certificate in Business Manager._

|  |
| --- |
| Available in: **B2C Commerce** |

> **Note:** To update hostnames assigned to a certificate in a proxy zone, add a certificate, add the hostnames correctly, and delete the old certificate. For availability reasons, we recommend adding all hostnames to a certificate before deleting the old certificate.

To replace or delete a certificate, open the actions menu on the certificate row, and then choose **Edit** to upload a replacement certificate or **Delete** to remove the certificate. A confirmation appears before deletion.

To view additional certificate details, click the chevron at the start of a certificate row. The expanded view shows certificate type, hosts, issuer, validation method, expiration details, and any TXT or CNAME records or verification actions required for unverified certificates.

1. In Business Manager, click App Launcher _(image: App Launcher)_, and then select **Administration > Sites > Embedded CDN Settings**.
2. Click **Certificates** or **Settings** for the zone to which you’re adding a certificate.
3. From the hostnames list, select a zone and click **Certificate**.
4. On the Crypto tab, select the zone from the list.
5. From the certificate row actions menu, click **Edit** on the certificate you want to update.
6. Select **eCDN Managed Certificate**.

   _(image: Replace Custom Certificate dialog with eCDN Managed Certificate selected, showing certificate details and assignment details for an assigned hostname)_
7. From the SSL Certificate Authority dropdown, select **Lets Encrypt** (default) or **Google**.
8. From the Certificate Validation Method dropdown, select **HTTP Validation** (recommended) or **TXT validation**.
9. Select the hostname to which you want to assign the SSL certificate.
10. Click **Replace Certificate**.
11. (Optional) Validate with HTTP.

   1. Copy the displayed hostname verification text into your own DNS portal.
   
      _(image: Certificates table showing hostname with Initiating status and hostname TXT validation values to copy)_
   2. To check the status of hostname validation, click **Verify HostName**. Verification can take up to six hours
   3. After the hostname is active, create a CNAME record that points traffic, by SSL for SaaS V2, to the new zone.
   4. Configure the DNS mapping for the zone.
   
      1. Log in to your DNS provider account.
      2. Search for your zone and select it from the list.
      3. On the DNS tab, locate the hostname that you want to map.
      4. Replace all text after “is an alias of” with the DNS CNAME from Business Manager.
      5. In the Status column, click the **cloud **until it shows a gray cloud with the tooltip “DNS Only”.
   5. When the CNAME record points traffic to the new zone, check the status of the certificate validation. Click **Verify eCDN Managed Certificate**. This verification can take up to six hours.
12. (Optional) validate with TXT.

   1. Copy the displayed verification text for the hostname into your own DNS portal.
   
      _(image: Certificates table showing hostname with Pending Validation status and certificate TXT and hostname TXT values to copy, plus DCV Delegation CNAME)_
   2. To check the status of hostname validation, click **Verify HostName**. Verification can take up to six hours
   
      > **Note:** Wildcard hostnames use TXT validation and can renew automatically with DCV delegation. For details, see [Wildcard Custom Hostnames](https://help.salesforce.com/s/articleView?id=cc.b2c_add_wildcard_custom_hostname.htm&type=5).
   3. After the hostname is active, click **Verify eCDN Managed Certificate**. Verification can take up to six hours.
   4. After the hostname and certificate are active, create a CNAME record that points traffic, by SSL for SaaS V2, to the new zone.
   5. Configure the DNS mapping for the zone.
   
      1. Log in to your DNS provider account.
      2. Search for your zone and select it from the list.
      3. On the DNS tab, locate the hostname that you want to map.
      4. Replace all text after “is an alias of” with the DNS CNAME from Business Manager.
      5. In the Status column, click the **cloud** until it shows a gray cloud with the tooltip DNS Only.
   6. When the CNAME record points traffic to the new zone, to check the status of the certificate validation, click Verify eCDN Managed Certificate. This verification can take up to six hours.
