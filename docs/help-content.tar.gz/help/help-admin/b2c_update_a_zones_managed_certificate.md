# Update a Managed SSL Certificate

_When your managed SSL certificate expires, or you update the hostnames assigned to a managed SSL certificate, update the certificate in Business Manager for B2C Commerce._

[Which Salesforce Commerce Product Do I Have?](https://help.salesforce.com/s/articleView?id=commerce.comm_what_product.htm)

For the DNS mapping rules and validation methods, see [DNS Mapping for eCDN Zones](https://help.salesforce.com/s/articleView?id=cc.b2c_dns_mapping_for_ecdn_zones.htm&type=5).

To update the hostnames assigned to a certificate in a proxy zone, add a new certificate with all the hostnames, verify the hostnames, and then delete the old certificate. Adding all hostnames before you delete the old certificate avoids availability gaps.

To switch a hostname from a self-managed (custom) certificate to an eCDN managed certificate, use the CDN Zones API `updateCertificate` method with the certificate type set to `automatic`. See [updateCertificate](https://developer.salesforce.com/docs/commerce/commerce-api/references/cdn-api-process-apis?meta=updateCertificate).

1. In Business Manager, click App Launcher _(image: App Launcher)_, and then select **Administration > Sites > Embedded CDN Settings**.
2. Select a zone from the hostnames list and click **Certificate**.
3. On the Crypto tab, select the zone from the list.

   To view certificate details, click the chevron at the start of a certificate row. The expanded view shows certificate type, hosts, issuer, validation method, expiration details, and any TXT or CNAME records or verification actions required for unverified certificates.
4. From the certificate row actions menu, click **Edit** on the certificate you want to update.
5. Select **eCDN Managed Certificate**.

   _(image: Replace Custom Certificate dialog with eCDN Managed Certificate selected, showing certificate details and assignment details for an assigned hostname)_
6. From the SSL Certificate Authority dropdown, select **Lets Encrypt** (default) or **Google**.
7. From the Certificate Validation Method dropdown, select **HTTP Validation** (recommended) or **TXT validation**.
8. Select the hostname to which you want to assign the SSL certificate.
9. Click **Replace Certificate**.
10. Copy the verification text for your chosen validation method into your own DNS portal.

   - **HTTP Validation** (recommended): Copy the displayed hostname verification text.
      
      _(image: Certificates table showing hostname with Initiating status and hostname TXT validation values to copy)_
   - **TXT Validation**: Copy the displayed certificate and hostname TXT verification text, including the DCV Delegation CNAME.
      
      _(image: Certificates table showing hostname with Pending Validation status and certificate TXT and hostname TXT values to copy, plus DCV Delegation CNAME)_
      
      > **Note:** Wildcard hostnames use TXT validation and can renew automatically with DCV delegation. For details, see [Configure Wildcard Custom Hostnames](https://help.salesforce.com/s/articleView?id=cc.b2c_add_wildcard_custom_hostname.htm&type=5).
11. To check the status of hostname validation, click **Verify HostName**.

   Verification can take up to six hours.
12. (TXT validation only) After the hostname is active, click **Verify eCDN Managed Certificate** to validate the certificate through the TXT record.

   Verification can take up to six hours.
13. Map DNS so that the hostname's traffic routes to the new zone.

   See [Map DNS to an eCDN Zone](https://help.salesforce.com/s/articleView?id=cc.b2c_map_dns_to_ecdn_zone.htm&type=5). After the CNAME record points traffic to the new zone, click **Verify eCDN Managed Certificate** to check the certificate validation status. Verification can take up to six hours.
