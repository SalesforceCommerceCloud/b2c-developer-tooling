# eCDN Caching and Cache Fingerprinting

_B2C Commerce eCDN caches static storefront content on edge servers, which are servers located close to your shoppers, and refreshes it automatically using a fingerprint value in each content asset's URL. Understand how caching and fingerprinting work before you clear the cache or add cache rules for dynamic content._

[Which Salesforce Commerce Product Do I Have?](https://help.salesforce.com/s/articleView?id=commerce.comm_what_product.htm)

Because every cached asset has its own unique URL, and B2C Commerce generates a new URL whenever you upload new content, you don't need to manually purge the CDN cache. The one exception is environment replication, which clears the cache of static content as part of the process.

- **Static content** is cached by default and refreshed automatically through fingerprinting. To force an update before the cache interval expires, see [Refresh a Static Asset in the eCDN Cache](https://help.salesforce.com/s/articleView?id=cc.b2c_clear_ecdn_cache_task.htm&type=5).
- **Dynamic content** (HTML pages and JSON responses) isn't cached by default. To make dynamic content eligible for edge caching, and to selectively invalidate the content by tag or path from Business Manager, see [eCDN Cache Rules and Cache Purge](https://help.salesforce.com/s/articleView?id=cc.b2c_ecdn_cache_rules_and_purge_overview.htm&type=5).

### How Static Caching and Fingerprinting Work for B2C Commerce eCDN

- eCDN uses the `Cache-Control` header to determine how long a file stays in cache. After the time to live (TTL) expires, eCDN retrieves the updated resource. If no cache headers are set, eCDN applies a default TTL of 30 days.
- The web adapter builds pages using static assets from both eCDN and web tier cache sources. Regardless of where an asset is cached, B2C Commerce assigns every static content asset a unique fingerprint value. For example, consider this URL:
   
   `https://www.samplecustomer.com/dis/dw/image/v2/XXXX_PRD/on/demandware.static/-/Sites-customer-main-product/default/dwabb3a337/images/hi-res/shoes.jpg?sw=200&sh=200&sm=fit&sfrm=png`
   
   The value `dwabb3a337` is the asset's fingerprint, a unique identifier for that specific version of the asset.
- Although cache updates happen on the interval you set, you can still update an asset held in static cache before that interval expires, without clearing the cache or filing a support ticket. See [Refresh a Static Asset in the eCDN Cache](https://help.salesforce.com/s/articleView?id=cc.b2c_clear_ecdn_cache_task.htm&type=5).

## Related Content

- [Refresh a Static Asset in the eCDN Cache](https://help.salesforce.com/s/articleView?id=cc.b2c_clear_ecdn_cache_task.htm&type=5)
  To show an updated static storefront asset before its B2C Commerce eCDN cache interval expires, upload the new version. B2C Commerce assigns the asset a new fingerprint and URL, so eCDN retrieves it. You don't need to clear the eCDN cache or file a support ticket.

- [eCDN Cache Rules and Cache Purge](https://help.salesforce.com/s/articleView?id=cc.b2c_ecdn_cache_rules_and_purge_overview.htm&type=5)
  Cache rules control which content is eligible for caching at the eCDN edge, and cache purge selectively invalidates cached content by tag or path. Both capabilities are available in Business Manager for your B2C Commerce storefront.
