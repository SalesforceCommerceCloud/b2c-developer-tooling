# eCDN Caching and Cache Fingerprinting

_B2C Commerce eCDN caches static storefront content at the edge and refreshes it automatically using a fingerprint value in each asset's URL. Understand how caching and fingerprinting work before you clear the cache or add cache rules for dynamic content._

eCDN serves all cached content using a unique URL. Cache purging a CDN on top of URLs from B2C Commerce isn't necessary, because B2C Commerce updates the URL when you upload new content. Aside from replicating environments to clear the cache of any static content, no action is required.

### Static and Dynamic Caching

- **Static content** is cached by default and refreshed through fingerprinting, as described in this topic. To force an update before the cache interval expires, see [Clear the eCDN Cache](https://help.salesforce.com/s/articleView?id=cc.b2c_clear_ecdn_cache_task.htm&type=5).
- **Dynamic content** (HTML pages and JSON responses) isn't cached by default. To make it eligible for edge caching and to selectively invalidate it by tag or path from Business Manager, see [eCDN Cache Rules and Cache Purge](https://help.salesforce.com/s/articleView?id=cc.b2c_ecdn_cache_rules_and_purge_overview.htm&type=5).

### How Static Caching and Fingerprinting Work

When working with eCDN cache, keep the following in mind:

- eCDN uses the Cache-Control header to persist a file in cache until that TTL expires. After the cache header expires, eCDN retrieves the new resource. eCDN caches based on the value set by the cache headers. If these headers aren't set, eCDN enforces a default value of 30 days.
- The web adapter configures web pages using static assets from both eCDN and web tier cache sources. Regardless of the cache location, web tier or eCDN, B2C Commerce assigns each static content asset on your storefront a fingerprint value. For example, consider the following URL:
   
   `https://www.samplecustomer.com/dis/dw/image/v2/XXXX_PRD/on/demandware.static/-/Sites-customer-main-product/default/dwabb3a337/images/hi-res/shoes.jpg?sw=200=200=fitm=png>`.
   
   The value `dwabb3a337` is the asset fingerprint. The fingerprint provides a unique identifier for the asset.
- Updates to static cache occur at intervals you set. If necessary, you can update an asset held in static cache before the cache interval expiration. The process doesn't require clearing the cache, and you can complete it without requesting a support ticket. See [Clear the eCDN Cache](https://help.salesforce.com/s/articleView?id=cc.b2c_clear_ecdn_cache_task.htm&type=5).

## Related Content

- [Clear the eCDN Cache](https://help.salesforce.com/s/articleView?id=cc.b2c_clear_ecdn_cache_task.htm&type=5)
  To refresh a static storefront asset in B2C Commerce eCDN cache before its cache interval expires, upload the updated asset so that B2C Commerce assigns it a new fingerprint and URL. You don't need to clear the cache or request a support ticket.

- [eCDN Cache Rules and Cache Purge](https://help.salesforce.com/s/articleView?id=cc.b2c_ecdn_cache_rules_and_purge_overview.htm&type=5)
  Cache rules control which content is eligible for caching at the eCDN edge, and cache purge selectively invalidates cached content by tag or path. Both capabilities are available in Business Manager for your B2C Commerce storefront.
