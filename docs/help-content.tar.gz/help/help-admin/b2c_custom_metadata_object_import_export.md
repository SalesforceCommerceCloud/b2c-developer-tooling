# Custom Metadata Object Import/Export in B2C Commerce

_When using the system meta data import functionality, the entire definition is replaced. For example, suppose you have a custom group with three attribute groups and you want to add another attribute group to make four attribute groups. In this case, specify all four attribute group definitions in the import file. This topic applies to B2C Commerce._

This section describes the elements in the metadata.xsd and considerations when creating values for them.

The `custom-attribute-definitions`, `attribute-definitions`, and `attribute-definition` elements use the `complexType.CustomAttributeDefinition` type, which allows you to set the `externally-managed-flag` and `externally-defined-flag`. However, you can only import the `externally-managed-flag` and `externally-defined-flag` elements via the ImportCatalog; they don't import if you do the import manually in Business Manager.

*Granularity:* organization's custom object type definitions.

### Business Manager Import Location

**Administration > Site Development > Import & Export**

### Pipelets

ExportMetaData

*Granularity:* organization's custom object type definitions
