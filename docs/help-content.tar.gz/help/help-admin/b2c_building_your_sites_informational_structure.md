# Build Your Site Structure

_When building your B2C Commerce site, the order that you collect and generate the underlying product, content, and promotional qualifier information in matters. In general, create your catalog, product and pricing information first, and then create a marketing program to promote your products._

- Create the catalog and category structure, which determine site navigation.
- Create the product information.
   
   - Import or create product details, including:
      
      - Product details
         
         - Products
         - Product options
         - Variation attributes
         - Product sets
         - Bundles
      - Product attributes
      - Category assignments
      - Images
      - Inventory
   - Import or create the site content.
      
      - Text
      - Images
      - Links
      - Templates
   - Create the price books and assign prices to products.
- Create a marketing program.
   
   - Create promotional elements.
      
      - Qualifiers
         
         - Source codes and Source code groups
         - Customer groups
         - Coupons
      - Content slot configurations
         
         - Product
         - Category
         - Content Asset
         - HTML
      - Search sorting rules
   - Create promotions.
      
      - Promotion class: product, order, shipping
      - Compatibility: Exclusivity
      - Discounts
   - Create campaigns that contain:
      
      - Schedules
      - Customer groups
      - Source codes
      - Coupons
      - Experiences
         
         - Slot configurations: assign:
            
            - Slot context
            - Schedule
            - Customer groups
            - Rank
         - Promotions: assign:
            
            - Schedule
            - Customer groups
            - Source codes
            - Coupons
            - Rank
         - Sorting rules
            
            - Categories
   - Create A/B tests to test promotional elements that contain:
      
      - Customer groups
      - Experiences
         
         - Slot configurations: assign:
            
            - Slot context
            - Rank
         - Promotions: assign:
            
            - Rank
         - Sorting rules: assign:
            
            - Categories
