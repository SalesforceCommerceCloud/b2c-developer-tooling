# Content Security Policy (CSP) Configuration

_Content Security Policy (CSP) is a security feature that you configure for your storefront. When you implement CSP, you're responsible for making sure that your configuration enables the necessary scripts to run as intended._

|  |
| --- |
| Available in: **B2C Commerce** |

### What Is Content Security Policy?

Content Security Policy (CSP) is an HTTP response header that helps protect your storefront against Cross-Site Scripting (XSS) and other code injection attacks. With CSP, you control which scripts, styles, images, and other resources browsers can load on your pages.

When you configure CSP headers for your storefront, browsers enforce these policies by blocking any content that doesn't match your specified rules.

### Customer Responsibility for CSP

CSP configuration is your responsibility as a B2C Commerce customer. Salesforce doesn't manage or configure CSP on your behalf. You control which scripts, styles, and other resources can load on your storefront. Make sure your CSP configuration permits all necessary scripts to execute, including Salesforce-provided scripts and any third-party integrations. If your CSP is too restrictive, it can block scripts that your storefront requires to function properly.

### Scripts That Require CSP Consideration

When configuring your CSP, make sure that your policy allows the following types of scripts:

- **Salesforce analytics scripts** — Scripts such as `dwanalytics` that provide tracking and analytics functionality.
- **Inline scripts** — Scripts embedded directly in your HTML pages that are required for storefront functionality.
- **Einstein scripts** — Scripts that power Einstein recommendations, predictive sort, and other personalization features.

### Troubleshooting CSP Issues

If storefront features aren't working as expected, CSP restrictions can block required scripts. To diagnose CSP issues, open your browser's developer tools and check the Console tab for CSP violation errors. Then review the error messages to identify which scripts or resources the browser is blocking. Finally, update your CSP configuration to allow the blocked resources.

Work with your development team to review and adjust your CSP settings to allow all required scripts while maintaining appropriate security protections.
