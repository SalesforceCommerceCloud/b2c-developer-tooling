# Use Secure Defaults

_As an administrator, you want to make the user experience secure and reduce the number of default security settings. Configure security settings so that users must opt out of default security settings rather than opt in. If there's a security risk, clearly label insecure functionality in APIs or the user interface to discourage use._

Here are some examples.

- Call a function "dangerousInlineHTML". Don't call it "inlineHTML".
- Business Manager enforces security questions for password reset by default. Always keep this setting enabled, but customers can choose to disable it if their business demands it.
