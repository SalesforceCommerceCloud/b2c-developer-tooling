# Log In with Identity Federation Allowed

_If you already have an account, you receive an email describing your options to either link your account or log in using your Account Manager credentials. This topic applies to Account Manager and B2C Commerce._

[Which Salesforce Commerce Product Do I Have?](https://help.salesforce.com/s/articleView?id=commerce.comm_what_product.htm)

1. To link your account to your Salesforce Identity, click **Log in with Single Sign-on**.
2. To log in with Account Manager credentials, enter your Account Manager credentials.

_(image: Log in screen.)_
