# Set Feature Switches (Toggles) in B2C Commerce

_Salesforce B2C Commerce sometimes introduces new features that are disabled by default, because they can disrupt your existing sites._

|  |
| --- |
| Available in: **B2C Commerce** |

For example, a new feature changes a fundamental system behavior in a non-backward-compatible way. Make sure that you prepare your sites for the change before you enable the feature. Feature switches let you enable new features only when you’re ready, and not before.

In general, first enable a feature on one or more of your SIG instances (sandboxes) and test your site modifications. Only enable the feature on your PIG instances when you’re confident that your changes work as expected.

To enable a feature using a feature switch (toggle), perform the following steps:

1. In Business Manager, click App Launcher _(image: App Launcher)_, and then select **Administration > Global Preferences > Feature Switches**.

   The Feature Toggles page opens. This page contains zero or more features. If the page contains no feature toggles, it shows the following message: *There are currently no visible feature toggles*.
2. Check the features that you want to enable.

   For any feature toggle that is visible on this page, an administrator can have read-only or read-write permissions.
3. Click **Apply**.
