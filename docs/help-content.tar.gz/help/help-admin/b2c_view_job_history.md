# View Job History

_View the B2C Commerce job history page to see information about jobs, including status, end time, and duration._

> **Note:** Successful job executions are automatically removed from the job history page after 5 days, and failed job executions are removed after 25 days.

- For jobs created in the new job framework, click App Launcher _(image: App Launcher)_, and then select **Administration > Operations > Job History**.
- For legacy jobs, Click App Launcher _(image: App Launcher)_, and then select **Administration > Operations > Job History (deprecated)**.

Jobs for multiple sites are split into one job per site at run time. Each job appears separately in the job history. Jobs for disabled sites or sites that are in the process of being deleted don't appear in the job history.
