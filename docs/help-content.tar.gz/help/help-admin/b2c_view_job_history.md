# View B2C Commerce Job History

_View the B2C Commerce job history page to see information about jobs, including status, end time, and duration._

[Which Salesforce Commerce Product Do I Have?](https://help.salesforce.com/s/articleView?id=commerce.comm_what_product.htm)

> **Note:** Successful job executions are automatically removed from the job history page after 5 days, and failed job executions are removed after 25 days.

- For jobs created in the new job framework, from the App Launcher _(image: App Launcher)_, find and select **Administration > Operations > Job History**.
- For legacy jobs, from the App Launcher _(image: App Launcher)_, find and select **Administration > Operations > Job History (Deprecated)**.

Jobs for multiple sites are split into one job per site at run time. Each job appears separately in the job history. Jobs for disabled sites or sites that are being deleted don't appear in the job history.
