# Common Product Feed Setup

_Several setup and reference tasks apply to both the OpenAI and Google catalog feed integrations for B2C Commerce. Complete the common steps that apply to your channel, and follow the channel-specific links where the two feeds differ._

The OpenAI and Google catalog feed integrations share the same underlying setup: you meet the [site requirements](https://help.salesforce.com/s/articleView?id=cc.b2c_product_feed_prerequisites.htm&type=5), connect to the channel partner over SFTP, map and preview your product data, and turn on the daily feed sync. These tasks cover the steps that are the same for both channels. Where a step differs by channel, such as the feature switches you turn on or the field that holds the product URL, the steps call out the difference and link to the channel-specific task.

For the steps that are unique to each channel, such as the overview, the Einstein feed configuration, General Settings, field mapping, and turning on the feed, see [Catalog Feed Integration with OpenAI](https://help.salesforce.com/s/articleView?id=cc.b2c_openai_feed_overview.htm&type=5) or [Catalog Feed Integration with Google](https://help.salesforce.com/s/articleView?id=cc.b2c_google_feed_overview.htm&type=5).

Complete these common setup and reference tasks:

## Related Content

- [Prerequisites for Product Feed Integration](https://help.salesforce.com/s/articleView?id=cc.b2c_product_feed_prerequisites.htm&type=5)
  Before configuring a product feed integration, ensure your B2C Commerce site meets the requirements. The channel partner supplies the SFTP credentials that you enter in Business Manager to connect.

- [Configure Catalog and Order Feeds for Commerce Cloud Einstein Deployment](https://help.salesforce.com/s/articleView?id=cc.b2c_product_feed_configure_einstein.htm&type=5)
  Before you can use the OpenAI or Google catalog feed integration, configure Einstein catalog feeds. If your B2C Commerce site already uses Einstein features, you can skip this task.

- [Configure URL Patterns for the Product Feed](https://help.salesforce.com/s/articleView?id=cc.b2c_product_feed_pwa_urls.htm&type=5)
  If you use PWA Kit or a headless B2C Commerce storefront, override the product URL field in Field Mapping with a URL pattern so the product feed contains the correct product detail page URL for each product.

- [Connect to the Channel Partner](https://help.salesforce.com/s/articleView?id=cc.b2c_product_feed_connect.htm&type=5)
  Configure the SFTP connection between B2C Commerce and your channel partner (OpenAI or Google) to allow product feed uploads.

- [Use Custom Attributes in Product Feed Mappings](https://help.salesforce.com/s/articleView?id=cc.b2c_product_feed_custom_attributes.htm&type=5)
  Map custom product attributes to product feed fields when the default B2C Commerce standard attributes don't meet your needs.

- [Product Filter Rules for the Product Feed](https://help.salesforce.com/s/articleView?id=cc.b2c_product_feed_product_filter.htm&type=5)
  Product filter rules control which products from your B2C Commerce catalog sync to your product feed for OpenAI or Google. Configure include and exclude rules to broaden or narrow the default ruleset based on how your catalog is organized.

- [Configure Product Filter Rules for the Product Feed](https://help.salesforce.com/s/articleView?id=cc.b2c_product_feed_configure_product_filter.htm&type=5)
  Add include and exclude rules in the Product Filter rule builder to control which products from your B2C Commerce catalog sync to your product feed for OpenAI or Google.

- [About the Product Feed Preview](https://help.salesforce.com/s/articleView?id=cc.b2c_product_feed_preview_about.htm&type=5)
  The Product Feed Preview shows you the resolved feed data, including missing required fields, before you turn on the daily feed sync. Use it to verify your field mappings, identify B2C Commerce products with errors, and download a sample CSV.

- [Preview the Product Feed](https://help.salesforce.com/s/articleView?id=cc.b2c_product_feed_preview.htm&type=5)
  Open the Product Feed Preview to verify your field mappings, identify B2C Commerce products with missing required fields, and download a sample CSV before turning on the daily feed sync.

- [Known Issues for the Product Feed](https://help.salesforce.com/s/articleView?id=cc.b2c_product_feed_known_issues.htm&type=5)
  Known issues and limitations for the OpenAI and Google catalog feed integrations for B2C Commerce.
