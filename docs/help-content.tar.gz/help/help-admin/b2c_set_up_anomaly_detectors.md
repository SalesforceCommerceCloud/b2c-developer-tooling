# Set Up Anomaly Detectors in Log Center

_Identify unusual log patterns in B2C Commerce Log Center and optionally send alerts when anomalies meet your alert threshold. Log Center continuously analyzes incoming log data and compares the data with learned baseline behavior. When data deviates from the baseline and meets your thresholds, Log Center flags the anomaly._

The New Anomaly Detector wizard has three steps: Data, Detector settings, and Alerts. To create a detector, complete the steps in order and click **Continue** to advance. To edit a detector later, reopen the wizard, where all three steps are prefilled.

1. Log in to Log Center. For the ways to access Log Center, including from Business Manager, see [Access Log Center](https://help.salesforce.com/s/articleView?id=cc.b2c_start_log_center.htm&type=5).
2. On the Anomaly Detection tab, click **Anomaly Detector Configurations**, and then click the plus (+) icon to open the New Anomaly Detector wizard.

   _(image: Anomaly Detection wizard in Log Center)_
3. On the Data step, define which logs the detector analyzes.

   1. Select the realm where the detector runs.
   2. To narrow the logs, add include filters. To exclude logs, add negative filters. To refine further, enter an advanced LCQL filter.
   3. To check which logs match your filters, click **Preview Logs**. Log Center applies your realm and filters to the last 24 hours of logs and shows a histogram of the matches. Adjust the filters until the preview reflects the logs you want, and click **Continue**.
4. On the Detector settings step, enter a name and an optional description. Then set how the detector runs.

   1. For Anomaly Detection Time Interval, select how often Log Center checks for anomalies (5, 10, 15, 20, or 30 minutes, with a default of 10 minutes). Shorter intervals detect anomalies sooner. Longer intervals smooth out short-term noise.
   2. For Detection Sensitivity, set how strict the detector is. The scale runs from Low (1) to High (10), with a default of 6. Higher sensitivity catches more anomalies but can increase false positives. Lower sensitivity flags only larger deviations.
   3. To start detection when you save, select **Enable Real-time Anomaly Detection**. To create the detector without running it yet, leave this option cleared. Then click **Continue**.
5. (Optional) On the Alerts step, set up notifications.

   1. Select **Enable Alerting**.
   2. Set the alert severity threshold (0.0 to 1.0) and the alert time interval. The alert time interval must be greater than or equal to the detection time interval. Log Center sends an alert when it detects an anomaly within the alert time interval that has a severity greater than the alert severity threshold. A severity level equal to the threshold doesn't trigger an alert.
   3. Choose where to send alerts. Enter up to five email addresses. The detector creator is always included as a recipient and isn't counted as one of the five. Select Slack or PagerDuty notification channels. To create a channel, click **Set up a notification channel**.
6. Click **Save**. If you enabled real-time detection, the detector starts running immediately.
