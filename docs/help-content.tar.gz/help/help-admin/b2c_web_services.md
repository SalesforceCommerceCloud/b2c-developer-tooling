# Web Services in B2C Commerce

_Salesforce B2C Commerce provides a web services framework that helps you manage calls to web services and analyze service performance. You need custom code to interact with a web service. We recommend that you use secure protocols as web service types, such as HTTPS, Secure File Transfer Protocol (SFTP), and Simple Object Access Protocol (SOAP) over Transport Layer Security (TLS). A web service can also use a service credential, such as username and password, to perform HTTP basic authentication._
