# eCDN-web application firewall (WAF) Log OCAPI References

_Request B2C Commerce eCDN-WAF log files through the Open Commerce API (OCAPI). Each realm supports up to 24 pending log request downloads, and a minimum of five minutes is enforced between a log request's end time and the current time._

## Related Content

- [Request eCDN-web application firewall (WAF) Logs with an Open Commerce API (OCAPI) Call for B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_waf_log_ocapi_call.htm&type=5)
  Use an OCAPI call to request the eCDN-WAF log. A minimum period of five minutes is now enforced for retrieving WAF logs.

- [JSON Log Output](https://help.salesforce.com/s/articleView?id=cc.b2c_waf_log_ocapi_json_log_outputs.htm&type=5)
  All B2C Commerce Open Commerce API (OCAPI) calls return all fields shown in the JavaScript Object Notation (JSON) log output.

- [Log Field Information for B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_waf_log_ocapi_log_fields.htm&type=5)
  The JSON request format provides category, field, and descriptions for the log output.
