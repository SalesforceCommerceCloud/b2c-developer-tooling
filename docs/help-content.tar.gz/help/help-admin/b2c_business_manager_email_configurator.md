# Business Manager Email Configurator

_Use the optional email settings to define your own SMTP server for customer and platform email delivery. This topic applies to B2C Commerce._

For information about SPF and DKIM authentication requirements for Google and Yahoo, See [Support for DKIM Authentication](https://help.salesforce.com/s/articleView?id=cc.b2c_support_for_dkim_authentication.htm&type=5).

When you configure this option, your customer email uses the SMTP server that you set up in the configurator. If you don’t set a custom configuration, your customer and platform email continue to use the default SMTP server that Salesforce provides. If you check use this custom email configuration but don’t complete the configuration setup, customer and platform email don’t work.

Set the configuration to use the server for customer and platform email or customer email only. When you set the configurator for customer email only, the platform notification email uses the default SMTP server. Make sure the SMTP server supports STARTTLS.

## Related Content

- [Support for DomainKeys Identified Mail (DKIM) Authentication](https://help.salesforce.com/s/articleView?id=cc.b2c_support_for_dkim_authentication.htm&type=5)
  Salesforce B2C Commerce provides an out-of-the-box solution on our first-party Point of Deployment (POD) that customers can use for their email requirements. This service provides support for DKIM and SPF authentication. DKIM is an email authentication protocol that adds a cryptographic digital signature to outgoing emails. With DKIM, receivers can verify that the domain owner authorized the email and that it wasn’t altered in transit. DKIM helps reduce spam and phishing emails.

- [Configure Business Manager Email Settings](https://help.salesforce.com/s/articleView?id=cc.b2c_configure_business_manager_email_settings.htm&type=5)
  To define your own SMTP server for customer and platform email delivery, configure email settings. This topic applies to B2C Commerce.
