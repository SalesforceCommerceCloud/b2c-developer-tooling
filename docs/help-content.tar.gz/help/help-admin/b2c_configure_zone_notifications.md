# eCDN Zone Notifications

_Get notified when eCDN events on your B2C Commerce storefront that matter to you happen, such as a Logpush job failure on a PCI-bound zone, a security incident, or a configuration change, without having to watch dashboards. The Notifications tab on the Configure Zone screen lets you configure webhook destinations and wire them up to one or more zones._

[Which Salesforce Commerce Product Do I Have?](https://help.salesforce.com/s/articleView?id=commerce.comm_what_product.htm)

> **Note:** Notifications aren't available on SCAPI zones. See [SCAPI Zone Support for B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_scapi_zone.htm&type=5).

### How eCDN Notifications Work

The Notifications tab is split into two sections.

- **Destinations**: Webhook endpoints that receive notification payloads, such as a Slack incoming webhook or a custom HTTPS endpoint.
- **Notifications**: Notification rules that bind a destination to one or more zones and toggle delivery on or off.

A destination is reusable across multiple notification rules and across zones. Register it once in the Destinations table, then reference it from any number of Notifications rows.

_(image: Notifications tab showing Destinations and Notifications sections)_

After you configure notification rules, eCDN sends runtime event notifications to the selected destinations for each enabled zone. Common use cases include PCI compliance alerts, security events, and configuration drift detection.

### Configure Notifications for a Zone

Notification setup is covered in these tasks.

- [Create a Notification Destination](https://help.salesforce.com/s/articleView?id=cc.b2c_create_ecdn_notification_destination.htm&type=5)
- [Create a Notification Rule](https://help.salesforce.com/s/articleView?id=cc.b2c_create_ecdn_notification_rule.htm&type=5)
- [Set Up PCI Compliance Alerts](https://help.salesforce.com/s/articleView?id=cc.b2c_set_up_ecdn_pci_alerts.htm&type=5)
- [Manage Notification Rules](https://help.salesforce.com/s/articleView?id=cc.b2c_manage_ecdn_notification_rules.htm&type=5)

For the other controls on the Configure Zone screen, see [eCDN Zone Settings in Business Manager](https://help.salesforce.com/s/articleView?id=cc.b2c_configuring_a_zone.htm&type=5).

### The Notifications Tab Isn't Showing

> **Note:** The Notifications tab is part of the new LWC Configure Zone screen. If you're on the legacy interface, switch to the new screen through your usual Business Manager navigation. If the tab still doesn't appear, contact your Salesforce Commerce Cloud administrator. The new LWC screens are rolled out per realm and might not yet be enabled for your instance.

## Related Content

- [Create a Notification Destination](https://help.salesforce.com/s/articleView?id=cc.b2c_create_ecdn_notification_destination.htm&type=5)
  Register a webhook destination that receives eCDN notification payloads for your B2C Commerce storefront, such as a Slack incoming webhook or a custom HTTPS endpoint. A destination is reusable across multiple notification rules and across zones.

- [Create a Notification Rule](https://help.salesforce.com/s/articleView?id=cc.b2c_create_ecdn_notification_rule.htm&type=5)
  Create a notification rule to bind a webhook destination to one or more eCDN zones for your B2C Commerce storefront and control whether delivery is enabled. Toggling a rule off pauses delivery without deleting the rule.

- [Set Up PCI Compliance Alerts](https://help.salesforce.com/s/articleView?id=cc.b2c_set_up_ecdn_pci_alerts.htm&type=5)
  Get alerted when an eCDN Logpush job fails on a zone that carries PCI-scoped traffic for your B2C Commerce storefront. Wiring a notification rule to your SIEM or on-call tool lets you detect a stalled PCI log stream before the audit window expires.

- [Manage Notification Rules](https://help.salesforce.com/s/articleView?id=cc.b2c_manage_ecdn_notification_rules.htm&type=5)
  Pause, resume, edit, or delete the eCDN notification rules that target a zone on your B2C Commerce storefront. The Notifications table shows every rule that targets the current zone, along with the destination it delivers to, the full zone list, and an Enabled toggle.
