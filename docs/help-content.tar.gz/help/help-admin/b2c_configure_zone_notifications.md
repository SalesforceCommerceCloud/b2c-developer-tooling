# Configure Notifications for an eCDN Zone

_Get notified when eCDN events that matter to you happen, such as a Logpush job failure on a PCI-bound zone, a security incident, or a configuration change, without having to watch dashboards. The Notifications tab on the Configure Zone screen lets you configure webhook destinations (such as a Slack incoming webhook or your own HTTPS endpoint) and wire them up to one or more zones._

Looking for the Logpush, Logpull, Crypto, Security Rules, Speed, Customization, Page Shield Policies, or Host Header Override Rules controls on the same screen? See the companion guides for Configure Logpush and Logpull for an eCDN Zone and Configure an eCDN Zone in Business Manager.

1. In Business Manager, click the App Launcher, then select **Administration > Sites > Embedded CDN Settings**.
2. Locate the zone you want to configure, and select **Configure Zone** from the actions menu.
3. Click the **Notifications** tab.

   _(image: Notifications tab showing Destinations and Notifications sections)_
   
   The Notifications tab is split into two sections:
   
   - **Destinations** - Webhook endpoints that receive notification payloads (Slack incoming webhook, custom HTTPS endpoint, and so on).
   - **Notifications** - Notification rules that bind a destination to one or more zones and toggle delivery on or off.
   
   A destination is reusable across multiple notification rules and across zones - register it once in the Destinations table, then reference it from any number of Notifications rows.

After you configure notification rules, eCDN sends runtime event notifications to the selected destinations for each enabled zone. Common use cases include PCI compliance alerts, security events, and configuration drift detection.

**Create a Destination**

A destination is a single webhook endpoint that the eCDN can POST notification payloads to. Salesforce Commerce Cloud sends a JSON body to the URL you register; what happens to that payload (Slack message, ticket, alert) is up to the receiving system.

_(image: Create Webhook dialog showing Name field with NewWebhook entered, URL field with webhooks entered, and Secret optional field with placeholder text)_

1. In the **Destinations** section, click **New Destination**. The Create Webhook screen opens.
2. Enter a **Name**. This is the label that will appear in the Webhook dropdown when you create a notification rule.
3. Enter a **URL**. The field accepts only valid HTTP or HTTPS URLs.
4. (Optional) Enter a **Secret**. The eCDN will use this value to sign request bodies; configure your receiver to verify the signature before trusting the payload.
5. Click **Save**.

If the URL is malformed, the URL field shows an inline error and the form blocks the save until you correct it. After save, the destination appears in the Destinations table with status Active. You can select the same destination in multiple notification rules and across multiple zones.

**Create a Notification Rule**

A notification rule binds one destination to one or more zones, and controls whether delivery is enabled. Toggling a rule off pauses delivery without deleting the rule.

_(image: Create Notification screen showing Webhook dropdown with Slack Webhook - Logpush Job Alert selected, Enable Notification Upon Saving checkbox checked, and Zones section with All checkbox and multiple zone checkboxes including sfcc-ecdn-test5.net)_

1. In the **Notifications** section, click **New Notification**. The Create Notification screen opens.
2. Open the **Webhook** dropdown and pick the destination you registered earlier. If the destination you want isn't in the list, register it first under Destinations.
3. Select **Enable Notification Upon Saving** if you want the rule to start delivering immediately. Leave it off to create the rule in a paused state.
4. Pick the **Zones** the rule applies to. Select **All** to select every zone in the list, or select zones individually. The current zone is selected by default.
5. Click **Save**.

If a selected zone no longer resolves after the page loads, a warning toast names the zone and saves the rule without that binding. Refresh the page and edit the rule to re-select any missing zones.

When the rule saves successfully, a confirmation toast appears and the rule shows up in the Notifications table with the Enabled toggle reflecting the choice you made on the form.

_(image: Success toast notification reading The notification Slack Webhook - Logpush Job Alert was created successfully, with Notifications tab showing Destinations table with one webhook and Notifications table with one rule including zone list and Enabled toggle)_

**Wire Up a PCI Alert**

The most common reason teams set this up is to alert on Logpush job failures for zones that carry PCI-scoped traffic to a customer SIEM. To configure Logpush delivery targets, see [Configure Logpush and Logpull for an eCDN Zone](https://help.salesforce.com/s/articleView?id=cc.b2c_configure_zone_logs.htm&type=5).

1. Create a webhook destination in the receiver of your choice (Slack incoming webhook, PagerDuty Events API endpoint, internal alerting service). Copy the URL.
2. In Business Manager, on the PCI zone's Notifications tab, click **New Destination** and paste the URL. Give it a clear name like Slack #pci-alerts or PagerDuty PCI.
3. Click **New Notification**, pick the destination from the Webhook dropdown, leave **Enable Notification Upon Saving** selected, and select the PCI zone (or All zones if you want fleet-wide coverage).
4. Click **Save**.

You will now receive a notification whenever an event configured for that destination fires on the selected zone(s) - including Logpush job failures, which is the signal you need to detect a stalled PCI log stream before the audit window expires.

> **Tip:** Keep the PCI alert destination separate from your general engineering channel. PCI alerts have a different on-call and a different escalation path, and mixing them with general traffic dilutes both.

**Manage Existing Notification Rules**

The Notifications table shows every rule that targets the current zone, along with the destination it delivers to, the full zone list, and an Enabled toggle.

_(image: Notifications table showing a notification rule Slack Webhook - Logpush Job Alert with zone list and Enabled toggle, with actions menu expanded displaying Edit and Delete options)_

- **Toggle delivery** - Flip the Enabled switch on a row to pause or resume delivery without losing the rule.
- **Edit** - Open the row's actions menu and choose **Edit** to change the destination, zone selection, or enabled state.
- **Delete** - Open the row's actions menu and choose **Delete** to remove the rule entirely. Deletion asks for explicit confirmation because it cannot be undone. If you only want to mute the rule temporarily, use the Enabled toggle instead.

_(image: Delete confirmation dialog with message Are you sure you want to delete the notification Slack Webhook - Logpush Job Alert? This action can't be undone, with Cancel and OK buttons)_

**I Don't See the Notifications Tab**

The Notifications tab is part of the new LWC Configure Zone screen. If you're on the legacy interface, switch to the new screen via your usual Business Manager navigation. If the tab still doesn't appear, contact your Salesforce Commerce Cloud administrator - the new LWC screens are rolled out per-realm and may not yet be enabled for your instance.
