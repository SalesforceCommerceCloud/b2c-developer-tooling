# Access Control for Log Center Alerts

_Verify that your role allows alert creation and management in B2C Commerce Log Center._

| Role | View | Create | Edit/delete |
| --- | --- | --- | --- |
| Admin | All | Yes | Yes |
| Support | All | Yes | Yes |
| External Admin | Realm-scoped | Yes | Yes (within assigned realms only) |
| User | Realm-scoped | Yes | No |
