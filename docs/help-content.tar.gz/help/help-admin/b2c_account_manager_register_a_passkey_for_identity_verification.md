# Register a Passkey for Identity Verification in B2C Commerce

_Register a passkey as a phishing-resistant verification method for multi-factor authentication (MFA) logins to Account Manager. A passkey uses FIDO2/WebAuthn to bind your credentials to Account Manager, so an attacker can’t reuse them on a spoofed site. To verify your identity, unlock your device or authenticator with a biometric (such as Touch ID, Face ID, or Windows Hello), a device PIN, or a pattern._

[Which Salesforce Commerce Product Do I Have?](https://help.salesforce.com/s/articleView?id=commerce.comm_what_product.htm)

A passkey can be device-bound (stored only on the device that created it) or synced across the devices where you’re signed in with the same platform account, depending on the operating system, browser, and password manager you use.

Have the device or authenticator that stores your passkey ready before you begin. If you wait too long at the prompt, your registration attempt can time out.

1. How you proceed depends on the MFA verification method settings of your organization:

   - Registering a passkey is required at your next login and is the only type of verification method allowed: proceed to the next step.
   - Registering a passkey or another verification method is required at your next login: click **Passkey** and proceed to the next step.
   - If you’re logged in to Account Manager, and if registering multiple MFA verification methods is an option, register a passkey in your Account Information. Click **Add** next to **Multi-Factor Verification** and choose **Passkey** and proceed to the next step.
2. At the browser prompt, choose where to save the passkey.

   Depending on your device and browser, you can save the passkey to this device, to a phone or tablet, to a hardware security key, or to a supported password manager. Follow the on-screen instructions.
3. Unlock the passkey with the method you set up on the device or authenticator, such as a biometric (Touch ID, Face ID, or Windows Hello), a device PIN, or a pattern.
4. Click **Continue** to dismiss the confirmation message.

   Now you’re ready to use this identity verification method. Your device or authenticator generates the required credentials, and the browser passes them on to Salesforce to complete the verification. To help keep your account secure, we send you an email notification whenever a new identity verification method is added to your Account Manager account.
