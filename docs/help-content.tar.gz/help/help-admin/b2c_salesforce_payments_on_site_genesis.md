# Salesforce Payments on SiteGenesis

_A successful implementation of Salesforce Payments on SiteGenesis includes the same features and functions on the same pages as the features and functions available from the overlay cartridge for Salesforce Reference Architecture (SFRA). The following process outlines how to achieve a basic application of Salesforce Payments on SiteGenesis. Where appropriate, we call out when and where different solutions are possible._
