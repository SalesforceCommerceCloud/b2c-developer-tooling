# Salesforce Payments on SiteGenesis

_A successful implementation of Salesforce Payments on B2C Commerce SiteGenesis includes the same features and functions on the same pages as the features and functions available from the overlay cartridge for Salesforce Reference Architecture (SFRA). The following process outlines how to achieve a basic application of Salesforce Payments on SiteGenesis. Where appropriate, we call out when and where different solutions are possible._

## Related Content

- [SiteGenesis Configuration for Salesforce Payments](https://help.salesforce.com/s/articleView?id=cc.b2c_add_salesforce_payments_functionality_to_site_genesis.htm&type=5)
  With some limitations, add Salesforce Payments to SiteGenesis on your B2C Commerce site.

- [SiteGenesis Page Samples for Salesforce Payments](https://help.salesforce.com/s/articleView?id=cc.b2c_salesforce_sitegenesis_page_samples.htm&type=5)
  When you add Salesforce Payments to your B2C Commerce SiteGenesis instance, you modify the page layouts for the Checkout, Cart, Mini-Cart, and Product Details pages. Here we describe an approach to these layout modifications.
