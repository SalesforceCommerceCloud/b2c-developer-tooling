# Inventory Management Using Omnichannel Inventory

_Integrating with Salesforce Omnichannel Inventory provides more powerful features for handling inventory data and working with external management systems. This topic applies to B2C Commerce._

### Omnichannel Inventory Integration

When you manage inventory with Omnichannel Inventory, you don’t create or modify inventory records in B2C Commerce. The integration handles that for you by automatically updating availability in B2C Commerce based on data received from Omnichannel Inventory. Reserving inventory for a basket or order is the only way that B2C Commerce can affect inventory levels. Perform all other inventory updates in Omnichannel Inventory.

For information on configuring and customizing Omnichannel Inventory, see the [Omnichannel Inventory topics in Salesforce Help](https://help.salesforce.com/articleView?id=inv_omnichannel_inventory_service.htm).

### Location Graph

The location graph is the collection of inventory locations and location groups in Omnichannel Inventory that fulfill orders from your B2C Commerce storefront. A location represents a specific inventory source, usually a physical location like a warehouse. A location group is a related set of locations, such as those covering a defined geographic area or locations that belong to a common brand or storefront. The location group aggregates and exposes the inventory at those locations. Inventory quantities for a location group are calculated as the sums of the corresponding quantities of the locations in that group. For example, the On Hand quantity for a location group is the sum of the On Hand quantities of all the locations in that group.

> **Note:** A location isn’t required to belong to a location group, but a location group must include at least one location.

To expose inventory data, B2C Commerce associates inventory lists with the locations and location groups in your location graph. Create one inventory list in B2C Commerce for each location or location group in Omnichannel Inventory that you want to directly expose to the storefront. The ID of the inventory list must match the External Reference value of the associated location or location group in Omnichannel Inventory. If a location only fulfills orders as part of a location group, then creating a list for that location isn’t required.

> **Note:** The integration uses the inventory list ID and the location or location group External Reference to transfer data between B2C Commerce and Omnichannel Inventory. For B2C Commerce to interact with an element of your location graph, it must have an inventory list whose ID matches that element’s External Reference.

For each B2C Commerce site, use a location or location group to represent the default inventory available to fulfill orders placed on that site. Assign the inventory list for that location or location group to the site. If you use other inventory lists, such as for a store, associate them with locations or location groups of their own.

> **Note:** Only associate one inventory list with each site or store. Other inventory lists can expose inventory availability data for individual locations in the group.

### Inventory Reservations

When B2C Commerce creates an order, it sends an inventory reservation request to Omnichannel Inventory. Omnichannel Inventory tries to assign the reservation to the location or location group associated with that site’s or store’s inventory list. If insufficient inventory is available, the reservation fails. After Omnichannel Inventory accepts a reservation, it handles any further processing together with your order management system.

> **Note:** When B2C Commerce sends a reservation request for a location group, it can’t affect the way Omnichannel Inventory transfers the reservation to specific locations in the group. Omnichannel Inventory and Salesforce Order Management provide tools for managing and processing inventory reservations.

If you implement a customization that requests temporary inventory reservations for baskets, the integration sends those requests to Omnichannel Inventory.

### Considerations and Limitations When Using Omnichannel Inventory

- Visible inventory availability data is eventually consistent, meaning that an update can take time (usually a few seconds) to be reflected in the UI or API. Therefore, when B2C Commerce makes an inventory reservation in Omnichannel Inventory, you can’t assume that availability data immediately reflects the quantities assigned to that reservation. This delay affects all B2C Commerce functionality that relies on availability data, such as Script API customizations that use inventory availability queries. However, Omnichannel Inventory processes reservation requests sequentially, so a reservation request only succeeds if inventory is actually available to fulfill that order.
- If your custom code requests temporary reservations for baskets, those temporary reservations affect visible inventory availability. (When not using Omnichannel Inventory, the Commerce platform considers existing temporary reservations when creating reservations, but doesn’t include them in visible availability data.)
- You can’t enable the On Order Inventory feature.
- You can create up to 20 location groups.
- The IDs of inventory lists associated with locations and location groups have the following restrictions:
   
   - They must be 2–128 characters in length.
   - They can only include the following characters: A–Z, a–z, 0–9, _ (underscore), - (hyphen)
- You can’t create or update inventory records in B2C Commerce. Import inventory lists into B2C Commerce, but must import product inventory data directly into Omnichannel Inventory.
   
   > **Note:** Attempting to import an individual inventory record into B2C Commerce causes this warning: **Omnichannel Inventory doesn’t support the import of inventory records. Skipping element.**
- Don’t export inventory data from B2C Commerce. It exports stale data from before the integration with Omnichannel Inventory. To export inventory data, export it from Omnichannel Inventory.
- You can’t use custom properties on inventory records.
- You can’t use B2C Commerce APIs to modify individual inventory records. Otherwise, inventory-related script API methods work the same as they do when not using Omnichannel Inventory.
- You can’t make Open Commerce API (OCAPI) calls to the `inventory_lists/{inventory_list_id}/product_inventory_records` endpoint.
- Because Omnichannel Inventory releases inventory reservations for unplaced orders after 30 days, keeping unplaced orders (in status Created) in B2C Commerce can cause availability discrepancies. To avoid this issue, use the **Auto-Fail Orders** setting in the site-level order preferences.
- Omnichannel Inventory doesn’t support explicit preorders. Instead, it represents expected inventory restocks with futures. Each future has a quantity and an expected date.
   
   - If a product has any futures in Omnichannel Inventory, then in B2C Commerce, its **backorderable** flag is true. Otherwise, that flag is false.
   - In B2C Commerce, product **preorderable** flags are always false.
   - In B2C Commerce, a product’s **BackorderAllocation** quantity is the sum of all existing future quantities for that product, and its **inStockDate** is the **expectedDate** of its earliest future. Its **PreorderAllocation** quantity is always zero, so its **PreorderBackorderAllocation** quantity always matches its **BackorderAllocation**.
   - Omnichannel Inventory futures require **expectedDate** values. When not using Omnichannel Inventory, B2C Commerce backorder and preorder quantities don’t require **inStockDate** values.
- Omnichannel Inventory doesn’t support perpetual availability for individual inventory records. However, you can implement similar functionality in a couple of ways.
   
   - Use a B2C Commerce inventory list’s **Default In-Stock** setting. When an order uses an inventory list with Default In-Stock turned on, products not on the list are automatically available. However, those products aren’t included in reservation requests. If you use Default In-Stock this way, customize your order workflow to create and manage reservations for those products.
   - In Omnichannel Inventory, set a product’s available inventory at one or more locations to 999999999. In B2C Commerce, handle that product normally. In this case, customize your order workflow to fulfill orders for that product at an appropriate location.
- B2C Commerce builds its Availability Search Index using the cached availability data received from Omnichannel Inventory. Remember that this data is considered eventually consistent.
- For best performance when implementing Omnichannel Inventory customizations, use the headless Commerce API. The corresponding Salesforce core Connect APIs and actions simply call the Commerce API under the hood. Updating the location graph is an exception, since the Commerce API doesn’t provide that functionality.
   
   > **Caution:** Attempting to upload large inventory data files using the Salesforce core Connect APIs can greatly affect your org’s performance. When using the Connect APIs, an inventory data file must be in JSON format and is limited to 10 MB. When using the headless Commerce API, a file can be in JSON or GZIP format and is limited to 100 MB.
- You can’t use Omnichannel Inventory with a staging instance of B2C Commerce that uses a custom SSL certificate. Custom domain traffic from B2C Commerce isn't allowlisted, so communication with Omnichannel Inventory requires the embedded Content Delivery Network (eCDN). The eCDN isn’t active for a staging instance.
- You can’t use Omnichannel Inventory with the order post-processing API (Gillian cartridge).

### B2C Commerce Inventory Modes

B2C Commerce can be in one of three inventory modes:

- Commerce Platform Inventory: B2C Commerce handles availability and reservations internally. The integration isn’t active.
- OCI Cache Enabled: Omnichannel Inventory is populating the availability data cache. However, B2C Commerce still handles availability and reservations internally.
- Omnichannel Inventory: The integration is active and B2C Commerce exclusively uses availability data in the cache and sends reservation requests to Omnichannel Inventory.

Initially, B2C Commerce is in Commerce Platform Inventory mode. When you first activate the integration with Omnichannel Inventory, B2C Commerce changes to OCI Cache Enabled mode. When the cache is ready, it can change to Omnichannel Inventory mode. The current mode appears on the Omnichannel Inventory Integration page in Business Manager.

### Availability Search Index

When B2C Commerce is in Commerce Platform Inventory mode or OCI Cache Enabled mode, the availability index is built using B2C Commerce inventory availability data. When B2C Commerce is in Omnichannel Inventory mode, the availability index is built using cached availability data from Omnichannel Inventory.

Selecting Omnichannel Inventory mode triggers a full rebuild of the availability index. Otherwise, the availability index functions normally.

> **Note:** Building the availability index from the cached Omnichannel Inventory data takes about the same amount of time as building it from B2C Commerce inventory data.

### Converting Existing Storefronts to Use Omnichannel Inventory

When integrating Omnichannel Inventory with an existing B2C Commerce storefront, include these steps in your planning process:

- Map your existing sites, stores, and inventory locations to locations and location groups in Omnichannel Inventory.
- Determine which locations and location groups to expose in B2C Commerce with inventory lists.
- Identify any inventory lists used for orders but not assigned to a site; for example, lists assigned to a store. Associate each one with a location or location group in Omnichannel Inventory.
- Create a plan to transfer existing inventory data import processes from B2C Commerce to Omnichannel Inventory.
- Identify any existing customizations that 's incompatible with Omnichannel Inventory and decide whether to modify or replace them. That includes any customization that modifies product inventory records.

### Terminology

The following terminology differs between B2C Commerce and Omnichannel Inventory.

| B2C Commerce Term | Omnichannel Inventory Term | Description |
| --- | --- | --- |
| n/a | On Hand Quantity | Current physical quantity |
| n/a | Safety Stock | Quantity of physical stock set aside to avoid overselling |
| Allocation Quantity | n/a | Calculated as (On Hand Quantity) - (Safety Stock) |
| Allocation Reset Date | Effective Date | Date of the most recent inventory data update; when using Omnichannel Inventory, this value can be null |
| Backorder Allocation Quantity (and Preorder Backorder Allocation Quantity) | Future Quantity (if multiple future quantities exist, the value in B2C Commerce is their sum) | Sellable expected future restock quantities |
| In Stock Date | Earliest Future Expected Date | Date when future restock quantities are expected |
| Turnover, Reserved, and On Order Quantity | Total Reserved | Quantity reserved to fulfill orders |
| Stock Level | Available to Fulfill (ATF) | Calculated as (On Hand Quantity) - (Safety Stock) - (Total Reserved); with a minimum value of 0 |
| Available to Sell (ATS) | Available to Order (ATO) | Calculated as (On Hand Quantity) + (Future Quantities) - (Safety Stock) - (Total Reserved); with a minimum value of 0 |

## Related Content

- [Omnichannel Inventory Integration Setup and Configuration](https://help.salesforce.com/s/articleView?id=cc.b2c_omnichannel_inventory_integration_setup_config.htm&type=5)
  Plan and implement your integration of Salesforce Omnichannel Inventory with B2C Commerce.

- [Omnichannel Inventory Data Synchronization](https://help.salesforce.com/s/articleView?id=cc.b2c_omnichannel_inventory_data_synchronization.htm&type=5)
  Visible inventory availability data is eventually consistent, meaning that an update can take time (usually a few seconds) to be reflected in the UI or API. Therefore, when B2C Commerce makes an inventory reservation in Omnichannel Inventory, you can’t assume that availability data immediately reflects the quantities assigned to that reservation. However, Omnichannel Inventory accepts a reservation request only if it actually has inventory available to fulfill that order.

- [Omnichannel Inventory Location Graph Changes](https://help.salesforce.com/s/articleView?id=cc.b2c_omnichannel_inventory_location_graph_changes.htm&type=5)
  When you manage inventory with Omnichannel Inventory, changes to the location graph in Omnichannel Inventory require coordinated updates in B2C Commerce. To make any of the changes described here, follow the appropriate steps in order.

- [Troubleshooting the Omnichannel Inventory Integration](https://help.salesforce.com/s/articleView?id=cc.b2c_troubleshooting_omnichannel_inventory_integration.htm&type=5)
  If you experience any of these problems with your Omnichannel Inventory integration, try these steps. This topic applies to B2C Commerce.

- [B2C Commerce Continuous Order Capture for Omnichannel Inventory](https://help.salesforce.com/s/articleView?id=cc.oci_continuousordercapture.htm&type=5)
  Turn on Continuous Order Capture to accept customer orders and maintain business continuity even if connectivity to Omnichannel Inventory is lost. When the service is unavailable, Continuous Order Capture automatically transitions to an offline mode and accepts transactions without immediate inventory reservations. By independently reconciling pending reservations and providing real-time recovery alerts, this feature protects your storefront from downtime while minimizing overselling risks.
