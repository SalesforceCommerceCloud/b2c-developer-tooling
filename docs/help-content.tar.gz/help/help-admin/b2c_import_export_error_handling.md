# Import/Export Error Handling in B2C Commerce

_All import, export, and validation processes create log files. Log files are accessible through WebDAV on the import and export share in your cartridge. This topic applies to B2C Commerce._

For example:

`https://<instance>/on/demandware.servlet/webdav/<organization>/​Impex/log.`

> **Note:** The `File Transfer Manager` access privilege is required to access this share. Click App Launcher _(image: App Launcher)_, and then select **Administration > Organization > Roles & Permissions**. Select **WebDAV_Transfer_Files.**

You can view the log files for processes that Business Manager started.

Click App Launcher _(image: App Launcher)_, and then select **Administration > Site Development > Development Setup**. In the WebDAV Access section, click the **Log files** link for general system and custom log files, and the **Import/Export** link for log files specific to import and export processes.

For the import and export process, it's important to distinguish between process errors and data errors.>

### Record Summary Information

B2C Commerce logs a `Starting Import` message for all import processes. For catalog imports, it also logs a `Phase 1 - Items` and `Phase 2 - Relations` message. For each type of item, it prints this message: Processed `N` <type name> elements successfully

where:

**`N`** — number of elements processed

**<type name>** — name of the data type, like product, catalog

It also prints the total number of elements:

```
Processed N total elements 
```

### Process Errors

Process errors can occur during import and export processes. They include missing or incorrect process parameters, problems while acquiring locks, malformed XML feeds, and general system errors. Process errors sometimes cause an import or export process not to start or to abort immediately during execution.

### Data Errors

Feeds cause data errors and data warnings, which occur only during an import process. They are always local to an element in the feed. The import process isn't aborted when a data error or warning occurs; instead the import process skips the invalid element. Thus an import process can end with no process error but with a data error. Problems with data are classified as DATAERROR or DATAWARNING. More details about the location and cause of the error or warning are provided in the log file.

| Error Type | Description |
| --- | --- |
| DATAERROR | Logged when an element in the feed (for example, category or product) can't be processed at all. For example, the element lacked a mandatory ID attribute. There is at most one DATAERROR logged per element in an import feed. |
| DATAWARNING | Indicates that an element was processed, but only partially. For example, a feed element comes with a custom attribute, but the attribute isn't defined in the system. In this case, the custom attribute is ignored. Another example is that a product references a classification category that doesn't exist. In this case, no classification category is defined for the product. There can be multiple DATAWARNINGs per import element in the feed. The use of obsolete elements or subelements is logged as DATAWARNING |

Import pipelets provide easy access to the number of DATAERRORs and DATAWARNINGs using the *Status* object.

In the following example, a script uses the status object to count errors.

`var dataErrors : Number = status.details.DataErrorCount;` `var dataWarnings : Number = status.details.DataWarningCount;`

It's a good practice to determine the success of an automated import process by first checking for process errors, then for DATAERRORs, as shown in the following script code.

`var success : boolean = (status.code == 'IMPEX-0') && (status.details.DataErrorCount == 0);`

Code shouldn't treat the occurrence of DATAWARNINGs as an unexpected error, because a feed that doesn't cause DATAWARNINGs today can cause DATAWARNINGs in a future B2C Commerce version (for example, because an element was deprecated or rules updated).
