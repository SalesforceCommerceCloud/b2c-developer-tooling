# Log Center Search

_Use Log Center to search logs with custom searches. You configure a search with query filters from categories such as period, message severity, issue type, key words, specific text, and other attributes._

When you start Log Center, you see the search page for your tenant Realm. The page lists the results of the last completed search.

Logs are available to view from one minute to the past 14 days. Log Center’s high volume processing, supports daily log volume and data retention limits. For PIGs, log volume is set using a tenant tier structure. For SIGs, the log volume default is 1 million per day with a maximum limit of 2 million per day. Request log volume increases for both PIG and SIG environments.
