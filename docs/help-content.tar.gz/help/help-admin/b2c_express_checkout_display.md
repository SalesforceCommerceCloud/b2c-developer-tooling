# Customize Where Express Checkout Payment Methods Appear on Your Storefront

_Choose where Express Checkout payment methods appear on your Storefront Reference Architecture (Salesforce Reference Architecture (SFRA)) or Composable Storefront site._

|  |
| --- |
| Available in: **B2C Commerce** |

1. In Business Manager, click App Launcher _(image: App Launcher)_, and then select **Merchant Tools > Site > Ordering > Salesforce Payments**.
2. Click **Settings**.
3. In the Express Checkout Display section, select where to place the Express Checkout payment methods.
4. Save your changes.

   For the changes to take effect, make sure your storefront is upgraded to the latest version.
