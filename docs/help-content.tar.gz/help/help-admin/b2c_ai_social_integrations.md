# AI and Social Integrations

_Syndicate your B2C Commerce product catalog to AI and social channels so shoppers can discover your products where they search, browse, and shop._

Use the AI & Social Integrations section of Business Manager to share your B2C Commerce product catalog with external AI and social commerce channels. Each integration generates a canonical product feed from your catalog, maps your catalog attributes to the channel's feed requirements, and uploads the feed to the channel on a daily schedule. Shoppers who discover your products on a channel click through to your storefront to complete their purchase.

To open the integrations, in Business Manager click App Launcher _(image: App Launcher)_, and then select **Merchant Tools > Site > AI & Social Integrations**.

### Available Integrations

B2C Commerce supports the following AI and social integrations:

## Related Content

- [Common Product Feed Setup](https://help.salesforce.com/s/articleView?id=cc.b2c_product_feed_setup.htm&type=5)
  Several setup and reference tasks apply to both the OpenAI and Google catalog feed integrations for B2C Commerce. Complete the common steps that apply to your channel, and follow the channel-specific links where the two feeds differ.
