# Metrics Dashboard

_Use the Metrics Dashboard to monitor your B2C Commerce storefront performance, security, and resource utilization. The dashboard improves developer productivity, reduces mean-time to resolution, and streamlines troubleshooting. The metrics that you can monitor include metrics for application performance, sales, embedded content delivery network (eCDN), B2C Commerce API (Shopper Commerce API (SCAPI)) and SCAPI hooks, and Managed Runtime._

> **Important:** Disclaimer: Log Center metrics are aggregated rates that the system emits, providing real-time visibility into your storefront. They aren't meant to be a source of truth for underlying data stores. For example, you can't compare the order per-minute rate with the count of orders on the Business Manager search page.

To access the Metrics Dashboard, in App Launcher _(image: App Launcher)_, select **Log Center**, and then click **Metrics**.

_(image: The Metrics Dashboard showing a graph of total platform requests.)_

### Metrics Dashboard Access

All Log Center roles, User and External Admin, can view the metrics dashboard for the realms they have access to.

### Metric Data Granularity

The data resolution granularity is one minute for all metrics.

### Metrics Dashboard Filters

Users can view metrics over a period of 1 day, 1 week, 2 weeks, or up to 30 days.

### Metrics

Check out the metrics that are available in the metrics dashboard.

## Related Content

- [Overall Application Metrics](https://help.salesforce.com/s/articleView?id=cc.b2c_metrics_overall_app.htm&type=5)
  All users can view traffic and performance metrics for their B2C Commerce sites, such as requests, sessions, and system workload. These metrics help website administrators and DevOps monitor performance of all sites.

- [Sales Metrics](https://help.salesforce.com/s/articleView?id=cc.b2c_metrics_sales.htm&type=5)
  All users can view live B2C Commerce sales metrics, such as the number of orders and baskets created.

- [Embedded Content Delivery Network (eCDN) Metrics](https://help.salesforce.com/s/articleView?id=cc.b2c_metrics_ecdn.htm&type=5)
  HTTP traffic metrics for your B2C Commerce storefront help website administrators, DevOps teams, and security professionals monitor and optimize performance, security, and resource utilization. These eCDN metrics are crucial for optimizing website performance, security, and reliability. By actively monitoring these metrics, website administrators can detect issues early, enhance caching efficiency, reduce costs, and improve the user experience.

- [B2C Commerce API (Shopper Commerce API (SCAPI)) Metrics](https://help.salesforce.com/s/articleView?id=cc.b2c_metrics_scapi.htm&type=5)
  SCAPI metrics help website administrators and DevOps teams monitor and analyze the performance of API calls. They help identify issues with APIs, such as long-running API calls or bad cache hit rates. SCAPI metrics appear in the Metrics Dashboard with a delay of up to 10 minutes.

- [B2C Commerce API (Shopper Commerce API (SCAPI)) Hook Metrics](https://help.salesforce.com/s/articleView?id=cc.b2c_metrics_scapi_hooks.htm&type=5)
  SCAPI Hook metrics help website administrators and DevOps teams monitor and analyze the performance of SCAPI hooks. These metrics help identify issues with slow performance and failures of SCAPI hooks. SCAPI Hook metrics appear in the Metrics Dashboard with a delay of up to 10 minutes.

- [Managed Runtime Metrics](https://help.salesforce.com/s/articleView?id=cc.b2c_metrics_managed_runtime.htm&type=5)
  For teams that operate B2C Commerce experiences based on Composable Storefront, Managed Runtime metrics help website administrators, DevOps teams, and security professionals monitor and optimize performance, security, and resource utilization. These CDN and application metrics are crucial for optimizing website performance, security, and reliability. By actively monitoring these metrics, website administrators can detect issues early, enhance caching efficiency, reduce costs, and improve the user experience.
