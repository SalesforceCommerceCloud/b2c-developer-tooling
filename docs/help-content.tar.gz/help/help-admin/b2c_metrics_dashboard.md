# Metrics Dashboard

_Use the Metrics Dashboard to monitor your B2C Commerce storefront performance, security, and resource utilization. The dashboard improves developer productivity, reduces mean-time to resolution, and streamlines troubleshooting. The metrics that you can monitor include metrics for application performance, sales, embedded content delivery network (eCDN), B2C Commerce API (Shopper Commerce API (SCAPI)) and SCAPI hooks, and Managed Runtime._

> **Important:** Disclaimer: Log Center metrics are aggregated rates that the system emits, providing real-time visibility into your storefront. They aren't meant to be a source of truth for underlying data stores. For example, you can't compare the order per-minute rate with the count of orders on the Business Manager search page.

To access the Metrics Dashboard, in App Launcher _(image: App Launcher)_, select **Log Center**, and then click **Metrics**.

_(image: The Metrics Dashboard showing a graph of total platform requests.)_

### Metrics Dashboard Access

All Log Center roles, User and External Admin, can view the metrics dashboard for the realms they have access to.

### Metric Data Granularity

The data resolution granularity is one minute for all metrics.

### Metrics Dashboard Filters

Users can view metrics over a period of 1 day, 1 week, 2 weeks, or up to 30 days.

### Metrics

Check out the metrics that are available in the metrics dashboard.
