# Purge the eCDN Cache

_Selectively invalidate cached content by cache tag or path directly from Business Manager. Click **Purge Cache** for your B2C Commerce storefront._

For storefront and Default Domain zones, content is available to purge after it's cacheable, which requires a cache rule and correct origin headers. See [Create an eCDN Cache Rule](https://help.salesforce.com/s/articleView?id=cc.b2c_create_ecdn_cache_rule.htm&type=5).

> **Note:** Cache purge by tag or path is available on SCAPI zones from the Production instance. Cache rules aren't available on SCAPI zones. SCAPI workers set cache tags automatically. See [SCAPI Zone Support for B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_scapi_zone.htm&type=5) and [eCDN Cache Rules and Cache Purge](https://help.salesforce.com/s/articleView?id=cc.b2c_ecdn_cache_rules_and_purge_overview.htm&type=5).

1. In Business Manager, click App Launcher _(image: App Launcher)_, and then select **Administration > Sites > Embedded CDN Settings**.
2. Locate the zone that you want to configure, and then select **Configure Zone** from the dropdown menu.
3. Click **Purge Cache**.

   _(image: Configure Zones Cache Rules tab with the Purge Cache button next to the zone selector)_
4. Select the purge method.

   - To invalidate specific URLs, select **By path**, and then enter one or more paths.
   - To invalidate all content stamped with specific cache tags, select **By tag**, and then enter one or more cache tags.
5. Confirm the purge.

   eCDN removes the matching content from the edge cache.

Purge by Tag and by Path Tag-based purge relies on the origin stamping responses with a `Cache-Tag` header (for example, `Cache-Tag: product-12345, category-shoes`). You can then purge all content that carries a given tag in a single request, which is useful for invalidating every page related to a product or category at once. For SCAPI zones, tags are assigned automatically by the SCAPI workers. You don't set them. Path-based purge invalidates specific URLs, which is useful when you know exactly which pages changed.

To prevent accidental large-scale or platform-breaking purges, these purge targets are blocked and return an error message.

- `/*`: Purges the entire site.
- `/cdn-cgi/*`: Cloudflare-managed paths.
- `/on/demandware.static/-/Sites-*`: Platform static content.

> **Important:** Deleting a cache rule doesn't purge already-cached content. To remove cached content immediately, run a purge separately.

A purge affects only content currently at the edge. Subsequent requests repopulate the cache according to your rules and origin headers.
