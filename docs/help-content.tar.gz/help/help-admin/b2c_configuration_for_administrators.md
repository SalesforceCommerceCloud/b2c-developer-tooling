# Configuration for Administrators

_B2C Commerce Log Center administrators can access the Config tab to set log levels and log volumes._

The Configuration options include:

- **Log Level: **Launches the Centralized Log Level Management page. The page provides access to the dynamic log configuration. Add log rules that set different log levels. All log level adjustments are time restricted and expire according to their setting
   
   - Log center pulls the rules every 30 seconds.
   - To add a rule click the plus icon and configure a new rule. When you modify a rule, the rule is listed as the last Modified Rule.
- **Log Volume: **Lists the log volume configuration for each realm. When the log volume for a realm is met, log messages aren’t sent to Log Center for that realm. Realms that aren’t assigned log rules don’t receive messages in Log Center. The maximum daily message volume for PIGs is based on a tiered approach. To inquire about increasing PIG default volume, contact your Salesforce Account rep or Salesforce Support. For SIGs, the log volume is also based on a tiered approach with a default of 1 million per day and a maximum limit of 8 million per day.
   
   To modify the default message volume setting, click the edit icon for a realm listing. The default limit for PIGs is based on your realm’s tier setting.
- **Loaner Realm Delete: **Use this page to delete the logs from a loaner realm or test realm. Deleting logs isn’t reversible. Salesforce recommends that you only delete loaner logs when transferring a loaner realm to another customer. To delete a loaner realm, requires the Log Center Support role.
