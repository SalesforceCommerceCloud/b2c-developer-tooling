# Undo a Data Replication Process in B2C Commerce

_When you undo a data replication, data on the target instance reverts to the values from before the most recent data replication process that included publishing. Only run an undo process after a data replication process of type Publishing or Transfer & Publishing._

> **Note:** The undo action is no longer available for data replication processes which run prior to a GA Release. For example, a process on 24.7 cannot be undone on 24.8. This does not apply to GA Updates. For example, 24.8.1 to 24.8.2.

|  |
| --- |
| Available in: **B2C Commerce** |

1. Click App Launcher _(image: App Launcher)_, and then select **Administration > Replication > Data Replication**. A list of existing data replication processes appears.

   When you undo a data replication process, enter a description, configure an email notification, and prevent the target instance page cache from refreshing. If you don't want to do any of those things, simply click **Undo** next to a replication process. Otherwise, proceed to Step 2.
2. Copy an existing process or create one.

   - To copy an existing process, select it in the list, then click **Copy**. Select multiple processes and copy them all at once. To modify a generated process, click its process ID to open its details page, then click **Edit**.
   - To create a replication process from scratch, click **New**, then continue with the steps to configure it.
3. The system generates a process ID. Enter a different ID.
4. From the dropdown list, select a target instance.
5. (Optional) Enter a description.
6. To refresh the page cache on the target instance at the end of the replication process, select **Invalidate**. It’s selected by default. Clearing the cache temporarily degrades your site's performance, so during times of high traffic, select **Don’t invalidate**. However, if you don't refresh the cache, shoppers can see outdated content on the storefront. Use the Don’t invalidate option with caution.
7. From the Activation Type dropdown list, select **Manual**.
8. From the dropdown list, select a notification email trigger. To enter multiple recipient email addresses, separate them with commas.

   | Option | Description |
   | --- | --- |
   | -None- | No emails are sent. |
   | When Process Ends | Sends an email to the specified addresses when the process ends, whether it succeeds or fails. If it hangs, then no email is sent. |
   | When Process Fails | Sends an email to the specified addresses only if the process fails. If the process succeeds or hangs, then no email is sent. |
   | Periodically | Enter an interval in minutes. While the process is running, emails are sent to the specified addresses at that interval until the process finishes. An email is also sent when the process succeeds or fails. |
   
   The email notifications contain the start and end time of the process, the target system, the replication type, and the included replication tasks. If there’s a failure, they also include an error code. Each process in a recurring series sends its own notification.
9. Click **Next**.
10. From the dropdown list, select the **Undo** replication type.
11. Click **Next** and review the process details.
12. Click **Create**.
13. Find the process in the list and click **Start**.

   After the Undo data replication process has begun, it can't be deleted.
