# Preview the Product Feed

_Open the Product Feed Preview to verify your field mappings, identify products with missing required fields, and download a sample CSV before turning on the daily feed sync._

Before you preview the feed, set up the OpenAI integration for your site:

- [Configure Catalog and Order Feeds for Einstein](https://help.salesforce.com/s/articleView?id=cc.b2c_openai_feed_configure_einstein.htm&type=5)
- [Meet the Prerequisites](https://help.salesforce.com/s/articleView?id=cc.b2c_openai_feed_prerequisites.htm&type=5)
- [Connect to OpenAI](https://help.salesforce.com/s/articleView?id=cc.b2c_openai_feed_connect.htm&type=5)
- [Map product fields](https://help.salesforce.com/s/articleView?id=cc.b2c_openai_feed_mapping.htm&type=5)

For an explanation of how the preview works and what's excluded, see [b2c_openai_feed_preview_about.xml](https://help.salesforce.com/s/articleView?id=cc.b2c_openai_feed_preview_about.htm&type=5).

1. Click App Launcher _(image: App Launcher)_, and then select **Merchant Tools > Site > AI & Social Integrations > OpenAI**.
2. Click **Catalog**.
3. In the **Field Mapping** section, click **Preview**.

   The Product Field Mapping Preview opens. No products are shown until you search.
4. (Non-production environments only) If the preview reports that product URLs aren't visible, click **Enter Hostname**, type your storefront hostname, and click **Save**.

   For example: `https://staging.example.com`. The hostname is used to construct the **url** column for each product. See [b2c_openai_feed_preview_about.xml](https://help.salesforce.com/s/articleView?id=cc.b2c_openai_feed_preview_about.htm&type=5).
5. In the search field, type a product name or one or more product IDs.

   The search field is an autocomplete; you don't need to press Enter. The system updates results as you type. The search supports two modes:
   
   - **By product name**: Substring match. Enter one product name at a time.
   - **By product ID**: Exact match. Enter up to 20 product IDs as a comma-separated list.
   
   The preview shows the resolved feed values for each matching product—the same values that the daily feed sync sends to OpenAI. If no products match, the preview shows **No results** and lists the reasons that products can be excluded.
6. To see variants for a master product, click the master product row to expand it.

   The preview shows up to 100 variants per master product.
7. To see field errors for a row, hover over the error icon at the start of the row.

   The system shows which required fields are missing or invalid for that product.
8. To download a CSV file of the data currently shown in the preview, click **Download Sample**.
9. To fix errors, go back to the Field Mapping section on the **Catalog** tab, configure the missing or invalid field, and then re-open the preview to verify the fix.

   For details on configuring field mappings, see [b2c_openai_feed_mapping.xml](https://help.salesforce.com/s/articleView?id=cc.b2c_openai_feed_mapping.htm&type=5).

The preview shows the resolved feed values that the daily feed sync sends to OpenAI. After the preview shows no errors and the data matches your expectations, turn on the daily feed sync. See [b2c_openai_feed_enable.xml](https://help.salesforce.com/s/articleView?id=cc.b2c_openai_feed_enable.htm&type=5).

You can return to the preview at any time to verify changes—for example, after adding a custom attribute, after changing a filter rule, or after a catalog update.
