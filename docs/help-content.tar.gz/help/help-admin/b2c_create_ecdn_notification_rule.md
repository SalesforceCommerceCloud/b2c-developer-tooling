# Create a Notification Rule

_Create a notification rule to bind a webhook destination to one or more eCDN zones for your B2C Commerce storefront and control whether delivery is enabled. Toggling a rule off pauses delivery without deleting the rule._

Register the webhook destination that the rule delivers to before you begin. See [Create a Notification Destination](https://help.salesforce.com/s/articleView?id=cc.b2c_create_ecdn_notification_destination.htm&type=5).

[Which Salesforce Commerce Product Do I Have?](https://help.salesforce.com/s/articleView?id=commerce.comm_what_product.htm)

A notification rule uses these fields.

- **Webhook** (required): Destination that receives notification events.
- **Enable Notification Upon Saving** (optional): Starts delivery immediately when you save the rule.
- **Zones** (required): Zones covered by the rule. Select **All** or select a subset.

1. In Business Manager, click the App Launcher, then select **Administration > Sites > Embedded CDN Settings**.
2. Locate the zone you want to configure, and select **Configure Zone** from the actions menu.
3. Click the **Notifications** tab.
4. In the **Notifications** section, click **New Notification**.

   The Create Notification screen opens.
   
   _(image: Create Notification screen showing Webhook dropdown with Slack Webhook - Logpush Job Alert selected, Enable Notification Upon Saving checkbox checked, and Zones section with All checkbox and multiple zone checkboxes including sfcc-ecdn-test5.net)_
5. Open the **Webhook** dropdown and select the destination you registered.

   If the destination you want isn't in the list, register it first in the Destinations section.
6. To start delivering immediately, select **Enable Notification Upon Saving**.

   Leave this option cleared to create the rule in a paused state.
7. Select the **Zones** that the rule applies to.

   Select **All** to include every zone in the list, or select zones individually. The current zone is selected by default.
8. Click **Save**.

   A confirmation toast appears, and the rule shows up in the Notifications table with the Enabled toggle reflecting the choice you made on the form.
   
   _(image: Success toast notification reading The notification Slack Webhook - Logpush Job Alert was created successfully, with Notifications tab showing Destinations table with one webhook and Notifications table with one rule including zone list and Enabled toggle)_

eCDN sends runtime event notifications to the selected destination for each enabled zone. If a selected zone no longer resolves after the page loads, a warning toast names the zone and saves the rule without that binding. Refresh the page and edit the rule to re-select any missing zones.

To change, pause, or remove a rule after you create it, see [Manage Notification Rules](https://help.salesforce.com/s/articleView?id=cc.b2c_manage_ecdn_notification_rules.htm&type=5).
