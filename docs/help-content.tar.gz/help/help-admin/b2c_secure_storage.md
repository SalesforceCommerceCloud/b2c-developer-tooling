# Secure Storage in B2C Commerce

_Salesforce B2C Commerce stores many types of sensitive information, the most important being credit card details. Credit card encryption, key generation, and re-encryption are automatic, and merchants undergoing a PCI audit can monitor this process._

Payment instruments, such as debit and credit cards, aren’t removed from B2C Commerce. They’re masked after a data retention period that you can configure. The default retention period is 12 months. B2C Commerce masks credit card payment instrument types based on credit card validity, and it masks payment instruments of other types after the data retention period expires. It masks payment instruments assigned to orders after the data retention period expires.

## Related Content

- [Private Keys and Certificates in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_certificates_and_private_keys.htm&type=5)
  In various scenarios, you must import your third-party certificates and private keys into your instance’s keystore. A keystore can store multiple entries, each of which can be of type `PrivateKeyEntry` or of type `TrustedCertificateEntry`. This is similar to the terminology used by `java.security.KeyStore`.
