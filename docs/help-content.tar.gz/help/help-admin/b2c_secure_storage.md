# Secure Storage in B2C Commerce

_Salesforce B2C Commerce stores many types of sensitive information, the most important being credit card details._
