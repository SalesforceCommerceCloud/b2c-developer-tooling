# eCDN Zone Security Rules

_The Security Rules tab in the Configure Zone screen is where you protect an embedded CDN (eCDN) zone for B2C Commerce. Using settings on that page, you can configure web application firewall (WAF) managed rulesets, realm and zone security rules, custom firewall rules, and rate limiting. Understand what each control does, which zone types are eligible, and how traffic from trusted sources bypasses security checks._

### What the Security Rules Tab Covers in B2C Commerce

The Security Rules tab on the B2C Commerce Configure Zone screen groups the controls that decide which requests reach your storefront and how suspicious traffic is handled. Page Shield policies and host header override rules appear on their own tabs in the Configure Zone screen but are part of the same zone-security workflow.

### Behavior: What Traffic Is Bypassed

When a request comes from an IP address in a trusted (Managed IP Address) list and matches a skip rule, the eCDN for B2C Commerce bypasses selected security checks. The core purpose, making sure that traffic from trusted IP addresses isn't blocked, is preserved from the legacy Trusted IP model. The new model implements it more precisely.

> **Tip:** Skip rules are evaluated before any blocking or rate-limiting rules and are automatically positioned at the top of the ruleset. If both an allowlist skip rule and a blocklist rule exist for a zone, the allowlist skip rule is positioned first. You don't need to manage rule ordering manually.

### DDoS Layer 7 Override Details

When an account has account-level (realm-level) trusted IP lists configured, B2C Commerce automatically applies DDoS Layer 7 overrides on all eligible zones. These overrides are separate from the skip rule applied to custom firewall rules, WAF rules, and rate limiting rules. They're set to `sensitivity_level: off` and `action: log` to prevent false-positive challenges on legitimate high-volume traffic from trusted sources.

The following Cloudflare DDoS managed rules are automatically overridden:

| Rule ID | Description |
| --- | --- |
| `0b1e17bd25c74e38834f19043486aee1` | Unusual headers/URI path signature #1 |
| `466d6c2e8ba74459a2670e91e269dfd6` | Unusual headers/URI path signature #56 |
| `12b9aecf1f6245b29d7e842bf35a42a0` | Unusual headers/URI path signature #57 |
| `6e3ccc23900c428e8ec0fb8a3a679c52` | Requests from known bad sources |
| `d38bbe6dc925461ca4e47e4cecd68c61` | High request rate to search endpoints |
| `0a07c24f3cd44a57a5c19b73d2f294d7` | Requests trying to impersonate browsers |

> **Important:** When an account has account-level trusted IPs, DDoS Layer 7 overrides apply to eligible storefront zone types: Proxy, Legacy, Default Domain, and Business Manager (BM) zones. This overall rule is broader than zone-level skip rules, which don't apply to Business Manager and SCAPI zones. Whether these Layer 7 overrides apply to SCAPI zones isn't confirmed.

### Zone Type Eligibility

The following zone types for B2C Commerce support Realm Security Rules (same as legacy Trusted IP support):

- Proxy zones
- Legacy zones (custom domains)
- Default Domain zones

### Feature Switch

Realm Security Rules are controlled by a feature switch in B2C Commerce Business Manager. When the **Enable eCDN Trusted IP Migration** feature switch is enabled, the Security Rules tab with the Managed IP Address Lists and Custom Firewall Rules functionality becomes available in the Configure Zones interface. Contact your Salesforce account team if this tab isn't visible in your organization.

## Related Content

- [Configure WAF Settings for an eCDN Zone](https://help.salesforce.com/s/articleView?id=cc.b2c_configure_zone_waf_settings.htm&type=5)
  Configure web application firewall (WAF) managed rulesets for an eCDN zone for B2C Commerce by using the Security Rules tab in Configure Zones in Business Manager.

- [Realm Security Rules for eCDN Zones](https://help.salesforce.com/s/articleView?id=cc.b2c_configure_zone_realm_security_rules.htm&type=5)
  Realm Security Rules let you define Managed IP Address Lists and custom firewall rules that control how trusted IP traffic is handled across **all** your eCDN zones for B2C Commerce. These rules replace the legacy Trusted IP configuration.

- [Create a Custom Firewall Rule for an eCDN Zone](https://help.salesforce.com/s/articleView?id=cc.b2c_create_eCDN_firewall_rule.htm&type=5)
  Configure a custom firewall rule to control incoming traffic to your B2C Commerce storefront based on specified request parameters.

- [Create a Rate Limiting Rule for an eCDN Zone](https://help.salesforce.com/s/articleView?id=cc.b2c_eCDN_create_rate_limiting_rule.htm&type=5)
  Configure a rate limiting rule to specify rate limits for requests that match a particular expression and then perform an action when requests reach those rate limits. Rate limiting rules improve B2C Commerce storefront availability, target specific traffic patterns and combat threats, such as bots.
