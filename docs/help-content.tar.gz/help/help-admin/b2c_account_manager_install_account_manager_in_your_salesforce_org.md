# Install Account Manager in Your Salesforce Org in B2C Commerce

_Configure the Salesforce org where you want to use identity federation._

[Which Salesforce Commerce Product Do I Have?](https://help.salesforce.com/s/articleView?id=commerce.comm_what_product.htm)

1. Log in to your Salesforce org and select **Setup > Apps > Connected Apps > Connected Apps OAuth Usage**.
2. In the list of connected apps, locate B2C Commerce Account Manager and click **Install**.

   If Account Manager isn’t listed as a connected app, it isn’t configured. See [Configure Account Manager for Identity Federation. ](https://help.salesforce.com/s/articleView?id=cc.b2c_account_manager_configure_account_manager_for_identity_federation.htm&type=5)
   
   _(image: List of Connected Apps)_
3. Click **Edit Policies**.
4. For IP Relaxation, select **Relax IP restrictions**, and save your changes.
5. In the Quick Find box, enter `My Domain`, and select **My Domain**.
6. Under My Domain Details, check the value set for My Domain Name. You use this value when configuring Account Manager settings.

   _(image: Configure connected app.)_
