# Add Stacked Proxy to the Firewall Allowlist

_Use the B2C Commerce CDN Zones API custom rules to selectively skip the web application firewall (WAF), other custom rules, rate limits, or security levels for third-party IP addresses that you specify._

> **Important:** This method isn't recommended as it bypasses all DDoS and WAF components. To selectively skip WAF, other custom rules, or rate limits for specific third-party addresses, use [eCDN Custom Rules](https://developer.salesforce.com/docs/commerce/commerce-api/guide/cdn-zones-custom-rules.html).

1. In Business Manager, click App Launcher _(image: App Launcher)_, and then select**Administrator > Site > Embedded CDN Settings**.
2. Locate your zone and select **Configure Zone** from the dropdown menu.
3. Add the third-party proxy IP address to a Managed IP Address List, and reference that list in a Custom Firewall Rule with a skip action. For instructions, see [Create and Manage Trusted IP Address Lists](https://help.salesforce.com/s/articleView?id=cc.b2c_manage_trusted_ip_address_lists.htm&type=5).
