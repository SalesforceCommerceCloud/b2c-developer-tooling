# Import an Inventory List

_When using an external inventory system other than Salesforce Omnichannel Inventory, use Business Manager to import inventory lists. Structure your inventory data files according to the `Inventory.xsd` schema. This topic applies to B2C Commerce._

|  |
| --- |
| Available in: **B2C Commerce** |

1. Click App Launcher _(image: App Launcher)_, and then select **Merchant Tools > Site > Products and Catalogs > Import & Export > Upload**.
2. Select an XML file on your local computer and click **Upload**.
3. Navigate to **Import Inventory Lists,** select your uploaded file and click **Next** (the file is validated).
4. Click **Next**, select the import mode you want to use for importing (to create the inventory list select **Merge**) and click **Apply**. The mode options for importing are:

   - Merge: Updates existing database objects and creates objects based on the XML file.
   - Update: Updates existing database objects only (it doesn't create objects based on the XML file).
   - Replace: Deletes and recreates existing database objects and creates objects based on the XML file.
   - Delete: Deletes all database objects contained in the XML file.
5. Assign an inventory list to a storefront site (if not already assigned by the initial Site Import).
6. Click App Launcher _(image: App Launcher)_, and then select **Merchant Tools > Site > Products and Catalogs > Inventory**.
7. Click **Edit** for an inventory list.
8. Select the **Site Assignments** tab.
9. Check the box of the site to which you want to assign the inventory list (only one list can be assigned to a site at a time).
