# Content and Content Library Folder Object Import and Export in B2C Commerce

_Use the library.xsd schema to import and export content and content libraries._

When importing or exporting content and content libraries, keep the following in mind:

- Use pipelets to zip or unzip content images.
- Manually upload gzipped files using Business Manager, as long as the files or images can be validated.
- Manually upload zipped files using Business Manager. When uploading zipped files, make sure to use a utility that doesn't include extraneous files. For example, the _MacOS folder created by the Mac system compression utility.
- You can't use WebDAV to move files on staging or production instances.
- To move files into their correct location in the cartridge, create a job that uses FTPClient or WebDAVClient.
- When creating job steps to import or export a private library, along with the library ID, you configure site-specific context as a scope for the job step flow.
   
   - Organization: Executes the flow for the instance and exports the shared library with the given ID.
   - Specific Sites: Use if the export is site-specific. Executes the job flow and exports the private library only on the site you select.
   - All Storefront Sites: Use if the export is for all instance sites. Executes the job flow and exports the private library to all sites.
- Private libraries are listed in the Business Manager UI and appended with the site name for better reference. When configuring a private library for export, only use “library” and the ID. Appending the ID with the site name returns an error.

To export a content asset part of a private library, click App Launcher _(image: App Launcher)_, and then navigate to ***site* > Merchant Tools > Content > Import & Export** and continue the export. The <library> tag of a private library doesn't have library-id as one of its attributes, while a shared library has the attribute set to the shared library's ID.

Import content in a private or a shared library at the same location. When the <library> tag has no library-id attribute, B2C Commerce treats it as the private library of the current site. To import content as part of a shared library, use a <library> tag with library-id attribute set to the shared library's ID.

| Object Information | Details |
| --- | --- |
| Schema file | library.xsd |
| Granularity | Entire library. |
| Business Manager import and export location | ***site* > Merchant Tools > Content > Import & Export** **Administration > Sites > Import & Export** |
| Pipelets | ImportContent ExportContent  *Granularity*: Passed folders and content assets of passed folders. **For Images**: Create a job that uses FTPClient or WebDAVClient to move files into their correct location in the cartridge. |

A site export results in an archive file (x.zip) containing a structured representation of all exported data including a folder structure, XML files, and static files. You can select which libraries (either private or shared) you want to export:

> **Note:** Use the site import or export workflow to select the libraries to export.

| Library Type | Details |
| --- | --- |
| Private | XML appears within `/<archive name>/sites/<site id>/library/library.xml.`  The *library-id* attribute is omitted on the top-level `<library>` element. Static content appears in a *static* subfolder in the folder structure. During site import, a *library.xml* file in this location refers to the private library for that site. During site import, B2C Commerce assumes that a *library.xml* file in this location refers to a shared library with the given folder ID. A private *library.xml* file always imports into the private library of the current or configured site, it does not follow the library to site assignment. |
| Shared | XML appears in the `/<archive name>/Libraries/<library ID`> folder. The XML file is called *library.xml.*  The *library-id* attribute on the top-level `<library>` element is specified.  If the library-id attribute is omitted on the top-level <library> element, it is considered a Private Library.  B2C Commerce imports the file into the private library of the current site, which can differ from the library currently assigned to the current site.   The Content object supports site-specific attributes. Import and export custom attributes defined on the *Library* system object. Static content appears in a *static* subfolder in the folder structure. |
