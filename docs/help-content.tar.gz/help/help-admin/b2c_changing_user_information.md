# Change User Information in B2C Commerce

_Both users and administrators can edit user information in B2C Commerce._

|  |
| --- |
| Available in: **B2C Commerce** |

The available languages for the user interface are restricted to the languages allowed for the data locales, managed in the global preferences. Also, the organization has a preferred data and user interface locale, which is the fallback for the user, if selected in the global preferences.

To manage user login and credential information, you must have permissions to the Users module. To manage roles and permissions, you must have permissions to the Roles & Permissions module. To assign roles to users, you must have permissions to both the Users module and the Roles & Permissions module.

1. Open a user's account.

   1. For a non-administrative user, open Business Manager and click *username* at the top right of a Business Manager page.
   2. For an administrator: click App Launcher _(image: App Launcher)_, and then select **Administration > Organization > Users > *user***.
2. Search for the user.
3. Enable or disable the user.
4. Click **Change Password and Security Settings**.
5. For an administrative user:

   1. Enter your password.
   2. Click **Generate**. An email is sent to the user notifying them of the new password.
6. For the non-administrative user:

   1. Click **Generate** or enter and reenter a new password.
   2. Click **<< Back to Profile**.
   3. Select a new security question and enter its answer to change these settings.
7. Click **Apply**.
8. Click **Change Email**.

   1. Enter your password.
   2. Enter the new email.
   3. Click **Apply**.
9. Change preferences:

   - Preferred UI Locale: select the locale to appear in the Business Manager user interface for this user.
   - Preferred Data Locale: select the locale to use for data creation and editing for this user. This locale is also used in the storefront for this data.
10. Click **Apply**.
11. On the **Roles** tab.

   1. Click **Assign**.
   2. On the Select Roles page, select one or more user role IDs.
   3. Click **Assign** or **Unassign**.
12. On the **Permissions** tab.

   1. To find a permission, use the filter.
   2. To export permissions, click **Export to CSV**.
