# Configure Salesforce Payments with Adyen for B2C Commerce

_Integrate your existing Adyen merchant accounts into Salesforce Payments in any B2C Commerce sandbox, staging, development, or production instance. Connect any B2C Commerce instance to a test or live Adyen merchant account._

Adyen test and live merchant accounts use different infrastructures. You can’t switch between test and live merchant accounts. To use both test and live Adyen merchant accounts in a B2C Commerce instance, configure each merchant account and its respective API credentials separately in Business Manager.

Salesforce recommends first creating a test merchant account in your staging instance. You can then replicate the merchant account to your development and production instances. After you replicate your merchant account across instances, choose whether an instance uses a test or live merchant account. Perform test transactions on your staging and development instances and real transactions on your production instance.

Regardless of whether you create a merchant account in your instance or whether you replicate your merchant account across instances, set the API key. To maintain security, the API key isn’t replicated.

## Related Content

- [Associate an Adyen Merchant Account with B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_associate_adyen_merchant_account.htm&type=5)
  To use Salesforce Payments with Adyen, associate your existing Adyen merchant account with your B2C Commerce instance. If you don’t have an Adyen merchant account, obtain one from Adyen first. You can't create an Adyen merchant account through Salesforce Payments.

- [Test Your Adyen Merchant Account Credentials for B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_test_adyen_credentials.htm&type=5)
  Validate your payment gateway credentials for your Adyen merchant account.
