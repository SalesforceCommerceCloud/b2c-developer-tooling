# Create an eCDN Cache Rule

_Create a cache rule to make HTML pages and JSON responses eligible for caching at the eCDN edge for your B2C Commerce storefront. By default, eCDN caches only static content based on file extension._

A cache rule makes an otherwise-uncacheable content type eligible for caching, but it doesn't force caching. For a response to be cached, your origin must still return appropriate `Cache-Control` (or `Expires`) response headers. For details about how eCDN decides what to cache, see [eCDN Cache Rules and Cache Purge](https://help.salesforce.com/s/articleView?id=cc.b2c_ecdn_cache_rules_and_purge_overview.htm&type=5).

> **Note:** Cache rules aren't available on SCAPI zones, where caching is platform-managed. See [SCAPI Zone Support for B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_scapi_zone.htm&type=5).

1. In Business Manager, click App Launcher _(image: App Launcher)_, and then select **Administration > Sites > Embedded CDN Settings**.
2. Locate the zone that you want to configure, and select **Configure Zone** from the dropdown menu.

   _(image: Embedded CDN Settings zone list with Configure Zone selected from the zone actions menu)_
3. Open the **Cache Rules** section.

   _(image: Cache Rules tab in Configure Zones with no cache rules configured and the New Cache Rule button)_
4. Click **Add Rule**, and then complete the rule fields.

   Complete the required fields.
   
   - **Description**: A human-readable label for the rule.
   - **Expression**: The match condition (maximum 4,096 characters). Supports fields such as `http.request.uri.path`, `http.request.uri.path.extension`, `http.host`, `http.cookie`, and `ssl`.
   - **Action**: Only `cache` is supported, which marks matching content as eligible for caching.
   
   Complete the optional fields as needed.
   
   - **Enabled**: Turns the rule on or off without deleting it. Selected by default.
   - **Exclude query strings**: The query parameters to exclude from the cache key (for example, `gclid` and `utm_campaign`).
   - **Ignore query string order**: Sorts query parameters alphabetically so that ordering variations hit the same cache entry. Deselected by default.
   - **Respect strong ETags**: Honors strong `ETag` validators from the origin. Deselected by default.
   - **Position**: Places this rule before or after another rule to control precedence. By default, the rule is added at the end.
   
   _(image: Edit Cache Rule form showing the rule name, expression builder, expression preview, cache action, and optional cache key settings)_
5. Order rules as needed. When multiple rules match a request, the last matching rule takes effect.
6. Save the rule.

   The rule applies at the eCDN edge for that zone.
   
   _(image: Saved cache rule listed on the Cache Rules tab with its priority, action, and enabled status)_

Example Cache Rule Expressions To cache PWA Kit product detail pages (HTML), use this expression. Recommended options: exclude `gclid` and `utm_campaign`, ignore query string order, and respect strong ETags. (http.request.uri.path matches ".*/product/[^/]+/?$" and http.request.uri.path.extension eq "html") To cache SFRA content and marketing pages (HTML), use this expression. ((http.request.uri.path contains "/content/" or http.request.uri.path contains "/campaigns/") and http.request.uri.path.extension eq "html")

Keep these limits in mind.

- A zone supports a maximum of 200 cache rules.
- The expression length limit is 4,096 characters.
- Only the `cache` action is supported. To prevent caching, configure your origin to send `private`, `no-store`, `no-cache`, or `max-age=0`.
- eCDN caches GET requests only, regardless of the rule configuration.

After content is cacheable, you can invalidate it from Business Manager. See [Purge the eCDN Cache](https://help.salesforce.com/s/articleView?id=cc.b2c_purge_ecdn_cache.htm&type=5).
