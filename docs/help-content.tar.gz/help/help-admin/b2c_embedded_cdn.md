# Embedded CDN

_Salesforce B2C Commerce comes with an embedded Content Delivery Network (CDN). To ensure low response times for consumers, the embedded CDN serves content from a location close to the consumer, enhancing the ability to scale sites. Contact Salesforce Support to enable the embedded CDN for your organization._

## Related Content

- [Embedded CDN Overview](https://help.salesforce.com/s/articleView?id=cc.b2c_embedded_cdn_overview.htm&type=5)
  Salesforce B2C Commerce provides digital customers an embedded content delivery network (eCDN) designed to accelerate site speed access and content delivery. The eCDN provides low response times for consumers using proxy servers. The use of proxy servers provides digital content.

- [Configure the Embedded CDN](https://help.salesforce.com/s/articleView?id=cc.b2c_configure_the_embedded_cdn.htm&type=5)
  The embedded CDN (eCDN) is a geographically distributed network of proxy servers. Configuring the eCDN improves availability and performance, ultimately enhancing the ability to scale your site (or sites).

- [Use the CDN Zones API to Configure eCDN](https://help.salesforce.com/s/articleView?id=cc.b2c_use_cdn_zones_api_to_configure_ecdn.htm&type=5)
  To set up development, staging, or production zones, your development team uses the CDN Zones APIs to upload customer certificates to test an Shopper Commerce API (SCAPI) implementation and configure vanity host names for development, staging, and production instances on eCDN.

- [Clear eCDN Cache](https://help.salesforce.com/s/articleView?id=cc.b2c_clear_ecdn_cache_task.htm&type=5)
  B2C Commerce stores static storefront content in eCDN cache or the web tier static content cache.

- [Configure an External CDN or Third-Party Proxy](https://help.salesforce.com/s/articleView?id=cc.b2c_configuring_an_external_cdn.htm&type=5)
  Use your own content delivery network (CDN) with Salesforce B2C Commerce's embedded CDN to deliver static and dynamic content to your customers. Deploy your CDN (or a reverse proxy) in front of B2C Commerce to improve performance and security, or to provide extra functionality using your CDN.

- [eCDN Web Application Firewall](https://help.salesforce.com/s/articleView?id=cc.b2c_waf_application.htm&type=5)
  Embedded Content Delivery Network (eCDN) Web Application Firewall (WAF) helps protect your storefront using extra layer 7 protection.

- [Manage HSTS in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_manage_hsts.htm&type=5)
  To secure your site, HTTP Strict Transport Security (HSTS) instructs web browsers to access your domain using only HTTPS. This topic applies to B2C Commerce.

- [Additional Embedded CDN Resources](https://help.salesforce.com/s/articleView?id=cc.b2c_ecdn_additional_resources.htm&type=5)
  We've prepared some resources to help you optimize your experience with Embedded CDN.
