# Embedded CDN

_Salesforce B2C Commerce comes with an embedded Content Delivery Network (CDN). To ensure quick response times for consumers, the embedded CDN serves content from a location close to the consumer. Embedded CDN also helps absorb high or sudden increases in traffic, so sites stay fast and responsive as demand grows._

## Related Content

- [Embedded CDN Overview](https://help.salesforce.com/s/articleView?id=cc.b2c_embedded_cdn_overview.htm&type=5)
  Salesforce B2C Commerce includes an embedded content delivery network (eCDN) that accelerates site performance and content delivery. The eCDN serves content from locations close to your shoppers for fast response times, and supports web application firewall (WAF) and HTTP Strict Transport Security (HSTS).

- [Set Up eCDN Zones and Hostnames](https://help.salesforce.com/s/articleView?id=cc.b2c_set_up_ecdn_zones_and_hostnames.htm&type=5)
  Create embedded CDN (eCDN) zones and add the hostnames that route your Salesforce B2C Commerce storefront traffic through the CDN. Use Default Domain for a Salesforce-managed hostname, or add your own custom hostnames and site URL aliases.

- [Manage SSL Certificates for eCDN Zones in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_manage_ssl_certificates_for_ecdn_zones.htm&type=5)
  Every embedded CDN (eCDN) zone requires a valid SSL certificate. Proxy zones can use either an eCDN managed certificate that's issued and auto-renewed by Salesforce or a self-managed certificate that you upload and renew yourself in Business Manager before it expires. Legacy (root) zones, for example, brand.com, support only a self-managed certificate. After adding or updating a certificate, map DNS so the hostname's traffic routes to its eCDN zone.

- [eCDN Zone Settings in Business Manager](https://help.salesforce.com/s/articleView?id=cc.b2c_configuring_a_zone.htm&type=5)
  Use the Configure Zone screen in Business Manager to manage settings for an embedded CDN (eCDN) zone for B2C Commerce, including certificates, security rules, performance, custom pages, notifications, and logs.

- [Proxy Zone Migration Overview](https://help.salesforce.com/s/articleView?id=cc.b2c_migrating_proxy_zones.htm&type=5)
  Migrate legacy zones to proxy zones by using B2C Commerce Business Manager or the CDN-API. Proxy zones give you standard eCDN configuration and the latest security features, and they prevent common hierarchy-assignment issues. Migration is required to move to Hyperforce, which doesn't support legacy zones.

- [CDN Zones API Overview](https://help.salesforce.com/s/articleView?id=cc.b2c_use_cdn_zones_api_to_configure_ecdn.htm&type=5)
  Use the CDN Zones API to create and manage B2C Commerce eCDN zones for your development, staging, and production instances when you want a scripted or self-service alternative to Business Manager. With the API, you can upload custom certificates, configure vanity hostnames, and migrate site traffic.

- [Configure an External CDN or Third-Party Proxy](https://help.salesforce.com/s/articleView?id=cc.b2c_configuring_an_external_cdn.htm&type=5)
  Use your own content delivery network (CDN) with Salesforce B2C Commerce's embedded CDN to deliver static and dynamic content to your customers. Deploy your CDN (or a reverse proxy) in front of B2C Commerce to improve performance and security, or to provide extra functionality.

- [eCDN Caching and Cache Fingerprinting](https://help.salesforce.com/s/articleView?id=cc.b2c_ecdn_caching_and_fingerprinting.htm&type=5)
  B2C Commerce eCDN caches static storefront content at the edge and refreshes it automatically using a fingerprint value in each asset's URL. Understand how caching and fingerprinting work before you clear the cache or add cache rules for dynamic content.

- [eCDN Web Application Firewall (WAF)](https://help.salesforce.com/s/articleView?id=cc.b2c_waf_protection.htm&type=5)
  The embedded CDN (eCDN) web application firewall (WAF) is a layer 7 defense that inspects HTTP and HTTPS traffic to your B2C Commerce storefront and blocks requests that try to exploit code-level vulnerabilities. WAF is enabled by default when you create a Proxy Zone and is one part of a multitiered approach to bad-actor mitigation.

- [HTTP Strict Transport Security (HSTS) for eCDN](https://help.salesforce.com/s/articleView?id=cc.b2c_manage_hsts.htm&type=5)
  HTTP Strict Transport Security (HSTS) secures your B2C Commerce site by instructing web browsers to access your domain using only HTTPS, which prevents downgrade attacks. You enable and disable HSTS per eCDN zone in Business Manager.
