# Set Up PCI Compliance Alerts

_Get alerted when an eCDN Logpush job fails on a zone that carries PCI-scoped traffic for your B2C Commerce storefront. Wiring a notification rule to your SIEM or on-call tool lets you detect a stalled PCI log stream before the audit window expires._

[Which Salesforce Commerce Product Do I Have?](https://help.salesforce.com/s/articleView?id=commerce.comm_what_product.htm)

To configure the Logpush delivery targets that these alerts monitor, see [Create a Logpush Job](https://help.salesforce.com/s/articleView?id=cc.b2c_create_ecdn_logpush_job.htm&type=5).

Alerting on Logpush job failures for PCI-scoped zones is the most common reason teams configure notifications. This task combines a destination and a notification rule for that use case. For the full field reference, see [Create a Notification Destination](https://help.salesforce.com/s/articleView?id=cc.b2c_create_ecdn_notification_destination.htm&type=5) and [Create a Notification Rule](https://help.salesforce.com/s/articleView?id=cc.b2c_create_ecdn_notification_rule.htm&type=5).

1. In the receiver of your choice (Slack incoming webhook, PagerDuty Events API endpoint, or an internal alerting service), create a webhook and copy its URL.
2. In Business Manager, on the PCI zone's **Notifications** tab, click **New Destination** and paste the URL.

   Give the destination a clear name, such as Slack #pci-alerts or PagerDuty PCI.
3. Click **New Notification**, and select the destination from the **Webhook** dropdown.
4. Leave **Enable Notification Upon Saving** selected, and select the PCI zone.

   Select all zones if you want fleet-wide coverage.
5. Click **Save**.

You now receive a notification whenever an event configured for that destination fires on the selected zones, including Logpush job failures, which is the signal you need to detect a stalled PCI log stream before the audit window expires.

> **Tip:** Keep the PCI alert destination separate from your general engineering channel. PCI alerts have a different on-call rotation and a different escalation path, and mixing them with general traffic dilutes both.
