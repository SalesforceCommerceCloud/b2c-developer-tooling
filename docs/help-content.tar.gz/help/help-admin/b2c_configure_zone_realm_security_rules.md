# Realm Security Rules for eCDN Zones

_Realm Security Rules let you define Managed IP Address Lists and custom firewall rules that control how trusted IP traffic is handled across **all** your eCDN zones for B2C Commerce. These rules replace the legacy Trusted IP configuration._

> **Note:** Realm Security Rules, including Managed IP Address Lists, are available on SCAPI zones. There's one SCAPI zone for Development, Staging, and Production. Configure it only from the Production instance. It doesn't appear in Business Manager or the CDN API on Development or Staging. Scope rules by org ID so that they don't affect other environments. See [SCAPI Zone Support for B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_scapi_zone.htm&type=5).

Realm Security Rules provide two components that work together to manage trusted IP traffic:

**Managed IP Address Lists**
: Named lists of IP addresses or CIDR ranges. You can scope a list to your entire realm (account level) or to a single zone (zone level). See [Manage IP Address Lists for eCDN Zones](https://help.salesforce.com/s/articleView?id=cc.b2c_manage_trusted_ip_address_lists.htm&type=5).

**Custom firewall rules**
: Rules that reference your IP address lists and define a skip action, so traffic from trusted IPs bypasses selected security checks. See [Create a Custom Firewall Rule for an eCDN Zone](https://help.salesforce.com/s/articleView?id=cc.b2c_create_eCDN_firewall_rule.htm&type=5).

> **Important:** Realm Security Rules replace the legacy Trusted IP list groups that were previously configured via the Firewall tab in the zone settings slider. If you had existing Trusted IP configurations, Salesforce migrates them automatically. See [Trusted IP Migration to WAF Custom Rules](https://help.salesforce.com/s/articleView?id=cc.b2c_migrate_trusted_ips_to_custom_rules.htm&type=5) for details.

For information about what traffic a skip rule bypasses, the DDoS Layer 7 overrides, eligible zone types, and the feature switch that controls this functionality, see [eCDN Zone Security Rules](https://help.salesforce.com/s/articleView?id=cc.b2c_ecdn_security_rules.htm&type=5).

### The Realm Security Rules Tab in B2C Commerce

Realm Security Rules is a sub-tab of the **Security Rules** tab on the Configure Zone screen. To open the Configure Zone screen, select **Configure Zone** from a zone's dropdown menu on the Embedded CDN Settings page.

### Configure Zone option in the zone dropdown menu

_(image: Embedded CDN Settings page showing the Configure Zone option in the zone actions dropdown menu)_

At the account level, the tab lists your custom firewall rules and Managed IP Address Lists, including rules migrated from legacy Trusted IP configurations.

### Realm Security Rules tab — account level

_(image: Realm Security Rules tab at the account level showing migrated custom firewall rules and Managed IP Address Lists)_

Each custom firewall rule uses IP address list conditions to match trusted traffic, and skip actions to define which security checks that traffic bypasses.

### Custom firewall rule — skip action detail

_(image: Edit Custom Rule dialog showing IP address list conditions and Skip actions configured for a migrated Trusted IP allowlist rule)_

Managed IP Address Lists and their associated custom firewall rules can be scoped at two levels:

> **Note:** Account-level changes affect all eligible zones across development, staging, and production. A warning banner is displayed when you make account-level changes on a Production instance. On non-production instances, the Realm Security Rules tab is read-only. Use the Production instance to create or modify account-level rules and lists.

### Realm Security Rules tab — zone level

_(image: Realm Security Rules tab at the zone level showing custom firewall rules and Managed IP Address Lists scoped to a single zone)_

### Zone Security Rules tab

_(image: Zone Security Rules tab showing zone-level custom firewall rules, rate limiting rules, and WAF-v2 eCDN Managed Ruleset settings for a specific eCDN zone)_

### Realm Security Rules Permissions in B2C Commerce

On non-production instances (staging, development, sandbox), the Realm Security Rules tab is read-only. A blue information banner indicates: *"Realm-level configuration is read-only on this instance. Use the Production instance to make changes."*

On Production, an amber warning banner indicates: *"Account-level changes affect all zones (development, staging, and production)."*

## Related Content

- [Manage IP Address Lists for eCDN Zones](https://help.salesforce.com/s/articleView?id=cc.b2c_manage_trusted_ip_address_lists.htm&type=5)
  Create named lists of trusted IP addresses or CIDR ranges to use with custom firewall rules that bypass security checks for trusted traffic on your B2C Commerce storefront.

- [Trusted IP Migration to WAF Custom Rules](https://help.salesforce.com/s/articleView?id=cc.b2c_migrate_trusted_ips_to_custom_rules.htm&type=5)
  Salesforce automatically migrates your legacy B2C Commerce Trusted IP configurations to web application firewall (WAF) custom rules and Managed IP Address Lists in the new Realm Security Rules tab. Learn what the migration does and how to verify your migrated configuration.
