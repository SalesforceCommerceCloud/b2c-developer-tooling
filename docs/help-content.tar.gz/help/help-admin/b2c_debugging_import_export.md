# Debugging Import/Export in B2C Commerce

_Debug a pipeline called by a job. This topic applies to B2C Commerce.\_

|  |
| --- |
| Available in: **B2C Commerce** |

1. Create a public subpipeline that calls the private subpipeline you’re trying to debug, and that ends in an interaction node.
2. Create breakpoints in the private pipeline.
3. Enter the URL for the public pipeline in your browser.

   Example:
   
   ```
   http://[realmname].demandware.net/on/demandware.store/
    Sites-YourShopHere-Site/default/Pipeline-Subpipeline
   ```
4. Step through the pipeline in the debugger using F5.
