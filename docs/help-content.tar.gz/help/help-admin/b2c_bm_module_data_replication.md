# Business Manager Module Data Replication in B2C Commerce

_The tables in this section map the data managed in Business Manager modules to data replication tasks._

## Related Content

- [Merchant Tools Data Replication in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_merchant_tools_data_replication.htm&type=5)
  These tables map Business Manager Merchant Tools modules to data replication tasks.

- [Administration Data Replication in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_administration_data_replication.htm&type=5)
  These tables map Business Manager Administration modules to data replication tasks.
