# Business Manager Module Data Replication in B2C Commerce

_The tables in this section map the data managed in Business Manager modules to data replication tasks. This topic applies to B2C Commerce._
