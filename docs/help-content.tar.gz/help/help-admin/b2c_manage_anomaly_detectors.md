# Manage Anomaly Detectors in Log Center

_View, edit, pause, resume, and delete anomaly detectors in B2C Commerce Log Center, and create a detector from a log search you already ran. What you can change depends on your Log Center role and the realms you can access._

### Who Can View, Edit, and Delete Detectors

Access to anomaly detectors depends on your Log Center role and the realms you can access.

### View Results

View the results and status of any detector in a realm you can access, regardless of who created it.

### Edit and Delete

What you can change depends on your role.

| Role | Can edit or delete |
| --- | --- |
| Log Center user | Only the detectors you created |
| Log Center external admin | Any detector in the realms you can access |
| Salesforce administrator or support | Any detector |

### Considerations

- Create detectors only for realms you can access.
- Each user can configure up to ten detectors. Administrators aren't subject to this limit.
- Detectors that analyze security logs are available only to users who have access to security logs.
- Pausing a detector doesn't free up a slot. To create a new detector when you reach your limit, delete one that you no longer need.

### Edit a Detector

1. On the **Anomaly Detection** tab, click **Anomaly Detector Configurations**.
2. Find the detector, and open it for editing.
3. Update the **Data**, **Detector settings**, or **Alerts** step. Log Center prefills all three steps with the current values.
4. Click **Save**.

> **Tip:** Changes to filters or settings can change which anomalies Log Center flags. After you save, review the detector's results to confirm that it behaves as you expect.

### Pause or Resume Detection

To stop a detector from checking for anomalies without losing its configuration, turn off **Real-time Anomaly Detection** for that detector. Log Center asks you to confirm. To resume, turn on **Real-time Anomaly Detection** again.

### Delete a Detector

Deleting a detector permanently removes it and its configuration. Log Center asks you to confirm before it deletes the detector. You can't undo this action. Delete only the detectors that your role allows you to delete.

> **Tip:** Pause a detector if you expect to use it again. Delete it if you no longer need it.

### Create a Detector from a Log Search

_(image: Log Center search results with the Detector button)_

If you've already built a search that finds the logs you care about, you can turn it into a detector.

1. In Log Center, run your search.
2. Click **Detector**. The New Anomaly Detector wizard opens with your search filters already applied on the **Data** step.
3. Review the filters, click **Preview Logs** to check the matches, and complete the remaining steps.

This is a quick way to start with filters that you've already tested. The **Detector** button appears only when the current search can be turned into a detector.

> **Important:** Creating detectors for multiple realms at once isn't supported.

### Salesforce-Managed Detectors

Salesforce can create some detectors for you, for example, to monitor security-related activity. For these detectors:

- The **Data** and **Detector settings** steps are read-only.
- Change the **Alerts** step to choose who is notified and how.
- Users who can access the detector's realm can update alerting, even if they didn't create the detector.

### Login Anomaly Detector

Salesforce creates a login anomaly detector for each realm. You don't set it up. In **Anomaly Detector Configurations**, the detector is named `login-ad-<realm ID>`, for example, `login-ad-abcd`. Its description is **Auto-created login anomaly detector**. The detector watches failed login attempts on SLAS login (SCAPI), storefront login, and OCAPI Shop login, and it flags spikes that can indicate credential stuffing. OCAPI is deprecated, and existing integrations can still call it. The detector sends no notifications until you turn on alerting, and it doesn't block login attempts.

You can't change which logs the detector monitors or its settings, such as the alert threshold. Turn on alerting, and choose who is notified and how: email, Slack, Microsoft Teams, or PagerDuty.

The login anomaly detector runs on Production only. To view it and turn on alerting, log in to Log Center with a role that can access the realm and its security logs. What you can change depends on your role.

Log Center compares login activity with a learned baseline. Wait through the learning period before you rely on the detector's results. A sale or other planned traffic spike can trigger an alert.

> **Important:** A custom login flow that rejects an attempt before the platform checks the shopper's credentials doesn't produce a signal for this detector.

To turn on alerting for the login anomaly detector:

1. On the **Anomaly Detection** tab, click **Anomaly Detector Configurations**.
2. Open the detector named `login-ad-<realm ID>`. Its description is **Auto-created login anomaly detector**.
3. On the **Alerts** step, select **Enable Alerting**, and choose the notification channels.
4. Click **Save**.

When the detector flags an anomaly, confirm the spike and apply the controls that you already have.

1. Check [eCDN Analytics](https://help.salesforce.com/s/articleView?id=cc.b2c_analyze_eCDN_traffic.htm&type=5) and Log Center for the spike. Use the paths, hostnames, and source patterns to tell credential stuffing apart from volumetric traffic.
2. Use the available controls, such as Leaked Credentials Detection rules, rate limits, and a Managed Challenge action on storefront login paths, plus Strict Client Auth for private SLAS clients. Start rules in log mode, review the matches, and then switch to an enforcement action. See [Create a Custom Firewall Rule for an eCDN Zone](https://help.salesforce.com/s/articleView?id=cc.b2c_create_eCDN_firewall_rule.htm&type=5), [Create a Rate Limiting Rule for an eCDN Zone](https://help.salesforce.com/s/articleView?id=cc.b2c_eCDN_create_rate_limiting_rule.htm&type=5), [Bot Management](https://developer.salesforce.com/docs/commerce/commerce-solutions/guide/bot-management.html), and [SLAS Best Practices](https://developer.salesforce.com/docs/commerce/commerce-api/guide/slas-best-practices.html).
3. If the attack continues or you need help, then open a support case. Include the time window in UTC, the affected hostnames and paths, the detector alert, and the mitigations that you already applied. If shopper accounts appear compromised, then also use [Report a Security Concern](https://security.salesforce.com/contact/).
4. After the attack, reset passwords for the affected accounts and revoke their sessions.

Use [Under Attack Mode](https://help.salesforce.com/s/articleView?id=cc.b2c_enable_under_attack_mode.htm&type=5) only as a last resort, and only on the storefront zone. Under Attack Mode isn't available on the SCAPI zone.

### View Detector Alerts

When alerting is turned on, anomalies that meet your alert threshold also appear on the **Alerts** page as Anomaly Detector alerts. From there, review the alert and open its settings.

### Manage Notification Channels

- Send alerts to email addresses, Slack channels, Microsoft Teams chats or channels, and PagerDuty services.
- To create a channel, click **Set up a notification channel** on the **Alerts** step.
- You can't delete a notification channel that a detector uses. Remove the channel from the detector first, and then delete it.

### Availability

The **Anomaly Detection** tab has been generally available since August 2026.
