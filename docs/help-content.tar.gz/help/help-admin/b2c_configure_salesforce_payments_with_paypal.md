# Configure Salesforce Payments with PayPal for B2C Commerce

_Configure the PayPal Payment Service Provider (PSP) with Salesforce Payments for B2C Commerce._

## Related Content

- [Associate a PayPal Merchant Account with B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_associate_paypal_merchant_account.htm&type=5)
  To use Salesforce Payments with PayPal, associate your PayPal merchant account with your B2C Commerce instance.

- [Onboard Your PayPal Merchant Account for B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_onboard_a_paypal_merchant_account.htm&type=5)
  After you associate a PayPal Merchant account with your B2C Commerce instance, onboard the account. The PayPal onboarding process collects business information such as names, addresses, and bank accounts. The steps vary based on the merchant account country.
