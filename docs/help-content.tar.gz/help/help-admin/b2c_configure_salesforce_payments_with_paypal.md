# Configure Salesforce Payments with PayPal for B2C Commerce

_Configure the PayPal Payment Service Provider (PSP) with Salesforce Payments for B2C Commerce._
