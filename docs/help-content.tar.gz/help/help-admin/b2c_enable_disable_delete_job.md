# Enable, Disable, or Delete a Job in B2C Commerce

_Turn a B2C Commerce job schedule on or off, or delete the job. Turning the schedule off stops automatic runs, and you can still run the job manually._

[Which Salesforce Commerce Product Do I Have?](https://help.salesforce.com/s/articleView?id=commerce.comm_what_product.htm)

1. From the App Launcher _(image: App Launcher)_, find and select **Administration > Operations > Jobs**.
2. On the Jobs list, select one or more jobs, and then click **Enable**, **Disable**, or **Delete**. You can also delete a job with the trash icon on its row.

   **Enable** turns the schedule on. **Disable** turns it off. A job with the schedule turned off can still be run manually.
   
   On the job page, the same setting is the **Enabled** checkbox on **Schedule and History**.
