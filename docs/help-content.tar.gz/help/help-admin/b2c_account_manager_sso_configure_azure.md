# Configure an Azure AD Security Assertion Markup Language (SAML) Provider

_This guide serves as a general integration overview for B2C Commerce. For precise instructions, Salesforce advises consulting the most up-to-date integration documentation specific to your Identity Provider (IDP), such as Azure IDP._

[Which Salesforce Commerce Product Do I Have?](https://help.salesforce.com/s/articleView?id=commerce.comm_what_product.htm)

The SSO support for B2C Commerce is done via core-licensed products and requires three connections.

- Azure AD
- Salesforce Platform
- Account Manager

To enable Salesforce SSO and Salesforce provisioning with Azure, use this [Azure documentation](https://docs.microsoft.com/en-us/azure/active-directory/saas-apps/salesforce-tutorial#configure-azure-ad-sso).

### When you integrate Salesforce with Azure AD, you can:

- Control who has access to Salesforce through Azure AD.
- Enable your users to be automatically signed-in to Salesforce with their Azure AD accounts.
- Manage your accounts in one central location: the Azure portal.
