# Automated Linking for Unlinked Accounts In Account Manager and B2C Commerce

_If you don’t want to enable the just-in-time provisioning, you can still take advantage of automatic activation and linking of new user accounts by creating the user accounts in Account Manager._

[Which Salesforce Commerce Product Do I Have?](https://help.salesforce.com/s/articleView?id=commerce.comm_what_product.htm)

When the new user initially performs SSO, their Account Manager account activates and links to their Salesforce Identity account or third-party Identity and Access Management (IAM) that uses Salesforce Identity.

You can also use this approach with existing Account Manager users. When the user performs SSO, Account Manager links their account to their Salesforce Identity account. For security purposes, existing users must authenticate with their Account Manager credentials before Account Manager links their account. If the user has an multi-factor authentication (MFA) verifier registered, they must submit the MFA verification to link the accounts.

After Account Manager links the user's Account Manager account to their Salesforce Identity account, Account Manager changes the user's username to the email address of their Salesforce Identity account.
