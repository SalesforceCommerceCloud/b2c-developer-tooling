# Creating Jobs in B2C Commerce

_Use Business Manager to create a job. We recommend that you use the new job framework to create jobs, but the legacy, deprecated functionality is also available in Business Manager._

## Related Content

- [Create a Job in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_create_job.htm&type=5)
  When you create a job, you configure at least one flow, and select which steps to execute in each flow. Use out-of-the-box system job steps that don't require any coding. If there isn't a system job step available to do what you want, have a developer create a custom job step. You can also schedule when the job executes, specify resources to lock during job execution, and configure email notifications and error handling.

- [Create a Job Parameter](https://help.salesforce.com/s/articleView?id=cc.b2c_create_global_parameter_for_jobs.htm&type=5)
  Create a parameter to use in different job steps. For example, create a parameter for ReplicationProcessID and set it to the ID of a specific replication process. Then use the parameter in different job steps. If you need to use a different replication process, change the value of the parameter, and B2C Commerce updates all steps that include the parameter. Overwrite the value of a job parameter if you use Open Commerce API (OCAPI) to execute a job.

- [Modify a Job Parameter](https://help.salesforce.com/s/articleView?id=cc.b2c_modify_global_parameter_for_jobs.htm&type=5)
  When you modify the value of a job parameter, B2C Commerce updates all steps that include the parameter to the new value.

- [Locking System Resources during Job Execution](https://help.salesforce.com/s/articleView?id=cc.b2c_system_resources_per_entity.htm&type=5)
  When you create a B2C Commerce job, prevent another job from modifying system resources while your job is executing. To know which system resources to assign to the job, know which resources are related to which entity. For example, if your job modifies customers, assign the system resource profile to your job because customers are related to the profile system resource. When your job is executing, another job can't modify the profile system resource and unexpectedly change the outcome of your job. Resource locks are re-entrant locks. In other words, if a job locks a resource, job steps in that job can lock the same resource again. The product index Rebuild task doesn't require any resource locks except itself. However, the product index update task requires resources locks on Product, Catalog and Category.

- [Using Job Steps](https://help.salesforce.com/s/articleView?id=cc.b2c_working_with_job_steps.htm&type=5)
  The B2C Commerce job framework includes some out-of-the-box system steps. When you use system steps in a job flow, no coding is required, although most job steps require that you configure some parameters. If there’s no system step that does what you want to do, have a developer create a custom job step.

- [Troubleshooting Custom Jobs for B2C Storefronts](https://help.salesforce.com/s/articleView?id=cc.b2c_troubleshooting_custom_jobs.htm&type=5)
  Use this table to resolve custom job alerts in Business Manager.
