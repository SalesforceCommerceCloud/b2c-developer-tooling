# Configure B2C Commerce Jobs

_Create B2C Commerce jobs with the new job framework. Pipeline jobs from the earlier framework remain in Business Manager._

[Which Salesforce Commerce Product Do I Have?](https://help.salesforce.com/s/articleView?id=commerce.comm_what_product.htm)

See [Legacy Jobs](https://help.salesforce.com/s/articleView?id=cc.b2c_legacy_jobs.htm&type=5).

Read [Job Flows](https://help.salesforce.com/s/articleView?id=cc.b2c_job_flows.htm&type=5) and [Where a B2C Commerce Job Flow Runs](https://help.salesforce.com/s/articleView?id=cc.b2c_scope.htm&type=5) before you create a job. Then create the job, run it, and use [job history](https://help.salesforce.com/s/articleView?id=cc.b2c_view_job_history.htm&type=5) and [job statistics](https://help.salesforce.com/s/articleView?id=cc.b2c_monitor_job_stats.htm&type=5) to see the result. Use a legacy job only when you still run a pipeline job.

When you create a job, configure at least one flow, and select which steps to execute in each flow. Use ready-made system job steps that don't require any coding. If there isn't a system job step available to do what you want, have a developer create a custom job step.

Schedule when the job executes, specify resources to lock while it runs, and configure email notifications and error handling.

Create the job and set its schedule first. See [Create and Schedule a B2C Commerce Job](https://help.salesforce.com/s/articleView?id=cc.b2c_create_job.htm&type=5). To change the job later, open it from the Jobs list. The other topics cover flows and steps, exit status rules, failure handling and notifications, resource locks, job alerts, and job parameters.

## Related Content

- [Create and Schedule a B2C Commerce Job](https://help.salesforce.com/s/articleView?id=cc.b2c_create_job.htm&type=5)
  Create a B2C Commerce job to execute various tasks, and then choose when it runs.

- [Add Flows and Steps for B2C Commerce Jobs](https://help.salesforce.com/s/articleView?id=cc.b2c_add_job_flows_and_steps.htm&type=5)
  B2C Commerce jobs run steps that execute various tasks. A flow controls the sequence in which B2C Commerce executes job steps.

- [Set Exit Status Rules for B2C Commerce Jobs](https://help.salesforce.com/s/articleView?id=cc.b2c_set_job_exit_status_rules.htm&type=5)
  A B2C Commerce job runs steps that execute various tasks. Set what job steps do when they finish running.

- [Set Failure Handling and Notifications for B2C Commerce Jobs](https://help.salesforce.com/s/articleView?id=cc.b2c_set_job_failure_handling.htm&type=5)
  A B2C Commerce job runs steps that execute various tasks. Choose what the job does when it fails, and who receives an email notification of the failure.

- [System Resource Locks for B2C Commerce Jobs](https://help.salesforce.com/s/articleView?id=cc.b2c_system_resources_per_entity.htm&type=5)
  When you create a B2C Commerce job, prevent another job from modifying system resources while your job is executing.

- [Job Alerts for B2C Commerce Custom Jobs](https://help.salesforce.com/s/articleView?id=cc.b2c_troubleshooting_custom_jobs.htm&type=5)
  Job alerts are Business Manager warnings that a custom job can slow the storefront or export orders out of sync. An alert applies to a job you create, not to one job step.

- [Create or Change a B2C Commerce Job Parameter](https://help.salesforce.com/s/articleView?id=cc.b2c_create_global_parameter_for_jobs.htm&type=5)
  A job parameter is a saved value that a B2C Commerce job reuses on more than one step.
