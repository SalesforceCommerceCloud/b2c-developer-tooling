# Creating Jobs in B2C Commerce

_Use Business Manager to create a job. We recommend that you use the new job framework to create jobs, but the legacy, deprecated functionality is also available in Business Manager._
