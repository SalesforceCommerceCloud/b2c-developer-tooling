# Instances

_A B2C Commerce instance contains the tools and resources for customizing storefronts. Access an instance through your browser, or use Business Manager._

### Instance Types

There are four instance types: Sandbox, Staging, Development, and Production. Depending on the type, the instance is either in the realm's primary instance group (PIG) or a secondary instance group (SIG).

| ‌ | Sandboxes | Staging | Development | Production |
| --- | --- | --- | --- | --- |
| Usage | Used by customer developers to create and update storefront code. Sandboxes without login activity for 150 days might be deleted. We notify you before scheduling deletion of a sandbox and its data. | Merchandising work is done here. | Simulates the production environment. Used as the final step in testing the intersection of content and code. Goes through the CDN provided by B2C Commerce, but doesn't cache. | Live instance used for storefront transactions. Connected to the CDN provided by B2C Commerce. If active merchandising is enabled, collects active data. Storefront toolkit is disabled. |
| Location | SIG | PIG | PIG | PIG |
| Data I/O | Most system jobs are disabled for sandboxes. | Upload data and code to Staging, and B2C Commerce replicates them to Production or Development. | B2C Commerce replicates data and code from Staging. Export data from the instance as needed. | B2C Commerce replicates data and code from Staging. B2C Commerce gathers active data from Production and imports it into other instance types. Export data from the instance and import it into Staging. |
| Global Release | Updated for:   Preview General Availability | Updated for:   General Availability | Updated for:   General Availability | Updated for:   General Availability |
| Caching | Caching is disabled. Full file system checks are performed. | Not connected to the CDN provided by B2C Commerce. Caching is disabled. Full file system checks are performed. | Caching is disabled. No file system checks are performed. | Caching is enabled all the way through to the browser. |

### Who Uses Which Instance Type?

Depending on the size of your team, one person can play more than one role.

| Role | Instance Type | Responsibilities |
| --- | --- | --- |
| Developer | Sandbox, Staging | A developer creates or modifies templates, pipelines, and scripts on a local machine and uploads them to a Sandbox instance to test. Ultimately, the developer is responsible for uploading code to the Staging instance. The developer can also export data added by merchandisers on the Staging instance to use as test data for the sandboxes.Developers never use the Development instance unless they’re involved in the testing process for the production site. |
| Merchandiser | Staging | A merchandiser or online marketer is typically responsible for creating campaigns and promotions, managing product information, and configuring search behavior. |
| Administrator | All instances | An admin is responsible for granting access to instances and functionality on instances. The admin restarts instances, manages data feeds, and uploads certificates. |
| Quality Assurance Engineer | Development | This role is responsible for testing the site in conditions as close to production as possible. No code development is done on the Development instance. |
