# eCDN WAFv2 Managed Ruleset

_The eCDN WAFv2 managed ruleset is the current-generation rule set the eCDN security team maintains for broad web application protection across your B2C Commerce applications. Enabled by default, it's updated frequently to cover new vulnerabilities and reduce false positives._

> **Note:** eCDN WAF managed rules aren't available on SCAPI zones. See [SCAPI Zone Support for B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_scapi_zone.htm&type=5).

This rule set is enabled by default

- Select the action to perform. The default option is recommended. When you define an action for the ruleset, you override the default action defined for each rule. To remove the action override, set the ruleset action to Default. The available actions are:
   
   - Default
   - Managed challenge
   - Block
   - JS challenge
   - Log
   - Legacy captcha

_(image: Embedded CDN Settings)_

_(image: WAFv2 Managed Ruleset Settings)_
