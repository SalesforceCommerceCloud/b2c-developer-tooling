# eCDN WAFv2 Managed Ruleset

_Created by the eCDN security team, this ruleset provides fast and effective protection for all of your applications. The eCDN security team updates the ruleset frequently to cover new vulnerabilities and reduce false positives._

This rule set is enabled by default

- Select the action to perform. The default option is recommended. When you define an action for the ruleset, you override the default action defined for each rule. The available actions are:
   
   - Default
   - Managed challenge
   - Block
   - JS challenge
   - Log
   - Legacy captcha

_(image: Embedded CDN Settings)_

_(image: WAFv2 Managed Ruleset Settings)_
