# Product Feed Field Reference for Google

_Reference information for the product feed fields used with Google, including required fields, optional fields, and their default mappings to B2C Commerce attributes._

### How Default Mappings Work

The product feed for Google uses a data-driven mapping system to transform B2C Commerce product data into the format required by Google. When B2C Commerce can derive a value using standard B2C Commerce attributes, it creates a default mapping that specifies how the value is derived:

- **Field mappings**: Map directly to a single B2C Commerce product attribute, such as **name**, **brand**, or **price**.
- **Derived mappings**: Calculate values from multiple attributes or apply transformations, such as stripping HTML from descriptions or formatting prices with currency codes.
- **Constant mappings**: Use a fixed value for all products.
- **Fallback mappings**: Map to the primary attribute first, then fall back to an alternative if the primary attribute is empty for that product. For example, **title** uses **name**, falling back to **masterProductName** if **name** is blank.

You can customize fields marked as **Overridable: Yes** in Business Manager. Fields marked as **Overridable: No** are system-managed and visible in the Field Mapping table, but you can't change their mappings.

### Automatic Field Formatting

B2C Commerce applies automatic formatting to field values before they are written to the feed. This formatting happens regardless of whether you keep the default mapping or override it with a different attribute. When you override a default mapping, you don't need to adapt your catalog data to match Google's format—B2C Commerce handles the transformation.

Formatting applies as follows:

- **Dates**: Date and datetime values are formatted to ISO 8601. Invalid dates are omitted from the feed.
- **Booleans**: Values are converted to `true` or `false`.
- **Numbers**: Numeric values are formatted to the required precision (for example, integers with no decimals, or two decimal places for prices). Invalid or null values are omitted.
- **Prices**: Positive values are formatted to two decimal places and concatenated with the currency code.
- **Descriptions**: HTML tags are stripped from text.
- **Enums**: Values such as **availability** and **age_group** are validated against predefined allowed values.

### Custom Attribute Inheritance for Variants

When you map a custom attribute to a Google field, B2C Commerce automatically resolves attribute values for variant products using the following inheritance chain:

1. **Variant product**: B2C Commerce first checks the variant product for the attribute value.
2. **Variation group**: If the variant doesn't have the attribute value, B2C Commerce checks the variation group (if applicable).
3. **Master product**: If the variation group doesn't have the value, B2C Commerce checks the master product.

This inheritance chain ensures that custom attributes defined at the master or variation group level are automatically inherited by variants without requiring duplicate data entry.

### Product Eligibility

Two layers control which products appear in the feed:

- **Product filter rules**: Configurable include and exclude rules that determine which products are sent to Google. By default, the rules match products that are online and searchable, but you can adjust them. See [../product_feeds/b2c_product_feed_product_filter.xml](https://help.salesforce.com/s/articleView?id=cc.b2c_product_feed_product_filter.htm&type=5).
- **Automatic exclusions**: Regardless of your filter rules, B2C Commerce always excludes the following from the feed:
   
   - Master products (variants are exported instead)
   - Variation groups (variants are exported instead)
   - Product sets. Bundles, which have fixed components, are supported and are sent to Google as standalone products.

After a product is included in the feed, you can further control where it appears in Google by mapping the **included_destination**, **excluded_destination**, and **pause** fields. For example, use **excluded_destination** to keep a product out of Shopping ads while still submitting it to free listings. See the Optional Fields table.

### List Price Derivation

The **price** field maps to the regular (list) price of a product. B2C Commerce doesn't have a built-in "list price" concept; storefront teams implement list pricing using different price book strategies. To accommodate this variety, B2C Commerce derives the list price for the feed in two steps:

1. **Selected list price book**. If you select a price book in **List Price Book** on the General Settings tab, B2C Commerce uses the price from that price book. The dropdown contains only price books that are active and contain prices in the feed currency. If you later deactivate the selected price book, reconfigure **List Price Book** to point at a different price book.
2. **Sale price book pathway**. If you don't select a list price book, B2C Commerce derives the list price from the sale price book that the B2C Commerce price engine selects for the product. The price engine evaluates all applicable price books for the product, not only active ones, and returns the best (lowest) price along with its source price book. From that sale price book, B2C Commerce applies one of two rules:
   
   - If the sale price book has a parent price book, B2C Commerce walks the parent chain to the root and returns the price from the root price book. This matches the default behavior of SFRA and SiteGenesis storefronts.
   - If the sale price book has no parent, B2C Commerce returns the maximum price across all applicable price books for the product. This matches the default behavior of PWA Kit storefronts.

> **Note:** If the resolved list price equals the sale price, B2C Commerce populates only the **price** field and omits **sale_price** from that product's feed entry. This avoids showing a strike-through price in Google for products that aren't on sale.

Setting **List Price Book** on the General Settings tab is the most reliable way to ensure the list price in your feed matches what shoppers see on your storefront, particularly for storefronts with custom pricing logic, zone-based pricing, or multi-currency price books.

### Sale Price Derivation

The **sale_price** field maps to the B2C Commerce **salePrice** attribute plus the configured **currency**. The **salePrice** value isn't taken from a single price book—the B2C Commerce price engine selects the best (lowest) price among all applicable price books for the product, regardless of price book hierarchy or whether a hierarchy is configured.

Because the same engine populates the price your storefront displays, the **sale_price** value sent to Google matches what shoppers see on your site.

If the resolved sale price equals the resolved list price (the **price** field), B2C Commerce omits **sale_price** from that product's feed entry. This avoids showing a strike-through price in Google for products that aren't on sale. See [#b2c_google_feed_default_mappings/list_price_derivation](#b2c_google_feed_default_mappings/list_price_derivation).

If your storefront uses custom pricing logic—such as zone-based or geo-based price book selection—the default sale price calculation may not match what shoppers see. Setting **List Price Book** on the General Settings tab is the most reliable way to align the feed with your storefront in these cases.

### Required Fields

The following fields are required for a valid product feed entry. Products that are missing required fields are still included in the feed, but Google may reject those individual rows. Use the Product Feed Preview to identify products with missing required fields and fix them before you turn on the daily feed sync. See [../product_feeds/b2c_product_feed_preview.xml](https://help.salesforce.com/s/articleView?id=cc.b2c_product_feed_preview.htm&type=5).

> **Warning:** If more than 30% of your products are missing required fields, Google may reject the entire feed. Ensure your catalog data is complete before you turn on the daily feed sync.

| Google Field | Type | Default SFCC Mapping | Description | Overridable |
| --- | --- | --- | --- | --- |
| **id** | string | **id** (Product ID) | Unique product identifier (SKU). Managed by B2C Commerce. Keep stable across feed updates. | No |
| **title** | string | **name**, falls back to **masterProductName** if blank | Product title. Avoid promotional text. | Yes |
| **description** | string | **longDescription**, falls back to **shortDescription** (HTML stripped) if blank | Full product description. HTML tags are automatically removed. | Yes |
| **link** | string | **productUrl** (generated) | Product detail page URL. Generated using the host name from the Einstein configuration. For PWA Kit and headless storefronts, configure URL patterns separately. See [../product_feeds/b2c_product_feed_pwa_urls.xml](https://help.salesforce.com/s/articleView?id=cc.b2c_product_feed_pwa_urls.htm&type=5). | Yes |
| **image_link** | string | Selected Image View Type, or default view-type lookup | Main product image URL. If you select a view type in **Image View Type** on the General Settings tab, B2C Commerce uses that view type. Otherwise, B2C Commerce attempts the "large" view type and falls back to the first available view type. Because the fallback can select an unsuitable view type (such as a swatch view), Salesforce recommends selecting a specific view type. Use high-resolution images without promotional overlays. | Yes |
| **availability** | string | **availability** (derived) | Stock status. Values derived by mapping B2C Commerce inventory levels to Google availability values: `in_stock`, `out_of_stock`, `preorder`, `backorder`. Managed by the system. | No |
| **price** | number | Combines **price** and **currency** (Selected List Price Book, or sale-price-book pathway) | Regular (list) product price with currency code, such as "15.00 USD". If you select a price book in **List Price Book** on the General Settings tab, B2C Commerce uses that price book. Otherwise, B2C Commerce derives the list price from the sale price book selected by the B2C Commerce price engine. See [#b2c_google_feed_default_mappings/list_price_derivation](#b2c_google_feed_default_mappings/list_price_derivation). Only positive values are included. | Yes |

### Optional Fields

The following fields are optional and can enhance your product listings in Google. Optional fields are omitted from the feed when the mapped attribute or constant value is blank. Fields with a default mapping derive their value automatically; fields without a default mapping (shown as "(none)") are populated only when you map an attribute or set a constant value or pattern.

| Google Field | Type | Default SFCC Mapping | Description | Overridable |
| --- | --- | --- | --- | --- |
| **sale_price** | number | Combines **salePrice** and **currency** if a sale price is active | Discounted price with currency code, such as "10.00 USD". B2C Commerce omits this field when the resolved sale price equals the resolved **price**. See [#b2c_google_feed_default_mappings/sale_price_derivation](#b2c_google_feed_default_mappings/sale_price_derivation). | Yes |
| **sale_price_effective_date** | date | Combines **salePriceStart** and **salePriceEnd** | Sale price date range in ISO 8601 format, such as "2016-02-24T11:07+0100/2016-02-29T23:07+0100". | Yes |
| **availability_date** | date | **inStockDate** | Date a preorder product becomes available, such as "2016-02-24T11:07+0100". | Yes |
| **expiration_date** | date | **onlineTo** | Date the product should stop appearing in feeds, such as "2016-07-11T11:07+0100". | Yes |
| **brand** | string | **brand** | Brand name. | Yes |
| **gtin** | string | **ean**, falls back to **upc** if EAN isn't available | Global Trade Item Number (UPC/EAN). Improves product matching. | Yes |
| **mpn** | string | **mpn** | Manufacturer part number. | Yes |
| **identifier_exists** | boolean | Computed from whether the product has standard identifiers (EAN, UPC, MPN, or brand) | Indicates whether the product has standard identifiers. | Yes |
| **is_bundle** | boolean | Evaluates to `true` when **bundleProductIds** is populated | Indicates whether the product is a bundle. Managed by B2C Commerce. | No |
| **item_group_id** | string | **masterProductId** | Groups product variants that share the same master product, such as "AB12345". | Yes |
| **product_type** | string | **categoryPath** (full path) | Merchant-defined product category, such as "Home > Women > Dresses > Maxi Dresses". | Yes |
| **google_product_category** | string | (none) | Google-defined product category, such as "Apparel & Accessories > Clothing > Outerwear > Coats & Jackets". | Yes |
| **additional_image_link** | string | **additionalImageLink** | Additional image URLs for richer presentation. | Yes |
| **lifestyle_image_link** | string | (none) | Lifestyle image URL. | Yes |
| **mobile_link** | string | (none) | Mobile-optimized landing page URL. | Yes |
| **virtual_model_link** | string | (none) | Virtual model (3D) asset URL. | Yes |
| **ads_redirect** | string | (none) | URL used to redirect ads traffic, such as one that includes tracking parameters. | Yes |
| **color** | string | (none) | Product color. | Yes |
| **material** | string | (none) | Primary product materials, such as "leather". | Yes |
| **pattern** | string | (none) | Product pattern, such as "polka dot". | Yes |
| **size** | string | (none) | Product size, such as "XL". | Yes |
| **size_system** | string | (none) | Size system, such as "US". | Yes |
| **size_type** | string | (none) | Size type, such as "regular". | Yes |
| **gender** | string | (none) | Intended gender audience, such as "male", "female", or "unisex". | Yes |
| **age_group** | string | (none) | Target age group. Values: `newborn`, `infant`, `toddler`, `kids`, `adult`. | Yes |
| **adult** | boolean | (none) | Indicates whether the product is adult-oriented. | Yes |
| **condition** | string | (none) | Product condition, such as "new", "used", or "refurbished". | Yes |
| **multipack** | number | (none) | Number of identical products in a merchant-defined multipack. | Yes |
| **product_highlight** | string | (none) | A key product highlight, such as "Supports thousands of apps". | Yes |
| **short_title** | string | (none) | A short title used in constrained placements, such as "Polo Shirt". | Yes |
| **structured_title** | string | (none) | Structured title, including the title's origin, for AI-generated content. | Yes |
| **structured_description** | string | (none) | Structured description, including the description's origin, for AI-generated content. | Yes |
| **custom_label_0**–**custom_label_4** | string | (none) | Custom labels used to segment products for reporting and bidding, such as "Seasonal", "Clearance", or "BestSeller". | Yes |
| **product_length**, **product_width**, **product_height** | number | (none) | Product dimensions with unit, such as "20 in". | Yes |
| **product_weight** | number | (none) | Product weight with unit, such as "3.5 lb". | Yes |
| **unit_pricing_measure** | string | Combines **unitQuantity** and **unitMeasure** | Measure and dimension of the product as sold, such as "1.5kg". | Yes |
| **unit_pricing_base_measure** | string | (none) | The product's base measure for pricing, such as "100g". | Yes |
| **energy_efficiency_class** | string | (none) | Energy efficiency class, such as "A+". | Yes |
| **min_energy_efficiency_class** | string | (none) | Lowest energy efficiency class on the product's label, such as "A+++". | Yes |
| **max_energy_efficiency_class** | string | (none) | Highest energy efficiency class on the product's label, such as "D". | Yes |
| **certification** | string | (none) | Product certification, such as "EC:EPREL:123456". | Yes |
| **consumer_notice** | string | (none) | A consumer notice, such as a Proposition 65 warning. | Yes |
| **cost_of_goods_sold** | number | (none) | Cost of goods sold with currency code, such as "8.00 USD". | Yes |
| **auto_pricing_min_price** | number | (none) | Minimum price for automated discounts, such as "15.00 USD". | Yes |
| **maximum_retail_price** | number | (none) | Maximum retail price (used in some regions, such as India), such as "15.00 INR". | Yes |
| **installment** | string | (none) | Installment payment details, such as "6:30 EUR:199 EUR". | Yes |
| **subscription_cost** | string | (none) | Subscription cost details, such as "month:12:35.00USD". | Yes |
| **loyalty_program** | string | (none) | Loyalty program benefits, such as "my_loyalty_program:silver:10 USD::10::free_member_shipping". | Yes |
| **promotion_id** | string | (none) | Promotion identifier, such as "ABC123". | Yes |
| **shipping** | string | (none) | Shipping cost details, such as "US:CA:Overnight:16.00 USD". | Yes |
| **free_shipping_threshold** | string | (none) | Minimum order value for free shipping, such as "US:16.00 USD". | Yes |
| **carrier_shipping** | string | (none) | Carrier-calculated shipping, such as "US:80302:USPS_MEDIA_MAIL:1:3:2:5". | Yes |
| **shipping_label** | string | (none) | Label used to assign shipping rules, such as "perishable". | Yes |
| **shipping_length**, **shipping_width**, **shipping_height** | number | (none) | Package dimensions used to calculate shipping, such as "22 in". | Yes |
| **shipping_weight** | number | (none) | Package weight used to calculate shipping, such as "3 kg". | Yes |
| **min_handling_time** | number | (none) | Minimum product handling time, such as "1". | Yes |
| **max_handling_time** | number | (none) | Maximum product handling time, such as "3". | Yes |
| **shipping_handling_business_days** | string | (none) | Business days when orders are handled, such as "US:Mon-Sat". | Yes |
| **shipping_transit_business_days** | string | (none) | Business days when orders are in transit, such as "US:Mon-Sat". | Yes |
| **ships_from_country** | string | (none) | Country the product ships from. Uses 2-letter ISO 3166 country code, such as "US". | Yes |
| **return_policy_label** | string | (none) | Label used to assign a return policy, such as "90 days". | Yes |
| **included_destination** | string | (none) | Destinations where the product should be included, such as "Shopping_ads". | Yes |
| **excluded_destination** | string | (none) | Destinations where the product should be excluded, such as "Shopping_ads". | Yes |
| **shopping_ads_excluded_country** | string | (none) | Countries excluded from Shopping ads, such as "DE". | Yes |
| **pause** | string | (none) | Pauses the item in a destination, such as "ads". | Yes |
| **native_commerce** | boolean | (none) | Indicates whether the product is eligible for native commerce—purchasing experiences that take place directly within Google's surfaces rather than on your storefront. Set this boolean per product to control eligibility. This field has no default mapping, so products aren't flagged as eligible unless you map it. | Yes |
| **external_seller_id** | string | (none) | Seller identifier for multi-seller accounts, such as "SellerPublicName1991". | Yes |
| **merchant_item_id** | string | (none) | Merchant-provided checkout item identifier, such as "some_checkout_item_id_1". | Yes |

### Additional Optional Fields (Product Detail)

Use the **Additional Optional Fields** section of the Field Mapping table to send technical specifications or other attributes to Google's **product_detail** field. For each entry, map a B2C Commerce attribute and, optionally, provide a section name to group related details. Click **Add Attribute** to add another product detail.

The **product_detail** field gives shoppers readable, structured information about aspects of a product that other fields don't cover, and it helps Google surface your products across search and AI-driven experiences. For the full list of accepted attributes and formatting requirements, see [Product detail [product_detail]](https://support.google.com/merchants/answer/9218260) in Google Merchant Center Help.
