# Secret Storage in B2C Commerce

_Storing and using secrets is one of the most sensitive actions taken by a developer to ensure the security of shopper information. A secret can be, and is not limited to, the following items._

- Credentials used to authenticate to remote services, such as username and password, API tokens, access tokens, and session IDs.
- Secret keys used to encrypt or decrypt sensitive data, such as private or symmetric keys.

Help prevent data exposure in a number of ways. First, make sure that sensitive data in forms isn’t logged or otherwise stored unless it’s absolutely necessary. Data that isn’t retained can’t be stolen. If you must store sensitive data, discard it as soon as possible and make sure that it’s encrypted. For credit card data, make sure that you use PCI Data Security Standard (DSS) compliant tokenization or truncation.

Use the following APIs to store secrets securely on Salesforce B2C Commerce.

- Service credentials
- Private keys
- Custom object attributes

### Service Credentials

For each web service, the framework requires a service configuration, service profile configuration, and service credential configuration. Create and manage these configurations in Business Manager.

Service credentials are accessible in B2C Commerce API as the `dw.svc.ServiceCredential` object. They are read-only. Never return them to a storefront request or write them into any logs.

### Private Keys

Cryptographic keys and certificates are pivotal resources for encryption and decryption, authentication, signatures, and more. To manage these keys and certificates, use the dedicated Business Manager wizard. They are accessible in the script API using the `CertificateRef` and `KeyRef` classes.

### Custom Object Attribute

To extend the B2C Commerce object model, use custom objects. Customize attributes, their respective fields, and properties of the custom object type.

Use type `PASSWORD` with any custom object attribute that handles secret information.
