# Examine Server Calls Using the Request Log in B2C Commerce

_The Request Log shows log entries related to the most recent server call and any server calls made while the tool is open. You can also view log entries for AJAX calls or other script calls. The Request Log tool shows exception information from the server and the custom logging in real time. If you use this tool to debug a script, use custom logging in your script as long as you configure the custom log settings in Business Manager._

To use the request log, you must access the storefront and Business Manager using the same host name. If using separate hostnames, assess your logs with [Log Center](https://help.salesforce.com/s/articleView?id=cc.b2c_log_center.htm&type=5).

1. Select the site to view and click **Toolkit.**

   A new tab opens showing the storefront, with the Storefront Toolkit icons in the upper right corner.
2. Click the Request Log icon. _(image: Request Log icon)_

   The Request Log opens.
3. Click the storefront element that runs the script or issues the request that you want to debug.

   All requests appear in the Request Log.
