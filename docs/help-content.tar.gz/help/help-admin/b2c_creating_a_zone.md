# Create an eCDN Zone

_The embedded CDN (eCDN) configuration is organized around zones. A zone represents a root or apex domain (for example, `example.com`). A hostname is a subdomain of a specific zone (for example, `www.example.com`). Create a zone in Business Manager to route your B2C Commerce storefront traffic through the eCDN._

[Which Salesforce Commerce Product Do I Have?](https://help.salesforce.com/s/articleView?id=commerce.comm_what_product.htm)

**How zones are derived.** Salesforce B2C Commerce examines the hostname alias files for all your development, staging, and production instances across all your realms. B2C Commerce then aggregates this information and derives the names of zones from the hostname entries in your alias files. For example, if the hostname alias file for your Production instance contains an entry for *www.example.com*, B2C Commerce creates the zone *example.com*.

> **Note:** Embedded CDN settings are specific to each instance (development, staging, and production). You manage the embedded CDN settings individually for each instance.

> **Note:** You don't create SCAPI zones. Salesforce auto-provisions one SCAPI zone for your realm. It appears in the zone list on the Production instance only. It doesn't appear in Business Manager or the CDN API on Development or Staging. See [SCAPI Zone Support for B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_scapi_zone.htm&type=5).

**Before you begin:**

- Register your domain name with your DNS provider before you create a zone. For example, register *www.example.com* before creating the zone *example.com*.
- eCDN settings are per-instance. Manage dev, staging, and production instances independently. Create and verify zones for each instance type separately.
- After you create a zone, you can't delete it in the user interface. To remove a zone, contact Salesforce Support.
- It can take up to 24 hours for B2C Commerce to create and verify a proxy zone.
- Your ODS realm must be eCDN-enabled before zone creation succeeds. If you see `CDN-API default-domain/hostnames call failed` in the Storefront Fast Setup job, your realm hasn't been provisioned yet. Contact Salesforce Support.

1. In Business Manager, click App Launcher _(image: App Launcher)_, and then select **Administration > Sites > Embedded CDN Settings**.
2. Click **Add Hostname**.

   The Embedded CDN Settings page shows your Default Zone and any existing hostnames.
3. For each hostname in the list that you want to add, click **Create Zone**.
4. On the confirmation dialog, click **Create Zone**.

   B2C Commerce automatically adds hostnames after you create and configure the zone and set the zone status to verified.
   
   _(image: Embedded CDN Settings Page)_
5. If you're creating a new zone, refresh the status of the individual zone with the **Refresh Status** link while zone creation is in progress. To check the status of hostname validation, click **Verify Configuration**.

   Verification can take up to 24 hours.
6. After the zone is verified and the certificate is active, map DNS so that your custom hostname points directly to the eCDN zone hostname.

   See [Map DNS to an eCDN Zone](https://help.salesforce.com/s/articleView?id=cc.b2c_map_dns_to_ecdn_zone.htm&type=5).

The zone is created and verified, and its hostnames are served through the eCDN. Next, add an SSL certificate and configure the zone's settings.

Watch a demo: [Create a Proxy Zone and Add a Hostname](https://salesforce.vidyard.com/watch/ms8AHPfGH2La24mjoKa38Y).

**Next steps**

- To create zones with the CDN Zones API instead, see [CDN Zones](https://developer.salesforce.com/docs/commerce/commerce-api/guide/cdn-zones.html#storefront-zone-creation) in the developer documentation.
- Add an SSL certificate to the zone. See [Manage SSL Certificates for eCDN Zones](https://help.salesforce.com/s/articleView?id=cc.b2c_manage_ssl_certificates_for_ecdn_zones.htm&type=5).
- Manage security rules, web application firewall (WAF), analytics, host header override rules, and Page Shield policies for the zone. Click **Configure Zones** and select the zone from the dropdown.

> **Important:** Unlike standard production instances, On-Demand Sandboxes (ODS) zones — including dev and production ODS — don't have a default Block All firewall rule. Salesforce recommends adding at least one custom rule after zone creation. As a starting point, add a rule to block AI crawlers to prevent unwanted automated traffic on your sandbox.

_(image: Configure Zones Security Rules page for an ODS zone showing empty Custom Firewall Rules and Rate Limiting Rules sections.)_

_(image: New Custom Firewall Rule form for an ODS zone showing a Block All expression targeting AI crawler user agents.)_

_(image: Configure Zones Security Rules page for an ODS zone showing one active custom firewall rule named Block AI crawlers.)_
