# Content Slot Object Import/Export in B2C Commerce

_Using Business Manager, import existing content slot configurations to use with a new instance, and export them for transfer between instances. The slots themselves aren’t imported or exported, but page templates define them (in UX Studio). Slot configurations only reference those slots (using the slot ID). Within Business Manager, the elements in the slot.xsd control the visibility of a slot. This topic applies to B2C Commerce._

A slot configuration can belong to zero or one site. A slot configuration that doesn't belong to a site is like a reusable part for the site to use. You can assign a slot configuration to no campaigns or promotions or to one campaign or promotion. The schedule, rank, and qualifier elements are part of the assignments.

| Elements or attributes | Impact |
| --- | --- |
| <slot-configuration> | When importing a <slot-configuration> element in MERGE mode, the system checks to see if there’s an existing slot configuration with the same ID in the current site domain. If so, the import process updates the existing one; if not, the import process creates one. |
| <rank>, <schedule> or <customer-groups> | If the import file includes any of the deprecated elements <rank>, <schedule>, or <customer-groups>, the system can only update them if there’s an explicit SlotConfigurationAssignment between the slot configuration and the site. If one exists, the import process updates those attributes of the assignment;. If none exists, the import logic logs a warning. |
| <slot-configuration-assignment> | When importing a <slot-configuration-assignment> element in MERGE mode, the system checks to see if there’s an existing assignment. The system checks between the specified slot configuration (identified by a compound key consisting of slot-id, context, context-id, and configuration-id) and the current site (derived from the import/export context, not specified in the file). If an assignment exists, it's updated; otherwise, the system creates one. |
| <slot-configuration-campaign-assignment> | When importing a <slot-configuration-campaign-assignment> element in MERGE mode, the system checks to see if there’s an existing assignment between the specified slot configuration and the campaign (specified by campaign-id). If an assignment exists, it's updated; otherwise one is created. If you perform the import in a different import mode, the usual modified semantics apply. |
| <mode> | There’s a new *mode* attribute in the existing <slot-configuration> element. This mode attribute is used for deleting individual objects without doing a full DELETE mode import. The <slot-configuration> element offers special *wildcard* behavior for deletion. You can omit the *context,* *context-id*, and *configuration-id* in delete mode. Use this technique to delete multiple slot configurations simultaneously. |
| <slot-configuration-assignment> and <slot-configuration-campaign-assignment> | The new elements <slot-configuration-assignment> and <slot-configuration-campaign-assignment> support a delete mode, but not a *wildcard* deletion, such as described previously. With this method, Only delete one assignment at a time. As a result, the attributes *context,* *context-id,* and *configuration-id* are required for these elements. |

> **Note:** Parent slots for deleted configurations aren’t deleted as part of this process, even if the import results in 0 slot configurations.

### Business Manager Import Location

** Online Marketing > Import & Export**

### Pipelets

- ImportSlots
- ExportSlots

## Import Content Slot Configurations

_Import slot configurations. This topic applies to B2C Commerce._

|  |
| --- |
| Available in: **B2C Commerce** |

1. Click App Launcher _(image: App Launcher)_, and then select ** *site*  >  Merchant Tools  > Online Marketing  >  Import & Export**.
2. In the Content Slot section, click **Import**.
3. Select an import file from the list and click **Next>>**.
4. B2C Commerce validates the schema file.

   - If the schema file validation is unsuccessful, examine the file for errors and start over.
   - If the validation is successful, click **Next>>**.
5. Select an import mode:

   | Option | Description |
   | --- | --- |
   | Merge | Updates existing database objects and creates objects based on XML import file. |
   | Update | Updates existing database objects only (doesn't create ones). |
   | Replace | Deletes and then recreates existing database objects; creates objects based on XML import file. |
   | Delete | Deletes slot configurations referenced in the file; parent slots aren’t deleted. |
6. Click **Import**.

   The Import & Export page reappears, where you can monitor the status of the import job.

### Content Slot Import Modes in B2C Commerce

_Import and export content slot configurations. This topic applies to B2C Commerce._

- Export: enter a valid file name (no special characters). If the file name doesn't end in ".xml", the system appends the extension.
- Import: select an import file from the list. The system performs a validation. After validation, the user can select an import mode: DELETE, UPDATE, MERGE and REPLACE.
   
   The following table describes the import behavior:

| Mode | Element/situation | Behavior |
| --- | --- | --- |
| DELETE | Slot configurations | If referenced in the file, the system deletes it from the database. |
|  | If you specify only a slot-id | All slot configurations for the slot with that id are deleted. |
|  | If you specify a slot-id and context | All slot configurations for the slot in that context are deleted. |
|  | If you specify slot-id, context, and context-id | The system deletes all slot configurations for the slot in that context, with that context-id. |
|  | If a slot-id, context, context-id, and configuration-id are all specified | The system deletes the one slot configuration for the slot in that context, with that name, if it exists. |
|  | If a context, context-id, or configuration-id specified, but not the slot-id | The system ignores the missing element with a warning. |
| UPDATE | Standard UPDATE mode | The system updates existing slot configurations referenced in the file. |
|  | If the slot-id, context, context-id, and configuration-id match a slot configuration | Only the specified elements result in updated properties of that configuration. |
|  | If the slot-id, context, context-id and configuration-id don't match a slot configuration | The system ignores the element with a warning. |
|  | If you specify multiple slot configurations as the default. | The last slot configuration is set to the default and a warning appears in the log. |
| MERGE | Standard MERGE mode | The system updates existing slot configurations referenced in the file and inserts any new slot configurations in the file. The defaults for optional MERGE properties are:  enabled-flag - false default - false schedule - continuously |
|  | For the update case | The same behavior as for the UPDATE mode. Required properties are: slot-id, context, context-id, configuration-id and the template. |
|  | For the insert case | Provide all required properties, or the system ignores the slot configuration with a warning. |
|  | If you specify multiple default configurations | The last slot configuration is set to the default and a warning appears in the log. |
| REPLACE | Standard REPLACE mode | The same as for MERGE mode, except that the update of existing slot configurations is as if they were first imported in DELETE mode. This means that the system deletes the existing slot configuration and inserts a new one with the provided data. The system reuses the location where the slot configuration was stored. |
|  | If optional element properties elements are not specified. | The defaults take effect, even if the default values are different than the values in the slot configuration being replaced. |
|  | If you specify multiple default configurations | The last slot configuration is set to the default and a warning appears in the log. |

> **Note:** Exactly one configuration can be set as the default for each combination of slot-id, context and context-id.

> **Note:** It's possible in MERGE mode to import slot configurations that reference a slot that doesn't exist. This can occur when an import occurs before the storefront templates have been changed to contain the correct <isslot> tags. In this case, the system creates a slot that contains the referenced slot-id, context and context-id, if appropriate. No problem results because no template actually references the slot.

### Troubleshooting Slot Import in B2C Commerce

_If you experience unexpected behavior during an import, check the file against this information. This topic applies to B2C Commerce._

- Did you run an import on slot configurations with references to slots that aren’t in the template? You can get a data warning, but the slot configurations are still imported as place holders.
- Did you have slot configurations with references to slots in the template, but the slots are later removed from the templates? Those slot configurations don't appear in the Business Manager.

When running an import in Delete mode:

- If only slot ID and content type are specified in the file, all slot configurations for the slot in that context are deleted.
- If slot ID, context type and context ID are specified, all slot configurations for the slot in that context with that context ID are deleted.
- If a slot ID, context type, context ID, and configuration ID are all specified, the one slot configuration that is uniquely identified by all settings is deleted.
- If the slot ID is left out, the element is ignored and a warning is issued.

When running an import in Update mode:

- Any existing slot configurations referenced in the file are updated.
- If the slot ID, context type, context ID, and configuration ID don't match a slot configuration, the element is ignored and a warning is issued. If they do match a slot configuration, then only the elements specified result in updated properties of that configuration.
- If multiple slot configurations are specified as the default, the last one is set to as default and a warning appears in the log. Exactly one configuration can be set as default for each combination of slot ID, context type, and context ID.

When running an import in Merge mode:

- Provide all required properties, or the slot configuration is ignored and a warning is issued. Defaults for optional properties are:

| Element | Default |
| --- | --- |
| enabled | false |
| default | false |
| schedule | Continuously |

- If multiple default configurations are specified, the last one is honored and a warning appears in the logs.

When running an import in Replace mode:

- The existing slot configuration is deleted and the new one inserted with the provided data, and the new one reuses the storage location of the old one.
- If elements aren’t specified, the defaults for optional properties take effect. They take effect even if the default values are different than the values in the slot configuration being replaced.

## Export Content Slot Configurations

_Export content slot configurations. This topic applies to B2C Commerce._

|  |
| --- |
| Available in: **B2C Commerce** |

1. Click App Launcher _(image: App Launcher)_, and then select ** *site*  >  Merchant Tools  >  Online Marketing  >  Import & Export**.
2. In the Content slot section, click **Export**.
3. Enter a name for the export file. If you don't enter the .xml suffix, it’s appended automatically.
4. Click **Finish** to submit the job.

   The Online Marketing > Import & Export page reappears. The job's status appears in the Status section of the page.
5. To view the job's log file, click the **Process** link in the `Status` section.
6. On the page that opens, click the **Download Export File** link in the `Export File` section to download the export file to your local machine.
