# Set Search Preferences

_The search preferences you configure control the behavior of the search feature for your instance. These preferences can be exported. This topic applies to B2C Commerce._

|  |
| --- |
| Available in: **B2C Commerce** |

1. In Business Manager, click App Launcher _(image: App Launcher)_, and then select **Merchant Tools >  *site*  > Search > Search Preferences**.
2. On the Search Preferences page, select your instance type: Sandbox/Development, Staging, or Production.
3. In the Availability Settings section:

   1. Select **Show Orderable Products Only** if you want to hide any products that aren’t available.
   
      You can also set **Show Orderable Products Only** at the Product Level.
   2. To indicate the percentage of availability from which products are to be ranked lower, enter a value in the Availability Low Ranking Threshold field. If products are ranked lower, they’re pushed to the end of the search results. (For example, 0.3 indicates that all products with availability of 0.3 and below are pushed to the end of the search result.)
   
      Ranking is done at query time instead of index building time. Therefore, a change to a rule or threshold takes effect immediately. The results aren’t sorted by availability; products are shifted via sorting criteria. You can control the priority of Availability Ranking and any other sorting criteria in the storefront. To control the priority, use the Sorting Configuration to change the predefined order of possible sorting conditions
4. In the Search Settings section:

   1. To make regional linguistic search rules available for a language locale, select **Dictionary Locale Fallback**. Linguistic search rules are composed of stop words, category names exclusions, synonyms, hypernyms, compound words, common phrases, search suggestions, and stemming exceptions. When you select this setting, the system applies the rules to the related region locales (en_US). It also applies the linguistic rules defined for the region locale itself.
   
      > **Note:** Locale fallback in the Search Dictionaries module only works from country locale to language locale, such as en_GB to en. Fall back from language to default locale is *not* available for Search Dictionaries.
      
      Each page of an affected search rule shows a message that indicates this setting. To have only the linguistic rules defined for the region locale used for this locale, disable this setting.
   2. To ignore leading zeros for all searchable attributes, such as product IDs, select **Ignore Leading Zeroes**.
   
      For example, when this setting is enabled, searching for `8234` or `8234` finds `8234`. Disable this setting and leading zeros are considered part of the search term. For example, only `8234` finds `8234`, an exact match.
      
      > **Note:** To activate this setting, rebuild the product catalog.
   3. Select **Search Autocorrections** so that search terms are automatically spell-corrected or completed before the actual search is executed.
   
      A spell corrected and complete version of the search phrase can appear as `Did You Mean` regardless of this setting.
      
      Disable this setting and search terms aren’t corrected or completed.
   4. To enable personalized search query correction using Einstein AI, select **B2C Commerce Einstein Search Recommendations**.
   5. Select **Search Redirect Keyword Rules** to use expanded match types: `Exact`(same as Disabled), `Phrase,` `Broad,`, and `Negative.`
   
      To use exact match, disable this setting (default).
   6. Select **Include Promotion IDs in the Product Index** to have promotion IDs for searchable promotions added to the product index.
   
      See APIs for Get Promotion Products for additional information.
      
      See [APIs for Get Promotion Products](https://developer.salesforce.com/docs/commerce/b2c-commerce/guide/b2c-promotions-for-developers.html#apis-for-promotions) for additional information.
   7. The **Search Suggestions** setting is deprecated. Enhanced search suggestion is automatically enabled and can't be disabled or enabled with this preference.
   8. Select **Merged Variation Groups Display Mode** to enable merging of Variation Groups.
   
      Variation Groups appear as individual search hits in the storefront search. Sometimes, many individual products can return, so it can be helpful to show all Variation Groups merged as the base product within the search results.
5. In the Notification Settings for Unbucketed Refinement Values section:

   1. Select **Notification Email** so that the users specified are notified when there are unbucketed refinement values.
   2. In the Email To Addresses field, enter one or more comma-separated email addresses for the notification.
   
      After a new product import, new refinement attributes can be imported that are not accounted for in existing bucketing rules. When products that have non-bucketed values are set to appear, they can cause customer confusion and a poor storefront experience. This setting enables merchants to easily identify these unbucketed values before they appear on the storefront.
      
      If at least one email address is configured, a notification email is sent to that address when unbucketed refinement values are found during indexing.
      
      Don't enable this setting on a Production instance.
6. In the Notification Settings for Search Indexer section:

   1. Select **Notification Email** so that the users specified are notified when the number of indexing errors exceed the threshold after indexing.
   2. In the Email To Addresses field, enter one or more comma-separated email addresses for the notification.
   
      If at least one email address is configured, a notification email is sent to that address when unbucketed refinement values are found during indexing.
7. In the Notification Settings for Einstein Dictionaries section:

   1. Select **Notification Email** so that the users specified are notified when there are new search dictionaries available.
   2. In the Email To Addresses field, enter one or more comma-separated email addresses for the notification.
8. Click **Apply** to save your changes or **Reset** to revert to the previous settings.

The search suggest and search auto correct settings can be configured in multiple ways, with different results. The examples shown in the following table were taken from spelling suggestion examples using SiteGenesis.

| Search Suggestions | Search Auto Correct | Storefront - Enhanced Search Suggest | Results |
| --- | --- | --- | --- |
| Enabled or Disabled | Enabled | Enabled | See spelling suggestion examples |
| Enabled or Disabled | Enabled | Disabled | Performs no Search Suggest Auto spells corrected search results |
| Enabled or Disabled | Disabled | Disabled | Opens No Search Results page |
| Enabled or Disabled | Disabled | Enabled | Search suggestion performs auto spell-correct Opens No Search Results page |
