# Storefront Toolkit Tips and Limitations

_For best results, configure your system for optimal Storefront Toolkit performance and make sure you’re aware of toolkit limitations. This topic applies to B2C Commerce_

- The search information tool only works for product search. It doesn't analyse content search results.
- If you redirect the browser to use an unencrypted HTTP version of the page, the Storefront Toolkit sometimes doesn’t work correctly. As a best practice, don't redirect the browser to use HTTP. To eliminate potential issues related to unencrypted pages completely, enable the global security preference Enforce HTTPS. In Business Manager, click App Launcher _(image: App Launcher)_, and then select **Administration > Global Preferences > Security**. On the Access Restrictions tab, select **Enforce HTTPS** and click **Apply**.
- Make sure that you’ve correctly configured the HTTPS host and that the hostname aliases point to the correct instance using DNS.
- Page Designer pages aren’t connected to the Content preview on either the old or new Storefront Toolkit.
- Make sure that all of your certificates are valid. If you have an invalid certificate, first open the storefront and allow an exception. Then open the Storefront Toolkit.
- For cookies, you must use the `Secure` attribute and set the `SameSite` attribute to None.
- The Storefront Toolkit uses an iframe to display your storefront. Avoid JavaScript that accesses the `window.top` or `window.parent` elements of the iframe. Make sure your code doesn’t write to `parent` in the global scope.
- Don’t use ClickJack Protection or Anti-ClickJack scripts, which can cause errors. Use the appropriate HTTP headers instead. For more information, see [b2c_troubleshooting_storefront_toolkit.xml](https://help.salesforce.com/s/articleView?id=cc.b2c_troubleshooting_storefront_toolkit.htm&type=5).
