# Create an eCDN Zone and Upload a Certificate

_Use the CDN Zones API to create a B2C Commerce development, staging, or production zone, then certify each hostname — with an eCDN managed certificate or by uploading your own self-managed certificate in PEM format._

Create an eCDN zone when a custom SSL certificate isn't installed to your development, staging, or production instance POD, or when a custom certificate installed to the POD doesn't cover the hostname. A zone can contain one or more hostnames. After you create the zone, certify each hostname. Not sure which Commerce product you have? See [Which Salesforce Commerce Product Do I Have?](https://help.salesforce.com/s/articleView?id=commerce.comm_what_product.htm).

> **Note:** A multiple-SAN or wildcard certificate is supported, and a certificate is required for each hostname you create.

1. Create an eCDN zone for each domain name with the `POST /storefront-zones` endpoint. See [createStorefrontZone](https://developer.salesforce.com/docs/commerce/commerce-api/references/cdn-api-process-apis?meta=createStorefrontZone).

   1. Call the `POST /storefront-zones` endpoint once for each zone, with the domain name in the payload.
   
      For example, to create zones for two domains, call the endpoint with each of these payloads:
      
      - `{"domainName": "mystore.com"}`
      - `{"domainName": "mystore.co.uk"}`
      
      The response contains the back-end zone name and the zone ID that you use to certify each hostname. For example:
      
      - stg-abcd-mystore-com.cc-ecdn.net
      - stg-abcd-mystore-co-uk.cc-ecdn.net
      
      Back-end zone names use this format: `stg-<realm_id>-<dashed-domain-com>.cc-ecdn.net`.
   2. (Optional) List the zones and zone IDs with the `GET /zones/info` endpoint.
   
      Use the `offset` or `limit` query parameters to page through all the zones. See [getZonesInfo](https://developer.salesforce.com/docs/commerce/commerce-api/references/cdn-api-process-apis?meta=getZonesInfo).
2. Certify each hostname with an eCDN managed certificate or a self-managed certificate.

   - **eCDN managed certificate**: Set `certificateType` to `automatic` when you add the certificate for each hostname. Formatting isn't necessary — skip the PEM formatting step and go to the upload step.
   - **Self-managed certificate**: Format your certificate and key in PEM format (next step), then upload it.
3. For a self-managed certificate, format the certificate and key in PEM format, with newlines represented by the `\n` character.

   To replace the newlines in the certificate and key files with the literal `\n`, follow the example for your operating system.
   
   **Mac/Linux**
   
   Use a shell command like:
   
   - ```
      cat cert.crt | perl -pe 's/\r?\n/\\n/g'
      ```
   
   **Windows PowerShell**
   
   - ```
      (Get-Content -path C:\path\to\cert-file.crt -Raw ) -replace ('\r?\n','\n')
      ```
   
   > **Note:** This command handles either Windows (CR LF) or Unix (LF) line endings.
   
   **Windows GUI**
   
   The default Windows Notepad can't programmatically replace line endings, but you can use a third-party advanced text editor. For example, [Notepad++](https://notepad-plus-plus.org).
   
   1. Open each cert and key file in Notepad++, and take note of the line ending.
   
      _(image: Certify Date Window)_
   2. Select **Search > Replace**.
   3. In the Find what field, enter the character for your line ending:
   
      - Enter `\n` if the file has Unix (LF) line endings.
      - Enter `\r\n` if the file has Windows (CR LF) line endings.
   4. In the Replace with field, enter `\\n`.
   5. In Search Mode, select Extended `(\n,\r,\t,\o,\x...)`.
   6. Click **Replace All**. If you have multiple cert or key files open, click **Replace All in All Opened Documents**.
   
      _(image: Notepad++ replace window)_
4. For each hostname, upload the certificate with the `POST` certificate endpoint, passing the hostname, certificate, and key in the payload.

   See [addCertificateForZone](https://developer.salesforce.com/docs/commerce/commerce-api/references/cdn-api-process-apis?meta=addCertificateForZone).

> **Important:** For certificates that cover multiple hostnames and for wildcard certificates, upload a certificate for each hostname. You can upload the same certificate multiple times.

_(image: Zone Creation Note)_

_(image: Embedded CDN Settings)_

_(image: Embedded CDN Settings)_

_(image: Embedded CDN Settings)_
