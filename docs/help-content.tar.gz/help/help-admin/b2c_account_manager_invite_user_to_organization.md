# Add an Account to Your Organization in B2C Commerce

_As an Account Administrator, you can add user accounts to your organization._

[Which Salesforce Commerce Product Do I Have?](https://help.salesforce.com/s/articleView?id=commerce.comm_what_product.htm)

1. Log into Account Manager.
2. Click **User**.

   The Users page opens, showing a list of accounts.
3. Click **Add User**.

   The Email validation page opens.
4. In the **Email Address** field, enter the email address of the account you want to add to your organization. If your email provider supports subaddressing, you can enter a subaddress with a + sign in the email address. Subaddressing directs variations of an email address to a single inbox. For example, if you want to create a user account for a specific function, such as development, you can enter a subaddress such as: username+development@sample.com. Subaddresses help you manage roles at a granular level. See [b2c_account_manager_manage_partner_access.xml](https://help.salesforce.com/s/articleView?id=cc.b2c_account_manager_manage_partner_access.htm&type=5).
5. Click **Add**.

   If Account Manager cannot find the account, the Add User page opens and you can create an account (see Create a User Account). If Account Manager finds the account, you can click **Add** to add the account to your organization.
   
   If the user account is from another organization (for example, a partner account), the added account shows up in the user list of your organization under **Invited Users**. A message is sent to the user's email address, which notifies the user about the membership in your organization.
   
   After the user account is added to your organization, you can manage the account's access to various B2C Commerce applications.
