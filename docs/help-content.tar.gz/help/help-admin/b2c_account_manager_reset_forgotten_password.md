# Reset a Forgotten Password in B2C Commerce

_You can reset your password if you forgot it. However, this procedure works only if you successfully activated your account. Define a new password even if your existing password has expired. After a password has expired, you can attempt to log in six times to set a new password before your account is temporarily locked. After successfully logging in with an expired password, immediately reset your password._

[Which Salesforce Commerce Product Do I Have?](https://help.salesforce.com/s/articleView?id=commerce.comm_what_product.htm)

This procedure works only when your Account Manager account is not linked to a Salesforce Identity account.

1. In a web browser, go to https://account.demandware.com/.
2. Enter your username (email address).
3. Click **LOG IN**.
4. Click the **Forgot Password?** link.

   The Forgot Your Password? page opens.
5. In the **Email Address** field, enter your email address.
6. Click **Submit**.

   A message is sent to your email address. The message contains an activation code you can use to reset your password. The Forgot Your Password? Page also shows a Code field, in which you can enter the activation code.
7. Access your email account, open the email message, and copy the activation code.
8. In the Code field, paste the activation code you copied from the email.
9. Click **Submit Code**.
10. In the **New Password** field, enter your new password.

   Minimum password requirements include:
   
   - At least 12 characters long. Some organization require more
   - At least 3 types of the following characters: Uppercase (A-Z), lowercase (a-z), number (0-9), and symbol (!, #, $, and so on)
   - Doesn't include part of your name or username
   - Can't reuse any of the 4 previous passwords
   
   As you enter characters, the page gives you feedback about the security strength of your password.
11. In the Confirm Password field, reenter your new password.
12. Click **Change Password**.

   A second message is sent to your email address, indicating that your password has changed. The purpose of this message is either to confirm that your activation was successful or to warn you that someone else tried to change the password. If someone else tried to change password, contact your account administrator or help desk.
