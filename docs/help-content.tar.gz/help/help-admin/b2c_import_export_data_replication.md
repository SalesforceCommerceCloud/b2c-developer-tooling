# Import/Export Data Replication in B2C Commerce

_Import and export data lives at the site level in its own file system, so it isn't replicated. This topic applies to B2C Commerce._
