# Declarative Security via HTTP Headers in B2C Commerce

_You can use declarative security controls as a strong line of defense against client browser-based attacks such as clickjacking and offer built-in browser protection against cross-site scripting (XSS). The OWASP Secure Headers Project describes HTTP response headers that your application can use to increase the security of your application._

The B2C Commerce APIs and the Storefront Reference Architecture (SFRA) provide this capability. Set HTTP headers on an HTTP response using the `addHttpHeader()` method on the Response object. If your storefront or cartridge is SFRA-based, you can use the `httpHeadersConf.json` file to automatically set HTTP response headers on *all* responses.

Declarative security controls via HTTP headers and other client browser-based protections apply only if the client’s browser supports the feature. Check the B2C Commerce list of support browsers before relying on a header to cover all supported user environments.
