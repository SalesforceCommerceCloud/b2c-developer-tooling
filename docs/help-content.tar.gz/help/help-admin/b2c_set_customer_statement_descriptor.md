# Set the Customer Statement Descriptor for B2C Commerce

_Customize the description that appears on a customer’s statement to identify the source of the charge, using a different description for each site in your realm. When shoppers recognize the charge, they’re less likely to file disputes or request chargebacks._

1. In Business Manager, click App Launcher _(image: App Launcher)_, and then select **Merchant Tools > Site > Commerce Apps > App Catalog**.
2. In the Installed Apps section, for Salesforce Payments, click **Manage**.
3. In the Advanced Settings card, enter a customer statement descriptor.

   Enter a short description to identify your site on bank and credit card statements. For example, `www.yoursitename`. For Stripe accounts, the description appears on the customer’s statement alongside the charge. Meet these requirements:
   
   - Contains 5–22 characters
   - Includes at least one letter (only Latin characters)
   - Doesn’t include the special characters < > \ ' " *
   - Reflects your business name
   - Contains more than a single common term, or a common website URL that clearly and accurately describes the transaction on a customer’s statement
4. Save your changes.

   _(image: Enter a customer statement descriptor.)_
