# Set the Customer Statement Descriptor for B2C Commerce

_Customize the description that appears on a customer’s statement to identify the source of the charge. Use different text for each site in your realm. When shoppers know the origin of a charge, it reduces payment disputes and chargeback requests._

|  |
| --- |
| Available in: **B2C Commerce** |

1. In Business Manager, click App Launcher _(image: App Launcher)_, and then select **Merchant Tools > *site* > Ordering > Payments**.
2. Click **Settings**.
3. For Customer Statement Descriptor, enter a short description to identify your site on bank and credit card statements. For example, www.yoursitename.

   The description must meet these requirements.
   
   - Contain 5–22 characters
   - Include at least one letter (only Latin characters)
   - Doesn’t include the special characters < > \ ' " *
   - Reflect your business name (DBA)
   - Contain more than a single common term or common website URL A website URL is acceptable only if it provides a clear and accurate description of the transaction on a customer’s statement.
4. Click **Save**.
