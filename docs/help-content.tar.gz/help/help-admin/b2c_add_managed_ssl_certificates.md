# Add a Managed SSL Certificate for B2C Commerce

_Add an eCDN managed SSL certificate to a hostname for a zone, validate it, and map DNS so the hostname's traffic routes to its zone. eCDN managed certificates are issued and auto-renewed by Salesforce._

> **Note:** Managed SSL certificates aren't available on SCAPI zones. Salesforce manages the SCAPI hostname and certificates. See [SCAPI Zone Support for B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_scapi_zone.htm&type=5).

[Which Salesforce Commerce Product Do I Have?](https://help.salesforce.com/s/articleView?id=commerce.comm_what_product.htm)

For the DNS mapping rules, validation methods, and certificate limits, see [DNS Mapping for eCDN Zones](https://help.salesforce.com/s/articleView?id=cc.b2c_dns_mapping_for_ecdn_zones.htm&type=5).

1. Click App Launcher _(image: App Launcher)_, and then select **Administration > Sites > Embedded CDN Settings**.
2. Click **Certificates** or **Settings** for the zone to which you're adding a certificate.
3. On the Crypto tab, select the zone from the list.
4. Click **New Certificate**.
5. Select **eCDN Managed Certificate**.

   An eCDN managed certificate uses the **automatic** certificate type: Salesforce issues and renews it for you.
   
   _(image: Upload Custom Certificate dialog with eCDN Managed Certificate selected, showing certificate details and assignment details)_
6. From the SSL Certificate Authority dropdown, select **Lets Encrypt** or **Google** (recommended).
7. From the SSL Certificate Validation Method dropdown, select **HTTP Validation** or **TXT validation**.

   Choose HTTP validation without a stacked CDN, or TXT validation with a stacked CDN and DCV delegation. For the details and requirements of each method, see [DNS Mapping for eCDN Zones](https://help.salesforce.com/s/articleView?id=cc.b2c_dns_mapping_for_ecdn_zones.htm&type=5).
8. Select the hostname to which you want to assign the SSL certificate.
9. Click **Upload Certificate**.
10. Copy the displayed verification text into your own DNS portal.

   - **HTTP validation:** Copy the displayed hostname verification text.
      
      _(image: Certificates table showing hostname with Initiating status and hostname TXT validation values to copy)_
   - **TXT validation:** Copy the displayed certificate and hostname TXT verification text, including the DCV Delegation CNAME.
      
      _(image: Certificates table showing hostname with Pending Validation status and certificate TXT and hostname TXT values to copy, plus DCV Delegation CNAME)_
11. To check the status of hostname validation, click **Verify HostName**.

   Verification can take up to six hours.
12. (TXT validation only) After the hostname is active, click **Verify eCDN Managed Certificate** to validate the certificate through the TXT record.

   Verification can take up to six hours.
13. Map DNS so that the hostname's traffic routes to its zone.

   See [Map DNS to an eCDN Zone](https://help.salesforce.com/s/articleView?id=cc.b2c_map_dns_to_ecdn_zone.htm&type=5). After the CNAME points traffic to the new zone, click **Verify eCDN Managed Certificate** to check the certificate validation status.
