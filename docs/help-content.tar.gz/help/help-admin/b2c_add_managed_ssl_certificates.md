# Add Managed SSL Certificates

_Add eCDN managed SSL certificates to your hostnames for zones, and map your origin endpoints._

|  |
| --- |
| Available in: **B2C Commerce** |

To add managed SSL certificates to your hostnames and map DNS values from B2C Commerce to your DNS provider account:

On the Crypto tab, click the chevron at the start of a certificate row to expand certificate details, including certificate type, hosts, issuer, validation method, expiration details, and any TXT or CNAME records or verification actions required for unverified certificates.

When mapping endpoints, keep the following in mind:

- The DNS Request for Comments (RFC) doesn’t support pointing root domains directly to B2C Commerce. When directing root domains to the eCDN CNAME alias, you must use an external service to redirect from the root domain to the subdomain.
- When setting up redirects, make sure that you set them up for both HTTP and HTTPS.
- To permanently serve traffic from the root domain (yourcompany.com) instead of a subdomain (www.yourcompany.com), use a DNS-level solution to direct root domains to the eCDN CNAME alias.

1. Click App Launcher _(image: App Launcher)_, and then select **Administration > Sites > Embedded CDN Settings**.
2. Click **Certificates or Settings** for the zone to which you’re adding a certificate.
3. On the Crypto tab, select the zone from the list.
4. Click **New Certificate**.
5. Select **eCDN Managed Certificate**.

   _(image: Upload Custom Certificate dialog with eCDN Managed Certificate selected, showing certificate details and assignment details)_
6. From the SSL Certificate Authority dropdown, select **Lets Encrypt** or **Google** (recommended).
7. From the SSL Certificate Validation Method dropdown, select either **HTTP Validation** or **TXT validation**.

   - HTTP Validation
      
      - Use this option without a stacked CDN.
      - If you choose to implement a stacked CDN configuration with an eCDN, be aware that when stacking a third-party CDN, HTTP validation isn't blocked. To keep validation processes running smoothly, allow the Domain Control Validation (DCV) HTTP path for ACME (Automatic Certificate Management Environment)-compliant Certificate Authorities (CAs). According to [Let's Encrypt documentation](https://letsencrypt.org/docs/challenge-types/), the HTTP path to allow is http://<YOUR_DOMAIN>/.well-known/acme-challenge/<TOKEN>.
   - TXT Validation
      
      - Use this option with a stacked CDN and DCV delegation. DCV delegation is required with a stacked CDN.
      - If DCV universally unique identifier (UUID) is needed, you can contact our support team to obtain a DCV delegation UUID to include in your DNS record.
      - Without DCV delegation:
         
         - Validate the TXT record every three months due to the automatic certificate rotation.
         - Even if you configure an eCDN Managed Certificate for TXT validation, HTTP validation attempts still occur during certificate renewal. Please allow DCV HTTP path validation mentioned in the previous item.
8. Select the hostname to which you want to assign the SSL certificate.
9. Click **Upload Certificate**.
10. (Optional) Validate with HTTP.

   1. Copy the displayed verification text into your own DNS portal.
   
      _(image: Certificates table showing hostname with Initiating status and hostname TXT validation values to copy)_
   2. To check the status of hostname validation, click **Verify HostName**. This verification can take up to six hours.
   3. When the hostname is active, create a CNAME record that points traffic, by SSL for SaaS V2, to the new zone.
   4. Configure the DNS mapping for the zone:
   
      1. Log in to your DNS provider account.
      2. Search for your zone and select it from the list.
      3. On the DNS tab, locate the hostname that you want to map.
      4. Replace all text after “is an alias of” with the DNS CNAME from Business Manager.
      5. In the Status column, click the cloud until it shows a gray cloud with the tooltip “DNS Only”.
   5. To check the status of the certificate validation, click **Verify eCDN Managed Certificate**. Verification can take up to six hours.
11. (Optional) Validate with TXT.

   1. Copy the displayed verification text for the certificate and hostname into your own DNS portal.
   
      _(image: Certificates table showing hostname with Pending Validation status and certificate TXT and hostname TXT values to copy, plus DCV Delegation CNAME)_
   2. To check the status of hostname validation, click **Verify HostName**. This verification can take up to six hours.
   3. When the hostname is active, to check the status of the certificate validation, click **Verify eCDN Managed Certificate**. Verification can take up to six hours.
   4. When the hostname and certificate are active, create a CNAME record that points traffic, by SSL for SaaS V2, to the new zone.
   5. Configure the DNS mapping for the zone:
   
      1. Log in to your DNS provider account.
      2. Search for your zone and select it from the list.
      3. On the DNS tab, locate the hostname that you want to map.
      4. Replace all text after “is an alias of” with the DNS CNAME from Business Manager.
      5. In the Status column, click the cloud until it shows a gray cloud with the tooltip “DNS Only”.
