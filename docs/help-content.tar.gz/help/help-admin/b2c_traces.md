# Traces (Beta)

_Use the Traces feature in Log Center to follow a single request as it travels across B2C Commerce services. A trace shows the end-to-end path of a request and the time spent in each service, so you can find where latency or errors occur._

> **Note:** The Traces feature is a pilot or beta service that is subject to the Beta Services Terms at [Agreements - Salesforce.com](https://www.salesforce.com/company/legal/agreements/) or a written Unified Pilot Agreement if executed by Customer, and applicable terms in the [Product Terms Directory](https://ptd.salesforce.com/). Use of this pilot or beta service is at the Customer's sole discretion.

_(image: The Traces page in Log Center, showing the filter panel on the left, the spans-by-status chart, and the results table of matching traces.)_

A trace represents one request as it moves through B2C Commerce services from end to end, across all storefront types. For example, a composable storefront request can travel from PWA Kit through Managed Runtime (MRT), Salesforce Commerce API (SCAPI), the web server, and the application server. Each step in the request is a span.

Spans are nested to show which service called another, so you can read a trace as a waterfall from the first span to the last.

Use traces to:

- See the full path of a request across service boundaries in one view.
- Identify the service or operation that contributed the most time to a request.
- Investigate requests that returned errors.

The Traces feature is a closed Beta for developers, DevOps engineers, and admins, and is enabled per realm through a feature flag. To join the Beta, contact Salesforce Support, your Technical Account Manager (TAM), or your Customer Success Manager (CSM).

The Traces page is available to users with the Log Center Admin or Support role.

The Beta implementation of traces has these limitations:

- During the Beta, only a sample of requests is traced (about 5%), so not every request has a trace.
- Traces are retained for 5 days. Search within that window.
- Traces is available only to realms that are participating in the closed Beta.

## Related Content

- [View Traces (Beta)](https://help.salesforce.com/s/articleView?id=cc.b2c_view_traces.htm&type=5)
  Open the Traces page in Log Center to see traces for your B2C Commerce realm.

- [Search Traces (Beta)](https://help.salesforce.com/s/articleView?id=cc.b2c_search_traces.htm&type=5)
  Find traces for a B2C Commerce service over a selected time period, and narrow the results with filters.

- [View Trace Details (Beta)](https://help.salesforce.com/s/articleView?id=cc.b2c_trace_details.htm&type=5)
  Read the span waterfall for a single B2C Commerce trace to see how a request moves across services and where it spends time.

- [Share a Trace (Beta)](https://help.salesforce.com/s/articleView?id=cc.b2c_share_a_trace.htm&type=5)
  Share a link to a specific B2C Commerce trace or search and filter selections with a colleague.
