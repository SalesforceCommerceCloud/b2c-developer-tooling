# Search Object Import and Export in B2C Commerce

_Use the Search object to import and export search-related elements including stop words, search term completion suggestions, synonyms, hypernyms, redirects, searchable attributes, search preferences, and sorting rules. This topic applies to B2C Commerce._

## Search Object Schemas in B2C Commerce

_The Search object uses several schemas including search2.xsd, preferences.xsd, and sort.xsd. The search.xsd schema was deprecated and replaced by the search2.xsd schema. The search.xsd schema remains for use with index stemmer or indexing mode. This topic applies to B2C Commerce._

This table describes the general purpose for each search schema.

| Schema | Purpose |
| --- | --- |
| search2.xsd | Use to import and export stop words, search term completion suggestions, synonyms, hypernyms, redirects, and searchable attributes. |
| preferences.xsd | Use to import and export search preferences. |
| sort.xsd | Use to import and export sorting rules and boost and bury rules. |
| search.xsd | This schema was deprecated and removed in 2011. The schema remains only to enable the import and export of index stemmer or indexing mode. |

The search2.xsd file doesn't support deprecated text relevance attributes and sorting attributes. To better understand the differences between the search.xsd and search2.xsd schemas, review the following table.

| Feature | search.xsd | search2.xsd |
| --- | --- | --- |
| Text relevance attributes | The `text-relevance-attributes` element is deprecated and no longer supported. It's ignored during import and export and replaced with searchable attributes. | To import text relevance boosts, use the `searchable-attributes` element. Text relevance attributes are a deprecated feature.The `text-relevance-attributes` element isn't included in the schema. |
| Searchable attributes | Not included. | The `searchable-attributes` element is supported. |
| Sorting attributes | The `sorting-attributes` element is deprecated, but still supported. | The `sorting-attributes` element isn't present in the schema. |
| Localization | In the search.xsd file, you must specify a locale for each object, such as a stop word. | In the search2.xsd file, you can specify a locale for a group of metadata objects, such as stop words. |
| Settings | The `settings` element is still supported. The settings element configures the index stemmer and indexing mode. | The `settings` element isn't included in the schema. |
| Incremental indexing and scheduled rebuild settings | Not exported in the search.xml file from **Site Import & Export**.  Not exported from **Search > Import & Export > Search Setting Export**. | Exported from **Site Import & Export** and **Search > Import & Export > Search Setting Export**. |
| All other search features | Not exported in the search.xml file from **Site Import & Export**. The elements exported in search.xsd include only those elements not supported in search2.xsd. Not exported from **Search > Import & Export > Search Setting Export**. | Exported from **Site Import & Export** and **Search > Import & Export > Search Setting Export**. |

## Search Preferences Schema Elements in B2C Commerce

_Use the preferences.xsd schema for importing search preferences. This topic applies to B2C Commerce._

Search uses two schemas: search2.xsd and preferences.xsd. You use the search2.xsd schema for search configuration, and the preferences.xsd for importing search preferences.

| Object Information | Details |
| --- | --- |
| Schema file | preferences.xsd |
| Business Manager import and export location | ***site* >  Administration > Site Development > Import & Export** or include in ***site* > Administration > Site Development > Site Import & Export**. |
| Pipelets | N/A |

## Search Sorting Rules Object Import and Export in B2C Commerce

_Use the sort.xsd schema to import sorting rules and dynamic attributes. This topic applies to B2C Commerce._

When using the sort.xsd schema, keep the following in mind:

- The `<sorting-rule-campaign-assignment>` element assigns a sorting rule to a campaign. If the specified campaign-ID doesn’t match a campaign ID, the system logs an error message and skips the element.
   
   > **Note:** Wildcard deletion isn't supported when mode=*delete*.
- B2C Commerce trims sorting rule IDs of leading and trailing white space before storing or exporting to XML. Correct any sorting rule IDs with leading or trailing white space before storing them. Though export trims ID white space, importing them again in merge mode results in added sorting rule IDs both with and without leading or trailing spaces.

| Object Information | Details |
| --- | --- |
| Schema file | sort.xsd |
| Granularity | Site-specific feature configuration. |
| Business Manager import location | ***site* > Administration > Site Development > Site Import & Export**and **Search > Import & Export** |
| Pipelets | N/A |

## Search2 Object Import and Export in B2C Commerce

_Use the search2.xsd schema file to import information used to build search indexes. This topic applies to B2C Commerce._

### Search2 Object Schema Information in B2C Commerce

_Use the search2.xsd schema file to import information used to build search indexes. This topic applies to B2C Commerce._

> **Note:** The search2.xsd schema does not support some elements. However, you can still import these elements using search.xsd.

| Object Information | Details |
| --- | --- |
| Schema file | search2.xsd |
| Granularity | Site-specific feature configuration. |
| Business Manager import location | ***site* > Administration > Site Development > Site Import & Export** and **Search > Import & Export** |
| Pipelets | N/A |

### Search Hypernym Import and Export in B2C Commerce

_The search2.xsd schema enables merchants to provide hypernyms. This topic applies to B2C Commerce._

A hypernym is a word with a broad meaning that more specific words fall under. For example, *color* is a hypernym of *red*.

If the hypernym of a hypernym group is empty, the system issues a warning and skips the hypernym group. For example:

```
<hypernym-list xml:lang="x-default">
    <hypernym-rule>
        <hypernyms></hypernyms>
        <hyponyms> 1 </hyponyms>
    </hypernym-rule>
</hypernym-list>
```

In this example, the system provides the following error:

WARN [WARNING] [DATAERROR] Line: 201/Hypernym Group:Empty hypernym. Skipping hypernym group.

### Search Common Phrases Import and Export in B2C Commerce

_The search2.xsd schema supports the import of common phrases. This topic applies to B2C Commerce._

Merchants can configure common phrases in multiple elements or as a comma-separated list in a single element. For example:

<common-phrases xml:lang="x-default"> <common-phrase match-mode="exact-match">ankle boots</common-phrase> <common-phrase match-mode="exact-match">red dress</common-phrase> <common-phrase match-mode="exact-match">infinity scarf, wool scarf</common-phrase> </common-phrases>

### Search Term Completion and Import and Export in B2C Commerce

_Merchants can include and exclude search suggestions using the search2.xsd schema. This topic applies to B2C Commerce._

For example, you can exclude specific "bad words" from the search.

```
<suggestion-list xml:lang="x-default">
    <suggestions>foo bar</suggestions>
    <exclusions>bad-word, bad-word</exclusions>
</suggestion-list>
```

> **Note:** The preferences.xsd also supports a *SearchSuggestions* preference.

### Search Refinements and Import and Export in B2C Commerce

_Merchants can create refinement definitions for search through Business Manager, and use this information in product and content search indexing. This topic applies to B2C Commerce._

For product search refinements, the catalog.xsd represents the refinement definitions through the *refinement-definitions* element, inside the complexType.Category.

For content search refinements, the library.xsd represents the refinement definitions through the *refinement-definitions* element, inside the complexType.Folder section of the schema.
