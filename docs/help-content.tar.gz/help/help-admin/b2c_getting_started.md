# Get Started with B2C Commerce

_B2C Commerce is a comprehensive Enterprise commerce platform designed to help you set up and manage online storefronts that sell directly to shoppers. The platform includes merchandising tools that enable you to showcase your products and drive sales. B2C Commerce offers data-driven insights that help you convert customers and achieve your sales goals. The platform comes with out-of-the-box templates that allow you to create feature-rich, localized storefronts that accurately represent your brand and cater to your target audience. Agentforce for Commerce provides a fully secure conversational commerce experience._

> **Note:** Commerce Cloud is now Agentforce Commerce. You may see references to Commerce Cloud in Salesforce applications and documentation.
