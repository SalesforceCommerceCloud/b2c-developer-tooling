# Update an eCDN Zone's Certificate

_When your SSL certificate expires, or you update the hostnames assigned to an SSL certificate, update the certificate in Business Manager for B2C Commerce. Update eCDN managed certificates and self-manged certificates_

## Related Content

- [Update an eCDN Zone's Managed Certificate](https://help.salesforce.com/s/articleView?id=cc.b2c_update_a_zones_managed_certificate.htm&type=5)
  When your managed SSL certificate expires, or you update the hostnames assigned to a managed SSL certificate, update the certificate in Business Manager for B2C Commerce.

- [Update an eCDN Zone's Self-Managed Certificate](https://help.salesforce.com/s/articleView?id=cc.b2c_update_a_zones_self_managed_certificate.htm&type=5)
  When your self-managed SSL certificate expires, or you update the hostnames assigned to an SSL certificate, update the certificate in Business Manager for B2C Commerce.

- [Configure Wildcard Custom Hostnames](https://help.salesforce.com/s/articleView?id=cc.b2c_add_wildcard_custom_hostname.htm&type=5)
  Use a single wildcard custom hostname (for example, `*.merchantsite.com`) to cover multiple subdomains and reduce onboarding and management overhead in B2C Commerce eCDN via Business Manager.
