# Apply Defense in Depth

_Defense in depth means using multiple layers of security within your B2C Commerce environment instead of just one. If an attack causes one security mechanism to fail, other mechanisms can still provide the necessary security to protect the system. Think of creating a security onion and not a security egg. When dropped, an egg smashes everywhere, while an onion just gets a little bruised because it has multiple layers._

Here are some best practices when applying defense in depth.

- Implement 2FA so a stolen password can’t compromise a user account. Using Account Manager to configure authentication enables customers to enforce 2FA on all their users, thereby implementing defense in depth.
- Add authentication mechanisms to internal systems in case an attacker manages to get inside the firewall.
