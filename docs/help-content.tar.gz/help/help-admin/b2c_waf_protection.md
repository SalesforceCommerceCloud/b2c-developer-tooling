# eCDN Web Application Firewall (WAF)

_The embedded CDN (eCDN) web application firewall (WAF) is a layer 7 defense that inspects HTTP and HTTPS traffic to your B2C Commerce storefront and blocks requests that try to exploit code-level vulnerabilities. WAF is enabled by default when you create a Proxy Zone and is one part of a multitiered approach to bad-actor mitigation._

[Which Salesforce Commerce Product Do I Have?](https://help.salesforce.com/s/articleView?id=commerce.comm_what_product.htm)

WAF protects production, staging, and development storefront hostnames from common application-layer attacks, such as:

- SQL injection
- Cross-site scripting (XSS)
- Other Open Web Application Security Project (OWASP)–identified threats that target the application layer

WAF monitors all HTTP and HTTPS (full-site) and Ajax (small data snippet) requests made to your storefront. Rules can match on request attributes such as user agent, path, country, query string, and IP address. WAF performs several functions to help protect your storefront:

- Inspects URLs to detect anything out of the ordinary.
- Filters out malicious traffic that attempts to exploit application vulnerabilities.
- Helps prevent bad actors from exploiting code vulnerabilities.

WAF protection is delivered through three managed rulesets that you enable and tune per zone. For what each ruleset does, see [eCDN WAF Managed Rulesets](https://help.salesforce.com/s/articleView?id=cc.b2c_waf_managed_rulesets.htm&type=5). To turn the rulesets on and set the action for matched requests, see [Configure WAF Settings for an eCDN Zone](https://help.salesforce.com/s/articleView?id=cc.b2c_configure_zone_waf_settings.htm&type=5).

WAF applies on Proxy Zones and on On-Demand Sandbox (ODS) Default Domain zones. For the ODS shared-zone specifics, see [eCDN WAF on On-Demand Sandboxes](https://help.salesforce.com/s/articleView?id=cc.b2c_waf_application.htm&type=5). To review the traffic WAF acts on, see [eCDN WAF Logs](https://help.salesforce.com/s/articleView?id=cc.b2c_waf_net_traffic_logs.htm&type=5).

- WAF can stop a bot that tries to exploit common code vulnerabilities. However, WAF can miss a bot that brute-forces coupon codes, because that request is a legitimate HTTP and web-form request. For bot-specific management, contact your account team about our recommended bot-mitigation partners.
- Each managed ruleset can be turned on or off as a whole. You can't customize individual rules within a managed ruleset.

## Related Content

- [eCDN WAF Managed Rulesets](https://help.salesforce.com/s/articleView?id=cc.b2c_waf_managed_rulesets.htm&type=5)
  The embedded CDN (eCDN) web application firewall (WAF) protects your B2C Commerce storefront through three managed rulesets: the eCDN WAFv2 Managed Ruleset, the OWASP WAFv2 Managed Ruleset, and the eCDN WAFv2 Exposed Credentials Check. You enable and tune each ruleset per zone.

- [eCDN WAF on On-Demand Sandboxes](https://help.salesforce.com/s/articleView?id=cc.b2c_waf_application.htm&type=5)
  B2C Commerce On-Demand Sandbox (ODS) Default Domain zones support the full embedded CDN (eCDN) web application firewall (WAF) feature set. Because ODS uses a shared zone model, plan rule changes carefully. The rules apply to every ODS instance in the realm.

- [eCDN WAF Logs](https://help.salesforce.com/s/articleView?id=cc.b2c_waf_net_traffic_logs.htm&type=5)
  eCDN logs include information about all of your B2C Commerce network traffic, not just the traffic that the web application firewall (WAF) acts on. Use the logs to track IP-reputation–blocked traffic and to see how much of your traffic doesn't trigger WAF.
