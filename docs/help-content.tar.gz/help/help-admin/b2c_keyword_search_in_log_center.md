# Keyword Search in Log Center

_Use keyword search in B2C Commerce Log Center to find the logs that contain certain terms. When you enter text or an ID in the text message, the search looks several places. It looks in the text message, activity ID, category name, thread name, and message stack trace. When you click the Search icon, the results appear in a list. The severity panel to the left shows the number of issues per severity that contain the text or ID. If the severity is selected as a filter on the left side, the keyword/ID search is restricted to a particular severity._

Search terms are applied using AND logic. For example, if the filter is set to show “warn” messages only, suppose that 14 messages are listed. If you then apply the search term "pipeline dictionary", suppose that only 5 issues are listed. The number of issues listed is smaller, because you see only issues that are of type "warn" *and* contain the search term "pipeline dictionary."

The following rules apply to searches:

- The search is case-insensitive.
- Operators are case-sensitive.
- The order of the search terms isn't important, except when entering a phrase.
- Stop words aren’t considered. If the query is composed just from stop words, the search doesn’t return any results. The underlined words in this query are stop words and are ignored: No event key present or no tag defined
   
   The stop words are:
   
   - a
   - an
   - and
   - are
   - as
   - at
   - be
   - but
   - by
   - for
   - if
   - in
   - into
   - is
   - it
   - no
   - not
   - of
   - on
   - or
   - such
   - that
   - the
   - their
   - then
   - there
   - these
   - they
   - this
   - to
   - was
   - will
   - with
   
   To remove the search term, delete the text in the text box and click the Search icon.
   
   Available query fields are:
   
   - text
   - stackTrace
   - stackTraceUUID
   - category
   - thread
   - activityID
   - requestID
   - sessionID
   
   Field names are case-sensitive.
   
   Conduct either a basic search or advanced search. When you switch from one search mode to another, your keyword query is reset. Resetting the query is necessary because the syntax of the two search modes isn't compatible.

### Basic Search

Search simultaneously in all search fields. The search results consist of the log messages that contain each search term in at least one of the fields.

The search mode doesn't support any operators or wildcards. For example, searching for "Pr*" doesn’t return any results. The searched keywords must be an exact match. The terms are searched in each search field. Each term must be found at least one time in the fields, otherwise no search results are found.

To use basic search, you enter the search term in the text field and click the Search icon.

Some examples of basic search:

- Search for logs that contain "PipeLine", "Storefront" in at least one of the fields
   
   PipeLine Storefront
- Search for logs that contain "PipeLine", "job", "223847682349" in at least one of the fields
   
   PipeLine job 22384782349
- Search for logs that contain"PipeLine", "job", "NullPointerException" in at least one of the fields
   
   PipeLine job NullPointerException
   
   The hits for this example are: Log messages that contain in text "PipeLine", in category "job" and in stack trace "NullPointerException Log messages that contain in text "PipeLine", "job", and "NullPointerException" Log messages that contain in text "job" and "NullPointerException", in thread name "PipeLine"

### Advanced Search

Advanced search enables selectable multi-field queries.

|  |  |
| --- | --- |
| Define your search with | Description |
| Special characters | There are some characters that have a special significance in the keyword query language:+ - = && \|\| > < ! ( ) { } [ ] ^ " ~ *? : \ / It's a good practice to avoid including the reserved characters in the search query. However, if you use any of the characters in your query itself (not as operators), escape them. |
| Boolean operators | Search terms can be combined with Boolean operators to form a more complex query. The main operators are:  AND (both search terms are present) OR (one of the search terms is present) NOT (the search term is not present) - (the search term is not present) No space is allowed between the "-" and the search term.  Operators are case-sensitive. |
| Wildcards | Use an asterisk (*) or question mark (?) as wildcards in your search. An asterisk represents zero or more characters. A question mark represents one character. To avoid getting too many results, when you enter partial search terms, make sure they contain as many characters as possible. You can't use a wildcard character at the beginning of a search term. |
| Grouping | For more complex queries, you can group the search terms using parentheses. |
| Phrase query | Phrase query means that the order and position of the search terms is considered. Enclose phrase searches in quotes. |
| Fuzzy query | A fuzzy query searches for terms that are similar to, but not exactly like the specified search terms. This query can be applied to search terms or phrases. The indicator for this type of query is a tilde (~) at the end of the term or phrase. The number after the tilde is the Damerau-Levenshtein distance. |
| Regular expression | Use regular expressions (regex) to match different patterns. For better results, make your regular expressions as concrete as possible. Surround regular expressions with forward slashes (/). |

Examples of advanced search using Boolean operators:

- Search for logs that contain the text "PipeLine" and are in category "log"
   
   text: (Pipeline) AND category: (log)
- Search for logs that contain the text "PipeLine" or are in category "log"
   
   text: (PipeLine) OR category: (log)
- Search for logs that contain the text "PipeLine" and are in a category that doesn't contain "log"
   
   text: (PipeLine) AND NOT category: (log)
- Search for logs that contain the text "PipeLine" and "Storefront" and are in the category "log"
   
   text: (PipeLine Storefront) AND category: (log)
- Search for logs that contain "job" in text or in stackTrace or in the category
   
   text: (job) OR stackTrace: (job) OR category: (job)

Example of advanced search using wildcards:

- Search for logs where the text contains "PipeLine" and words that start with "Store"
   
   text: (PipeLine Store*)
   
   text: (PipeLine AND Store*)
- Search for logs where the text contains "store" or "story"
   
   text: (stor?)
- Search for logs where the text contains words that start with "la" and end with "m"
   
   text (la*m)
- Invalid wildcards
   
   text: (*m)
   
   text: (?tory)

Example of advanced search using grouping:

- Search for logs where the text contains "PipeLine" and "Store", or "PipeLine" and "Product"
   
   text: (PipeLine AND (Store OR Product))

Example of advanced search using a phrase: Search for logs where the text contains the exact phrase "create event"text: ("create event")

Examples of advanced search using fuzzy query: Search for logs where the text contains words similar to "world". The search results show logs that contain in the text field: world, wordl, wroldtext: (world~2)  Phase proximity search: search for phrases that contain the same words but the specified words can be further apart or in a different order. The search results show logs that contain in the text field: "create configuration", "create job configuration", "create cleanup configuration".text: ("create configuration"~2)

Example of advanced search using regular expression: Search for logs where the text contains "store" or "story"text: (/stor[ey]/)
