# eCDN WAF Managed Rulesets

_The embedded CDN (eCDN) web application firewall (WAF) protects your B2C Commerce storefront through two managed rulesets: the eCDN WAFv2 Managed Ruleset and the OWASP WAFv2 Managed Ruleset. You enable and tune each ruleset per zone._

[Which Salesforce Commerce Product Do I Have?](https://help.salesforce.com/s/articleView?id=commerce.comm_what_product.htm)

The eCDN security team (or, for OWASP, the upstream project) updates the rules to cover new vulnerabilities and reduce false positives. You can turn each ruleset on or off and set the action it takes, but you can't customize individual rules within a ruleset. To enable and configure these rulesets for a zone, see [Configure WAF Settings for an eCDN Zone](https://help.salesforce.com/s/articleView?id=cc.b2c_configure_zone_waf_settings.htm&type=5).

> **Important:** Exposed Credentials Check is deprecated and was removed from Embedded CDN Settings in B2C Commerce 26.10. Leaked Credentials Detection is a separate capability, and Exposed Credentials Check doesn't work with Leaked Credentials Detection. To act on leaked credentials, create a custom firewall rule or a rate-limiting rule that uses the Leaked Credentials Detection fields. See [Create a Custom Firewall Rule for an eCDN Zone](https://help.salesforce.com/s/articleView?id=cc.b2c_create_eCDN_firewall_rule.htm&type=5) and [Create a Rate Limiting Rule for an eCDN Zone](https://help.salesforce.com/s/articleView?id=cc.b2c_eCDN_create_rate_limiting_rule.htm&type=5).

Each ruleset takes an action when a request matches. For the eCDN WAFv2 Managed Ruleset, setting the action overrides the default action defined for each rule. To restore per-rule defaults, set the ruleset action back to **Default**. The OWASP WAFv2 Managed Ruleset uses the same actions except **Default**. The available actions are:

- **Default** (recommended) — use the action defined for each rule.
- **Managed Challenge**
- **Block**
- **JS Challenge**
- **Log**
- **Legacy Captcha**

_(image: WAF Rules on a B2C Commerce 26.10 instance showing the WAFv2 eCDN Managed Ruleset and the WAFv2 OWASP Managed Ruleset, including Anomaly Score Threshold and Paranoia Level)_

### eCDN WAFv2 Managed Ruleset

The eCDN WAFv2 Managed Ruleset is the current-generation ruleset the eCDN security team maintains for broad web application protection across your B2C Commerce applications. The eCDN WAFv2 Managed Ruleset is enabled by default and updated frequently to cover new vulnerabilities and reduce false positives.

Select the action to perform. The **Default** option is recommended.

_(image: WAFv2 eCDN Managed Ruleset action list showing Default, Block, Log, Managed Challenge, JS Challenge, and Legacy Captcha)_

### OWASP WAFv2 Managed Ruleset

The OWASP WAFv2 Managed Ruleset for the B2C Commerce eCDN mirrors the OWASP ModSecurity Core Rule Set (CRS) and is kept aligned with the latest upstream version. The OWASP WAFv2 Managed Ruleset is enabled by default. Rather than acting on a single rule, the ruleset assigns each incoming request a threat score. Each rule a request triggers adds to the score, and WAF performs the configured action when the cumulative score exceeds the threshold. Some rules affect the score more than others.

Configure these settings:

- **Paranoia Level** — PL1 (default), PL2, PL3, or PL4. Each rule is assigned a paranoia level; setting a level enables all rules up to and including the level you set. Higher levels add stricter protection but can block more legitimate traffic (false positives).
- **Anomaly Score Threshold** — the score at which the ruleset acts:
   
   - Low (60 and higher)
   - Medium (40 and higher — default)
   - High (25 and higher)
   
   A higher threshold value (High) makes the ruleset act on more requests; a lower threshold value (Low) requires more matching rules before it acts.
- **Action** — the action WAF performs when the threat score exceeds the threshold. See [Ruleset actions](#b2c_waf_managed_rulesets/actions).

_(image: WAFv2 OWASP Managed Ruleset with Paranoia Level open to PL1, PL2, PL3, and PL4. Action is Block, and Anomaly Score Threshold is Medium, 40 and higher.)_
