# eCDN WAF Managed Rulesets

_The embedded CDN (eCDN) web application firewall (WAF) protects your B2C Commerce storefront through three managed rulesets: the eCDN WAFv2 Managed Ruleset, the OWASP WAFv2 Managed Ruleset, and the eCDN WAFv2 Exposed Credentials Check. You enable and tune each ruleset per zone._

[Which Salesforce Commerce Product Do I Have?](https://help.salesforce.com/s/articleView?id=commerce.comm_what_product.htm)

The eCDN security team (or, for OWASP, the upstream project) updates the rules to cover new vulnerabilities and reduce false positives. You can turn each ruleset on or off and set the action it takes, but you can't customize individual rules within a ruleset. To enable and configure these rulesets for a zone, see [Configure WAF Settings for an eCDN Zone](https://help.salesforce.com/s/articleView?id=cc.b2c_configure_zone_waf_settings.htm&type=5).

Each ruleset takes an action when a request matches. Setting the action for a ruleset overrides the default action defined for each rule; to restore per-rule defaults, set the ruleset action back to **Default**. The available actions are the same for all three rulesets:

- **Default** (recommended) — use the action defined for each rule.
- **Managed Challenge**
- **Block**
- **JS Challenge**
- **Log**
- **Legacy Captcha**

_(image: Embedded CDN Settings showing the WAF managed rulesets)_

### eCDN WAFv2 Managed Ruleset

The eCDN WAFv2 Managed Ruleset is the current-generation ruleset the eCDN security team maintains for broad web application protection across your B2C Commerce applications. The eCDN WAFv2 Managed Ruleset is enabled by default and updated frequently to cover new vulnerabilities and reduce false positives.

Select the action to perform. The **Default** option is recommended.

_(image: eCDN WAFv2 Managed Ruleset settings)_

_(image: eCDN WAFv2 Managed Ruleset action setting)_

### OWASP WAFv2 Managed Ruleset

The OWASP WAFv2 Managed Ruleset for the B2C Commerce eCDN mirrors the OWASP ModSecurity Core Rule Set (CRS) and is kept aligned with the latest upstream version. The OWASP WAFv2 Managed Ruleset is enabled by default. Rather than acting on a single rule, the ruleset assigns each incoming request a threat score. Each rule a request triggers adds to the score, and WAF performs the configured action when the cumulative score exceeds the threshold. Some rules affect the score more than others.

Configure these settings:

- **Paranoia Level** — PL1 (default), PL2, PL3, or PL4. Each rule is assigned a paranoia level; setting a level enables all rules up to and including the level you set. Higher levels add stricter protection but can block more legitimate traffic (false positives).
- **Anomaly Score Threshold** — the score at which the ruleset acts:
   
   - Low (60 and higher)
   - Medium (40 and higher — default)
   - High (25 and higher)
   
   A higher threshold value (High) makes the ruleset act on more requests; a lower threshold value (Low) requires more matching rules before it acts.
- **Action** — the action WAF performs when the threat score exceeds the threshold. See [Ruleset actions](#b2c_waf_managed_rulesets/actions).

_(image: OWASP WAFv2 Managed Ruleset settings)_

### eCDN WAFv2 Exposed Credentials Check

> **Important:** Exposed Credentials Check is deprecated and isn't recommended for new configurations. Leaked Credentials Detection is a separate capability, and Exposed Credentials Check doesn't work with Leaked Credentials Detection. To act on leaked credentials, create a custom firewall rule or a rate-limiting rule that uses the Leaked Credentials Detection fields. See [Create a Custom Firewall Rule for an eCDN Zone](https://help.salesforce.com/s/articleView?id=cc.b2c_create_eCDN_firewall_rule.htm&type=5) and [Create a Rate Limiting Rule for an eCDN Zone](https://help.salesforce.com/s/articleView?id=cc.b2c_eCDN_create_rate_limiting_rule.htm&type=5).

The eCDN WAFv2 Exposed Credentials Check deploys an automated credential check on your B2C Commerce end-user authentication endpoints. For any credential pair, WAF looks up the credentials against a public database of stolen credentials for well-known Content Management System (CMS) applications. Unlike the other managed rulesets, this check is turned off by default.

Select the action to perform. The **Default** option is recommended.

_(image: eCDN WAFv2 Exposed Credentials Check settings)_

_(image: eCDN WAFv2 Exposed Credentials Check action setting)_
