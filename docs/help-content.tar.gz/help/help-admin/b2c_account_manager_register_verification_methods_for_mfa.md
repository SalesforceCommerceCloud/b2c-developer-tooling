# Register Verification Methods for Multi-Factor Authentication in B2C Commerce

_Multi-factor authentication (MFA) is an extra layer of protection beyond a single password._

[Which Salesforce Commerce Product Do I Have?](https://help.salesforce.com/s/articleView?id=commerce.comm_what_product.htm)

With MFA, you enter multiple pieces of evidence – or factors – to prove your identity. The first factor is your username and password combination (something you know). Additional factors are verification methods that you have in your possession, such as an authenticator app or security key. MFA is required for all Account Manager users and can’t be turned off. The first time you log in, you’re prompted to register a verification method for MFA. The registration process connects the method you choose to your Account Manager account. You must supply a registered verification method each time you log in. Register additional methods at any time from your account information in Account Manager.

> **Note:** We highly recommend registering two or more methods so you have a backup if you forget or lose your primary method. Register different types of methods (such as Salesforce Authenticator and a security key) or two instances of the same method type (such as two security keys or two different third-party time-based one-time password (TOTP) authenticator apps).
