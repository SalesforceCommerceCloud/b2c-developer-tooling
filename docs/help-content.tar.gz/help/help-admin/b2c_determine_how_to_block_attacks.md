# Determine How to Block Attacks in B2C Commerce

_While Salesforce B2C Commerce provides security protections, customers are responsible for configuring security controls and for not removing security controls that are enabled by default. You must consider all of these aspects to maintain the security of your B2C Commerce instance._

Keep the following security questions in mind while working with Salesforce B2C Commerce.

- How can you block attackers at the edge, preventing them from even being able to access your instance over the network?
- How can you make sure that an attacker can't read or modify sensitive information exchanged between shoppers and your site, or between users and Business Manager, such as credit card data and personally identifiable information (PII)?
- Are the shoppers and users who they claim to be?
- Are they authorized to perform the action they’re attempting to perform?
- Can an attacker limit or deny access to legitimate shoppers or users?
- If there's an attack, can you use audit logs to determine what happened?

To better understand B2C Commerce security concepts, it helps to understand the platform architecture. Take a look at the Salesforce B2C Commerce for Developers trail for more information.
