# B2C Commerce 2026 Deployment Schedule

_To uphold our commitment to customer trust and to make sure that our B2C Commerce releases meet our rigorous standards, we deploy the B2C Commerce major releases to customers in four phases. See the Deployment table for information about which instances are included in each major release phase._

B2C Commerce deployment dates are subject to change, but deployment typically happens within 1-2 weeks of the published date. We update these dates as soon as we’re aware of changes.

Production releases occur between 2:00 AM - 7:00 AM local Point of Delivery (POD) time.

On-Demand Sandbox releases occur in 2:00 AM - 7:00 AM windows:

- ODS-US - EST
- ODS-AP - JST
- ODS-EU - BST

| Deployment | 26.1 | 26.2 | 26.3 | 26.4 | 26.5 | 26.6 | 26.7 | 26.8 | 26.9 | 26.1 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Included in Salesforce Release Notes | Spring ’26 | Spring ’26 | Spring ’26 | Spring ’26 | Spring ’26 | Summer ’26 | Summer ’26 | Summer ’26 | Summer ’26 | Winter ’27 |
| Preview | Dec-04 (Thu) | Jan-27 (Tue) | Feb-24 (Tue) | Mar-24 (Tue) | Apr-21 (Tue) | May-19 (Tue) | Jun-23 (Tue) | Jul-21 (Tue) | Aug-18 (Tue) | Sep-29 (Tue) |
| Preview Update | Dec-18 (Thu) | Feb-03 (Tue) | Mar-03 (Tue) | Mar-31 (Tue) | Apr-28 (Tue) | May-28 (Thu) | Jun-30 (Tue) | Jul-28 (Tue) | Aug-25 (Tue) | Oct-06 (Tue) |
| Major: AUS PODs | Jan-06 (Tue) | Feb-10 (Tue) | Mar-10 (Tue) | Apr-07 (Tue) | May-05 (Tue) | Jun-09 (Tue) | Jul-07 (Tue) | Aug-04 (Tue) | Sep-01 (Tue) | Oct-13 (Tue) |
| Major: JAPAN PODS & PODS 283/282, 290/291, 293/292, 295/294 | Jan-13 (Tue) | Feb-12 (Thu) | Mar-12 (Thu) | Apr-09 (Thu) | May-07 (Thu) | Jun-11 (Thu) | July-09 (Thu) | Aug-06 (Thu) | Sep-03 (Thu) | Oct-15 (Thu) |
| Major: EMEA PODs **Excluding** PODs 284/285, 270/271, 240/241, 330/331 | Jan-22 (Thu) | Feb-19 (Thu) | Mar-19 (Thu) | Apr-16 (Thu) | May-14 (Thu) | Jun-18 (Thu) | Jul-16 (Thu) | Aug-13 (Thu) | Sep-24 (Thu) | Oct-22 (Thu) |
| Major: **Remaining** AMER PODs & EMEA PODs 284/285, 270/271, 240/241, 330/331 | Jan-29 (Thu) | Feb-26 (Thu) | Mar-26 (Thu) | Apr-23 (Thu) | May-21 (Thu) | Jun-25 (Thu) | Jul-23 (Thu) | Aug-20 (Thu) | Oct-01 (Thu) | Oct-29 (Thu) |

For questions about the B2C Commerce global release process, see the [Agentforce Commerce B2C Global Release Overview](https://help.salesforce.com/s/articleView?id=000352370&language=en_US&mode=1&type=1).
