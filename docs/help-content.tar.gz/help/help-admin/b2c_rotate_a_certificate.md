# Renew a Certificate for B2C Commerce

_Development, staging, and production zone certificates require renewal when you use self-managed SSL certificates._

> **Note:** Renewal is not required for [eCDN managed SSL certificates](https://help.salesforce.com/s/articleView?id=cc.b2c_add_managed_ssl_certificates.htm) as they are auto-renewed. Enable Automatic Certificates on an Existing Hostname [eCDN Automatic Certificates](https://developer.salesforce.com/docs/commerce/commerce-api/guide/cdn-zones-automatic-certs.html).

When your self-managed SSL certificate expires, or you update the hostnames assigned to an SSL certificate, update the certificate in Business Manager or with the CDN zones API

Use the CDN Zones API for certificate rotation. See, [CDN Zones](https://developer.salesforce.com/docs/commerce/commerce-api/references/cdn-api-process-apis?meta=Summary) API.

1. Obtain a new certificate via your CA of choice.
2. Use the CDN Zones API with these methods. See [getZonesInfo](https://developer.salesforce.com/docs/commerce/commerce-api/references/cdn-api-process-apis?meta=getZonesInfo).
3. To retrieve the staging zone ID, use the `GET /zones/info` endpoint. See [getZonesInfo](https://developer.salesforce.com/docs/commerce/commerce-api/references/cdn-api-process-apis?meta=getZonesInfo).
4. To get the ID of the certificate that you’re rotating, use the `GET/zones/{zoneId}/certificates` See [getCertificates](https://developer.salesforce.com/docs/commerce/commerce-api/references/cdn-api-process-apis?meta=getCertificates).
5. Use the `PATCH /zones/{zoneid}/certificates/{certificateId}` endpoint for each custom hostname to which the certificate is installed. See [updateCertificate](https://developer.salesforce.com/docs/commerce/commerce-api/references/cdn-api-process-apis?meta=updateCertificate)
