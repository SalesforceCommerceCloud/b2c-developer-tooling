# Complete Post-Migration Tasks

_After you migrate B2C Commerce site traffic to eCDN, coordinate with B2C Commerce Engineering to validate the traffic flow, revert the origin certificate, and create the staging Business Manager zone._

[B2C Commerce Engineering](https://developer.salesforce.com/docs/commerce/b2c-commerce/overview) services include the lockdown protections that protect your production and development instances. Business Manager supports eCDN for staging instances, so that Business Manager traffic goes through only your Business Manager hostname — for example, `staging-<realm>-<customer>.demandware.net`.

1. Revert to the *.demandware.net certificate at the origin. This step applies to custom certificates installed to the POD for the staging instance.

   B2C Commerce Engineering validates that traffic is flowing through eCDN for the configured hostnames. After validation, B2C Commerce Engineering reverts the certificate at the origin level to the standard *.demandware.net certificate. The Salesforce Commerce API (Shopper Commerce API (SCAPI)) can then connect to your staging instance.
2. Create and activate a staging Business Manager zone.

   B2C Commerce Engineering creates and activates the Business Manager zone for your implementation.
   
   If you use the self-service steps to create an eCDN zone and certificate, contact Salesforce Commerce Cloud (SFCC) Support. They contact B2C Commerce Engineering to create and activate a staging Business Manager zone.
   
   If you implement an existing custom certificate for your staging instance, B2C Commerce Engineering creates and activates the staging Business Manager zone automatically. If you don't want this, contact [Salesforce Support](https://help.salesforce.com/s/articleView?id=000318530&type=1&language=en_US).
