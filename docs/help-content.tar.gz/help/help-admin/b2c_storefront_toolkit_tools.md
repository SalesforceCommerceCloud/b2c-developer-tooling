# Storefront Toolkit Tools

_The B2C Commerce Storefront Toolkit provides six tools._

| Toolkit Icon | Tool |
| --- | --- |
| _(image: Page info)_ | **Page Info**. Move your mouse over the page to display the templates, controllers, and pipelines associated with a component. |
| _(image: Content info)_ | **Content Info**. Move your mouse over the page to display links to the product, content asset, or content slot associated with the page component. Click the link to open the content for editing in Business Manager. |
| _(image: Search info)_ | **Search Info**. Display sorting rule and search scoring information for a search result. |
| _(image: Cache info)_ | **Cache Info**. Icons on the page indicate cached and uncached page components. A red icon indicates an uncached component. A green icon indicates a cached component. Click a cache icon to display more information about the caching for that component. |
| _(image: Request log)_ | **Request Log**. Displays log entries related to the most recent request to the server from the storefront. Log entries related to requests to the server made while the Request Log is open are also displayed. |
| _(image: Preview setting)_ | **Preview Settings**. View the storefront as it appears at a specific date and time.  Specify a customer group or source code and see how the storefront looks when logged in as a customer of the group or using the source code.  To preview an A/B test on a storefront, enter the A/B test and A/B test segment values.  You can also enable promotions tracing to test promotions. |
