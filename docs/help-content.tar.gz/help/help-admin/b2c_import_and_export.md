# Import and Export in B2C Commerce

_The B2C Commerce application environment is designed to facilitate backend integration. You can import data from other systems into the B2C Commerce environment and export B2C Commerce data to backend systems._

To transfer data between a B2C Commerce instance and a system such as an inventory, ordering, or marketing system, use import and export and not data replication. Import processes an external file and uses the data to populate the database. Import is sometimes used for frequently updated import feeds, such as pricing feeds. Use export to extract data from the B2C Commerce database and create XML files that can be used as feeds for external systems.

Site Import and Export are also used to move configuration and setting information for a site from one instance to another.

### Data and Code Replication vs. Import and Export

You use both the import and export feature and data replication to populate instance databases that is used by your site. However, import and export and data replication are different mechanisms.

Replication is used to move data from one instance to another, after the data is already in a B2C Commerce database. Import and export enable you to move data to and from external systems.

Data replication creates a copy of the data from the originating instance database. It creates the copy at a new location in the target instance database, without replacing the original data. When data replication is complete, you switch from the existing data to the new data on the target system. The change to a site is instantaneous, rather than gradual.

### Catalog Feed Feature vs. Import and Export

The catalog feed feature in Business Manager isn't used to import catalog or product data. It isn't part of the import and export framework. The catalog feed feature processes third-party files.
