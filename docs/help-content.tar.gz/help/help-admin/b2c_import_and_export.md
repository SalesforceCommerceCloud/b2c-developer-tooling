# Import and Export in B2C Commerce

_The B2C Commerce application environment is designed to facilitate backend integration. You can import data from other systems into the B2C Commerce environment and export B2C Commerce data to backend systems._

To transfer data between a B2C Commerce instance and a system such as an inventory, ordering, or marketing system, use import and export and not data replication. Import processes an external file and uses the data to populate the database. Import is sometimes used for frequently updated import feeds, such as pricing feeds. Use export to extract data from the B2C Commerce database and create XML files that can be used as feeds for external systems.

Site Import and Export are also used to move configuration and setting information for a site from one instance to another.

### Data and Code Replication vs. Import and Export

You use both the import and export feature and data replication to populate instance databases that is used by your site. However, import and export and data replication are different mechanisms.

Replication is used to move data from one instance to another, after the data is already in a B2C Commerce database. Import and export enable you to move data to and from external systems.

Data replication creates a copy of the data from the originating instance database. It creates the copy at a new location in the target instance database, without replacing the original data. When data replication is complete, you switch from the existing data to the new data on the target system. The change to a site is instantaneous, rather than gradual.

### Catalog Feed Feature vs. Import and Export

The catalog feed feature in Business Manager isn't used to import catalog or product data. It isn't part of the import and export framework. The catalog feed feature processes third-party files.

## Related Content

- [Import/Export Checklist in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_import_export_checklist.htm&type=5)
  We provide a checklist for the tasks you must perform to create and maintain import and export feeds for your sites.

- [Business Manager Import and Export Privileges in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_business_manager_import_export_privileges.htm&type=5)
  Business Manager provides many levels of system privileges, and with that comes many separate importing and exporting modules. However, the functionality presented in the Business Manager is similar for each module.

- [Overview of the Import/Export Process in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_overview_of_the_import_export_process.htm&type=5)
  Follow a set of basic steps to complete import and export.

- [Import/Export Methods in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_import_export_methods.htm&type=5)
  B2C Commerce offers several ways you can add or extract data from your instance database.

- [File Formats in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_file_formats.htm&type=5)
  B2C Commerce only accepts XML import files that conform to B2C Commerce schema files. Older versions of B2C Commerce allowed preprocessing of comma-separated value (CSV) files, but B2C Commerce no longer supports this feature.

- [Import and Export Transaction Handling and Feed Size in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_import_export_transaction_handling_and_feed_size.htm&type=5)
  B2C Commerce designs standard imports to handle feeds of arbitrary sizes. As with every transactional system, the size of a transaction is bounded. Standard behavior for imports that 's triggered through the Business Manager and triggered when you execute an import pipelet, is to commit after each object.

- [Import Modes in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_import_modes.htm&type=5)
  For import processes, specify an *import mode* to define how to interpret the data within a feed. Some modes aren’t supported for some object types. The import mode, defined for the import process, applies to all objects within the feed. Import modes apply to all import files defined by B2C Commerce schemas.

- [Removing Outdated Objects in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_removing_outdated_objects.htm&type=5)
  How you remove outdated objects depends on whether you enrich the data from your backend system with more attributes in Business Manager. It also depends on the type of business object you want to remove. B2C Commerce generally recommends creating feeds of objects to delete, imported using the DELETE mode, to safely remove all types of objects, regardless of whether they have enriched data or not.

- [Recovery and Rollback in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_recovery_and_rollback.htm&type=5)
  Detect problems and recover from errors during import and export processes.

- [Import/Export Analytics and Reporting in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_import_export_analytics_and_reporting.htm&type=5)
  B2C Commerce reports on import and export processes via the Reports & Dashboards Technical dashboard, system logs, and import and export logs. System logs provide general information about the system and APIs. Import and export logs, in contrast, provide information that is specific to import/export processes (whether through Business Manager or via pipelets).

- [Import/Export Error Handling in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_import_export_error_handling.htm&type=5)
  All import, export, and validation processes create log files. Log files are accessible through WebDAV on the import and export share in your cartridge.

- [Import Localization in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_import_localization.htm&type=5)
  Across all B2C Commerce import feeds, B2C Commerce processes `xml:lang` attributes for all localizable elements the same way.

- [Import/Export Site-Specific Attributes in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_import_export_site_specific_attributes.htm&type=5)
  Site-specific product attributes require specific import/export handing, specifically for metadata.xsd and catalog.xsd.

- [Import/Export Data Replication in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_import_export_data_replication.htm&type=5)
  Import and export data lives at the site level in its own file system, so it isn't replicated.

- [Importing or Exporting SiteGenesis Data in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_importing_or_exporting_site_genesis_data.htm&type=5)
  The SiteGenesis application doesn't include import and export feed examples. However, if you run Site Import/Export (export) on the SiteGenesis data, the files exported are valid import files. These import files contain the SiteGenesis data.

- [Using Site Import/Export to Copy Instances and Development Testing in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_using_site_import_export_to_copy_instances.htm&type=5)
  Use site import and export to populate a new sandbox instance with data from an existing instance.

- [Using Site Import/Export for Development Testing in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_using_site_import_export_for_development_testing.htm&type=5)
  When multiple developers work on one or more sites, make sure that they all have the same data in their systems. They can use Site Import/Export to set up multiple sandboxes with the same configuration.

- [Creating Data Files for Import in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_creating_data_files_for_import.htm&type=5)
  When the data structure and scope is understood and documented, map how to translate existing data into the B2C Commerce format. Also, map how to export the data from the B2C Commerce environment back into the customer's environment.

- [Delta Exports in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_delta_exports.htm&type=5)
  Export data for certain business entities as deltas rather than as full datasets.

- [Transferring Files to an Instance in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_transferring_files_to_an_instance.htm&type=5)
  The first step in importing a feed is transferring it from an external server to the instance you want to import it into. Only XML from within a B2C Commerce instance can be uploaded or downloaded via APIs.

- [Importing Data into and Exporting Data from a B2C Commerce Instance Database](https://help.salesforce.com/s/articleView?id=cc.b2c_importing_data_into_and_exporting_data_from_the_instance_database.htm&type=5)
  When you have transferred files to your instance, you are ready to import data into the B2C Commerce database on the instance.

- [Debugging Import/Export in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_debugging_import_export.htm&type=5)
  Debug a pipeline called by a job. \

- [Using a Pipeline to POST Data in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_using_a_pipeline_to_post_data.htm&type=5)
  We have provided sample code to post data results in an HTTP client using B2C Commerce script.

- [Best Practices for Import/Export in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_best_practices_for_import_export.htm&type=5)
  We recommend that you follow established best practices for import and export.

- [XLS to XML Workbooks for Bulk Data Imports in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_import_resources.htm&type=5)
  We've prepared some XLS to XML workbook resources to help you optimize your users’ experience with bulk data imports.

- [Troubleshooting Import/Export in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_troubleshooting_import_export.htm&type=5)
  If attempts to connect to an FTP server using the FTPClient results in a "java.net.SocketTimeoutException", contact customer support to open access to the FTP port.

- [Generic Mapping in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_generic_mapping.htm&type=5)
  Use the generic mapping capability to map keys to values, with the mapping stored in a high-performance data store. Generic mapping supports large datasets, with high performance for lookup.

- [Import and Export Object Cheatsheet in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_import_export_object_cheatsheet.htm&type=5)
  Learn about and access B2C Commerce object type-specific import and export capabilities.

- [Services Import/Export in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_services.htm&type=5)
  The services.xsd schema file describes all web service profile and credential data. B2C Commerce encrypts credentials during a services export.

- [URL Rules Object Import/Export in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_url_rules_object_import_export.htm&type=5)
  Use the redirecturl.xsd schema file to import URL redirects.

- [A/B Test Object Import and Export in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_ab_testing_object_import_export.htm&type=5)
  Use the abtest.xsd schema to import and export A/B tests.

- [Cache Settings Object Import and Export in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_cache_settings_import_export.htm&type=5)
  Use the cache settings object to manage static cache time to live, cache enablement, and page cache partitions.

- [Catalog Object Import/Export in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_catalog_object_import_export.htm&type=5)
  Import an entire catalog at once; the import operation includes the catalog and any categories and products within the catalog. Export works similarly; you export the entire catalog at once.

- [Content and Content Library Folder Object Import and Export in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_content_and_content_library_folder_object_import_export.htm&type=5)
  Use the library.xsd schema to import and export content and content libraries.

- [Content Slot Object Import/Export in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_content_slot_object_import_export.htm&type=5)
  Using Business Manager, import existing content slot configurations to use with a new instance, and export them for transfer between instances. The slots themselves aren’t imported or exported, but page templates define them (in UX Studio). Slot configurations only reference those slots (using the slot ID). Within Business Manager, the elements in the slot.xsd control the visibility of a slot.

- [Coupons and Coupon Code Object Import/Export in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_coupons_and_coupon_code_object_import_export.htm&type=5)
  Coupons are imported as XML and exported as comma-separated value (CSV) files. Use the coupon.xsd schema file to import merchant-generated coupons.

- [Customer List Object Import/Export in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_customer_list_object_import_export.htm&type=5)
  The customerlist2.xsd contains the meta information and security preferences of the list itself, and all the customers. Each file represents one customer list if you perform a site export and select all the lists. Each file takes the name of the list itself, for example, SiteGenesis.xml for the SiteGenesis customer list.

- [Customer Group Object Import/Export in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_customer_group_object_import_export.htm&type=5)
  You can use the elements in the customergroup.xsd and considerations when creating values for them.

- [Custom Object Import/Export in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_custom_object_object_import_export.htm&type=5)
  Gain a better understanding of the elements in the customobject.xsd and considerations when creating values for them.

- [Custom Metadata Object Import/Export in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_custom_metadata_object_import_export.htm&type=5)
  When using the system meta data import functionality, the entire definition is replaced. For example, suppose you have a custom group with three attribute groups and you want to add another attribute group to make four attribute groups. In this case, specify all four attribute group definitions in the import file.

- [Geolocation Object Import and Export in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_geolocation_object_import_export.htm&type=5)
  The geolocation.xsd schema supports importing store geolocations based on ZIP code.

- [Gift Certificate Object Import and Export in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_gift_certificate_object_import_export.htm&type=5)
  Use the giftcertificate.xsd schema file to import gift certificates.

- [Inventory List Object Import and Export in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_inventory_list_object_import_export.htm&type=5)
  Use the inventory.xsd schema file to import or export inventory lists.

- [Order Object Import and Export in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_order_object_import_export.htm&type=5)
  For integration with external systems, and for working with test data, B2C Commerce can export and import order data as XML.

- [Payment Method Information Import and Export in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_payment_method_information_import_export.htm&type=5)
  Import or export payment method information (schema file `paymentmethod.xsd`) through site import and export, or directly from Merchant Tools, Ordering, Import & Export in Business Manager. The Ordering module handles payment methods but not payment processors.

- [Payment Processor Information Import and Export in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_payment_processor_information_import_export.htm&type=5)
  Import or export payment processor information (schema file `paymentprocessor.xsd`) only through site import and export, from Administration, Site Development, Site Import & Export in Business Manager. The Ordering module doesn't handle payment processors, unlike payment methods.

- [Price Book Object Import/Export in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_pricebook_object_import_export.htm&type=5)
  Use the pricebook.xsd schema file to import and export price books, including the delete, delete-all, UPDATE, REPLACE, and MERGE modes that control how price entries are added or removed.

- [Product List Object Import/Export in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_product_list_object_import_export.htm&type=5)
  Use the productlist.xsd schema file to import and export product lists.

- [Promotion and Campaign Object Import and Export in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_promotion_and_campaign_object_import_export.htm&type=5)
  Use the promotion.xsd schema file to import campaigns and promotions. Promotions can be assigned to multiple campaigns.

- [Schedule Object Import/Export in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_schedule_object_import_export.htm&type=5)
  Use the schedules.xsd schema file to import schedules.

- [Search Object Import and Export in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_search_object_import_export.htm&type=5)
  Use the Search object to import and export search-related elements including stop words, search term completion suggestions, synonyms, hypernyms, redirects, searchable attributes, search preferences, and sorting rules.

- [Shipping Method Object Import/Export in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_shipping_method_object_import_export.htm&type=5)
  Use the shipping.xsd schema file to import shipping methods.

- [Site Import/Export in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_site_import_export.htm&type=5)
  The site.xsd schema file describes the structure of data that is exported from an instance to a zip file, or imported from a .zip file. The site.xsd file describes all site-related data and global, non-site-related data (that is, organization-level data, such as shipping methods).

- [Sorting Rule Import/Export in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_sorting_rule_import_export.htm&type=5)
  The sort.xsd schema defines sorting rules, dynamic attributes, and sorting options.

- [Source Code Object Import/Export in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_source_code_object_import_export.htm&type=5)
  Import and export source code groups and source codes using XML documents formatted with the sourcecode.xsd and promotion.xsd schemas.

- [Store Information Import/Export in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_store_information_import_export.htm&type=5)
  Use the store.xsd schema file to import store information.

- [Tax Table Object Import/Export in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_tax_table_object_import_export.htm&type=5)
  Use the tax.xsd schema file to import tax rates.

- [Wish List or Order Status Object Import/Export in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_wishlist_object_import_export.htm&type=5)
  There’s no built-in support for importing wish list objects or order status objects. However, you can develop a proprietary XML format and use the B2C Commerce script or a pipelet to update these objects.
