# Examine Search Results Using the Search Information Tool in B2C Commerce

_The Search Information Tool provides information about how customer queries are processed, including information about hypernyms, compound words, synonyms, negative search terms, and stemming. The tool shows the sorting rule used to determine search results, the sorting criteria within the rule, and the sorting criteria values for each search result. The tool also shows if refinements are used to navigate to the search results and the text relevance for the search result._

## Related Content

- [Enable the Search Information Tool for Storefront Toolkit in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_implementing_the_search_information_tool.htm&type=5)
  To enable the Search Information tool, your site must correctly implement the `<isobject>` tag in the storefront Internet Store Markup Language (ISML) templates.

- [Open the Search Information Tool in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_using_the_search_information_tool.htm&type=5)
  Open the Search Information Tool from the search icon in the Storefront Toolkit.

- [Search Results Window in the Search Information Tool in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_search_results_window.htm&type=5)
  The Search Results window shows basic information about the search results. This window appears only if your site has implemented the `isobject` Internet Store Markup Language (ISML) tag appropriately.

- [Product Search Model Window in the Search Information Tool in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_search_query_window.htm&type=5)
  The Product Search Model window shows basic information about how the search model handled the search query. This window appears only if your site implements the `isobject` Internet Store Markup Language (ISML) tag appropriately.
