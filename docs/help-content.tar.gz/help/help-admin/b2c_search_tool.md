# Examine Search Results Using the Search Information Tool in B2C Commerce

_The Search Information Tool provides information about how customer queries are processed, including information about hypernyms, compound words, synonyms, negative search terms, and stemming. The tool shows the sorting rule used to determine search results, the sorting criteria within the rule, and the sorting criteria values for each search result. The tool also shows if refinements are used to navigate to the search results and the text relevance for the search result. This topic applies to B2C Commerce._
