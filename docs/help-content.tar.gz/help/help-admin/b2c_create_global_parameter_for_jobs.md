# Create or Change a B2C Commerce Job Parameter

_A job parameter is a saved value that a B2C Commerce job reuses on more than one step._

[Which Salesforce Commerce Product Do I Have?](https://help.salesforce.com/s/articleView?id=commerce.comm_what_product.htm)

If you change the value of a parameter, every step that uses it updates, so you don't edit each step. For example, create a parameter for ReplicationProcessID and set it to the ID of a specific replication process. If you change the value of ReplicationProcessID, B2C Commerce updates all steps that include that parameter.

Before you can create or change a job parameter, create the job and add its flows and steps. See [Create and Schedule a B2C Commerce Job](https://help.salesforce.com/s/articleView?id=cc.b2c_create_job.htm&type=5) and [Add Flows and Steps for B2C Commerce Jobs](https://help.salesforce.com/s/articleView?id=cc.b2c_add_job_flows_and_steps.htm&type=5).

Create a job parameter from a field on a job step. Use it only for fields of the same type. When you open Job Parameters for a field, the list shows only parameters of that type. For example, a parameter created for a true or false field does not appear for a text field. You can change a parameter later, after you create it.

In B2C Commerce, from the App Launcher _(image: App Launcher)_, find and select **Administration > Operations > Jobs**, and then open the job.

1. Create a job step or select an existing one.
2. On the job page, click the **Job Steps** tab, and then click the job step for which you want to create a parameter.
3. In the Select and Configure Step window, click **Job Parameters** for the applicable job step.
4. In the Job Parameters window, click **Add Job Parameter**.
5. Enter a unique name for the parameter.

   Don't name the parameter SiteScope. That name is reserved for flows with scope of Site Parameter.
6. Enter a value for the parameter.
7. Click **Save**.
8. Click **Assign**.
9. To use the parameter in another job step:

   1. Click the step that you want to use the parameter for.
   2. Click **Job Parameters**.
   3. Select the parameter to use.
   4. Click **Assign**.
10. Change a job parameter.

   When you change a job parameter value, B2C Commerce updates every step that includes the parameter.
   
   1. On the **Job Steps** tab, select **Job Parameters**.
   2. Select the parameter you want to change and enter the new value.
   3. Click **Save**.
