# Create a Job Parameter

_Create a parameter to use in different job steps. For example, create a parameter for ReplicationProcessID and set it to the ID of a specific replication process. Then use the parameter in different job steps. If you need to use a different replication process, change the value of the parameter, and B2C Commerce updates all steps that include the parameter. Overwrite the value of a job parameter if you use Open Commerce API (OCAPI) to execute a job._

Create a job parameter within a job step. Use the job parameter only for step parameters that have the same type as the parameter for which you originally set the job parameter. For example, if you create a job parameter for a step parameter that requires a Boolean true or false value, you can't use that job parameter to specify a value that requires a text string entry.

1. Create a job step or select an existing one.
2. Click the field that you want to create a parameter for.
3. Click **Job Parameters**.
4. Click **Add Job Parameter**.
5. Enter a unique name for the parameter.

   Don't name the parameter SiteScope. That name is reserved for flows with scope of Site Parameter.
6. Enter a value for the parameter.
7. Click **Save**.
8. Click **Assign**.
9. To use the parameter in another job step:

   1. Click the field that you want to use the parameter for.
   2. Click **Job Parameters**
   3. Select the parameter to use.
   4. Click **Assign**.
