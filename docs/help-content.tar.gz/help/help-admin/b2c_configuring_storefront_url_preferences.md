# Configure Storefront URL Preferences

_Enable your SEO URL rules for a site._

|  |
| --- |
| Available in: **B2C Commerce** |

1. In Business Manager, click App Launcher _(image: App Launcher)_, and then select **Merchant Tools >  *site*  > Site Preferences > Storefront URLs**.
2. Select **Enable Storefront URLs**.
3. Select **Copy Source URL Parameters**.

   This setting applies to URL redirect objects with the Copy Source URL Parameter value `Default`.
4. Select **Enforce HTTPS**.

   This setting forces URL generation to use HTTPS protocol only. Incoming requests using HTTP are automatically redirected to HTTPS. If the global preference Enforce HTTPS setting is enabled, you can't modify this setting for a site.
5. Click **Apply**.
6. After you’ve configured and tested your storefront URLs, investigate whether you want to change the following:

   | Option | Description |
   | --- | --- |
   | Code | If you use the Salesforce B2C Commerce SEO Support module without custom code for SEO, no code changes are necessary to take advantage of this feature. If you have custom code or have other integrations for SEO, you can alter your custom code to work with the feature. |
   | Canonical links | B2C Commerce best practice is to create canonical links for categories using the `URLUtils` method. If you used the `URLUtils` method, no changes to code are necessary. However, if you have hard-coded canonical links in your templates, update them to use your new URLs. |
   | Content links | To make sure that links don't require updates for the new URLs, check links in your content assets. If you’re using the content link functions, no updates are needed. However, if you have included hard-coded links in your content assets, update these links. |
   | URL redirects | Check your URL redirects to make sure they don't require adjustment for your new URLs. If the redirects are outdated or conflict with your new URLs, update them. |
   | Static mappings and mapping rules | To make sure that your redirects don't require adjustment for your new URLs, check your URL mappings.   If your old URLs now match the new storefront URLs, a redirect is no longer necessary. |
   | Product ID search | Make sure that the product ID search works as you expect if customers enter the product ID as it appears in the URL. |
   | Sitemap | Create a sitemap that includes the SEO URLs. |
7. To view SEO URLs:

   | Option | Description |
   | --- | --- |
   | In Business Manager | After you configure SEO URLs, validate the URL Rule and B2C Commerce runs a job in the background to generate the URLs. See potential URL conflicts on the URL Rules page General tab. |
   | In the browser | When the URLs are generated, you can view them in your browser. In your storefront, hover over a category link to see the URL in the status bar. If you click the link, you can see the URL at the top of the browser. |
