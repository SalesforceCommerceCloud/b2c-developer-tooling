# Secure Logging in B2C Commerce

_Salesforce B2C Commerce logs are stored securely and are accessible only to users in the `site_admin` or `developer` roles. Logs are accessible via the web interface or over WebDAV. Consider this when you decide what types of information to log._
