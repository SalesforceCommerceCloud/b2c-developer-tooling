# Log Center Dashboard

_The B2C Commerce Log Center dashboard is populated based on your Account Manager tenant filters and realm assignment. Users with Admin and Support roles can set the dashboard to show data for any company realm. The dashboard's default settings shows a histogram of the top stack traces over the last ten days. To show the exact count for each stack trace, hover over the bar in the chart._

Other dashboard options include:

- **View individual stack traces: **Click the horizontal label in the histogram for the stack trace you want to view
- **Search messages: **Click Search All Messages in the listed stack trace. The Search page displays the histogram for the stack trace and the search results
- **Toggle time filters: **Click the colored dates at the bottom of the histogram. The histogram shows the stack traces for the selected time
- **Filter stack traces: **Set the stack trace filters to select by realms (admin only) instance types, and service
- **Initiate a search: **To run a search with the current filter settings, click **Show Filtered Results**

To switch between geographic regions, use the dropdown list in the top right corner of the page.

Here's an example of the dashboard.

_(image: View of the Log Center dashboard)_
