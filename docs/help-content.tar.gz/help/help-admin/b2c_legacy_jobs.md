# Legacy Jobs

_We recommend that you use the new job framework to create and manage jobs, but the legacy, deprecated functionality is also available in Business Manager. This topic applies to B2C Commerce._

The new jobs framework has many advantages.

- Use preconfigured steps that require no coding.
- Developers can create custom job steps using their preferred IDE to write a CommonJS module.
- Use flows to set up parallel execution of job steps.
- Start and monitor jobs using OCAPI (Open Commerce API).
- Monitor the progress of jobs in Business Manager.
