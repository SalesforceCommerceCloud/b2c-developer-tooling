# Legacy B2C Commerce Jobs

_A legacy job runs a pipeline and is still available under Jobs (Deprecated). Use the new job framework to create and manage jobs._

[Which Salesforce Commerce Product Do I Have?](https://help.salesforce.com/s/articleView?id=commerce.comm_what_product.htm)

A legacy job runs a pipeline. Legacy jobs are listed at **Administration > Operations > Jobs (Deprecated)**.

The new job framework has many advantages.

- Use ready-made steps that require no coding.
- Developers can create custom job steps using their preferred IDE to write a CommonJS module.
- Use flows to set up parallel execution of job steps.
- Start and monitor jobs using Open Commerce API (OCAPI).
- Monitor the progress of jobs in Business Manager.

A legacy custom job that has been migrated has flows, appears on the Jobs list, and is no longer a legacy job.

## Related Content

- [Create a Legacy B2C Commerce Job](https://help.salesforce.com/s/articleView?id=cc.b2c_create_job_legacy.htm&type=5)
  Legacy B2C Commerce jobs use pipelines that a developer creates using the UX Studio plug-in to the Eclipse IDE. This functionality is available but is deprecated. Create jobs with the new job framework.
