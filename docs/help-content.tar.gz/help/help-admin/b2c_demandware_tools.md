# B2C Commerce Tools

_If you have the correct permissions assigned to you, you can access the B2C Commerce tools. To access B2C Commerce tools, click App Launcher or press Command+k (macOS) or Ctrl+k (Windows), and move between the tools._

- Business Manager--Configure storefronts in real time. Categorize, price, search, display, navigate, and promote merchandise.
- Control Center--Gives your IT staff operational control over your site, such as starting instances, and managing users.
- Account Manager--Lets your IT staff create user accounts on B2C Commerce, grant and revoke user access to B2C Commerce instances.
