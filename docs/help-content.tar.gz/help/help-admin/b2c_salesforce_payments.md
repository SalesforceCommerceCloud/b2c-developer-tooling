# Salesforce Payments for B2C Commerce

_Salesforce Payments is a plug-in for the B2C Commerce Storefront Reference Architecture (Salesforce Reference Architecture (SFRA)) sites. Salesforce Payments offers an easy-to-use payment solution that quickly and seamlessly collects payments. It includes back-end and front-end components that support payment services offered through Adyen, Stripe, and PayPal._
