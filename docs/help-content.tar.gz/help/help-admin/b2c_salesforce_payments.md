# Salesforce Payments for B2C Commerce

_Salesforce Payments is a plug-in for the B2C Commerce Storefront Reference Architecture (Salesforce Reference Architecture (SFRA)) sites. Salesforce Payments offers an easy-to-use payment solution that quickly and seamlessly collects payments. It includes back-end and front-end components that support payment services offered through Adyen, Stripe, and PayPal._

## Related Content

- [Salesforce Payment Platforms and Services for B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_salesforce_payments_platforms_services.htm&type=5)
  Salesforce Payments supports these Payment Service Providers (PSPs) and payment methods for B2C Commerce.

- [Set Up Salesforce Payments for B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_setting_up_salesforce_payments.htm&type=5)
  Salesforce Payments is a native checkout solution that supports multiple payment methods and payment gateways such as Adyen, Stripe, and PayPal. Salesforce Payments is available for use with Storefront Reference Architecture (SFRA) or Composable Storefronts.

- [Install the Salesforce Payments Plug-In for a B2C Commerce Salesforce Reference Architecture (SFRA) Site](https://help.salesforce.com/s/articleView?id=cc.b2c_install_salesforce_payment_plugin.htm&type=5)
  The Salesforce Payments plug-in supports multiple payment methods and third-party payment gateways, streamlining a shopper’s checkout experience. To set up the Salesforce Payments plug-in for a B2C Commerce Storefront Reference Architecture (SFRA) site, make sure you have access to the Salesforce B2C Commerce repositories on GitHub.

- [Salesforce Payments Platform Configuration for B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_salesforce_payments_platform_configuration.htm&type=5)
  To use the Salesforce Payments plug-in with your B2C Commerce Storefront Reference Architecture (Salesforce Reference Architecture (SFRA)) site, configure your site with Adyen, Stripe, and PayPal.

- [Salesforce Payments B2C Commerce Storefront Settings](https://help.salesforce.com/s/articleView?id=cc.b2c_salesforce_payments_storefront_settings.htm&type=5)
  To configure your storefront payment experience, use the Business Manager Payments module for B2C Commerce. Select express and multi-step payment methods, and the payment services for each method.

- [Salesforce Payments Settings for B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_salesforce_payments_settings.htm&type=5)
  Use the B2C Commerce Salesforce Payments Settings to configure instance status, payment card capture timing, and payment card credential storage for your site.

- [Link Salesforce Payments for B2C Commerce with Salesforce Order Management](https://help.salesforce.com/s/articleView?id=cc.b2c_link_salesforce_payments_with_som.htm&type=5)
  To integrate your existing B2C Commerce merchant account with Salesforce Order Management, first link your B2C merchant account to a merchant account and a Payment Gateway record for Salesforce Payments on the core Salesforce platform. The same Stripe or PayPal account you established for your B2C merchant account gets linked to the new records on the core platform.

- [Customer Object Import and Export for Payments with B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_customer_object_impex_for_salesforce_payments.htm&type=5)
  For Payments with B2C Commerce, use the Customer Object (customer.xsd) to import and export site-specific data about payment customers. See Customer Object Import and Export for Customer object details.

- [Salesforce Payments on SiteGenesis](https://help.salesforce.com/s/articleView?id=cc.b2c_salesforce_payments_on_site_genesis.htm&type=5)
  A successful implementation of Salesforce Payments on SiteGenesis includes the same features and functions on the same pages as the features and functions available from the overlay cartridge for Salesforce Reference Architecture (SFRA). The following process outlines how to achieve a basic application of Salesforce Payments on SiteGenesis. Where appropriate, we call out when and where different solutions are possible.
