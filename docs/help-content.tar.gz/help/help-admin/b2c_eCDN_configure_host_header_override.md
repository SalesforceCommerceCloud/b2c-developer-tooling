# Configure a Host Header Override Rule for an eCDN Zone

_To support a single hostname across multiple realms, create a Host Header Override Rule for sites that use an external content delivery network (CDN). This rule replaces unique hostnames with a common hostname to maintain the single-hostname setup. If you reuse a hostname, traffic can be unintentionally served from a different realm._

Proxy zones don’t support the same subdomain/hostname across zones, so a unique hostname is required in each zone with the appropriate custom hostname and certificate.

Before you create a host header override rule, make sure that you have your own stacked CDN configuration. CDN stacking is a prerequisite for directing traffic to appropriate eCDN zones based on locales or regions.

Create host header rules for each locale. To create a host header override rule:

1. In Business Manager, click App Launcher _(image: App Launcher)_, and then select **Administration > Sites > Embedded CDN Settings**.
2. Locate the zone you want to configure, and select **Configure Zone** from the dropdown menu.

   _(image: Configure Zone dropdown menu for a Proxy Zone in Business Manager)_
3. Select the Host Header Override Rules tab, and then select **New Rule**. To switch to a different zone from this tab, select another name from the Zone dropdown menu.
4. Enter the Host Header Override Rule details:

   1. Enter the rule expression using the visual dropdown interface to select a field, operator, and value. This expression specifies the host header of incoming requests where the traffic goes. For example, `Hostname equals shop.alpine.net`.
   2. (Optional) If you want the rule to be active when you save it, select **Enable Host Header Override Rule Upon Saving**. If you’re not ready to activate the rule yet, create it first. When you’re ready, return to the Host Header Override Rules tab and enable your rule from the list.
   3. The Rule Name is automatically filled based on the rule details.
   4. Click **Save**. Upon saving, a check make sure that the rule’s host header ends with the same hostname as the current zone.
5. Modify your external CDN to route traffic to the proxy zones for each locale.
