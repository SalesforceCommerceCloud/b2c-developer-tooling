# Preview a Site Using the Site Preview Tool in B2C Commerce

_Use the Site Preview Tool to view the storefront as it appears for a certain date or time. Choose to view the storefront as it appears for certain customer groups, or with certain source code. To preview an A/B test on a storefront, enter the A/B test and A/B test segment values._

|  |
| --- |
| Available in: **B2C Commerce** |

1. Select the site to view and click **Toolkit.**

   A new tab opens showing the storefront, with the Storefront Toolkit icons in the upper right corner.
2. Click the Preview Settings Tool icon. _(image: Preview Settings Tool icon)_
3. (Optional) Enter a date and time.

   The Site Preview Tool uses the date and time format for the site locale according to the corresponding definition in regional settings. If multiple locales are allowed for a site, the tool uses the current locale.
   
   If you select a date in the past, the current content shows in the storefront. If the content asset was removed, no content appears.
4. (Optional) Enter a source code or customer group.

   You can't select Registered and Unregistered at the same time.
   
   If source codes or customer groups that you created within the last few minutes aren't available to select, try to refresh the page or reopen the Storefront Toolkit.
5. To preview an A/B test:

   1. Select the A/B test.
   2. Select the A/B test segment.
   3. Enter a date that falls within the schedule of the A/B test. If you don't enter a date, the preview tool uses the test's effective date. If the test is inactive at the time you select, an error appears.
   
   If A/B tests or A/B test segments that you created within the last few minutes aren't available to select, try to refresh the page or reopen the Storefront Toolkit.
6. To test promotions using the test promotions tool, select **Enable Promotion Tracing** and enter a Promotion Trace ID by which to track promotion messages in the Request Log.

   See [b2c_sftk_test_promotions.xml](https://help.salesforce.com/s/articleView?id=cc.b2c_sftk_test_promotions.htm&type=5) for information about promotion tracking.
7. (Optional) Set date to preview future dated pricing.

   1. In Step3, enter the future date you want to preview.
   2. Confirm that you’ve rebuilt the product index since importing or setting price tables.
   
      > **Note:** For Salesforce Reference Architecture (SFRA) implementations, future pricing is only shown in the product details page. The product listing page shows current pricing only. It doens't show future pricing.
8. Click **Preview**.

   The URL in the browser tab includes the date and time in the locale-specific format. For a source code or customer group preview, the storefront shows content slots, prices, and other data for the specified time. For an A/B test preview, the promotions, discounts, slots, and sorting rules related to the A/B test segment are enabled, regardless of the scheduled time of the A/B test.
