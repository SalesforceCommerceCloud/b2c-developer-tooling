# Purge a B2C Commerce API Client

_Account Manager administrators can purge API clients with the Account Manager purge feature._

[Which Salesforce Commerce Product Do I Have?](https://help.salesforce.com/s/articleView?id=commerce.comm_what_product.htm)

The purge option is only available after an API client is set to a disabled status for seven days. This wait period prevents accidental purging that ‌can impact your business. The purge option is greyed out and not active for API clients disabled for less than seven days.

> **Note:** API clients disabled before the purge feature was turned on aren't subject to the 7-day wait period and can be purged.

The Account Manager API Client Detail page displays the last authenticated date for API clients. This date tells you when an API client last used valid credentials to get an access token. Use the last authenticated date to monitor API client activity and pinpoint any inactive API clients. For security reasons, Salesforce recommends disabling and purging API clients that aren’t in use.

B2C Commerce started tracking last authentication values for API clients on August 14, 2024. If an API client’s last authentication value is empty, it hasn't been used since before August 14, 2024.

See Also:

- [Track API Client Activity with Last Authentication Date](https://help.salesforce.com/s/articleView?id=commerce.account_manager_rn_track_api_client_last_authentication_date.htm&language=en_US&type=5)
