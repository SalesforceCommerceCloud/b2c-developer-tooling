# B2C Commerce API (Shopper Commerce API (SCAPI)) Metrics

_SCAPI metrics help website administrators and DevOps teams monitor and analyze the performance of API calls. They help identify issues with APIs, such as long-running API calls or bad cache hit rates. SCAPI metrics appear in the Metrics Dashboard with a delay of up to 10 minutes._

Use filters to refine the metrics to a specific API.

- `API Family`: Filter for all APIs belonging to an API family.
- `API Name`: Filter for a single API.

### Request Latency

The Request Latency metric measures the total time in milliseconds an API request takes to process on the SCAPI side, excluding external networking.

Use case:

- Identify long-running APIs and APIs with deteriorating performance.

### Request Count

The Request Count measures the total number of requests made to B2C Commerce APIs.

Use case:

- Identify APIs that receive an unexpected traffic volume. An unusually high or low number of requests can signify a wrong or ineffective caller implementation, an outage of a calling system, or a DDoS attack.

### Cache Hit Rate

The SCAPI cache hit rate metric measures the number of calls that have the response served from the SCAPI cache (HIT), not served from the cache (MISS), or that are constructed from parts that are served from the cache and parts that are not (PARTIAL).

Use cases:

- Identify which API calls are reliably served from cache and which calls can be improved to reach higher cache hit rates.

Find additional SCAPI metrics in the Commerce Analytics Center (CCAC) SCAPI Dashboard. See [Troubleshooting Salesforce B2C Commerce Performance](https://developer.salesforce.com/docs/commerce/b2c-commerce/guide/b2c-troubleshooting-platform-performance.html) in the B2C Commerce Guide.
