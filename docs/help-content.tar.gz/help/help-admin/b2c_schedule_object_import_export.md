# Schedule Object Import/Export in B2C Commerce

_Use the schedules.xsd schema file to import schedules. This topic applies to B2C Commerce._

### Business Manager Import Location

*Granularity:* selected schedules.

**Administration  >  Site Development  >  Site Import & Export**

### Pipelets

N/A

### Schema Elements

Specify either the run-once element or the recurrence element, but not both.
