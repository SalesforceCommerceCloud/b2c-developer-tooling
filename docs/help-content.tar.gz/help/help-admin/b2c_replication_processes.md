# Replication Processes in B2C Commerce

_A replication process performs a replication or rolls back a previous replication. You can run a replication process manually, or schedule it to run automatically in B2C Commerce._

When using replication, first replicate from your staging instance to a development instance. Then, check the results on the development instance. If changes are needed, make them on your staging instance and repeat the process. When you’ve verified that everything is correct on the development instance, replicate from staging to production.

> **Note:** Only use replication on instances in your Primary Instance Group (PIG). To move code from a sandbox instance in your Secondary Instance Group (SIG) to a staging instance in your PIG, use code deployment.

### Copying Data or Code

A replication process is a collection of replication tasks that push specified data or code to the target instance.

To manage replication processes in Business Manager, log in to the staging instance, click App Launcher _(image: App Launcher)_, and then select **Administration > Replication**. The main data or code replication page displays basic information about each existing process. Select the ID of a process to open its details, or select its replication type to expand a list of its replication tasks. When viewing the details of a process that is in the Waiting state, click **Edit** to edit it.

Don’t make manual edits in Business Manager on either the source or target instance while replication is running. Also, make sure that no jobs are running on the target instance during replication.

> **Note:** A scheduled replication process replicates the current system state when it runs, not the state from the time when the process was created.

> **Note:** If a recurring data replication process fails, it stops recurring.

### Rolling Back a Code or Data Transfer

To roll back a replication and restore the target instance to its previous state, run another replication process with the Replication Type set to Undo.

> **Note:** Only roll back the single most recent data or code replication. For example, you can't undo a code replication and then undo the previous code replication. However, data and code replications don’t affect each other's rollbacks. For example, if you run a data replication and then a code replication, you can still undo the data replication, and vice versa.

> **Note:** The undo action is no longer available for data replication processes which run prior to a GA Release. For example, a process on 24.7 cannot be undone on 24.8. This does not apply to GA Updates. For example, 24.8.1 to 24.8.2.
