# Create a Log Center Alert

_Monitor conditions and send notifications. Catch behavioral anomalies early, get notified when a log delivery pipeline fails, or create an alert for a specific incident._

1. In Log Center, on the Alerts tab, go to **Alert Management**.
2. Click **Create Alert**.
3. Select your alert mode: **New Alert, Saved Search, Log Streaming, or Anomaly Detector** and enter the information.

   You can create up to 50 alerts. Notifications are automatically emailed to the alert creator’s email address. You can add up to five email recipients per alert.
   
   If you’re creating a new alert, select which realms to apply the alert. Users can view alerts if they have access to the realm regardless of who created the alert. If you need to change the realms that apply to an alert, delete the alert and create a new one.
   
   If you’re creating a Log Streaming alert, any user in the log stream’s Edit Permission List can edit or delete the alert.
4. Click **Create**.

To keep your teams aligned during incidents, you can set up a Slack or PagerDuty channel.
