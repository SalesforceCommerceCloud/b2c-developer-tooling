# eCDN WAF Log Fields and JSON Output

_Request B2C Commerce eCDN-WAF log files through the Open Commerce API (OCAPI). This reference covers the request constraints, an example call, the JSON log output, and the fields each log returns._

[Which Salesforce Commerce Product Do I Have?](https://help.salesforce.com/s/articleView?id=commerce.comm_what_product.htm)

Each realm supports up to 24 pending log-request downloads. A minimum of five minutes is enforced between a log request's end time and the current time.

In this example, the current time is 11:00. To retrieve a 60-minute increment log file, set the start time to 09:50 and the end time to 10:50. The end time is more than five minutes before the current time, so the request is valid. Setting an end time within five minutes of the current time isn't allowed.

| OCAPI Call Example |
| --- |
| POST https//<yourvanityhostname>/s/-/dw/data/v18_8/log_requests/ecdn HEADER Authorization: Bearer aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa REQUEST BODY {zone_name: "redcliff.de", start_time: "2024-04-04T09:50:00.000Z", end_time: "2024-04-04T10:50:00.000Z"} |

All OCAPI calls return all fields shown in the JavaScript Object Notation (JSON) log output.

| Log Output |
| --- |
| {"CacheStatus":["unknown", "hit", "miss","dynamic"] "ClientCountry":"us", "ClientDeviceType":"mobile", "ClientIP":"1.1.1.1" "Client IP class:'badHost', "ClientRequestHost":"www.customer.com", "ClientRequestMethod":"GET", "ClientRequestURI":"/dw/image/v2/xxxx_PRD/on/demandware.st atic/-/template/default/uniqueid/productimages/aaaaaa.jpg?sw=470", "ClientRequestUserAgent":"Mozilla/5.0 (Linux; Android 7.1.1; XT1650 Build/NCLS26.118-23-13-6-5) AppleWebKit/537.36 (KHTML, like Gecko Chrome/66.0.3359.158 Mobile Safari/537.36", "EdgeResponseStatus":xxx, "EdgeStartTimestamp":1528631882657999872, "FirewallMatchesActions":["simulate", "challenge", "drop"], "FirewallMatchesSources":["firewallRules", "waf", "rateLimit"], "FirewallMatchesRuleIDs":["4861c39f2cf84aa985d5d813576d08b8"], "RayID":"xxxxxxxxxx", |

The JSON request format provides the category, field, and description for each value in the log output.

| Category | Field | Description |
| --- | --- | --- |
| general | CacheStatus | Array of strings that define whether a resource caches. Possible sources: hit \| miss \| dynamic |
| client | ClientCountry | Country of the client IP address |
| client | ClientDeviceType | Client device type |
| client | ClientIP | IP addresses of the client |
| client | ClientIPClass | IP that is blocked for bad reputation status |
| clientRequest | ClientRequestHost | Host requested by the client |
| clientRequest | ClientRequestMethod | HTTP method of client request |
| clientRequest | ClientRequestURI | URI requested by the client |
| clientRequest | ClientRequestUserAgent | User agent reported by the client |
| edge | EdgeResponseStatus | HTTP status code returned by eCDN to the client |
| edge | EdgeStartTimestamp | UNIX nanosecond timestamp, the edge received request from the client |
| edgeWAF | FirewallMatchesActions | Array of actions (strings) that the eCDN firewall performed on a request: allow \| log \| simulate \| drop \| challenge \| jschallenge \| connection close |
| edgeWAF | FirewallMatchesSources | Array of firewall source types (strings) that have performed actions on a request: asn \| country \| ip \| ipRange \| securityLevel \| zoneLockdown \| waf \| firewallRules \| uaBlock \| rateLimit \| bic \| hot \| l7ddosThe same product appearing multiple times indicates different rules or actions activated. |
| edgeWAF | FirewallMatchesRuleIDs | Array of RuleIDs (strings) that matched the request |
| general | RayID | Unique request identifier, 64-bit binary ID |
