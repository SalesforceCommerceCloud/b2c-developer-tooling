# Minimize the Attack Surface

_To reduce overall risk in secure development, reduce the attack surface that’s exposed to potential attackers. Every port you open, every external library you use in your code, and every user you give access to your data creates a new attack surface. To reduce the overall risk to the system, minimize the attack surface._

Here are some examples.

- A server running unnecessary services such as FTP, SMB, and Telnet gives the attacker an opportunity to exploit a vulnerability in any of those listening services.
- A web API built with only HTTPS exposed on the server minimizes attackable ports and prevents eavesdropping.
- A feature that uses many third-party libraries in the code, some of which may be unnecessary, is vulnerable to potential issues in any of those libraries.
