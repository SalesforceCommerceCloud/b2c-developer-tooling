# Import/Export Checklist in B2C Commerce

_We provide a checklist for the tasks you must perform to create and maintain import and export feeds for your sites. This topic applies to B2C Commerce._

### Design

Complete the following tasks in the design phase of the project.

| Task |
| --- |
| Determine the number of import feeds you want to create.   Consider how often to update each type of object. For example, price books must be updated more frequently than catalog data. Consider whether the objects are dependent upon other objects. For example, campaigns and promotions must be updated together, because campaigns are collections of promotions and can't be created without them. |
| Determine the number of export feeds you want to create. |
| For each import feed, determine:  The systems to export the file to be imported. The instances to import it into. How frequently you want to import the file. The names of the files to import and their location. The B2C Commerce or custom schema used for the import file. The required import mode. The security requirements. For example, whether you intend to use HTTPS or encryption in transferring the file. The persons with permissions move files for the import onto the cartridge or run the job. Who to contact if the feed doesn't complete successfully. |
| For each export feed, determine:  The instances to export it from The schedule for export The names of the files to export and their location The schema or file structure used for the export file The security requirements. For example, you do intend to use HTTPS or encryption in transferring the file. |
| _(image: checkbox)_ Use the information you’ve gathered to create a main feed diagram for your import feeds. |

### Development

The following are tasks to complete in the site development phase of the project. Before starting development, check the B2C Commerce code repository for code to help you advance your project.

*Sandbox Instances*

| Task |
| --- |
| Create a feed-mapping file that maps fields in your existing systems to the fields in the B2C Commerce import schema. |
| Configure your backend system to produce the XML files required by the feed schema. Create a job on your backend system that automatically produces the import file. |
| Apply any transformations needed to enrich the data or reorganize the file. It's recommended that this process is done outside of B2C Commerce. |
| Create users with permissions to import objects. |
| Manually import files as needed using Business Manager. |
| Create a template sandbox, configure it, and perform Site Import/Export to populate your other sandbox instances. |
| Manually import files as needed using Business Manager. |
| Create a cartridge for your import export code and add the cartridge to the site or organization path. |
| Create pipelines for automated import feeds. |
| Create jobs to run the import pipelines. Associate each job with a single pipeline. Configure jobs to alert an administrator if they don't complete in a specified amount of time. |
| Create users with the privileges to execute the jobs. |
| Record the average length it takes to run each job and make a job schedule. |

*Staging Instance*

| Task |
| --- |
| Use Site Import/Export to transfer job schedules from a sandbox instance or create jobs for the instance. |
| Create users with appropriate privileges to import objects and execute jobs. |
| Use UX Studio to upload custom file transfer and import/export pipelines to the staging instance. |
| Create a pipeline and job that cleans up import/export log files regularly. |
| Create a pipeline and job that cleans up archived site exports regularly. |
| If you’re using SSL, create the public key infrastructure for your production instance. |
| If a third party has to place files in the cartridge but can’t use WebDAV, configure the third party to use HTTP Post. |

*Production Instance*

| Task |
| --- |
| Use Site Import/Export to transfer job schedules from a sandbox instance or create jobs. |
| Create users with appropriate privileges to import objects and execute jobs. |
| Use code replication to move custom file transfer and import/export pipelines from the staging instance to the production instance. |
| Create a scheduled job that exports your site on a regular basis. |
| Create a scheduled job that archives your site export files regularly. |
| Create a pipeline and job that cleans up import/export log files regularly. If created for staging, use code replication to add this pipeline to the instance. |
| Create a pipeline and job that cleans up archived site exports regularly. If created for staging, use code replication to add this pipeline to the instance. |
| If you’re using SSL, create the public key infrastructure for your production instance. |

*Development Instance *

| Task |
| --- |
| Use Site Import/Export or code replication to transfer job schedules from the production instance to the development instance. |
| Create users with appropriate privileges to import objects and execute jobs. |
| Use code replication to move custom file transfer and import/export pipelines from the production instance to the development instance. |

### Import/Export Deployment and Maintenance

Deployment of import/export is similar to ordinary code deployment. If you’re choosing not to manage it programmatically, also make sure that archiving and archive cleanup is done. If you run import from Business Manager, when you delete the record of the import, Business Manager removes the log file automatically. If you run the import programmatically, the log file is never cleaned up, so clean up the log files as well.

If you must troubleshoot a problem with your production site, export the site meta data and import it into your sandbox.
