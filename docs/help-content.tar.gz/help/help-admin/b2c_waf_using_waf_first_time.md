# Using web application firewall (WAF) for the First Time

_When using WAF for the first time on your B2C Commerce storefront, we recommend that you run WAF in Log or Simulate mode for at least one week._

Simulate mode captures and logs information about your site traffic. Review generated logs to make data-backed decisions around your firewall needs, and better determine how to configure action and sensitivity settings for your storefront.

When reviewing your logs, consider the following:

- Which rules are triggering and how often?
- Which geographic areas (countries) are triggering rules? Do you sell product to those countries? Do you ship to those countries?
- What IP addresses are associated with any bad actors or triggered WAF rules? Performing IP lookups on troublesome IP addresses can potentially identify where they’re registered.
   
   | IP Address Registered Source | Reason for Access |
   | --- | --- |
   | Google | Search engines (typically good bots). |
   | Amazon Web Services (AWS) | Good scrubbing (information used across the Internet and intended to drive more sales). |
   | Bad scrubbing (inventory scraping bots that target sites to identify valuable content like text, images, or prices). |  |
   | Competitor | Competitors scanning your site to gather intelligence. |

If running WAF in Simulate mode results in identifying many bad actors, you can raise your WAF sensitivity level. Alternatively, if you find that WAF is triggering on real shopper activities, you can lower the sensitivity.
