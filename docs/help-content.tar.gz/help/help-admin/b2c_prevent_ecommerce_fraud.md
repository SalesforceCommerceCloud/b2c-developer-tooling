# Prevent Ecommerce Fraud

_Ecommerce fraud is a growing security challenge. Cyber attackers use lists of stolen credentials to gain access to user accounts and conduct brute force attacks to make unauthorized transactions._

Most attacks are simple and automated. Attackers use malicious bots to test stolen credit card data on merchant storefronts. Web scrapers use automated software to collect information from targeted websites. Scrapers can steal content and strain web infrastructure, which can reduce a website’s search engine optimization (SEO) ranking.

Fraudulent orders are difficult to deal with because of the many different types of fraud—account takeovers due to password reuse, consumers falling for phishing attacks, identity theft, and triangulation schemes. To help reduce fraud and fraudulent orders, use a fraud prevention service or contact partners from the LINK Technology Partner Program.

When a customer reports fraud or fraudulent orders, make sure to check with your fraud provider first. Effective fraud prevention involves implementing an overall risk management process.
