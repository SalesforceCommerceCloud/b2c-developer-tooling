# Publish Specific Page Designer Pages with Granular Replication

_After you turn on granular replications and organize the Page Designer pages that you want to replicate into a content library asset folder, Run small, targeted replications multiple times a day without the expense and complexity of a full data replication. This topic applies to B2C Commerce._

Prerequisites:

- Turn on granular replications.
- Assign Page Designer pages to a content asset library folder.

1. In Business Manager, click App Launcher _(image: App Launcher)_, and then select **Merchant Tools > Site > Content > Library Folders**.
2. Select the parent library folder that you assigned the Page Designer pages to.
3. Select the child library folder that you assigned the Page Designer pages to, if applicable.
4. Find the Page Designer pages that you want to replicate.

   _(image: Publish specific Page Designer pages.)_
5. Publish your changes.
