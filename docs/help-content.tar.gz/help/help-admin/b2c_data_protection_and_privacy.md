# Data Protection and Privacy in B2C Commerce

_On May 25, 2018, a new landmark privacy law called the General Data Protection Regulation (GDPR) came into effect, impacting every retailer conducting business in the European Union (EU)._

The GDPR expands the data privacy rights of EU citizens and places new obligations on merchants who handle EU-based personal data. Salesforce B2C Commerce is here to help our merchants prepare for the GDPR. The GDPR replaces the patchwork of national data protection laws currently in place with a single set of rules. Merchants established in the EU who process personal data fall under the purview of the GDPR. The GDPR also extends to merchants established outside the EU if they’re transacting business in the EU by, for example, offering goods or services or monitoring the online behavior of EU data subjects

All B2C Commerce merchants, note the following:

- The GDPR isn’t just for EU-based organizations - If you think the GDPR doesn’t apply to you, take a closer look. If your brand does business in the EU, offers goods or services to EU shoppers, collects data, or monitors EU data subjects, you fall within scope of the regulation.
- Merchants must understand the impact of the GDPR on their business - Merchants are responsible for assessing the scope of the GDPR within their own companies and taking action to ensure compliance.
- The GDPR requires a partnership between Salesforce and our merchants - Salesforce looks forward to working with and listening to our merchant’s GDPR to better understand the impact of the law.

GDPR isn’t the only data protection and privacy regulation that can require you and your company to keep individuals' personal data secure and private. We've listed some other regulations that are important to many companies collecting and processing their shoppers' data.

- California Consumer Privacy Act (CCPA)
- Personal Information Protection Act (PIPA), Japan
- Privacy Act, Australia
- Personal Information Protection and Electronic Documents Act (PIPEDA), Canada

As new data protection and privacy solutions are launched, B2C Commerce will provide specific documentation to help merchants understand how these new features can be used to help with compliance. This covers existing tools and also extends to new release items.

For more information, visit the Salesforce GDPR Resources and the Salesforce Privacy websites.

Various regulations can include principles that are similar to one another. So we give you guidance on some of the common privacy principles.

- [Data Deletion](https://help.salesforce.com/s/articleView?id=cc.b2c_data_deletion.htm&type=5): Delete Personal Data. Get guidance on deleting personal data as you comply with various data protection and privacy regulations. We give you examples of common shopper requests and things to consider. That way, you can determine how to best comply with the regulations that apply to your company.
- [Consent Management](https://help.salesforce.com/s/articleView?id=cc.b2c_consent_management.htm&type=5): Track Shopper Consent. Track your shoppers’ approval for how your company interacts with them. To help you assess your compliance with various data protection and privacy regulations, we give you examples of common shopper requests. And we provide details to help you determine the best way to comply with the regulations that apply to your company.
- [Restriction of Processing](https://help.salesforce.com/s/articleView?id=cc.b2c_restrict_processing.htm&type=5): Restrict How to Process Personal Data. Prevent the processing of your shoppers’ data when situations require you to do so. We give guidance on how to restrict forms of data processing. That way, you can work toward complying with the laws that are important to your company.
- [Data Portability](https://help.salesforce.com/s/articleView?id=cc.b2c_data_portability.htm&type=5): Give Shoppers Their Data when They Want It. Export shopper-related data when shoppers request it, so that you can work toward complying with various data protection and privacy regulations. We give you examples of common shopper requests and things to consider when you evaluate your compliance with the regulations that apply to you.

**Browser-Based Local Data Storage**

B2C Commerce uses various cookies and session storage objects on users' and shoppers' local machines. [The details of how they are used and how long they persist are documented here](https://help.salesforce.com/s/articleView?id=cc.b2c_local_data_storage.htm&type=5). In some cases, for example, if you receive a data deletion request, inform shoppers that some session data can remain on their computers.

## Related Content

- [Data Deletion: Delete Personal Data in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_data_deletion.htm&type=5)
  Delete personal data when it’s necessary to comply with various data protection and privacy regulations. We give you examples of common requests and things to consider. That way, you can determine a plan of action for complying with the regulations that apply to you.

- [Consent Management: Track Shopper Consent in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_consent_management.htm&type=5)
  Honor and respect your customers’ wishes when they request only specific forms of contact from your company or opt-out of certain types of data-sharing. We provide details to help you determine the best way to comply with the data protection and privacy regulations that apply to your company.

- [Restriction of Processing: Restrict How to Process Personal Data in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_restrict_processing.htm&type=5)
  When situations require you to do so, prevent the processing of your customers’ data. We give guidance to help you restrict forms of data processing. That way, you can work toward complying with the laws that are important to your company.

- [Data Portability: Give Shoppers Their Data When They Want It in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_data_portability.htm&type=5)
  When your customers request it, prepare and pack up the data you’ve received from them to work toward complying with various data protection and privacy regulations. We give you examples of common customer requests and things to consider. That way, you can determine how best to work toward complying with the regulations that apply to your company.

- [Browser-Based Local Data Storage in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_local_data_storage.htm&type=5)
  B2C Commerce uses browser cookies and session storage objects to store and track information.

- [Outbound Connections Allowlist in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_data_outbound_connections.htm&type=5)
  Connections from B2C Commerce to an external cloud provider over a private internet are referred to as outbound connections. To ensure the security and integrity of your B2C Commerce realm, Salesforce Customer Support approves all outbound connections. To control which destinations your data can be sent to, add new endpoints to your outbound connections allowlist. Send data from B2C Commerce to any of the endpoints on the allowlist, including third party providers such as Secure File Transfer Protocol (SFTP), FTP, WebDAV, and HTTP and HTTPS.
