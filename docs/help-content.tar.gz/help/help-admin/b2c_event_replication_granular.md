# Granular Replication Events

_The system fires granular replication events when the granular replication job completes, partially fails, or fully fails. Granular replication operates at the per-object level (products, price tables, content assets) rather than the bulk replication-process level, so its events report which individual object IDs succeeded and which failed._

**Available in:** B2C Commerce release 26.7 and later.

### Event IDs

### HTTP headers

Granular replication events use the standard Commerce Cloud platform headers documented in [Common HTTP Headers for B2C Commerce Events](https://help.salesforce.com/s/articleView?id=cc.b2c_event_common_headers.htm&type=5), with `x-sf-cc-event-id` set to the granular replication event ID (for example, `sf.cc.replication.granular.completed`).

### JSON payload structure — common fields

### Event-specific fields

### Granular process states

The `state` field indicates the final state of the granular replication job.

### Object buckets

The `objects`, `successfulObjects`, and `failedObjects` payload fields share the same three-bucket structure, one bucket per trackable type.

Successful entries (in `objects` and `successfulObjects`) contain an `id` string. Failed entries (in `failedObjects`) contain an `id` string and a machine-readable `status` code.

### Failure status values

The `status` field on each `failedObjects` entry contains a machine-readable code.

> **Note:** `NOT_INVALIDATED` objects don't appear in `failedObjects`. When an object imports successfully but the cache invalidation step doesn't finish, the object is still reported in the success lists (`objects` or `successfulObjects`). A non-zero job-level non-invalidated count is what causes the job to emit an `sf.cc.replication.granular.incomplete` event rather than a `completed` event.

### Example: successful granular replication event

```
{
"processId": 456,
"type": "GRANULAR",
"targetSystem": "Production",
"state": "COMPLETED",
"success": true,
"objects": {
"products": [
{ "id": "prod-001" }
],
"priceTables": [
{ "id": "prod-001@usd-prices" }
],
"contentAssets": []
},
"startDate": "2026-03-11T22:13:20Z",
"endDate": "2026-03-11T22:13:25Z"
}
```

### Example: failed granular replication event

```
{
"processId": 456,
"type": "GRANULAR",
"targetSystem": "Production",
"state": "FAILED",
"success": false,
"errorState": "GRANULAR_REPLICATION_FAILURE",
"failedObjects": {
"products": [
{ "id": "prod-001", "status": "TARGET_ERROR" }
],
"priceTables": [],
"contentAssets": []
},
"startDate": "2026-03-11T22:13:20Z",
"endDate": "2026-03-11T22:13:25Z"
}
```

### Example: incomplete granular replication event

```
{
"processId": 456,
"type": "GRANULAR",
"targetSystem": "Production",
"state": "INCOMPLETE",
"success": false,
"errorState": "GRANULAR_REPLICATION_INCOMPLETE",
"successfulObjects": {
"products": [
{ "id": "prod-001" }
],
"priceTables": [
{ "id": "prod-001@usd-prices" }
],
"contentAssets": []
},
"failedObjects": {
"products": [
{ "id": "prod-002", "status": "IMPORT_ERROR" }
],
"priceTables": [
{ "id": "prod-003@eur-prices", "status": "NOT_FINISHED" }
],
"contentAssets": []
},
"startDate": "2026-03-11T22:13:20Z",
"endDate": "2026-03-11T22:13:25Z"
}
```

### Granular replication implementation notes

- `type` is the literal string `GRANULAR`; the per-object granular replication flow is distinct from the process-level `Replication`, `Publication`, and `Code*` event types.
- `processId` is the granular replication job execution ID, not a process UUID.
- `endDate` reflects when the event was emitted, not the final job end time.
- `errorState` is `GRANULAR_REPLICATION_FAILURE` for failed events and `GRANULAR_REPLICATION_INCOMPLETE` for incomplete events.
- Each object bucket (`products`, `priceTables`, `contentAssets`) is always present in the payload, even when empty.
- Failure status values are machine-readable codes, not localized text.
- Each event type is gated by both the global replication eventing property and a per-event feature toggle (one each for the completed, failed, and incomplete events). If either is disabled, the event isn't sent.
