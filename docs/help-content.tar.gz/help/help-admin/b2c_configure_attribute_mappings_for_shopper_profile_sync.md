# Configure Attribute Mappings for Shopper Profile Sync

_Attribute mappings define which shopper attributes sync between B2C Commerce and your Salesforce org._

Twelve default mappings are always active, including first name, last name, email address, and phone numbers. You can't edit or remove these default mappings.

After the default mappings, add up to 20 custom mappings for additional standard or custom shopper attributes.

To add a custom attribute mapping, go to the Attribute Mappings section while auto-sync is turned off. Select the B2C Commerce shopper attribute and the corresponding Salesforce person account field that you want to map. If you don't see the person account attribute that you want, make sure that you've created it in the connected Salesforce org. Attribute mapping supports attributes of type Boolean, Double, Integer, Long, String, and Text.

_(image: Attribute Mappings section showing custom attribute mapping configuration)_

Configure your custom mappings before turning on auto-sync. If you update mappings while auto-sync is turned on, changes take effect at the next scheduled sync. However, limit mapping updates to avoid time-intensive re-syncs of existing shopper data.

> **Important:** Whenever you update attribute mappings, propagate those changes across both production and non-production environments to keep them synchronized.

### Mandatory Shopper Profile Sync Attributes

This table details the mandatory fields synchronized between B2C Commerce and a connected Salesforce org.

By default, there are 12 default attribute mappings sent from B2C Commerce to the Salesforce org that are always active and can't be edited or removed. After the connected Salesforce org successfully creates or updates these profiles, the system returns specific Salesforce identifiers back to B2C Commerce.

| Direction | B2C Commerce Shopper Field | Salesforce Org Field (Person Account or Contact) | Description & Mandatory Status |
| --- | --- | --- | --- |
| **B2C Commerce to Salesforce Org** | lastName | LastName | **Strictly Mandatory.** Required for person account creation in Salesforce. |
| **B2C Commerce to Salesforce Org** | customerId | CommerceCustomerReference | **Required Sync Reference.** Stable B2C Commerce customer identity used for strict system deduplication. |
| **B2C Commerce to Salesforce Org** | B2C Commerce instance and realm ID | CommerceOrganizationReference | **Required Sync Reference.** Identifies the specific B2C Commerce realm and instance the shopper originated from. |
| **B2C Commerce to Salesforce Org** | customerListId | CommerceGroupReference | **Required Sync Reference.** Identifies the B2C Commerce customer list to preserve lineage. |
| **B2C Commerce to Salesforce Org** | firstName | FirstName | Auto-mapped system attribute. |
| **B2C Commerce to Salesforce Org** | customerNo | AccountNumber | Auto-mapped system attribute. |
| **B2C Commerce to Salesforce Org** | email | PersonEmail (or Email) | Auto-mapped system attribute. |
| **B2C Commerce to Salesforce Org** | phoneMobile | Phone (or PersonMobilePhone) | Auto-mapped system attribute. |
| **B2C Commerce to Salesforce Org** | phoneHome | Home Phone | Auto-mapped system attribute. |
| **B2C Commerce to Salesforce Org** | phoneBusiness | Other Phone | Auto-mapped system attribute. |
| **Salesforce Org to B2C Commerce** | (Saved to accountId) | AccountId | **Returned by Salesforce org.** Persisted in B2C Commerce's CustomerUnifiedProfile table to establish the unified identity.In the June release, the accountId field on the CustomerUnifiedProfile table isn't populated for existing Person Accounts. A future release is planned to update all customer profiles to contain their corresponding Person Account ID. For integration use cases, use the Contact ID. |
| **Salesforce Org to B2C Commerce** | (Saved to contactId) | ContactId | **Returned by Salesforce org.** Embedded into the Shopper Login and API Access Service (SLAS) JSON Web Token (JWT) to securely enable downstream Agentic interactions. |

> **Note:** For a custom attribute mapping to be saved and for the sync to function successfully, any attribute defined as required on the Salesforce person account schema must be mapped in the B2C Commerce UI. If a required attribute is left unmapped or without a default value, the enablement validation blocks the synchronization process from starting.
