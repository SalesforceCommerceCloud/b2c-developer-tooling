# Prerequisites for Product Feed Integration

_Before configuring a product feed integration, ensure your B2C Commerce site meets the requirements. The channel partner supplies the SFTP credentials that you enter in Business Manager to connect._

### Site Requirements

Verify that your B2C Commerce site meets all of these requirements before using a product feed integration:

- **Locale**: The site must be configured for US English. How the system verifies this depends on the locales your site has configured:
   
   - If your site has only the `Default` locale configured, the feed generates without further locale setup. Because the `Default` locale has no fixed language, the site admin is responsible for ensuring that its content is US English. The integration is intended for US sites only.
   - If your site has more than one locale configured, `en_US` must be one of them. The `en_US` locale doesn't need to be the site default, but it must be in the site's list of configured locales. If `en_US` isn't the site default, turn on the **Multi-Locale** option in the Einstein configuration.
- **Currency**: The site has `USD` configured as its default currency.

### Supported Storefronts

The product feed integration supports the following storefront architectures:

- SFRA (Storefront Reference Architecture)
- SiteGenesis
- PWA Kit
- Storefront Next
- Headless storefronts

### SFTP Credentials

The channel partner supplies your SFTP credentials, which you enter in Business Manager to connect. See [b2c_product_feed_connect.xml](https://help.salesforce.com/s/articleView?id=cc.b2c_product_feed_connect.htm&type=5).

- **OpenAI**: OpenAI provides your SFTP credentials when it onboards your merchant account.
- **Google**: You retrieve your SFTP credentials from Google Merchant Center.

> **Restriction:** SFTP credentials can be entered only on production instances, and the daily feed sync runs only on production. You can configure General Settings (other than SFTP), field mappings, product filter rules, and the feed preview on any non-production instance: development, staging, or sandbox.

After you enter your SFTP credentials and turn on the daily feed sync, B2C Commerce automatically uploads the feed to the channel partner after generation. For the OpenAI feed, see [Turn On the Product Feed for OpenAI](https://help.salesforce.com/s/articleView?id=cc.b2c_openai_feed_enable.htm&type=5). For the Google feed, see [Turn On the Product Feed for Google](https://help.salesforce.com/s/articleView?id=cc.b2c_google_feed_enable.htm&type=5).
