# Purge an Account in B2C Commerce

_You can purge an account only if you are an account administrator and the account is within one of your organizations. When you purge an account, Account Manager removes the user record from its database._

[Which Salesforce Commerce Product Do I Have?](https://help.salesforce.com/s/articleView?id=commerce.comm_what_product.htm)

> **Note:** Purged accounts can't be restored.

Before you purge an account, check that the account you want to purge is deleted. Only deleted accounts can be purged.

To delete an account:

1. Log into Account Manager.
2. Click **Users**.

   The Users page opens, showing a list of accounts.
3. Set Filter by status to **Deleted Users only**.
4. Click **Purge** next to the user whose account you want to purge.

   A dialog box opens, asking you to confirm that you want to purge the user's account. If you click **Cancel**, the purge operation is canceled, and the user's account isn't purged.
5. Click **Purge**.

   The account is now purged and can't be restored.

> **Note:** If a user is purged and you want to restore the user with the same login username, complete one of the following options. Do not complete both options. Otherwise the User will have issues logging into Business Manager
> 
> - Option 1: Make sure you delete the user in Business Manager.
> - Option 2: Request to have an admin recreate the user in Account Manager and update the user’s universally unique identifier (UUID) in their Business Manager user profile. To update the Business Manager user profile:
>    
>    1. In Business Manager click App Launcher _(image: App Launcher)_, and then select **Administration > Organization > Users**.
>    2. Select the user.
>    3. Locate the user's Account Manager User ID and compare with the User ID for the user in the Account Manager User Details page. The values must match.
>    4. If necessary, update the value in Business Manager to match the Account Manager value.
