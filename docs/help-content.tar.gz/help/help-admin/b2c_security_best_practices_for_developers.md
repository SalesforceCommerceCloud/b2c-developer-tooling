# Security Best Practices for Developers in B2C Commerce

_As a B2C Commerce developer, use these security best practices to develop secure storefronts._
