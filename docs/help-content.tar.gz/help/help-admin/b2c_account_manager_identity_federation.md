# Identity Federation with Salesforce Identity in B2C Commerce

_Identity federation enables users to access multiple applications or systems with a single set of credentials. Account Manager uses identity federation to enhance security and the app login experience._

[Which Salesforce Commerce Product Do I Have?](https://help.salesforce.com/s/articleView?id=commerce.comm_what_product.htm)

Before you enable identity federation in Account Manager, review the available options and their impact on your federated user experience. See [ User Management with Identity Federation In Account Manager ](https://help.salesforce.com/s/articleView?id=cc.b2c_account_manager_user_management_with_identity_federation.htm)

### Salesforce My Domain

Account Manager uses Salesforce My Domain to identify the subdomain of a user’s org in Salesforce (Salesforce Identity Management (SFIDM)). If their organization's Salesforce My Domain is used by more than one Account Manager organization, users select their Account Manager organization during the SSO process. This one-time selection is required for account linking. For My Domain verification, the user’s Account Manager and Salesforce org email address must match. To verify My Domain and use just-in-time user provisioning, a user logs in to their Salesforce My Domain and authenticates with their Salesforce Identity or third-party Identity and Access Management (IAM). Identity Federation of Account Manager with third-party IAM is done through Salesforce Identity. Account Manager does not directly integrate with third-party IAM.

Account Manager activation and account linking for users depends on how their account is set up.

- **Non-linked user account**—To link their account to their SFIDM, a match of the user’s primary organization My Domain is verified with the one they used for SSO with SFIDM.
- **Existing account**—My Domain verification isn’t required, but the user’s primary organization’s My Domain must match the one that was used for SSO with SFIDM.
- **Just-In-Time User Provisioning**—Salesforce My Domain is verified during Just-In-Time user provisioning.
