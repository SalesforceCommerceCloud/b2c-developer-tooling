# Site Preferences in B2C Commerce

_Use site preferences to control the behavior of individual Salesforce B2C Commerce sites. Configure various site preferences._

## Related Content

- [Configure Product and Content Locking for B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_configuring_product_and_content_locking.htm&type=5)
  Define the time (in minutes) for when products or content are locked while editing. During this time, other users can't edit the product record or content asset. The lock (applied before product editing) is released after this time.

- [Add Favorites to Business Manager](https://help.salesforce.com/s/articleView?id=cc.b2c_adding_favorites_to_homepage.htm&type=5)
  To make your work faster and more efficient, save B2C Commerce Business Manager modules as favorites. Add up to 20 site-specific or global modules to the Business Manager home page. Site-specific modules are only available for the selected site.

- [Set A/B Test Preferences in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_setting_ab_test_preferences.htm&type=5)
  A/B tests appear as enabled in the A/B testing module (if set to enabled), when these preferences are set to `False.`

- [Configure Commerce Intelligence Preferences for IP Filtering](https://help.salesforce.com/s/articleView?id=cc.b2c_configuring_cidr_ip_filters.htm&type=5)
  Internal performance and load testing tools can contaminate the data you see in Reports and Dashboards, making it difficult to distinguish between generated traffic and actual customer behavior. Specify IP address ranges to filter out traffic from your internal testing tools, ensuring that your analytics reflect genuine B2C Commerce customer interactions.

- [Gift Certificate Site Preferences for B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_gift_certificate_site_preferences.htm&type=5)
  Set the site preferences that control gift certificate emails and exports in Business Manager, including the sender name and email, the ISML email template, whether certificate codes are masked, and whether the merchant ID is exported.

- [Configure Allowed Currencies in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_configuring_allowed_currencies.htm&type=5)
  Configure the currencies that are allowed for your site.

- [Customer Lists Preferences for B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_customer_lists_preferences.htm&type=5)
  Use customer site preferences to control how your storefront responds to failed login attempts by customers. You can optionally lock out a customer's account after a specified number of failed attempts, preventing *brute force* attempts to crack the customer's password.

- [Create Custom Preferences for B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_creating_custom_preferences.htm&type=5)
  In Salesforce B2C Commerce, you can create custom preferences for sites, and then view and edit them both locally and across multiple sites. Custom preferences enable site developers to make properties of the system modules configurable in Business Manager.

- [Set Privacy Preferences for B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_setting_privacy_preferences.htm&type=5)
  Setting Privacy Preferences  When shoppers visit a Salesforce B2C Commerce storefront, connected systems can collect and process their behavior and personal data to enhance the shopper experience. However, some shoppers can decide that they don’t want the merchant to collect their personal information.

- [Configure Basket Preferences](https://help.salesforce.com/s/articleView?id=cc.b2c_configure_basket_preferences.htm&type=5)
  Configurable basket settings include persistence across B2C Commerce shopper sessions, the treatment of duplicate product line items, and the maximum number of product line items per basket. These preferences are site-specific, and a customized storefront doesn’t necessarily evaluate them.

- [Configure Site Locales for B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_configuring_site_locales.htm&type=5)
  Salesforce B2C Commerce is structured as an organization containing one or more sites (storefronts). Define locale settings in Business Manager for these two entities, first at the organization level and then at the site level.

- [Specify Source Code Site Preferences](https://help.salesforce.com/s/articleView?id=cc.b2c_specifying_source_code_site_preferences.htm&type=5)
  Merchants use source codes to track customer activity and the source of incoming visits to a storefront. Salesforce B2C Commerce source-code groups enable you to use this information to manage such things as customer redirects, price books, and campaigns. Specify how you want B2C Commerce to handle source codes via site preferences.

- [Set Search Preferences](https://help.salesforce.com/s/articleView?id=cc.b2c_setting_search_preferences.htm&type=5)
  The search preferences you configure control the behavior of the search feature for your B2C Commerce instance. These preferences can be exported.

- [Order Preferences for B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_order_preferences.htm&type=5)
  Select how orders are processed with Salesforce B2C Commerce.

- [Configure Storefront URL Preferences](https://help.salesforce.com/s/articleView?id=cc.b2c_configuring_storefront_url_preferences.htm&type=5)
  Enable your SEO URL rules for a B2C Commerce site.

- [Embedded CDN](https://help.salesforce.com/s/articleView?id=cc.b2c_embedded_cdn.htm&type=5)
  Salesforce B2C Commerce comes with an embedded Content Delivery Network (CDN). To ensure low response times for consumers, the embedded CDN serves content from a location close to the consumer, enhancing the ability to scale sites. Contact Salesforce Support to enable the embedded CDN for your organization.
