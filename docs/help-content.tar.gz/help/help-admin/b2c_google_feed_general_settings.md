# Configure Product Feed General Settings for Google

_On the General Settings tab, enter the SFTP credentials that Google Merchant Center provides to connect your store. Optionally, set global overrides for the price and image columns that apply to every row in your feed._

Before you configure General Settings, ensure that:

- [Your site meets the prerequisites](https://help.salesforce.com/s/articleView?id=cc.b2c_product_feed_prerequisites.htm&type=5)
- [Catalog and Order feeds are configured for Einstein](https://help.salesforce.com/s/articleView?id=cc.b2c_product_feed_configure_einstein.htm&type=5)
- You have the SFTP credentials that you retrieve from Google Merchant Center.

The General Settings tab has two sections:

- **SFTP Configuration**: Enter the SFTP credentials that Google Merchant Center provides. B2C Commerce uses these credentials to upload your product feed to Google.
- **Business Details**: Set optional global overrides for the price and image columns. Business Details values apply to every row in the feed.

> **Restriction:** SFTP credentials can be entered only on production instances, and the daily feed sync runs only on production. You can configure Business Details, field mappings, product filter rules, and the feed preview on any non-production instance—development, staging, or sandbox.

> **Note:** The Google catalog feed integration is available for US sites only.

1. Click App Launcher _(image: App Launcher)_, and then select **Merchant Tools > Site > AI & Social Integrations > Google**.
2. Click the **General Settings** tab.
3. In the **SFTP Configuration** section, enter your SFTP credentials and click **Connect**.

   For step-by-step details, including how to disconnect, see [../product_feeds/b2c_product_feed_connect.xml](https://help.salesforce.com/s/articleView?id=cc.b2c_product_feed_connect.htm&type=5).
4. (Optional) In the **Business Details** section, for **List Price Book**, select a price book.

   The selected price book overrides the **price** column in Field Mapping. The dropdown lists only price books that are active and contain prices in the feed currency. If you later deactivate the selected price book, reconfigure **List Price Book** to point at a different price book. If you don't select a price book, B2C Commerce derives the list price from the sale price book selected by the B2C Commerce price engine. See [b2c_google_feed_default_mappings.xml#b2c_google_feed_default_mappings/list_price_derivation](b2c_google_feed_default_mappings.xml#b2c_google_feed_default_mappings/list_price_derivation).
5. (Optional) For **Image View Type**, select an image view type.

   The selected image view type overrides the **image_link** column in Field Mapping. If you don't select a view type, B2C Commerce uses the default mapping: large view, falling back to the first available view type.
   
   Salesforce recommends that you select a specific view type. If your catalog doesn't include a "large" view type, the default fallback selects the first available view type, which can be unsuitable for Google (for example, a swatch view).

B2C Commerce saves your General Settings and applies them to every row in the product feed. Any global overrides are visible in the Product Feed Preview and in the daily feed sync.

After you configure General Settings:

- [Map product fields for Google](https://help.salesforce.com/s/articleView?id=cc.b2c_google_feed_mapping.htm&type=5)
- [Configure product filter rules](https://help.salesforce.com/s/articleView?id=cc.b2c_product_feed_configure_product_filter.htm&type=5)
- [Preview the product feed](https://help.salesforce.com/s/articleView?id=cc.b2c_product_feed_preview.htm&type=5)
