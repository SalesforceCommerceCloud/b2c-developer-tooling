# B2C Commerce Accounts FAQ for B2C Commerce

_B2C Commerce uses a unified account management system, Account Manager. This topic answers common questions about setting up and accessing your account using Account Manager._

[Which Salesforce Commerce Product Do I Have?](https://help.salesforce.com/s/articleView?id=commerce.comm_what_product.htm)

Q: Does Account Manager require multi-factor authentication?

A: Yes, all Account Manager users require MFA to access B2C Commerce. You can find more details [here](https://help.salesforce.com/s/articleView?id=000364011&type=1)

Q: Does Account Manager integrate with 3rd party Identity Providers?

A: While Account Manager doesn’t integrate directly with 3rd party Identity Providers, you can configure Account Manager to do SSO/Federation using Salesforce Identity and Salesforce Identity can be configured to work with 3rd party Identity Providers. You can find more details [here](https://help.salesforce.com/s/articleView?id=cc.b2c_account_manager_sso_solution_kit.htm).

Q: Does Account Manager support international characters?

A: Yes. Account Manager supports international characters. Password and email values, however, can only be standard ASCII characters. All other non-digit input fields accept international characters beyond the standard ASCII character set.

Q: I did not get a B2C Commerce email (or I accidentally deleted it), so how can I access my B2C Commerce Account?

A: Contact your account administrator and request another copy of your B2C Commerce invitation email. If you’re an account administrator having issues accessing your account, open a Support case in the [Salesforce Help](https://help.salesforce.com/s/).

Q: Who manages my account data?

A: Everyone with an account can maintain their own personal account information. Each B2C Commerce client or partner organization is assigned an account administrator. The account administrator is responsible for managing accounts for all members of their organization. To change your roles, permissions, or membership, contact your account administrator. The account administrator can also add new user accounts to their organizations.

Q: I tried to log in multiple times and when I tried to use the "Forgot Password" operation, I could not reset my password.

A: If you try too many times to log in, your account gets locked temporarily for 30 minutes. For security reasons, the "Forgot Password" operation is disabled for locked accounts.

Q: Does Account Manager support subaddressing?

A: Yes, Account Manager supports subaddressing (also known as plus addressing) for account email addresses. Subaddressing allows you to use variations of a primary email address with a + sign and a tag. Emails sent to these subaddresses are delivered to the primary email address. If your email provider supports subaddresses, you can use them in Account Manager to create multiple user accounts for a single email inbox. You can also assign precise roles based on the subaddress. See [b2c_account_manager_invite_user_to_organization.xml](https://help.salesforce.com/s/articleView?id=cc.b2c_account_manager_invite_user_to_organization.htm&type=5).
