# Payment Method Information Import and Export in B2C Commerce

_Import or export payment method information (schema file `paymentmethod.xsd`) through site import and export, or directly from Merchant Tools, Ordering, Import & Export in Business Manager. The Ordering module handles payment methods but not payment processors._

A payment method is a storefront payment option that shoppers select at checkout, such as credit card or gift certificate. Each method relies on a payment processor to authorize the transaction. Method import and export moves the method definitions and their customer-group, billing-country, and amount restrictions. To create or configure methods, see [../ordering/b2c_managing_payment_methods.xml](https://help.salesforce.com/s/articleView?id=cc.b2c_managing_payment_methods.htm&type=5).

Payment methods belong to the Ordering module, so you can import or export them on their own from Merchant Tools, Ordering, Import & Export. They also move as part of a full site import or export.

| Object Information | Details |
| --- | --- |
| Schema file | paymentmethod.xsd |
| Granularity | Selected payment methods. |
| Business Manager import and export location | ***site* > Merchant Tools > Ordering > Import & Export** |
| Pipelets | N/A |
