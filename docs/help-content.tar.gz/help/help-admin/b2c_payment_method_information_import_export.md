# Payment Method Information Import and Export in B2C Commerce

_Import or export payment method information using site import and export, or directly from the Ordering module. This topic applies to B2C Commerce._

| Object Information | Details |
| --- | --- |
| Schema file | paymentmethod.xsd |
| Granularity | Selected payment methods. |
| Business Manager import and export location | ***site* > Merchant Tools > Ordering > Import & Export** |
| Pipelets | N/A |
