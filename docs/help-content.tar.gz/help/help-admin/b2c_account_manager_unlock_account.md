# Unlock an Account in B2C Commerce

_After six unsuccessful attempts to log in to an account, Account Manager temporarily locks the account for 30 minutes. An account administrator can explicitly unlock locked accounts within the administrator’s organizations._

[Which Salesforce Commerce Product Do I Have?](https://help.salesforce.com/s/articleView?id=commerce.comm_what_product.htm)

1. Log into Account Manager.
2. Click **Users**.

   The Users page opens, showing a list of email addresses for all users in your organizations.
3. Click the **Unlock** action in the user list.
4. In the **Organization User** section, click the **Unlock** action in the user list.
