# Log Center Configuration

_Modify the Log Center display to meet your business needs. In addition Log Center Administrators can configure log levels and log volumes._

## Related Content

- [Modify the Log Center Display](https://help.salesforce.com/s/articleView?id=cc.b2c_modify_the_log_center_display.htm&type=5)
  By default, when you conduct a search, Log Center shows the list of issues in a detailed view. You can also view the list in compact view.

- [Configuration for Administrators](https://help.salesforce.com/s/articleView?id=cc.b2c_configuration_for_administrators.htm&type=5)
  Log Center administrators can access the Config tab to set log levels and log volumes.
