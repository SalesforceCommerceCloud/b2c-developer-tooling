# Log Center Configuration

_Modify the Log Center display to meet your business needs. In addition Log Center Administrators can configure log levels and log volumes._
