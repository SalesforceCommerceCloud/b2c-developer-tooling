# Replication Best Practices in B2C Commerce

_When defining and running replication processes, follow these recommendations._

- Before replicating to production, run each replication from staging to development to test it. Make sure that search is working and that data is correct on the development system.
- Test everything on production, even if it replicated properly to development.
- Do not run multiple replication processes at the same time.
- If you modify a system object type, replicate global system object types before replicating any objects of that type.
- Identify and follow the dependencies between different data replication groups. For example, if you have campaigns that use source codes and coupons, replicate source codes and coupons before, or together with, campaigns. Replicating campaigns first in that situation can result in data corruption.
- When replicating to a production instance, first transfer the data or code to verify the transfer process. Examine the logs before publishing the data or activating the code.
- Always rebuild your search indexes and make sure that the process is complete before replicating them. When replicating search indexes, disable incremental and scheduled indexing, and stop other jobs. Replication fails when an index is being rebuilt or modified.
- Replication processes are resource-intensive and can affect site performance. Run replication during low traffic times, such as late night or early morning hours. Schedule replication to production when storefront activity is at a minimum. Try to avoid major data replications during Salesforce B2C Commerce's standard maintenance windows.
- Limit user privileges to perform data replication, and split the responsibility between multiple user roles. For example:
   
   - A product manager defines replication processes, but does not have permission to schedule or execute them.
   - A replication manager manages and executes replication processes.
- Avoid modifying or moving static content files whenever possible. These changes take a long time to replicate.
- Copy an existing replication process when possible, instead of creating a process from scratch.
- When the replication process automatically clears the page cache, don't clear it again manually.
- Do not edit cartridge paths or code directly in a production instance. Doing so can result in unexpected behavior, such as multiple versions of pages. Always replicate code and preferences from staging to production.
- For performance reasons, we recommend you store no more than 100,000 objects (regular files and directories) for each directory created on the following path `/on/demandware.servlet/webdav/Sites/Catalogs/CatalogName/MyDirectoryWithNoMoreThan100kObjects/.`
