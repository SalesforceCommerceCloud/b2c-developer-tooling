# Create a Custom B2C Business Manager App

_Create a custom app in Business Manager with the modules and navigation tailored to how you work, either from the Merchandising template or from scratch._

A custom Business Manager app lets you group only the modules you use most into your own sections in the left navigation, instead of using the full Merchant Tools or Administration navigation.

1. Click App Launcher _(image: App Launcher)_, then select **New Custom App**.
2. Choose a template.

   - **Merchandising** — Creates a unified workspace with a starter set of Business Manager modules tailored to common merchandising tasks. Customize the template after you create it.
   - **Manual Setup** — Creates an empty custom app with no preselected modules, so you can build a workspace from scratch.
3. Enter a name for your custom app and click **Create New App**.

Your custom app appears in the App Launcher. You can now organize it into sections and modules.
