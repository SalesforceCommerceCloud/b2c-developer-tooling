# Account Manager for B2C Commerce

_Account Manager creates, maintains, and disables B2C Commerce accounts. It also grants (or denies) access to selected applications based on the account's credentials. Account Manager supports two different types of users: account administrators and non-administrative users. Account administrators can do everything non-administrative users can do. Account administrators can also create accounts, disable accounts, and so on. At least one account administrator is assigned to each organization. Before you can use Account Manager, you must log in._

[Which Salesforce Commerce Product Do I Have?](https://help.salesforce.com/s/articleView?id=commerce.comm_what_product.htm)

## Related Content

- [Integrate B2C Commerce with Single Sign-On](https://help.salesforce.com/s/articleView?id=cc.b2c_account_manager_sso_solution_kit.htm&type=5)
  To make sure the connection is secure and reduce friction, integrate B2C Commerce Account Manager and other Salesforce applications with your identity provider.

- [User Management with Identity Federation In Account Manager and B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_account_manager_user_management_with_identity_federation.htm&type=5)
  You can configure the Identity Federation settings of your organization so that Account Manager user accounts are automatically created, provisioned, and linked to the Salesforce Identity of your Salesforce Organization (Salesforce Identity Management (SFIDM)).

- [Just-In-Time User Provisioning In Account Manager and B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_account_manager_just_in_time_user_provisioning.htm&type=5)
  Just-in-time user provisioning automates creating a user account in Account Manager eliminating the need for admins to add users manually. It also links the account with the Salesforce Identity account used for single sign-on (SSO).

- [Automated Linking for Unlinked Accounts In Account Manager and B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_account_manager_automated_linking_for_unlinked_accounts.htm&type=5)
  If you don’t want to enable the just-in-time provisioning, you can still take advantage of automatic activation and linking of new user accounts by creating the user accounts in Account Manager.

- [Log In with Identity Federation Enforced](https://help.salesforce.com/s/articleView?id=cc.b2c_account_manager_log_in_with_identity_federation_enforced.htm&type=5)
  Before logging in for the first time, you receive an email with a login link. This topic applies to Account Manager and B2C Commerce.

- [Log In with Identity Federation Allowed](https://help.salesforce.com/s/articleView?id=cc.b2c_account_manager_log_in_with_identity_federation_allowed.htm&type=5)
  If you already have an account, you receive an email describing your options to either link your account or log in using your Account Manager credentials. This topic applies to Account Manager and B2C Commerce.

- [Email Notifications](https://help.salesforce.com/s/articleView?id=cc.b2c_account_manager_email_notifications.htm&type=5)
  Email notifications are sent to users based on how the account is created and the identity federation setting for your organization in Account Manager. This topic applies to Account Manager and B2C Commerce.

- [Log into Account Manager in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_account_manager_login.htm&type=5)
  Account Manager offers two login options, link for single sign-on (SSO) or log in with your username.

- [Verify Your Identity with Multi-Factor Authentication in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_account_manager_verify_with_mfa.htm&type=5)
  Multi-factor authentication (MFA) is a simple, effective mechanism for enhancing login security and safeguarding your users’ accounts against security threats. MFA is part of the B2C Commerce login experience and can’t be turned off.

- [Register Verification Methods for Multi-Factor Authentication in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_account_manager_register_verification_methods_for_mfa.htm&type=5)
  Multi-factor authentication (MFA) is an extra layer of protection beyond a single password.

- [Remove Verification Methods for Multi-Factor Authentication in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_account_manager_remove_verification_methods_for_mfa.htm&type=5)
  If you want to replace a multi-factor authentication (MFA) verification method, you can remove registered methods from your Account Manager account.

- [Link an Account Manager Account to Salesforce Identity (SSO) in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_account_manager_link_account_to_salesforce_identity_sso.htm&type=5)
  Depending on the settings of your organization, you can link Account Manager accounts to Salesforce accounts managed in Salesforce Identity. If your organization enables this capability, you can link your Account Manager account to a Salesforce account when you log in to Account Manager. To unlink your account, contact your account administrator.

- [Roles Managed in Account Manager](https://help.salesforce.com/s/articleView?id=cc.b2c_account_manager_roles.htm&type=5)
  Use this table as a guide to the B2C Commerce Account Manager roles.

- [Removal of Deprecated Roles in Account Manager](https://help.salesforce.com/s/articleView?id=cc.b2c_account_manager_deprecated_roles.htm&type=5)
  Avoid assigning deprecated roles to users in B2C Commerce. These roles no longer provide access to B2C services, and Salesforce plans to remove them starting in Account Manager 3.9 (June 2026). Removing a deprecated role from a user doesn’t result in loss of functionality or access.

- [Activate a B2C Commerce Account in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_account_manager_activate_account.htm&type=5)
  Before you can activate an account, it must first be created for you by an account administrator. When the administrator creates your account, Account Manager sends a message to your email address. This email message serves as a starting point for activating your account.

- [Change Your Account Password in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_account_manager_reset_password.htm&type=5)
  You are required to change your password every 90 days. Define a new password even if your existing password expired. After a password has expired, you can attempt to log in six times to set a new password before your account is temporarily locked. After you successfully log in with an expired password, immediately reset your password.

- [Reset a Forgotten Password in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_account_manager_reset_forgotten_password.htm&type=5)
  You can reset your password if you forgot it. However, this procedure works only if you successfully activated your account. Define a new password even if your existing password has expired. After a password has expired, you can attempt to log in six times to set a new password before your account is temporarily locked. After successfully logging in with an expired password, immediately reset your password.

- [Change Account Information in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_account_manager_change_account_information.htm&type=5)
  Change your account information with Account Manager. You can't change your email address, but you can change other account values, such as your business phone number. Also, depending on the multi-factor authentication (MFA) verification method settings of your organization, you can register methods for verifying your identity when logging in to B2C Commerce applications.

- [Create a User Account in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_account_manager_create_user.htm&type=5)
  You must be an account administrator to create an account. Each account must belong to one or more organizations, and you can create accounts only for organizations of which you are a member.

- [Edit a User Account in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_account_manager_edit_user.htm&type=5)
  Account Administrators can edit the details, access permissions, and status of users accounts in their organization.

- [Unlock an Account in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_account_manager_unlock_account.htm&type=5)
  After six unsuccessful attempts to log in to an account, Account Manager temporarily locks the account for 30 minutes. An account administrator can explicitly unlock locked accounts within the administrator’s organizations.

- [Add an Account to Your Organization in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_account_manager_invite_user_to_organization.htm&type=5)
  As an Account Administrator, you can add user accounts to your organization.

- [Manage Access of Partner Accounts in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_account_manager_manage_partner_access.htm&type=5)
  Account administrators can use Account Manager to manage access of user accounts invited to the administrator's organization (for example, a partner account). You can control which B2C Commerce applications the invited account can access.

- [Reset a User Account in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_account_manager_reset_user.htm&type=5)
  Account administrators can use Account Manager to reset a user's account. This operation is useful if the user forgets their password or if you want to unlink an Account Manager account from a Salesforce account. When you reset a user's account, you put the account in the same state it was in when it was initially created. The user must reactivate the account.

- [Delete an Account in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_account_manager_delete_account.htm&type=5)
  You can delete an account only if you are an account administrator and the account is within one of your organizations. When you disable an account, the user can't log in to services using their credentials. When you delete an account, Account Manager still stores the user in the database for security-related reasons.

- [Purge an Account in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_account_manager_purge_account.htm&type=5)
  You can purge an account only if you are an account administrator and the account is within one of your organizations. When you purge an account, Account Manager removes the user record from its database.

- [Undelete an Account in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_account_manager_undelete_account.htm&type=5)
  When an account is deleted, the deleted user can no longer log into any systems requiring Account Manager credentials. If you delete an account by mistake or as a security precaution, you can undelete the account. Only account administrators can undelete an account.

- [Add an API Client in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_account_manager_add_api_client_id.htm&type=5)
  Account administrators use Account Manager to create API clients. To access Salesforce Commerce API (Shopper Commerce API [SCAPI]) or Open Commerce API [OCAPI]), use an API client. Append the API client ID to the URLs that you use to access these APIs. The On-Demand Sandbox API also requires an API client.

- [Enable and Disable an API Client ID in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_account_manager_enable_disable_client_id.htm&type=5)
  Account administrators can use Account Manager to enable and disable API clients. The Open Commerce API requires to be accessed with API clients. The API client ID needs to be appended to the URLs used to interact with the Open Commerce API. An API client is also required to use the On-Demand Sandbox API.

- [Purge a B2C Commerce API Client](https://help.salesforce.com/s/articleView?id=cc.b2c_account_manager_api_client_purging.htm&type=5)
  Account Manager administrators can purge API clients with the Account Manager purge feature.

- [Edit an Organization in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_account_manager_edit_organization.htm&type=5)
  As an Account Administrator, you can edit an organization to specify a password policy,  allow your users to link their Account Manager account to an existing account in your organization in the Salesforce Platform, and specify the multi-factor authentication (MFA) verification methods that are available for users to verify their identity when logging in to B2C Commerce B2C applications. MFA is required for all Account Manager users to improve security and reduce the risk of unauthorized access and account compromise.

- [Audit Log Events](https://help.salesforce.com/s/articleView?id=cc.b2c_account_manager_audit_logs.htm&type=5)
  Account Manager B2C Commerce audit log events are available in Log Center and provide visibility into changes to users, API clients, and organizations.

- [B2C Commerce Accounts FAQ for B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_account_manager_faq.htm&type=5)
  B2C Commerce uses a unified account management system, Account Manager. This topic answers common questions about setting up and accessing your account using Account Manager.

- [Select Contact Users to Receive Account Manager Security Notification Emails](https://help.salesforce.com/s/articleView?id=cc.b2c_account_manager_maintain_security_contact_email.htm&type=5)
  Select up to five contact users to receive security email alerts about changes in B2C Commerce Account Manager.
