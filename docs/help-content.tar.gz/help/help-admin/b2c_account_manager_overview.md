# Account Manager for B2C Commerce

_Account Manager creates, maintains, and disables B2C Commerce accounts. It also grants (or denies) access to selected applications based on the account's credentials. Account Manager supports two different types of users: account administrators and non-administrative users. Account administrators can do everything non-administrative users can do. Account administrators can also create accounts, disable accounts, and so on. At least one account administrator is assigned to each organization. Before you can use Account Manager, you must log in._

[Which Salesforce Commerce Product Do I Have?](https://help.salesforce.com/s/articleView?id=commerce.comm_what_product.htm)
