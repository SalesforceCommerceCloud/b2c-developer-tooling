# Generate a Short Code and Create an API Client ID

_To use the B2C Commerce API (SCAPI), you need:_

A short code. For instructions on getting your short code, see [Configuration Values](https://developer.salesforce.com/docs/commerce/commerce-api/guide/commerce-api-configuration-values.html) in the *B2C Commerce API Developer Guide*.Starting in B2C Commerce 26.7, generate a dedicated short code for on-demand sandboxes (ODS) as well as non-ODS realms. Previously, ODS realms shared a common short code (`kv7kzm78`). The shared short code continues to work. However, if you use SLAS hybrid auth or encounter the error "Cannot construct SLAS session-bridge URL: no ACTIVE SCAPI short code found for this organization," generate your dedicated short code to resolve the issue. An API client ID and authorization token for the CDN Zones API. See [CDN Zones-Content Delivery Network](https://developer.salesforce.com/docs/commerce/commerce-api/references/cdn-api-process-apis?meta=Summary). When you obtain the API authorization token, make sure that the `<tenant_id>` matches the instance.

- For the eCDN development process, use `<realm>_dev`.
- For the eCDN staging process, use `<realm>_stg`.
- For the eCDN production process, use `<realm>_prd`.

When you complete the short code and API authorization, use the returned values to call the various endpoints required throughout the process.

- `{shortcode}`
- `{organizationId} - f_ecom_<realm>_stg`
