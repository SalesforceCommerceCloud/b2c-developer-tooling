# Validate a New Certificate for B2C Commerce

_Validate the new certificate for your eCDN zone using the managed or self-managed process._

1. To validate a managed certificate, see [Add Managed SSL Certificates](https://help.salesforce.com/s/articleView?id=cc.b2c_add_managed_ssl_certificates.htm&type=5).
2. To validate a self-managed certificate, see [Add Self-Managed SSL Certificates](https://help.salesforce.com/s/articleView?id=cc.b2c_add_self_managed_ssl_certificates.htm&type=5).
