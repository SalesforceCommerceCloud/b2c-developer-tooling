# Add Flows and Steps for B2C Commerce Jobs

_B2C Commerce jobs run steps that execute various tasks. A flow controls the sequence in which B2C Commerce executes job steps._

[Which Salesforce Commerce Product Do I Have?](https://help.salesforce.com/s/articleView?id=commerce.comm_what_product.htm)

Before you can add flows and steps, create the job. See [Create and Schedule a B2C Commerce Job](https://help.salesforce.com/s/articleView?id=cc.b2c_create_job.htm&type=5).

In B2C Commerce Business Manager, add at least one flow and the steps that flow runs.

1. Add at least one flow.

   1. From the App Launcher _(image: App Launcher)_, find and select **Administration > Operations > Jobs**, and then open the job.
   2. On the job page, click the **Job Steps** tab.
   3. To add sets of sibling flows, click _(image: Icon for adding a new sibling flow.)_
   4. For each set of sibling flows, specify either parallel or sequential processing. _(image: Icon for selecting parallel or sequential processing for a set of sibling flows.)_
   5. To add another sequential flow, click _(image: Plus symbol icon for adding a new sequential flow.)_ at the bottom of a flow.
   6. Select a scope for the flow.
   
      For what each scope option does, see [Where a B2C Commerce Job Flow Runs](https://help.salesforce.com/s/articleView?id=cc.b2c_scope.htm&type=5).
2. Add steps to the flows, and perform all of the following actions for each step.

   > **Note:** Some job steps, such as CreateSitemap, can execute only in the context of a site. Other job steps, such as ExecuteDataReplication, can execute only in the context of the organization. If you try to assign a job step to a flow that has a scope the step doesn't support, the step shows an error.
   
   1. On the **Job Steps** tab, select the flow where you want to add a step.
   2. Click **Configure a step**, and select a step.
   3. Configure the step parameters. Required parameters are marked with a red asterisk. For some parameters, hover over the parameter to see what to enter.
   4. If applicable, select **Always execute on restart.**. The step runs when the job is restarted, even if the step was already completed.
