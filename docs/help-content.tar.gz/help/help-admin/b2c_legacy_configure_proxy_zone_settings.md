# Configure Proxy Zone Settings

_After you migrate a B2C Commerce legacy zone to a proxy zone, most settings transfer automatically. Manually copy the two settings that don't transfer, Logpush and rate limiting rules, from the legacy zone to the new proxy zone._

[Which Salesforce Commerce Product Do I Have?](https://help.salesforce.com/s/articleView?id=commerce.comm_what_product.htm)

When you migrate a legacy zone to a proxy zone, most zone settings are transferred automatically. Two settings aren't, so copy each one manually from the legacy zone to the proxy zone: the Logpush configuration and the rate limiting rules. This task is part of the migration sequence. See [Proxy Zone Migration Overview](https://help.salesforce.com/s/articleView?id=cc.b2c_migrating_proxy_zones.htm&type=5).

1. In Business Manager, click the App Launcher _(image: App Launcher)_, and then select **Administration > Sites > Embedded CDN Settings**.
2. Copy the Logpush settings from the legacy zone to the proxy zone.

   1. In the legacy zone you migrated, select **Settings > Logpush**.
   2. Select and copy the Logpush setting.
   3. In the new proxy zone, select **Settings > Logpush**.
   4. Paste the Logpush setting.
   5. Validate bucket ownership using the CDN-API. See [eCDN Logpush](https://developer.salesforce.com/docs/commerce/commerce-api/guide/cdn-zones-logpush.html).
3. Copy the rate limiting rules from the legacy zone to the proxy zone by using the CDN-API.

   1. Retrieve the rate limiting rules from the legacy zone.
   2. Create the same rate limiting rules on the new proxy zone. See [eCDN Rate Limiting Rules](https://developer.salesforce.com/docs/commerce/commerce-api/guide/cdn-rate-limiting-rules.html).

Continue with [Create a Custom Hostname with a Custom Certificate](https://help.salesforce.com/s/articleView?id=cc.b2c_legacy_create_custom_hostname_with_custom_cert.htm&type=5).
