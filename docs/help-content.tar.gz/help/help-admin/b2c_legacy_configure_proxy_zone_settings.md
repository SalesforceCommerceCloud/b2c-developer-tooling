# Configure Proxy Zone Settings

_Configure Proxy Zone Settings for Legacy Zone Migration._

|  |
| --- |
| Available in: **B2C Commerce** |

When you migrate a legacy zone to a proxy zone, most of the zone settings are automatically transferred. However, there are some settings, you manually copy from the legacy zone to the proxy zone.

1. In Business Manager, click App Launcher _(image: App Launcher)_, and then select **Administration > sites > Embedded CDN Settings**.
2. Copy the Logpush settings. .

   1. In the window for the legacy zone you previously migrated, select **Settings > Logpush**.
   2. Select and copy the logpush setting.
   3. In the new proxy zone, select **Settings > Logpush**.
   4. Paste the logpush settings.
   5. Validate bucket ownership using the CDN-API. See [eCDN Logpush](https://developer.salesforce.com/docs/commerce/commerce-api/guide/cdn-zones-logpush.html)
3. Copy Rate Limit Rule using API. .

   1. In the legacy zone, select **Settings > Rate Limit Rule using API**.
   2. Select and copy the Rate Limit Rule using API.
   3. In the new proxy zone, select **Settings > Rate Limit Rule using API**.
   4. Paste the Rate Limit Rule using API.
   5. Validate bucket ownership using the CDN-API.See [eCDN Rate Limit Rules](https://developer.salesforce.com/docs/commerce/commerce-api/guide/cdn-rate-limiting-rules.html)
