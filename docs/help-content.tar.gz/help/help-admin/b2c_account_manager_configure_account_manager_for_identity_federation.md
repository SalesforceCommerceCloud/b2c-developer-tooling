# Configure Account Manager for Identity Federation in B2C Commerce

_Identity federation enables users to access multiple applications or systems with a single set of credentials. When you combine identity federation with a Salesforce My Domain, users can link their Salesforce Identity or third-party Identity and Access Management (IAM) credentials with Account Manager._

[Which Salesforce Commerce Product Do I Have?](https://help.salesforce.com/s/articleView?id=commerce.comm_what_product.htm)

1. Log in to Account Manager.
2. Click **Organization** and select the organization that you want to add identity federation to.
3. Under Identity Federation with Salesforce Identity, select how to enable identity federation.

   1. **Allowed**: A user can decline to link their Account Manager account with Salesforce Identity and still log in to B2C Commerce with an Account Manager account.
   2. **Enforced**: If a user declines to link their Account Manager account with Salesforce Identity, they no longer can log in to B2C Commerce with an Account Manager account.
   3. **Disabled**: Users can’t link their Account Manager account with Salesforce identity.
4. (Optional) Select Just-in-time User Provisioning.

   This option automatically provisions new users in Account Manager. The setting applies only if identity federation is enabled and the Salesforce My Domain is verified.
5. Specify the `My Domain` subdomain of your organization.

   1. Use the dropdown menu to change the suffix.
   
      The default domain suffix is `my.salesforce.com`. If the identity federation is allowed or enforced, you can change the value. For example, if you use a Salesforce Core sandbox, you can use `sandbox.my.salesforce.com` as the domain suffix.
      
      Supported Salesforce Core domain suffixes include:
      
      - `my.salesforce.com`
      - `sandbox.my.salesforce.com`
      - `develop.my.salesforce.com`
      - `trailblaze.my.salesforce.com`
      - `scratch.my.salesforce.com`
      - `sfdctest.my.salesforce.com`
      
      > **Note:** After a user enters the wrong password six times, their account is locked for 30 minutes. In the Account Manager user list, the account is marked as for 30 min. In the Account Manager user list, the account is marked as **temporary locked**.
      
      To change the subdomain name after setup, reset the Salesforce Identity integration. For these steps and answers to other common questions, see [b2c_account_manager_idfed_faq_troubleshooting.xml](https://help.salesforce.com/s/articleView?id=cc.b2c_account_manager_idfed_faq_troubleshooting.htm&type=5).
6. If you selected the Just-in-time option, authenticate with your Salesforce org. Click **Start verification**.

   If you don’t see the Start verification link, save your configuration and refresh the page.
   
   > **Note:** If you disable identity federation and later enable it, verify My Domain again.

_(image: Identity Federation settings)_

_(image: Identity Federation settings)_
