# Inventory Management

_To manage storefront inventory data, connect B2C Commerce to an external inventory management system that serves as your system of record. Rely on the platform for basic tracking or integrate Salesforce Omnichannel Inventory to access advanced availability features. This integration makes sure of accurate stock levels and supports complex fulfillment scenarios._

### Inventory Basics

Your inventory solution can include availability tracking in B2C Commerce and inventory data exchange with an external system. For example, B2C Commerce can import inventory data at regular intervals. To avoid overselling between imports, update local data when creating orders.

Beginning with release 21.2, you can use Salesforce Omnichannel Inventory. Omnichannel replaces some of the B2C Commerce platform’s inventory functionality and provides a more full-featured interface with your external inventory management system. It’s designed to integrate easily with B2C Commerce and Salesforce Order Management. Omnichannel Inventory records in B2C Commerce are read-only.

For more information about Omnichannel Inventory with B2C Commerce, see [b2c_inventory_management_omnichannel_inventory.xml](https://help.salesforce.com/s/articleView?id=cc.b2c_inventory_management_omnichannel_inventory.htm&type=5).

> **Note:** When you integrate B2C Commerce with Omnichannel Inventory, some of the functionality described in this topic works differently or isn’t available. Carefully review the details to understand the differences.

### Inventory Features

Some of B2C Commerce’s inventory features include:

- Information about product availability based on current and future stock level information.
- Different types of order availability, such as backorders, preorders, and perpetual availability. (Omnichannel Inventory doesn’t directly support these types. Instead, it uses a future inventory system.)
- Requests to the external system or to Omnichannel Inventory to reserve specific quantities of products for an order.
- Automatic adjustment of visible availability when reserving inventory for an order in the external management system.
- Use of availability data in promotion rules.
- Use of availability data in product search results.
- Support for Script API customizations, such as:
   
   - Buy Online, Pick up in Store (BOPIS) orders
   - Temporary inventory reservations for baskets
   - Partial inventory reservations for baskets

If you manage inventory on the B2C Commerce platform, use Business Manager to:

- Import inventory data according to the Inventory.xsd schema.
- Create individual product inventory records, including perpetual, pre-order, and backorder settings.
- Extend the ProductInventoryRecord object to store custom attributes. For example, include a product-specific message to appear when the inventory of a product drops below a certain threshold value.

To learn how storefront cart and product detail pages show availability information, see [Page Designer Resources](https://help.salesforce.com/s/articleView?id=cc.b2c_page_designer_merch_resources.htm).

### Inventory Lists

Inventory lists define a set of inventory records associated with individual products. You can use each inventory list with one or more sites or stores, but each site or store can reference only one inventory list. The inventory list assigned to a site is the default online inventory for that site. When creating an order, B2C Commerce uses this list by default.

Associate each product line item in an order with a store inventory list. When B2C Commerce creates an order, it reserves inventory for each product based on that list. If a product isn’t associated with a store list, then the order uses the site inventory list instead.

Example: A shopper places an order for two products, one for shipment and the other for store pickup. For the shipped product, B2C Commerce requests an inventory reservation based on the site inventory list. For the item at the store, it uses the store inventory list.

If you switch from one inventory list to another, a product's availability immediately changes in the storefront to reflect the new inventory list.

> **Note:** Only the inventory list assigned to the site shows product availability. When viewing any other inventory list, all product availability appears as N/A.

B2C Commerce can store up to 3,000 inventory lists, enforced by the inventory list (Product Inventory Record) quota. Import up to 3,000 inventory lists at a time. To import full and delta inventory lists, use UPDATE, REPLACE, and MERGE modes. To delete records, use REPLACE mode and import data that doesn’t include those records.

Unavailable fields in the Business Manager Inventory module indicate you have read-only permission. Only search for inventory lists and view their details, but you can't modify, delete, or create lists. If you have mixed permission to access one module (via different roles), the higher-level access is granted. See your administrator if you require write access.

For read-only access, the role still needs one of the functional permissions, `Manage_Inventory` (for all inventory lists globally) or `Manage_Site_Inventory` for selected sites.

### Inventory Records

Inventory records describe a product's quantity and availability in the context of an inventory list. It references exactly one product and one list. A list can include only one inventory record for each unique product SKU.

> **Note:** When using Omnichannel Inventory, inventory records in B2C Commerce are read-only. When using Business Manager, set any of the attributes except for Reset Date.

Creating or importing a new product doesn't implicitly create an inventory record. You explicitly create the record in Omnichannel Inventory, through Business Manager, or by import from a third-party tool.

An inventory record includes these attributes.

| Attribute | Description |
| --- | --- |
| Allocation | Quantity of products in stock on the Reset Date. Omnichannel Inventory uses the attribute Allocation as On Hand. |
| Reset Date | Time that the allocation was initialized or reset. |
| Perpetual | Flag that indicates the product is always in stock. For Omnichannel Inventory, this value is always false. |
| Pre-Order/Backorder Handling | If the product is not in stock, indicates a product's availability for order. The possible values are NONE, PREORDER, and BACKORDER. For Omnichannel Inventory, if the product has any future restocks, this value is BACKORDER. If it doesn't the value is NONE. |
| Pre-Order/Backorder Allocation | If the product is out of stock, indicates the quantity of products available for order. For Omnichannel Inventory, this value is the sum of future restocks for the product. |
| In-StockDate | Date that a product is expected to be in stock. For Omnichannel Inventory, this value is the date of the earliest future restock. |

### Inventory Handling

Here are some examples of how your application, based on Business Manager settings, handles specific inventory situations:

| Situation | Your application can... |
| --- | --- |
| A product isn't released yet | Allow or disallow orders Show a customized message to the shopper Provide an availability date Take pre-orders Limit the number of pre-orders |
| A product isn’t in stock | Allow or disallow orders Show a customized message to the shopper Provide an availability date Take backorders Limit the number of back-orders |
| An order requests more units of a product than are in stock | Break an order into X units for immediate delivery and Y units for backorder |
| You don't want to promote out of stock products | Write promotion rules that consider units available to sell (ATS) |
| Out of stock products appear in search lists | Sort unavailable products to the bottom of the search results lists Set the product on-line attribute to `false`. |
| Stock levels are inaccurate | Correct stock levels with an inventory update |

### Product Availability Handling

If a site doesn't have an assigned inventory list, or a product doesn't have an inventory record, B2C Commerce has specific ways of dealing with these conditions.

For bundled products, B2C Commerce doesn't retain availability. Instead, create a product inventory record for the bundle.

| Name | Description | Approach |
| --- | --- | --- |
| Default | No inventory list is assigned to the site. No information is available to derive availability. | Considers all products unavailable. |
| Single site setting | The site has an inventory list, but the product doesn't have a record. | If the default is `in stock`,B2C Commerce considers the product in stock. Otherwise, the product isn't available. |
| Single product setting | The product has an inventory record, but no allocation is specified. | If `Perpetual` is set, B2C Commerce considers the product in stock. Otherwise, the product isn't available. |
| Allocation tracking | The product has an inventory record and an allocation is specified. | Calculates the availability at run time. |

> **Note:** Availability information can't be staged.
