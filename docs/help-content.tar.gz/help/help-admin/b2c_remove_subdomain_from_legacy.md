# Remove a Subdomain from a Legacy Zone

_After you migrate a subdomain to the proxy zone, remove it from the legacy zone and delete the old certificate so that the legacy certificate no longer shows on your B2C Commerce storefront._

[Which Salesforce Commerce Product Do I Have?](https://help.salesforce.com/s/articleView?id=commerce.comm_what_product.htm)

This task has two parts: first remove the subdomain from the legacy zone, then delete the legacy certificate. It's part of the migration sequence. See [Proxy Zone Migration Overview](https://help.salesforce.com/s/articleView?id=cc.b2c_migrating_proxy_zones.htm&type=5).

1. In Business Manager, click the App Launcher _(image: App Launcher)_, and then select **Administration > Sites > Embedded CDN Settings**.
2. Remove the subdomain from the legacy zone.

   1. Click the trash icon for the legacy zone.
   2. Click **Remove Subdomain**.
3. Delete the legacy zone certificate.

   1. On the **Crypto** tab, locate the legacy zone certificate and click the **X** icon.
   2. In the confirmation message, click **Delete**.

When all subdomains are migrated and removed, continue with [Delete a Legacy Zone](https://help.salesforce.com/s/articleView?id=cc.b2c_legacy_delete_legacy_zone.htm&type=5).
