# Remove a Subdomain from a Legacy Zone

_After you migrate a subdomain to the proxy zone, remove it from the legacy zone and delete the self-managed certificate that you uploaded for that subdomain._

Confirm that the subdomain's DNS points to the new proxy zone and that no valid traffic still reaches the legacy zone. The legacy zone's Universal SSL certificate can keep serving valid traffic without errors, making an incomplete cutover easy to miss. See [Update Authoritative DNS](https://help.salesforce.com/s/articleView?id=cc.b2c_legacy_update_auth_dns.htm&type=5).

[Which Salesforce Commerce Product Do I Have?](https://help.salesforce.com/s/articleView?id=commerce.comm_what_product.htm)

1. In Business Manager, click the App Launcher _(image: App Launcher)_, and then select **Administration > Sites > Embedded CDN Settings**.
2. Remove the subdomain from the legacy zone.

   1. Click the trash icon for the legacy zone.
   2. Click **Remove Subdomain**.
3. Delete the self-managed certificate for the subdomain.

   1. On the **Crypto** tab, locate the self-managed certificate for the subdomain and click the **X** icon.
   2. In the confirmation message, click **Delete**.

When all subdomains are migrated and removed, continue with [Delete a Legacy Zone](https://help.salesforce.com/s/articleView?id=cc.b2c_legacy_delete_legacy_zone.htm&type=5).
