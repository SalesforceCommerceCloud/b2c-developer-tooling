# Pipelets for Import and Export in B2C Commerce

_Use pipelets to import and export automatically within an application. This topic applies to B2C Commerce._

| Pipelet | Description |
| --- | --- |
| ExportCatalog | Exports selective information in the specified Catalog. This pipelet offers granular control over the information that the *ExportXXX* input parameters export. Use it also to export a specific list of categories or products. |
| ExportContent | Exports the specified Folders in the specified content Library. |
| ExportCoupons | Exports the specified Coupons. |
| ExportCustomers | Exports the customer Profiles contained in Customers. |
| ExportCustomObjects | Exports the specified CustomObjects. |
| ExportGiftCertificates | Exports Gift Certificates. |
| ExportMetadata | Exports the system metadata according to the input parameters. |
| ExportOrders | Exports the specified Orders, with optional encryption of payment information (credit card or bank account). B2C Commerce exports masked versions if there’s no new encryption information. B2C Commerce marks orders as *exported* during execution. The *UpdateExportStatus* (boolean) input parameter enables you to specify how the order export status and on-order inventory are handled. When you use this pipelet to export orders, enable this parameter to update the Order Export status and the inventory. |
| ExportPriceBooks | Exports the specified price books. |
| ExportShippingMethods | Exports the specified ShippingMethods. |
| ExportSourceCodes | Exports the specified SourcCodeGroups. |
| ExportStores | Exports the specified Stores. |
| ExportTaxTable | Exports all tax classes, tax jurisdictions, and tax rates of the current site. |
| ImportCatalog | Imports the catalog data specified by ImportFile into the system in the specified mode. |
| ImportContent | Imports the data specified by ImportFile into the specified Library in the specified mode. |
| ImportCustomers | Imports the customers contained in ImportFile in the specified mode. |
| ImportCustomObjects | Imports the custom object data contained in ImportFile in the specified mode. |
| ImportGiftCertificates | Imports the gift certificates contained in ImportFile in the specified mode. |
| ImportInventoryList | Imports the inventory lists contained in ImportFile in the specified mode. |
| ImportPriceBooks | Imports the price data contained in ImportFile in the specified mode. |
| ImportShippingMethods | Imports the shipping methods contained in ImportFile in the specified mode. |
| ImportSourceCodes | Imports the source code groups contained in ImportFile in the specified mode. |
| ImportStores | Imports the stores contained in ImportFile in the specified mode. |
| ImportTaxTable | Imports the tax classes, tax jurisdictions, and tax rates contained in ImportFile in the specified mode. |
| ValidateXMLFile | Validates the given XML file against the given xsd schema definition and returns a status reporting the results of the validation.  If the validation operation executes with no process error, regardless of whether the XML file is valid, the pipelet returns next. If the given XML file or xsd schema file doesn’t exist in the given path, the pipelet exits in a pipelet error. The status contains the status of the validation. |

The *Status* output property represents the result of any B2C Commerce import operations (via a pipelet). The pipelet returns to the error connector if a process error occurs when executing the import. A process error prevents or interrupts the basic execution of the import. An example of a process error is when the specified import file doesn't exist on the file system. We recommend that client code consults Status object details to determine if there were any problems importing the individual data within the import file.
