# Payment Processor Information Import and Export in B2C Commerce

_Only import or export payment processor information using site import and export. This topic applies to B2C Commerce._

| Object Information | Details |
| --- | --- |
| Schema file | paymentprocessor.xsd |
| Granularity | Selected payment processors. |
| Business Manager import and export location | ***site* > Administration > Site Development > Site Import & Export** |
| Pipelets | N/A |
