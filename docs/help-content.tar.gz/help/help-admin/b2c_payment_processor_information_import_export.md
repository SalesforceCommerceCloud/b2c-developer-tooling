# Payment Processor Information Import and Export in B2C Commerce

_Import or export payment processor information (schema file `paymentprocessor.xsd`) only through site import and export, from Administration, Site Development, Site Import & Export in Business Manager. The Ordering module doesn't handle payment processors, unlike payment methods._

A payment processor authorizes and settles transactions with a payment provider, such as a credit card gateway or PayPal. Processor import and export moves the processor definitions and their provider preferences, not the storefront payment options that shoppers see. To create or configure processors, see [../ordering/b2c_managing_payment_processors.xml](https://help.salesforce.com/s/articleView?id=cc.b2c_managing_payment_processors.htm&type=5).

Payment processors aren't part of the Ordering module, so there's no standalone import or export for them. Processors move only within a full site import or export, from Administration, Site Development, Site Import & Export.

| Object Information | Details |
| --- | --- |
| Schema file | paymentprocessor.xsd |
| Granularity | Selected payment processors. |
| Business Manager import and export location | ***site* > Administration > Site Development > Site Import & Export** |
| Pipelets | N/A |
