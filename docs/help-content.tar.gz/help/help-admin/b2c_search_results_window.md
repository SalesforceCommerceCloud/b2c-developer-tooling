# Search Results Window in the Search Information Tool in B2C Commerce

_The Search Results window shows basic information about the search results. This window appears only if your site has implemented the `isobject` Internet Store Markup Language (ISML) tag appropriately. This topic applies to B2C Commerce._

For information about implementing the `isobject`, see [b2c_implementing_the_search_information_tool.xml](https://help.salesforce.com/s/articleView?id=cc.b2c_implementing_the_search_information_tool.htm&type=5).

The SKU in bold in the Represents field is the highest ranked variation product that the search finds. The category is the path to the current search result. If no value exists for an attribute, the value shows as Null. A product without a value for an attribute is ordered after products that have a value.

### Represents Window

If the product you inspect is a base product, click the information icon in the Represents field to show the individual SKUs.

### Text Relevance Explanation Window

To see information about the text relevance scoring for a search result, click the information icon in the Text Relevance field. The Text Relevance Explanation window can help you determine how terms found in attributes contribute to the text relevance score. In the following example, see that most of the score for the term `hiker` comes from hits in the content-text field, not the ShortDescription field (0.15 vs 0.03). The content-text field includes all indexed information for all fields, except fields that have a boosting factor applied._(image: Text Relevance Explanation window)_

- **Total Score**: The sum of all term matches scores. This score is the value of the text relevance score before it's normalized. The normalized score appears in the Search Results Window.
- **Term Match Scores**: The product of all field matches.
- **Field Matches**: The product of the queryWeight and the fieldWeight. All unboosted fields are processed together and shown as the content-text field. Boosted fields show with their name.
- **Query Weight**: The query weight is the product of the idf (inverse document frequency) and the queryNorm (query normalizing factor). The idf(t) value is the inverse of docFreq (the number of documents in which the term t appears). Rarer terms give higher contribution to the total score. The queryNorm doesn't affect document ranking (because all ranked documents are multiplied by the same factor), but makes scores from different queries (or even different indexes) comparable.**Field Weight**: The field weight is the product of the tf (term frequency), the idf (inverse document frequency), and the fieldNorm (field normalizing factor). The tf(t) is the term's frequency, defined as the number of times term t appears in the currently scored document d. Documents that have more occurrences of a given term receive a higher score. The idf(t) value is the inverse of docFreq (the number of documents in which the term t appears). The fieldNorm doesn't affect field scores, because all scores are multiplied by the same factor, but does make scores from different fields comparable.

### Dynamic Attributes Window

If the product includes a dynamic attribute, click the information icon beside the dynamic attribute to show the following information.

- **Attribute name**
- **Reporting period**: Time period for data in the attribute value. For example, `Views (30 days)` is the number of product views over 30 days.
- **Weighting**: Percentage of the total score from this attribute. For example, `Look To Book Ratio [25%]` means that 25% percent of the total score comes from the normalized score of the Look To Book Ratio attribute.
- **Summary score**: Score for the product before the score is weighted and normalized. To compare the value for an attribute in a dynamic attribute to the same attribute in a search result, use the normalized score instead of this score.

If your sorting rule uses a dynamic attribute, click the information icon to see additional information about the rule. The attribute score is the score for each attribute after it's weighted and normalized. Normalizing scores distributes them from 0 to 1. This process makes scores more relevant in relation to each other. The attribute score also includes the sorting value, which is the sum of all attribute scores. The sorting value determines the position of the product.

Click the information icon for a searchable attribute used in the dynamic attribute to display the following information:

- **Direction**: Sorting direction is either `Ascending`, which sorts the search results from the lowest value to the highest (A–Z, 1–100) or `Descending`, which sorts the search results from the highest value to the lowest (Z-A, 100-1).
- **Weight**: Percentage of the total score determined by this attribute. The sum of the weights for all attributes must add up to 100%. For example, if the weight of the Views attributes is 25%, then the weight of the other attributes used in the dynamic attribute must add up to 75%.
- **Values**:
   
   - **Min, Max, Avg**: Minimum, maximum, and average values for this attribute for all indexed products. Search calculates the minimum, maximum, and average of each used attribute based on the current search result. The minimum, maximum, and average values are used for normalization and weighing, meaning the final sorting value of a search hit can be different for different search results. The score of a search hit is calculated in relation to the other search hits, and isn’t a fixed value.
   - **Default**: If an attribute doesn't have data defined or the data is stale, the default value determines whether the item appears at the top, bottom, or middle of search results. The default designation `(Default)` appears after the default number. For example, if the entry is `Min=74 (Default) Max=149219 Avg=9246.0` the default value is `74`. Use the default value to control how products that don't have data defined or stale data is treated. For example, a set of new products doesn't yet have sales velocity data, but you want to feature them at the top of a section for Hot Items. The Hot Items section sorts by descending sales velocity. Set the default to `Maximum`. New items with undefined data automatically appear at the top of the search results.
- **Product Value**: Value of this attribute for this product.
- **Formula**: Formula used to calculate the normalized score for the product search result.
- **Calculation**: Values used in the formula to calculate the normalized score.
- **Normalized Value**: Normalized score that determines the sorting position of the search result.
