# User Authentication and Authorization in B2C Commerce

_As an administrator, you configure security controls in Business Manager. You must perform authentication to determine if the Business Manager user is who they claim to be. You can also perform authorization to determine if the user has permission to perform the specific action they’re attempting._
