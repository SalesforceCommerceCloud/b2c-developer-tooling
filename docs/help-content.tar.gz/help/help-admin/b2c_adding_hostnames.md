# Add Hostnames to an eCDN Zone

_You can configure subdomains of the same zone on the same Salesforce B2C Commerce instance, or on different instances of different realms of the same retailer. For example, you can have www.shop.com on the Production instance, test.shop.com on the Development instance, and eu.shop.com on the Production instance of the EU realm._

[Which Salesforce Commerce Product Do I Have?](https://help.salesforce.com/s/articleView?id=commerce.comm_what_product.htm)

> **Note:** You can't add or remove hostnames on a SCAPI zone. Salesforce auto-provisions the SCAPI hostname, and **Add Hostname** shows 0 hostnames available. See [SCAPI Zone Support for B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_scapi_zone.htm&type=5).

- To validate a hostname and cut over DNS with the CDN Zones API instead, see [CDN Zones](https://developer.salesforce.com/docs/commerce/commerce-api/guide/cdn-zones.html#validate-the-hostname-and-cut-over-dns) in the developer documentation.
- For multiple subdomains on the same base domain, consider using a single wildcard custom hostname. See [Configure Wildcard Custom Hostnames](https://help.salesforce.com/s/articleView?id=cc.b2c_add_wildcard_custom_hostname.htm&type=5).
- For permission rules that apply to legacy zones, see [Legacy Zones and Proxy Zone Migration](https://help.salesforce.com/s/articleView?id=cc.b2c_migrating_proxy_zones.htm&type=5).

1. Click App Launcher _(image: App Launcher)_, and then select **Administration > Sites > Embedded CDN Settings > Add Hostnames**.

   The Additional Hostnames slider opens from the right side of the page. This slider shows the names of zones and hostnames (subdomains) that you can add to the Embedded CDN Settings page. If the list is long, search for specific zones and hostnames using the search field. If you don’t see the hostname you want, verify that it exists in the site's Aliases section under **Merchant Tools > *site* > SEO & Discoverability > Aliases**.
2. Select a hostname in the list and click **Add Hostname**.

   Business Manager adds the hostname to the Embedded CDN Settings page, as a child of its zone.
   
   After you add an SSL certificate and activate the hostname, complete the remaining steps.
3. Test inbound communication through the embedded CDN by resolving your custom hostname to the IP address of the embedded CDN locally (modify /etc/hosts).

   Example: 104.12.34.7 shop.abcd.com
   
   The CDN domain name resolves to different IP addresses over time. Using a fixed IP address is acceptable for testing purposes only.
4. In your DNS server configuration, point the DNS record of your hostname to the embedded CDN.

   Create a CNAME record. The value of the record appears in Business Manager.

> **Note:** Removing a hostname from a zone doesn't remove it from the zone's SSL certificate. To remove the hostname from the certificate, update the certificate.
