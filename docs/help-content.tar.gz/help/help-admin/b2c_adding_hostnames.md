# Add Hostnames (Subdomains)

_Subdomains of the same zone can be configured on the same Salesforce B2C Commerce instance, or on different instances of different realms of the same retailer._

> **Note:** You can't add or remove hostnames on a SCAPI zone. Salesforce auto-provisions the SCAPI hostname, and **Add Hostname** shows 0 hostnames available. See [SCAPI Zone Support for B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_scapi_zone.htm&type=5).

For example, configure *www.shop.com* on the Production instance, *test.shop.com* on the Development instance, and *eu.shop.com* on the Production instance of the EU realm.

For legacy zones only: To prevent damage to the production experience, users on a non-Production instance can't modify subdomains configured on other instances. In addition, users can’t modify certificates on a zone with at least one Production instance as origin. However, they can add hostnames to existing zones with Production instance origins. Users on Production instances can modify all CDN settings, even if another Production instance of the same retailer is impacted.

> **Note:** For multiple subdomains on the same base domain, consider using a single wildcard custom hostname. See [Wildcard Custom Hostnames](https://help.salesforce.com/s/articleView?id=cc.b2c_add_wildcard_custom_hostname.htm&type=5).

1. Click App Launcher _(image: App Launcher)_, and then select **Administration > Sites > Embedded CDN Settings > Add Hostnames**

   The Additional Hostnames slider opens from the right side of the page. This slider shows the names of zones and hostnames (subdomains) that you can add to the Embedded CDN Settings page. If the list is long, search for specific zones and hostnames using the search field.
2. Select a hostname in the list and click **Add Hostname**.

   Business Manager adds the hostname to the Embedded CDN Settings page, as a child of its zone.
   
   After you add an SSL certificate and activate the hostname, complete Steps 3 and 4.
3. Test inbound communication through the embedded CDN by resolving your custom hostname to the IP address of the embedded CDN locally (modify/etc/hosts).

   The CDN domain name resolves to different IP addresses over time. Using a fixed IP address is acceptable for testing purposes only.
4. In your DNS server configuration, point the DNS record of your hostname to the embedded CDN.

   Create a CNAME record. The value of the record appears in Business Manager.
