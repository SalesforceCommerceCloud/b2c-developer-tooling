# Set up and Integrate OKTA with Salesforce Identity

_This guide serves as a general integration overview for B2C Commerce. For precise instructions, Salesforce advises consulting the most up-to-date integration documentation specific to your Identity Provider (IDP), such as Okta._

[Which Salesforce Commerce Product Do I Have?](https://help.salesforce.com/s/articleView?id=commerce.comm_what_product.htm)

The SSO support for B2C Commerce is done via core-licensed products and requires three connections.

- Account Manager
- Salesforce Platform
- OKTA

Step 1: To enable Salesforce SSO and enable Salesforce provisioning with OKTA, use [OKTA documentation](https://saml-doc.okta.com/SAML_Docs/How-to-Configure-SAML-2.0-in-Salesforce.html?baseAdminUrl=https://salesforceidentity-admin.okta.com&app=salesforce&instanceId=0oa3z1twaYjgu968R5d6%20https://help.okta.com/en/prod/Content/Topics/integrations/open-id-connect.htm).

This document contains instructions for configuring Security Assertion Markup Language (SAML) 2.0 for Salesforce (see [Configuring SAML](https://saml-doc.okta.com/SAML_Docs/How-to-Configure-SAML-2.0-in-Salesforce.html)), and other useful information about [How to Configure SP-Initiated SAML between Salesforce and Okta](https://saml-doc.okta.com/SAML_Docs/How-to-Configure-SAML-2.0-in-Salesforce.html) and [How to Configure Delegated Authentication in Salesforce](https://saml-doc.okta.com/SAML_Docs/How-to-Configure-SAML-2.0-in-Salesforce.html) (optional).

Step 2: To allow authenticated users to flow from OKTA to Salesforce, configure [Salesforce as the Service Provider](https://help.salesforce.com/s/articleView?id=xcloud.sso_saml_setting_up.htm&type=5).

SAML is an open-standard authentication protocol that Salesforce uses for SSO into a Salesforce org from a third-party identity provider. You can also use SAML to automatically create user accounts with Just-in-Time (JIT) user provisioning.

When you configure Salesforce as the service provider using SAML, authenticated users can flow from a third-party identity provider into Salesforce.

SAML allows your identity provider to exchange user information with Salesforce. When a user tries to log in, your identity provider sends SAML assertions containing facts about the user to Salesforce. Salesforce receives the assertion, validates it against your Salesforce configuration, and allows the user to access your org.

If your users can’t log in, [review the SAML login history](https://help.salesforce.com/articleView?id=sso_saml_login_history.htm&type=5) to determine why. Use the [SAML Assertion Validator](https://help.salesforce.com/articleView?id=sso_saml_validation.htm&type=5) to troubleshoot errors in the SAML assertion.

### Configuration Help

To configure SSO into your org, establish a SAML identity provider and follow these general steps.

- [Gather Information from Your Identity Provider](https://help.salesforce.com/articleView?id=sso_saml_validation.htm&type=5)
   
   - Before you configure SAML settings for SSO into Salesforce, work with your identity provider to gather SAML information and assertion parameters.
- [Customize SAML Start, Login, Logout, and Error Pages](https://help.salesforce.com/articleView?id=sso_saml_start_stop_pages.htm&type=5)
   
   - When you configure SAML single sign-on into Salesforce, you define URLs for the pages users see throughout the SSO flow. Your identity provider can provide the URLs for the start, login, and logout pages. Or you can provide your own URLs for these pages. You can also specify a custom error page.
- [Configure Salesforce as the Service Provider with SAML Single Sign-On](https://help.salesforce.com/s/articleView?id=xcloud.sso_saml.htm&type=5)
   
   - Configure Salesforce as a service provider with SAML single sign-on.
- [View and Edit Single Sign-On Settings](https://help.salesforce.com/articleView?id=sso_saml_detail.htm&type=5)
   
   - After you configure your Salesforce org to use SAML, you can manage the SAML configuration from the Single Sign-On Settings page.
- [Review the Login History](https://help.salesforce.com/s/articleView?id=xcloud.sso_saml_login_history.htm&type=5)
   
   - When users fail to log in to your org with SSO, search the login history to find out why. For example, see if a login failure is related to the SAML assertion or to your Salesforce configuration.
- [Troubleshoot SAML Assertion Errors](https://help.salesforce.com/articleView?id=sso_saml_validation.htm&type=5)
   
   - Use the SAML Assertion Validator to troubleshoot SSO login problems and identify errors in SAML assertions sent by your identity provider.
- [SAML Login Errors](https://help.salesforce.com/articleView?id=sso_saml_validation_errors.htm&type=5)
   
   - If users have trouble accessing your org with SSO, use the login history to determine whether it’s a SAML assertion error or a configuration problem. If it’s an assertion-related error, identify specific assertion problems with the SAML Assertion Validator. Work with your identity provider to make sure that both the SAML assertion and your SSO configuration are valid.
- [Configure SSO to Salesforce Using Microsoft AD FS as the Identity Provider](https://help.salesforce.com/articleView?id=identity_provider_examples_3p_adfs.htm&type=5)
   
   - Your users can log in from a Microsoft environment to a Salesforce org using Microsoft Active Directory Federation Services (AD FS) 2.0. Microsoft AD FS functions as the identity provider for single sign-on authentication.
- [Just-in-Time Provisioning for SAML](https://help.salesforce.com/articleView?id=sso_jit_about.htm&type=5)
   
   - Use JIT provisioning to automatically create a user account in your Salesforce org the first time a user logs in with single SSO. JIT provisioning can reduce your workload and save time. JIT provisioning also automatically applies password policies for your corporate network to your org, potentially increasing security.
