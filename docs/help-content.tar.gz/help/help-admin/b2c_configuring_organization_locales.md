# Configure Organization Locales for B2C Commerce

_Salesforce B2C Commerce is structured as an organization containing one or more sites (storefronts). Define localization settings for both entities._

|  |
| --- |
| Available in: **B2C Commerce** |

Add new data locales and transfer, add, delete, and update regional settings using Site Import/Export.

After you configure organization locales, configure site locales.

1. To assign the organization's default language, click App Launcher _(image: App Launcher)_, and then select **Administration > Organization > Organization Profile**.

   1. Select the default UI language.
   2. Select the default data language.
   3. Click **Apply**.
2. To activate and deactivate the locales available in the instance, click App Launcher _(image: App Launcher)_, and then select **Administration > Global Preferences > Locales**.

   Only activated locales can be used in the storefront and appear in language select boxes in the Business Manager. The default locale is mandatory and can't be deactivated.
   
   B2C Commerce treats the en, de, and es language-specific locales the same as any other locale. They can only be recognized and related to their respective country-locales (such as en_US and en_GB) via a language code (such as en). Activate or deactivate them and edit their regional settings. You can also select them as a site's default or allowed locale, or a Business Manager's user preferred locale. Regional settings configured on the default locale apply to Business Manager.
   
   1. Select a locale and click **Apply** to activate it.
   2. Deselect a locale and click **Apply** to deactivate it.
   3. Click a Locale ID.
   4. On the General tab, select the fallback locale. This is the locale that is used if the assigned locale isn't available.
   5. On the General tab, to overwrite the default numeral system defined by the CLDR data for this locale, select a numeral system.
   6. Click the **Regional Settings** tab to define how currency appears for the locale.
   
      Regional settings provide format patterns for locale-sensitive operations such as:
      
      - Date/time
      - Number format
      - Currency format
      
      The format for numbers is the Java DecimalFormat. The format for date and time is the Java SimpleDateFormat. For information about these formats, refer to the following sites.
      
      - [https://docs.oracle.com/javase/8/docs/api/java/text/DecimalFormat.html](https://docs.oracle.com/javase/8/docs/api/java/text/DecimalFormat.html)
      - [https://docs.oracle.com/javase/8/docs/api/java/text/SimpleDateFormat.html](https://docs.oracle.com/javase/8/docs/api/java/text/SimpleDateFormat.html)
      
      B2C Commerce is pre-defined with default regional settings for a subset of the locales. Change regional settings for each locale. Regional settings are globally defined (not site-specific).
      
      Use these characters to define currency number, separator, and currency symbol placement: (# , . *).
      
      Use the * symbol to specify where the currency symbol ($, ₤, or €) is placed. For example, look at the Long Currency Positive Pattern field for en_US. The * character indicates where the dollar symbol is placed.
3. To add new locales, click App Launcher _(image: App Launcher)_, and then select **Administration > Global Preferences > Locales**.

   By default, the country locale (for example, en_US) inherits data from the respective language locale (en), and the language locale (en) inherits from the locale default. Configure locale inheritance.
   
   Disable the fallback behavior for each locale.
   
   For example:
   
   - A product description is in the en locale
   - For the en locale, the fallback is disabled and there’s no description for that product
   - Nothing is returned
   
   For each locale, you can configure the fallback to a different locale. For example, you can configure en_US to fall back to default instead of to en.
   
   If you configure a locale as the fallback for another locale, you can't delete it; an error message appears.
   
   For example:
   
   - You configure en_US > en > default.
   - You can't delete en because it's the fallback for en_US.
   - Similarly, if you attempt to import en in delete mode, an error message appears in the import log.
   
   1. Click **Add**.
   2. On the New Locale page, enter the Language Code and Country Code, for example, `fr` and `NL` respectively, for the French locale: French - Netherlands (Locale code *fr_NL*).
   3. Click **Apply**.
   4. Click **<<Back to List**. Because you already added this locale to B2C Commerce, you see the name as *French (Netherlands)*.
4. To transfer, add, delete, and update locales and their regional settings, click App Launcher _(image: App Launcher)_, and then select **Administration > Site Development > Site Import & Export**.

   1. In the Data Units to Export section, expand Global Data.
   2. Select **Locales**.
   3. Enter your export file name and click **Export**.
