# CDN Zones API Overview

_Use the CDN Zones API to create and manage B2C Commerce eCDN zones for your development, staging, and production instances when you want a scripted or self-service alternative to Business Manager. With the API, you can upload custom certificates, configure vanity hostnames, and migrate site traffic._

Business Manager and the CDN Zones API manage the same eCDN zones. Use whichever fits your workflow:

- Use **Business Manager** for interactive, point-and-click setup and management. See [Create a Zone in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_creating_a_zone.htm).
- Use the **CDN Zones API** for scripted, repeatable, or self-service setup. For example, upload custom certificates to test a Shopper Commerce API (SCAPI) implementation, or configure vanity hostnames across instances.

> **Note:** There's one SCAPI zone for Development, Staging, and Production. SCAPI zone controls aren't available through Business Manager or the CDN Zones API on Development or Staging. Configure the SCAPI zone from the Production instance. See [SCAPI Zone Support for B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_scapi_zone.htm&type=5).

The CDN Zones component of the [Salesforce Commerce API](https://developer.salesforce.com/docs/commerce/commerce-api/overview) configures and manages development, staging, and production eCDN zones programmatically. Zones that you create with the API also appear in Business Manager (available in the 24.4 release and later), so you can mix the two management paths.

> **Note:** Since the introduction of [Selective Origin Shielding](https://help.salesforce.com/s/articleView?id=commerce.rn_b2c_selective_origin_shielding_w9698195_21_8_je.htm&type=5) and [Origin Shielding](https://help.salesforce.com/s/articleView?id=000391803&type=1), all traffic through eCDN enforces origin shielding. This enforcement applies to all configured instances.

### API Setup Sequence

To configure eCDN with the CDN Zones API, complete these tasks in order:

- [Short Code and API Client ID Requirements](https://help.salesforce.com/s/articleView?id=cc.b2c_generate_a_shortcode_and_api_client_id.htm&type=5) — get the credentials the API calls require.
- [Create an eCDN Zone and Upload a Certificate](https://help.salesforce.com/s/articleView?id=cc.b2c_create_an_ecdn_zone_and_certificate.htm&type=5) — create zones and certify each hostname.
- [Migrate Site Traffic](https://help.salesforce.com/s/articleView?id=cc.b2c_migrate_site_traffic.htm&type=5) — validate hostnames and cut traffic over to eCDN.
- [Complete Post-Migration Tasks](https://help.salesforce.com/s/articleView?id=cc.b2c_post_migration_process.htm&type=5) — finish staging setup with B2C Commerce Engineering.
- [Renew a Certificate for B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_renew_a_certificate.htm&type=5) — update self-managed certificates as they expire.

## Related Content

- [Short Code and API Client ID Requirements](https://help.salesforce.com/s/articleView?id=cc.b2c_generate_a_shortcode_and_api_client_id.htm&type=5)
  Before you call the CDN Zones API to configure B2C Commerce eCDN, get a short code, an API client ID, and an authorization token whose tenant ID matches the instance you're configuring.

- [Create an eCDN Zone and Upload a Certificate](https://help.salesforce.com/s/articleView?id=cc.b2c_create_an_ecdn_zone_and_certificate.htm&type=5)
  Use the CDN Zones API to create a B2C Commerce development, staging, or production zone, then certify each hostname — with an eCDN managed certificate or by uploading your own self-managed certificate in PEM format.

- [Migrate Site Traffic](https://help.salesforce.com/s/articleView?id=cc.b2c_migrate_site_traffic.htm&type=5)
  After you create your B2C Commerce eCDN zones and certificates, validate each hostname and update DNS to cut site traffic over to eCDN — optionally stacking a third-party CDN such as Akamai in front.

- [Complete Post-Migration Tasks](https://help.salesforce.com/s/articleView?id=cc.b2c_post_migration_process.htm&type=5)
  After you migrate B2C Commerce site traffic to eCDN, coordinate with B2C Commerce Engineering to validate the traffic flow, revert the origin certificate, and create the staging Business Manager zone.

- [Renew a Certificate for B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_renew_a_certificate.htm&type=5)
  Development, staging, and production zone certificates require renewal when you use self-managed SSL certificates.
