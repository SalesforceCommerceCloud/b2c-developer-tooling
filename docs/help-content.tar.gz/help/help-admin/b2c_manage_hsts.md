# HTTP Strict Transport Security (HSTS) for eCDN

_HTTP Strict Transport Security (HSTS) secures your B2C Commerce site by instructing web browsers to access your domain using only HTTPS, which prevents downgrade attacks. You enable and disable HSTS per eCDN zone in Business Manager._

[Which Salesforce Commerce Product Do I Have?](https://help.salesforce.com/s/articleView?id=commerce.comm_what_product.htm)

When HSTS is enabled, your site sends an HSTS header that tells web browsers to connect only over HTTPS. After a browser receives the header, it uses HTTPS for every later visit until the max age expires, which helps prevent downgrade attacks. Because the browser gets the header only after it connects, a shopper's first visit can still happen over HTTP. For extra security, you can enable preload. Major web browsers include a built-in list of domains, called the HSTS preload list, that they always open over HTTPS. Enabling preload is one step toward adding your domain to this list. After your domain is on the list, web browsers use HTTPS for your site from the first request.

All current major web browsers support HSTS. Details, such as how long a browser keeps HSTS settings in private browsing or how quickly it updates its preload list, vary by browser.

## Related Content

- [Configure HSTS for an eCDN Zone](https://help.salesforce.com/s/articleView?id=cc.b2c_configure_hsts.htm&type=5)
  Enable HTTP Strict Transport Security (HSTS) for a B2C Commerce eCDN zone to make web browsers connect to your domain over HTTPS only. Set the max age, choose whether HSTS applies to subdomains, and optionally enable preload.

- [Disable HSTS for an eCDN Zone](https://help.salesforce.com/s/articleView?id=cc.b2c_disable_hsts.htm&type=5)
  Disabling HTTP Strict Transport Security (HSTS) for a B2C Commerce eCDN zone is a two-step process. You first let shoppers access your site over an insecure connection by setting the max age to 0, and then you stop your site from sending the HSTS header.
