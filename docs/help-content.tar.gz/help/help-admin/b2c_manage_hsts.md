# Manage HSTS in B2C Commerce

_To secure your site, HTTP Strict Transport Security (HSTS) instructs web browsers to access your domain using only HTTPS. This topic applies to B2C Commerce._

## Related Content

- [Configure HSTS for B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_configure_hsts.htm&type=5)
  HTTP Strict Transport Security (HSTS) secures your site by instructing web browsers to access your domain using only HTTPS. HSTS prevents attackers from using downgrade attacks against your site. For extra security, enable preload, which forces web browsers to open your site in HTTPS the first time it's requested. Read the Internet Engineering Task Force (IETF) on HSTS for more information.

- [Disable HTTP Strict Transport Security (HSTS) for B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_disable_hsts.htm&type=5)
  Disabling HSTS is a two-step process. You first let shoppers access your site using an insecure connection and then, stop your site from sending HSTS in the header.
