# Security Managed by Salesforce

_Salesforce ensures that security is a focus of B2C Commerce development and provides secure development and platform-level security._

### Security-Focused Development

Salesforce secure development lifecycle (SSDL) delivers security at every stage of the development process. The SSDL provides education, industry-leading processes, and tools to ensure predictability, accountability, and transparency. Secure development best practices include defense in depth, least privilege, secure defaults, and regular static and dynamic vulnerability analyses.

Salesforce secure development lifecycle:

- Applies Open Web Application Security Project (OWASP) secure coding principles.
- Performs threat modeling activities on all products and newly developed features before implementation.
- Administers static and dynamic vulnerability scans.
- Conducts regular third-party security assessments.
- Supports customer-initiated security assessments.
- Supports customers with Q&A sessions and peer reviews.

### B2C Commerce Platform-Level Security

B2C Commerce takes a defense in depth approach when protecting its production environments. This approach includes multiple security controls at the application, infrastructure, and network levels to make sure that customer data is securely processed and stored.

The multiple applications that make up B2C Commerce provide strong authentication mechanisms. You can authorize authenticated users to access various parts of the application depending on their role. The SSDL ensures that these features provide security controls that protect the users while enabling customization.

The infrastructure level has multiple layers of trust, with firewalls and access controls at every level of the system including the database layer.

- We enforce multi-tenancy at the database layer that provides protections from data being accessed across tenants.
- Each tenant has its own database, and all data is tied to the tenant’s org ID and entitlements.
- Encryption secures data in transit to prevent potential open data exposure when it travels between primary and backup locations.
- Also, security extends to the physical layer in our data centers. For example, when disks in our data centers reach their end of life, they’re erased and then shredded—so that the data can’t be recovered.

We notify customers of security advisories related to the B2C Commerce platform on the Security Advisories site.

### Tracking Internal User Access

The B2C Commerce Security model regarding actions taken by Salesforce employees on customer realms includes transparent logging of all sensitive areas. For more information, see [b2c_security_event_auditing.xml](https://help.salesforce.com/s/articleView?id=cc.b2c_security_event_auditing.htm&type=5).
