# Geolocation Object Import and Export in B2C Commerce

_The geolocation.xsd schema supports importing store geolocations based on ZIP code._

When configuring the geolocation object, keep the following in mind:

- The root geolocations element serves as a wrapper for various geolocation elements for a single country.
- The country is defined as an attribute of the root geolocations element.
- The geolocation element spans a section with the common import replace semantic. For this reason, a geolocation import file always replaces any existing geolocations of a particular country.
- Geolocations of different countries are imported as separate files.

| Object Information | Details |
| --- | --- |
| Schema file | geolocation.xsd |
| Business Manager import location | ***site* > Administration > Site Development > Site Import & Export** |
| Pipelets | N/A |

The following is a sample XML file containing two geolocation records for the USA:

```
<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<geolocations country-code="US" xmlns="http://www.demandware.com/xml/impex/geolocation/2007-05-01">
    <geolocation postal-code="00501">  
        <city xml:lang="x-default">HOLTSVILLE</city>
        <state xml:lang="x-default">NY</state> 
        <longitude>-72.637078</longitude> 
        <latitude>40.922326</latitude> 
    </geolocation>
    <geolocation postal-code="00544">  
        <city xml:lang="x-default">HOLTSVILLE</city>
        <state xml:lang="x-default">NY</state> 
        <longitude>-72.637078</longitude> 
        <latitude>40.922326</latitude> 
</geolocation>...</geolocations>
```

> **Note:** For information about geolocation values in orders, see the Order Object.
