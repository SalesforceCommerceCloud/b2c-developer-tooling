# Modify a Job Parameter

_When you modify the value of a job parameter, B2C Commerce updates all steps that include the parameter to the new value._

|  |
| --- |
| Available in: **B2C Commerce** |

1. Select **Job Parameters** on the Job Steps screen.
2. Select the parameter you want to change and enter the new value.
3. Click **Save**.
