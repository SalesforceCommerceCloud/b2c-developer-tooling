# Integrate B2C Commerce with Single Sign-On

_To make sure the connection is secure and reduce friction, integrate B2C Commerce Account Manager and other Salesforce applications with your identity provider._

[Which Salesforce Commerce Product Do I Have?](https://help.salesforce.com/s/articleView?id=commerce.comm_what_product.htm)

This documentation helps you:

- Connect your customer’s identity provider (IDP) to Salesforce Identity.
- Connect B2C Commerce’s Account Manager to Salesforce Identity.
- Enable a single sign-on (SSO) experience across Salesforce applications.
- Provision and deprovision users for B2C Commerce.

### License Requirements

- Two or more paid licenses in the Enterprise, Unlimited, Performance, and Developer Editions for Sales, Service, Industries or Platform products
- An Identity license for each user. Identity licenses are available to Commerce users with a core org at no charge. To request them, work with your Account Executive.

### Other Requirements

- Administrator access to Account Manager
- Administrator access to your core or platform organization
- An Account Manager profile for every user (not needed if Just-In-Time User Provisioning is enabled in Account Manager)
- A plan for multi-factor authentication (MFA) with your third-party identity provider or Salesforce MFA
- A third-party identity provider such as OKTA, Azure, or Duo (optional, only if needed by customers)
- A Developer Edition organization for testing your integration. If you aren’t already a member of the Lightning Platform developer community, go to [developer.salesforce.com/signup](https://developer.salesforce.com/signup) and follow the instructions for signing up for a Developer Edition organization. Even if you already have Enterprise Edition, Unlimited Edition, or Performance Edition, use Developer Edition for developing, staging, and testing your solutions against sample data. Protect your organization's live user data.

### Implement This Solution

Workflow

- Learn how data flows through the configurations when you integrate B2C Commerce Account Manager and other Salesforce applications with your identity provider.

Design Considerations

- Keep these design considerations in mind when you integrate B2C Commerce Account Manager and other Salesforce applications with your identity provider.

Configurations

- Complete SSO configuration
