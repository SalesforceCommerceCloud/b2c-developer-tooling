# eCDN Step in Storefront Fast Setup

_The Storefront Next Fast Setup workflow in Business Manager for B2C Commerce automatically provisions an eCDN Default Domain zone as part of storefront creation via the `SetupEcdnForStorefront` job step._

### What the SetupEcdnForStorefront Job Step Does

When you create a new storefront using the Fast Setup workflow, the `SetupEcdnForStorefront` job step runs automatically. It provisions an eCDN Default Domain zone for the storefront and registers the custom hostnames in the shared Cloudflare zones for the realm.

The job step performs the following actions:

- Calls `POST /{organizationId}/configure-ecdn/ods` with the `originHostname` (ingress FQDN of the ODS instance) to kick off shared zone provisioning (storefront and BM zones) in the realm's Cloudflare account.
- Calls `POST /{organizationId}/ods/hostnames` with `instance` and `bmHostname` to register the custom hostnames in the shared zones. The response returns the `storefrontHostname` and `bmOrigin` used to update Route53.

To verify shared zone creation before proceeding with custom hostname provisioning, use `GET /{organizationId}/configure-ecdn/ods/status?zoneOnly=true`.

Required API scope and role: `edge.orchestration.rw` scope and `COMMERCECLOUD_APP` role (AM JWT).

### What Gets Provisioned

- eCDN storefront hostname: `<instance>.sbx.my.commercecloud.salesforce.com`
- eCDN Business Manager hostname: `<instance>.dx.commercecloud.salesforce.com` (routed through shared BM zone)
- Salesforce-managed wildcard certificates for both hostnames
- The Default Zone appears in Business Manager under **Administration > Sites > Embedded CDN Settings** after provisioning completes.

### Troubleshooting: CDN-API default-domain/hostnames Call Failed

The error `CDN-API default-domain/hostnames call failed` typically means the realm hasn't been provisioned for ODS eCDN — the shared zones haven't been created yet. To resolve it:

- Confirm that `configure-ecdn/ods` was called first to provision the shared zones for the realm.
- Use `GET /{organizationId}/configure-ecdn/ods/status?zoneOnly=true` to check shared zone creation status.
- If the shared zones aren't created, contact Salesforce Support.

### Troubleshooting: Storefront Creation Takes Longer Than Expected

eCDN zone provisioning and hostname verification can take up to 30 minutes. After that time, check the Embedded CDN Settings page in Business Manager for the Default Zone status. If provisioning hasn't completed, contact Salesforce Support.

### Troubleshooting: Pilot Customers with Vanity Domains

For 26.5 pilot customers using custom hostnames on ODS, the automatic fast setup path may not apply. See the ODS Vanity Hostname Migration guidance in [Create an eCDN Zone](https://help.salesforce.com/s/articleView?id=cc.b2c_creating_a_zone.htm).
