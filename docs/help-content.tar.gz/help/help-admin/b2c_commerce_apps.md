# Commerce Apps for B2C Commerce

_Manage checkout integrations from a single workspace. Commerce Apps combines APIs, back-end code, and UI components to integrate native Salesforce, partner, and custom solutions into the B2C Commerce platform._

Install and configure native and partner apps from Business Manager with minimal custom development, or develop custom apps for any domain. Commerce Apps supports these B2C Commerce domains.

### App Types

- **Native Commerce apps**: Salesforce-built solutions that you install and configure in Business Manager.
- **Partner Commerce apps**: Prebuilt integrations from Independent Software Vendor (ISV) partners that you install in Business Manager.
- **Custom Commerce apps**: Solutions that your integration team installs and builds. Custom solutions are available for all domains.

For information about developing Commerce apps, see the [Commerce Apps ISV Developer Guide](https://developer.salesforce.com/docs/commerce/b2c-commerce/guide/commerce-apps-overview.html) and the [Commerce Apps Repository](https://github.com/SalesforceCommerceCloud/commerce-apps).

## Related Content

- [Install a Commerce App for B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_install_commerce_app.htm&type=5)
  Install and configure a Commerce app in Business Manager to add domain functionality to your Storefront Next site.

- [Reinstall Commerce Apps After Upgrading to B2C Commerce Version 26.7](https://help.salesforce.com/s/articleView?id=cc.b2c_reinstall_commerce_apps.htm&type=5)
  When you upgrade to version 26.7, Commerce apps installed on B2C Commerce version 26.6 no longer appear as installed on the Commerce Apps page in Business Manager, even if you didn’t remove them.

- [Customize Where Commerce App Components Appear on Your B2C Storefront](https://help.salesforce.com/s/articleView?id=cc.b2c_commerce_app_storefront_display.htm&type=5)
  Choose where Commerce app components appear on your Storefront Reference Architecture (SFRA), Composable Storefront, or Storefront Next site.

- [Uninstall a Commerce App from B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_disable_commerce_app.htm&type=5)
  Uninstall a Commerce app in Business Manager to remove domain functionality from your Storefront Next site.
