# Manage Custom Caches Using Business Manager

_You enable or disable caching, monitor custom cache statistics, and clear caches for your B2C Commerce storefront, all from the Custom Caches page._

1. In Business Manager, click App Launcher _(image: App Launcher)_, and then select **Administration > Operations > Custom Caches**.
2. To enable or disable custom caches, select or deselect **Enable Caching**.

   Disable caching only for testing purposes. Always keep caching enabled on production systems. When you enable or disable caching, all custom caches on all application servers in the instance are cleared.
3. To monitor cache behavior, review the cache statistics table.

   The table shows values only for the current active code version of the current application server. The statistics show data for the previous 15 minutes. It can take up to five seconds for an event to appear in the statistics.
4. To clear a cache on all application servers in the instance, click **Clear** for that cache.
