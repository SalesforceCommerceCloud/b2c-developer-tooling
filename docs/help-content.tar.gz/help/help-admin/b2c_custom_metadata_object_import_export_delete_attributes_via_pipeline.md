# Deleting Existing Attribute Definitions via Pipeline

_Use the ImportMetaData pipelet input parameter ImportConfiguration to delete attribute definitions or attribute group definitions._

For attribute definitions, use the following:

```
key=cleanupAttributeDefinitions; value=true | false
```

If set to `true`, B2C Commerce deletes existing attribute definitions that aren’t contained in the import file. If not specified or set to `false`, such attribute definitions aren’t deleted.

For attribute definitions, use the following:key=cleanupAttributeGroupDefinitions; value=true | false If set to `true`, B2C Commerce deletes existing attribute group definitions that aren’t contained in the import file. If not specified or set to `false`, attribute group definitions aren’t deleted.

### Site-Specific Attributes

The complex type `CustomAttributeDefinition` supports the `site-specific-flag` attribute. Because you can't change the `site-specific-flag` of system attributes, you can't use this `system-object-flag` with the complex type `SystemAttributeDefinition`.
