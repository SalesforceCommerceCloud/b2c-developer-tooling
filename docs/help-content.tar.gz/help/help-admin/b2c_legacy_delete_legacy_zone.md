# Delete the Legacy Zone for B2C Commerce

_After you move all subdomains to the proxy zone, delete the legacy zone using the remove zone option._

Don't remove the legacy zone until an independent DNS lookup of your public hostname confirms that the CNAME is the proxy zone target, including any stacked third-party CDN. Salesforce is removing unused legacy zones. If DNS still points to the legacy CNAME, removing the zone takes the site down.

1. In Business Manager, click App Launcher _(image: App Launcher)_, and then select **Administration > Sites > Embedded CDN Settings**.
2. On the Embedded CDN Settings page, locate the Legacy Zone row and click **Remove Zone**.

   Perform the migration on each instance (Dev/Stg/Prod) and then **delete the Legacy zone from the Production instance after it has been successfully migrated on all instances**.
