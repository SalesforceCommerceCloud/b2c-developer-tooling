# Delete a Legacy Zone

_After you move all subdomains from the B2C Commerce legacy zone to the proxy zone, delete the legacy zone with the Remove Zone option. This is the final step of the proxy zone migration._

Migrate and remove every subdomain from the legacy zone first. See [Remove a Subdomain from a Legacy Zone](https://help.salesforce.com/s/articleView?id=cc.b2c_remove_subdomain_from_legacy.htm&type=5).

This task is part of the migration sequence. See [Legacy Zones and Proxy Zone Migration](https://help.salesforce.com/s/articleView?id=cc.b2c_migrating_proxy_zones.htm&type=5).

Because a legacy zone is shared across your Development, Staging, and Production instances, delete it only after you migrate it successfully on every instance.

> **Important:** Don't remove the legacy zone until an independent DNS lookup of your public hostname confirms that the CNAME is the proxy zone target, including any stacked third-party CDN. Salesforce is removing unused legacy zones. If DNS still points to the legacy CNAME, removing the zone takes the site down.

1. In Business Manager, click the App Launcher _(image: App Launcher)_, and then select **Administration > Sites > Embedded CDN Settings**.
2. On the Embedded CDN Settings page, locate the legacy zone row and click **Remove Zone**.

   > **Note:** Perform the migration on each instance (Dev, Staging, and Production), and then delete the legacy zone from the Production instance only after it has been successfully migrated on all instances.
