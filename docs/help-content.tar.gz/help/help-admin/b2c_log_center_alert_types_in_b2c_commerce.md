# Log Center Alert Types in B2C Commerce

_To determine the best method for monitoring your environment, review the available alert types in this table._

| Alert Type | What It Monitors | When to Use |
| --- | --- | --- |
| New Alert | Custom log queries and event searches that you configure directly from the Alerts page. | Build a custom, purpose-specific alert from scratch. |
| Saved Search | Results of an existing saved log search query. | Receive alerts on a search configuration that you run on a regular basis. |
| Log Streaming | Real-time operational health of your log stream pipelines. | Receive immediate notifications when a log delivery pipeline fails. |
| Anomaly Detection | Unusual or irregular log patterns using built-in AI baseline detection. | Catch behavioral anomalies that you can't define with static, numeric thresholds. |
