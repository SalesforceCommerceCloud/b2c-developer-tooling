# Troubleshooting Import/Export in B2C Commerce

_If attempts to connect to an FTP server using the FTPClient results in a "java.net.SocketTimeoutException", contact customer support to open access to the FTP port._

You can't manually import or export a file that takes longer than 5 minutes to import. The system imposes a timeout for requests to a B2C Commerce instance. If the application server doesn't respond within 5 minutes, the web server closes the connection. Create an import/export pipeline and associate it with a job. The job framework doesn't impose a timeout.

If you don't see changes after successfully importing your file, either manually or through a custom pipeline, check to make sure you’re using the correct import mode. For example, new objects don't appear in UPDATE mode.
