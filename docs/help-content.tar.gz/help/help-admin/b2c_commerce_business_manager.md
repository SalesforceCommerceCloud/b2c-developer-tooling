# B2C Commerce Business Manager

_Use Business Manager to manage all aspects of your digital commerce operations. Business Manager gives merchandisers, admins, developers, and business users a unified interface for managing products, customers, orders, promotions, as well as admin and development-related settings._

Business Manager organizes its capabilities into functional modules that you access from the left navigation or the App Launcher. Merchant Tools brings together the modules that merchandisers use day to day, including Products, Product Sets, Price Books, Content Assets, Libraries, Customers, and Ordering, so you can manage the full product lifecycle and shopper experience from one place.

Administration brings together the modules for managing your organization and sites, including Site Preferences, Job History, Services, and user roles and permissions. Site Development gives developers the modules to deploy code, import and export data, and configure development-specific settings.

To see Business Manager tasks in action, watch this [../video_content/b2c_videos.xml](https://help.salesforce.com/s/articleView?id=cc.b2c_videos.htm&type=5).

## Related Content

- [Create a Custom B2C Business Manager App](https://help.salesforce.com/s/articleView?id=cc.b2c_create_a_custom_business_manager_app.htm&type=5)
  Create a custom app in Business Manager with the modules and navigation tailored to how you work, either from the Merchandising template or from scratch.

- [Manage Sections and Modules in a Custom B2C Business Manager App](https://help.salesforce.com/s/articleView?id=cc.b2c_manage_sections_and_modules_in_business_manager_app.htm&type=5)
  Organize your custom Business Manager app by creating sections, adding modules, and dragging modules between sections to reorder them.

- [B2C Business Manager Cosmos UI: Overview](https://help.salesforce.com/s/articleView?id=cc.b2c_new_business_manager_ui.htm&type=5)
  Starting with Salesforce B2C Commerce Version 26.5, the default user interface is Salesforce Cosmos Design. The Cosmos UI includes interactive circular motifs, improved fonts and icons, inviting cues, and higher contrast colors.
