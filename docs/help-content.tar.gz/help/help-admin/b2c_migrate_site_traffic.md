# Migrate Site Traffic

_After you create your B2C Commerce eCDN zones and certificates, validate each hostname and update DNS to cut site traffic over to eCDN — optionally stacking a third-party CDN such as Akamai in front._

1. (Optional) Pre-validate the hostname.

   Pre-validate the hostname when either of these conditions applies:
   
   - You want to avoid downtime when cutting traffic over to eCDN.
   - You want to stack a third-party CDN in front of eCDN, for example, Akamai.
   
   For each hostname, submit the TXT records to your DNS provider to validate control over the domain. The TXT record, hostname, and target are listed in the response of a GET certificates call for a hostname that isn't validated. See [getCertificates](https://developer.salesforce.com/docs/commerce/commerce-api/references/cdn-api-process-apis?meta=getCertificates).
   
   Example TXT validation record:
   
   `_cf-custom-hostname.stg.mystore.com. IN TXT 3adc7a39-12d7-4baf-be1b-c5ea5295181b`
   
   If B2C Commerce Engineering completed the eCDN configurations, they provide the TXT validation record.
   
   > **Important:** Submit validation records as soon as possible. After the configurations are created, automated validation checks run up to 4 hours apart for 7 days. If you don't complete validation within 7 days, you can request that B2C Commerce Engineering manually restart the validation checks.
2. To send traffic directly to eCDN, update DNS to the CNAME values. The CNAME target uses this format: `commcloud.<zone_name>`.

   Example CNAME record:
   
   `stg.mystore.com. IN CNAME commcloud.stg-abcd-mystore-com.cc-ecdn.net.`
   
   > **Note:** If you don't pre-validate the hostname, pointing traffic directly to eCDN serves as validation. This approach results in downtime for the period between when you update DNS and the next validation check.
3. (Optional) Stack a third-party CDN. This step requires a validated hostname.

   Make sure that the connections to eCDN use SNI. SNI is required for eCDN configurations.
   
   - On Akamai, SNI support for upstream connections is disabled by default. Refer to the Akamai [documentation on configuring Origin Server behavior](https://techdocs.akamai.com/property-mgr/docs/the-third-party-origin#4-set-up-the-origin-server-behavior), and enable the SNI Transport Layer Security (TLS) Extension.
   - For all other CDNs, work with the CDN provider to determine how to enable SNI to the origin if it's not enabled by default. For guidance on suggested Business Manager settings, see [Configure an External CDN or Third-Party Proxy](https://help.salesforce.com/s/articleView?id=cc.b2c_configuring_an_external_cdn.htm&type=5). Use the target value from the provided CNAME as the origin server.
4. (Optional) Delete the TXT validation records.

   Before you delete the records, confirm that the hostname is validated and that traffic is flowing through eCDN.
