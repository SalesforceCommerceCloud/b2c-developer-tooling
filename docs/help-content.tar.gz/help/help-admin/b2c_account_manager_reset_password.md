# Change Your Account Password in B2C Commerce

_You are required to change your password every 90 days. Define a new password even if your existing password expired. After a password has expired, you can attempt to log in six times to set a new password before your account is temporarily locked. After you successfully log in with an expired password, immediately reset your password._

[Which Salesforce Commerce Product Do I Have?](https://help.salesforce.com/s/articleView?id=commerce.comm_what_product.htm)

> **Note:** To improve security, if a user is logged in and resets their password, their session is automatically invalidated. To continue their session, the user must log in again.

This procedure works only when your Account Manager account is not linked to a Salesforce Identity account.

1. Log into Account Manager.
2. Click **Password**.
3. In the **Current Password** field, reenter your current password.
4. In the **New Password** field, enter your new password.

   Minimum password requirements include:
   
   - Character length 7. Some organization require more
   - 1 alpha character
   - 1 upper case character
   - 1 digit character
   - 1 special character
   
   As you enter characters, the page gives you feedback about the security strength of your password.
5. In the **Confirm Password** field, reenter your new password.
6. Click **Change Password**.
