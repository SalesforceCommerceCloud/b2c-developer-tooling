# Open the Search Information Tool in B2C Commerce

_Open the Search Information Tool from the search icon in the Storefront Toolkit._

|  |
| --- |
| Available in: **B2C Commerce** |

1. Select the site to view and click **Toolkit.**

   A new tab opens showing the storefront, with the Storefront Toolkit icons in the upper right corner.
2. Enter a search query or select a category in the storefront.

   You can also further refine the search or sort the search results using the storefront sorting options.
3. Click the Search Information Tool icon. _(image: Search Information Tool icon)_
4. To see information about a search result, click any of the _(image: Search Information Tool icon)_ icons on the page.
