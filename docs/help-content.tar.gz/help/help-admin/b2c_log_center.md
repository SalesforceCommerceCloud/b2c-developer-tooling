# Log Center

_Log Center is a B2C Commerce application that you can use to view realm logs messages generated from system and custom code. From Log Center, you can access all your tenant realm logs for primary instance groups (PIGs) and secondary instance groups (SIGs). View the Log Center dashboard, search for logs, set up log streaming, and view Control Center audit events. If you have Admin permissions, you can configure log levels and volumes._

## Related Content

- [Access Log Center](https://help.salesforce.com/s/articleView?id=cc.b2c_start_log_center.htm&type=5)
  Access B2C Commerce Log Center from a browser or from Business Manager.

- [Log Center Dashboard](https://help.salesforce.com/s/articleView?id=cc.b2c_log_center_dashboard.htm&type=5)
  The B2C Commerce Log Center dashboard is populated based on your Account Manager tenant filters and realm assignment. Users with Admin and Support roles can set the dashboard to show data for any company realm. The dashboard's default settings shows a histogram of the top stack traces over the last ten days. To show the exact count for each stack trace, hover over the bar in the chart.

- [Account Manager Audit Log Events](https://help.salesforce.com/s/articleView?id=cc.b2c_account_manager_log_center.htm&type=5)
  B2C Commerce Log Center publishes audit log events for Account Manager, including changes to users, API clients, and organizations. Use filters and keyword searches to track specific field changes or action events within a selected time frame.

- [Log Center Search](https://help.salesforce.com/s/articleView?id=cc.log_center_search.htm&type=5)
  Use B2C Commerce Log Center to search logs with custom searches. You configure a search with query filters from categories such as period, message severity, issue type, key words, specific text, and other attributes.

- [Log Center Configuration](https://help.salesforce.com/s/articleView?id=cc.b2c_log_center_configuration.htm&type=5)
  Adjust how B2C Commerce Log Center presents results and how administrators control logging. Switch between detailed and compact display views, and use the Config tab to set dynamic log levels, manage per-realm log volumes, and delete loaner-realm logs.

- [Log Streaming for Enhanced Monitoring](https://help.salesforce.com/s/articleView?id=cc.b2c_log_streaming_faq.htm&type=5)
  Log Center supports log streaming to third-party monitoring and analytics tools. You can also stream logs using a generic HTTP connection. With these tools, Log Center users get enterprise-scale monitoring and automation capabilities. All B2C Commerce Log Center customers get log streaming at no additional cost.

- [Anomaly Detection in Log Center](https://help.salesforce.com/s/articleView?id=cc.b2c_anomaly_detection.htm&type=5)
  Identify performance regressions, operational issues, and suspicious activity from unusual patterns in B2C Commerce Log Center. Log Center continuously analyzes incoming log data and compares the data with learned baseline behavior. When data deviates from the baseline and meets your thresholds, Log Center flags the anomaly. Each user can configure up to ten detectors. Use these guidelines to reduce false positives and improve detector accuracy.

- [Set Up Anomaly Detectors in Log Center](https://help.salesforce.com/s/articleView?id=cc.b2c_set_up_anomaly_detectors.htm&type=5)
  Identify unusual log patterns in B2C Commerce Log Center and optionally send alerts when anomalies meet your alert threshold. Log Center continuously analyzes incoming log data and compares the data with learned baseline behavior. When data deviates from the baseline and meets your thresholds, Log Center flags the anomaly.

- [View Control Center Audit Events in Log Center](https://help.salesforce.com/s/articleView?id=cc.b2c_cc_view_the_audit_log.htm&type=5)
  To monitor the state of your B2C instances, view Control Center audit events in Log Center, the centralized location for log management. Audit events show all Control Center activity, regardless of which user performs an action, and if necessary, take corrective action to solve any issues.

- [Metrics Dashboard](https://help.salesforce.com/s/articleView?id=cc.b2c_metrics_dashboard.htm&type=5)
  Use the Metrics Dashboard to monitor your B2C Commerce storefront performance, security, and resource utilization. The dashboard improves developer productivity, reduces mean-time to resolution, and streamlines troubleshooting. The metrics that you can monitor include metrics for application performance, sales, embedded content delivery network (eCDN), B2C Commerce API (Shopper Commerce API (SCAPI)) and SCAPI hooks, and Managed Runtime.

- [Traces (Beta)](https://help.salesforce.com/s/articleView?id=cc.b2c_traces.htm&type=5)
  Use the Traces feature in Log Center to follow a single request as it travels across B2C Commerce services. A trace shows the end-to-end path of a request and the time spent in each service, so you can find where latency or errors occur.

- [Log Center Alerts in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_log_center_alerts.htm&type=5)
  Monitor custom alerts across all Log Center data sources from a centralized interface. Configure notifications to identify application performance degradations before they affect your users. Route alerts in real time via email, Slack, and PagerDuty to help your teams respond to critical system events.
