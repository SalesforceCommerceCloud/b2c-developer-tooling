# Log Center

_Log Center is an application that you can use to view realm logs messages generated from system and custom code. From Log Center, you can access all your tenant realm logs for primary instance groups (PIGs) and secondary instance groups (SIGs). View the Log Center dashboard, search for logs, set up log streaming, and view Control Center audit events. If you have Admin permissions, you can configure log levels and volumes._

## Related Content

- [Access Log Center](https://help.salesforce.com/s/articleView?id=cc.b2c_start_log_center.htm&type=5)
  Access Log Center from a browser or from Business Manager.

- [Log Center Dashboard](https://help.salesforce.com/s/articleView?id=cc.b2c_log_center_dashboard.htm&type=5)
  The dashboard is populated based on your Account Manager tenant filters and realm assignment. Users with Admin and Support roles can set the dashboard to show data for any company realm. The dashboard’s default settings shows a histogram of the top stack traces over the last ten days. To show the exact count for each stack trace, hover over the bar in the chart.

- [Account Manager Audit Log Events](https://help.salesforce.com/s/articleView?id=cc.b2c_account_manager_log_center.htm&type=5)
  Log Center publishes audit log events for Account Manager, including changes to users, API clients, and organizations. Use filters and keyword searches to track specific field changes or action events within a selected time frame.

- [Log Center Search](https://help.salesforce.com/s/articleView?id=cc.log_center_search.htm&type=5)
  Use Log Center to search logs with custom searches. You configure a search with query filters from categories such as period, message severity, issue type, key words, specific text, and other attributes.

- [Log Center Configuration](https://help.salesforce.com/s/articleView?id=cc.b2c_log_center_configuration.htm&type=5)
  Modify the Log Center display to meet your business needs. In addition Log Center Administrators can configure log levels and log volumes.

- [Log Streaming for Enhanced Monitoring](https://help.salesforce.com/s/articleView?id=cc.b2c_log_streaming_faq.htm&type=5)
  Log Center supports log streaming to third-party monitoring and analytics tools. You can also stream logs using a generic HTTP connection. With these tools, Log Center users get enterprise-scale monitoring and automation capabilities. All B2C Commerce Log Center customers get log streaming at no additional cost.

- [Anomaly Detection in Log Center](https://help.salesforce.com/s/articleView?id=cc.b2c_anomaly_detection.htm&type=5)
  Identify performance regressions, operational issues, and suspicious activity from unusual patterns in Log Center. Log Center continuously analyzes incoming log data and compares the data with learned baseline behavior. When data deviates from the baseline and meets your thresholds, Log Center flags the anomaly. This topic applies to B2C Commerce. Use these guidelines to reduce false positives and improve detector accuracy.

- [Set Up Anomaly Detectors in Log Center](https://help.salesforce.com/s/articleView?id=cc.b2c_set_up_anomaly_detectors.htm&type=5)
  Identify unusual log patterns and optionally send alerts when anomalies meet your alert threshold. Log Center continuously analyzes incoming log data and compares the data with learned baseline behavior. When data deviates from the baseline and meets your thresholds, Log Center flags the anomaly. This topic applies to B2C Commerce.

- [Metrics Dashboard](https://help.salesforce.com/s/articleView?id=cc.b2c_metrics_dashboard.htm&type=5)
  Use the Metrics Dashboard to monitor your B2C Commerce storefront performance, security, and resource utilization. The dashboard improves developer productivity, reduces mean-time to resolution, and streamlines troubleshooting. The metrics that you can monitor include metrics for application performance, sales, embedded content delivery network (eCDN), B2C Commerce API (Shopper Commerce API (SCAPI)) and SCAPI hooks, and Managed Runtime.

- [Log Center Alerts in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_log_center_alerts.htm&type=5)
  Monitor custom alerts across all Log Center data sources from a centralized interface. Configure notifications to identify application performance degradations before they affect your users. Route alerts in real time via email, Slack, and PagerDuty to help your teams respond to critical system events.
