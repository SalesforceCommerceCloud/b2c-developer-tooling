# Log Center

_Log Center is an application that you can use to view realm logs messages generated from system and custom code. From Log Center, you can access all your tenant realm logs for primary instance groups (PIGs) and secondary instance groups (SIGs). View the Log Center dashboard, search for logs, set up log streaming, and view Control Center audit events. If you have Admin permissions, you can configure log levels and volumes._
