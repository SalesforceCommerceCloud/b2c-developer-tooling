# Configure Salesforce Payments with Stripe for B2C Commerce

_Configure Stripe merchant accounts with Salesforce Payments in any B2C Commerce sandbox, staging, development, or production instance. Stripe merchant accounts that you create in a B2C Commerce instance can operate in both test and live mode._

Salesforce recommends first creating a test merchant accounts in your staging instance. Then replicate the merchant account to your development and production instances. After you replicate your merchant account across instances, choose whether an instance uses test or live mode. Perform test transactions on your staging and development instances and real transactions on your production instance.

To perform transactions in test mode only, conclude the onboarding process after providing the email address associated with your Stripe user account. Providing personal or financial information isn’t required to use your Stripe account in test mode.

To transact real funds in live mode, fully onboard your Stripe merchant account, including providing accurate business and customer information.
