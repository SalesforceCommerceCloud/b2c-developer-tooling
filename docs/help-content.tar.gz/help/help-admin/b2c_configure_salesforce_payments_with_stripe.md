# Configure Salesforce Payments with Stripe for B2C Commerce

_Configure Stripe merchant accounts with Salesforce Payments in any B2C Commerce sandbox, staging, development, or production instance. Stripe merchant accounts that you create in a B2C Commerce instance can operate in both test and live mode._

Salesforce recommends first creating a test merchant accounts in your staging instance. Then replicate the merchant account to your development and production instances. After you replicate your merchant account across instances, choose whether an instance uses test or live mode. Perform test transactions on your staging and development instances and real transactions on your production instance.

To perform transactions in test mode only, conclude the onboarding process after providing the email address associated with your Stripe user account. Providing personal or financial information isn’t required to use your Stripe account in test mode.

To transact real funds in live mode, fully onboard your Stripe merchant account, including providing accurate business and customer information.

## Related Content

- [Associate a Stripe Merchant Account with Your B2C Commerce Instance Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_associate_stripe_merchant_account.htm&type=5)
  To use Salesforce Payments with Stripe, create a Stripe merchant account directly from your B2C Commerce instance. You can also use a Stripe merchant account that’s already associated with a B2C Commerce instance.

- [Onboard Your Stripe Merchant Account for B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_onboard_a_stripe_merchant_account.htm&type=5)
  After you associate a Stripe merchant account with your B2C Commerce instance onboard the account. The Stripe onboarding process collects business information such as names, addresses, and bank accounts. The steps vary based on the merchant account country.

- [Remove a Stripe Merchant Account from B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_remove_account_association.htm&type=5)
  Remove the association between a Stripe merchant account and your B2C Commerce instance. If a Stripe merchant account is linked to a default payment zone, first reassign the default payment zone to another merchant account. When you remove the merchant account, B2C Commerce unassigns all payment zones from the account.
