# Embedded CDN Overview

_Salesforce B2C Commerce includes an embedded content delivery network (eCDN) that accelerates site performance and content delivery. The eCDN serves content from locations close to your shoppers for fast response times, and supports web application firewall (WAF) and HTTP Strict Transport Security (HSTS)._

[Which Salesforce Commerce Product Do I Have?](https://help.salesforce.com/s/articleView?id=commerce.comm_what_product.htm)

B2C Commerce customers are part of a growing worldwide content delivery network built for scale. When you streamline connections between shoppers and retailers, every B2C Commerce site renders fast and efficiently from whatever device a shopper is using.

You can also manage proxy zones programmatically. See [CDN Zones](https://developer.salesforce.com/docs/commerce/commerce-api/guide/cdn-zones.html) in the developer documentation.

### eCDN Zone Types

The eCDN organizes your hostnames into zones. There are three zone types:

- **Proxy zone:** Any new zone created in the eCDN. Business Manager translates the proxy zone name, so customers don't see it. A proxy zone's name ends with `cc-ecdn.net`, its DNS CNAME starts with `commcloud`, and you configure it in Business Manager or with the CDN API.
- **Legacy zone (root zone):** A zone that includes the customer domain name, for example, `brand.com`. See [Legacy Zones and Proxy Zone Migration](https://help.salesforce.com/s/articleView?id=cc.b2c_migrating_proxy_zones.htm&type=5).
- **SCAPI zone:** A Salesforce-managed zone that fronts Salesforce Commerce API (SCAPI) traffic and is auto-provisioned for Development, Staging, and Production. You configure a subset of eCDN controls for the SCAPI zone from the Production instance. See [SCAPI Zone Support for B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_scapi_zone.htm&type=5).

To determine a zone's type in Business Manager, go to **Administration > Sites > Embedded CDN Settings** and find the hostname. If the DNS CNAME starts with `commcloud`, the zone is a proxy zone.

### Where the eCDN Is Available

The embedded CDN, which includes the eCDN console in Business Manager, is available on all Primary Instance Group (PIG) instance types: Development, Staging, and Production. The embedded CDN is also available on Secondary Instance Group (SIG) instances, including On-Demand Sandboxes (ODS). The eCDN for your custom hostnames (subdomains) requires configuration before you can route traffic to B2C Commerce.

Configure subdomains of the same zone on the same B2C Commerce instance, or on different instances of different realms of the same retailer. For example, configure *www.shop.com* on the Production instance, *test.shop.com* on the Development instance, and *eu.shop.com* on the Production instance of the EU realm. For help with configuring eCDN, contact Salesforce Customer Support.

### Managing the eCDN

Use either Business Manager or the CDN Zones API to manage the zones created to support the eCDN on your B2C Commerce Development, Staging, and Production instances.

Each instance, Development, Staging, and Production, has its own embedded CDN settings, which you manage individually. For example, a proxy zone in Production doesn't automatically replicate a corresponding proxy zone in the Development or Staging instances.

### Additional Configuration Notes

- Enable [Enforce HTTPS](https://help.salesforce.com/articleView?id=b2c_enforce_https.htm&type=5) for all storefronts.
- The eCDN uses various cookies to maximize network resources, manage traffic, and protect sites from malicious traffic. For more information about these cookies, see [Understanding the Cloudflare Cookies](https://support.cloudflare.com/hc/en-us/articles/200170156-Understanding-the-Cloudflare-Cookies).
- The eCDN also supports web application firewall (WAF) and HTTP Strict Transport Security (HSTS).
