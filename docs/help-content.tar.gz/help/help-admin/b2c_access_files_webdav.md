# Access WebDAV Files for B2C Commerce

_Use the folder browser in Business Manager to easily view and download WebDAV files. You can also use a third-party WebDAV client to view, download, upload, and delete WebDAV files._

|  |
| --- |
| Available in: **B2C Commerce** |

1. In Business Managerm click App Launcher _(image: App Launcher)_, and then select **Administration > Site Development > Development Setup**.
2. Click the **Folder Browser** tab.

   You see the folders that you have WebDAV permission for in the folder browser.
   
   - To filter folders, type the folder name in the **Filter By Name** text box, and click **Filter**. Folder names aren’t case-sensitive. Use asterisks (*) and question marks (?) as wildcards.
   - To download a file, click the download icon under **Actions**.
   - To copy the URL of the directory to the clipboard of your local machine, click **Copy WebDAV URL**. Use the URL to access the directory in a third-party WebDAV client.
3. To use a third-party WebDAV client to access a directory, on the Development Setup window:

   1. Scroll down to the **WebDAV Access** section.
   2. Click the link icon beside a directory name to copy its URL to the clipboard of your local machine. Paste the URL into the WebDAV client.
   
      To access the WebDAV files from the WebDAV client, enter your WebDAV credentials.
   
   To use the folder browser to see the directory, click the folder icon beside the directory name in the **WebDAV Access** section.
