# Clear the eCDN Cache

_To refresh a static storefront asset in B2C Commerce eCDN cache before its cache interval expires, upload the updated asset so that B2C Commerce assigns it a new fingerprint and URL. You don't need to clear the cache or request a support ticket._

Static assets are refreshed automatically through fingerprinting. When you upload updated content, B2C Commerce generates a new fingerprint, which changes the asset's URL and causes eCDN to retrieve the new asset. For how caching and fingerprinting work, see [eCDN Caching and Cache Fingerprinting](https://help.salesforce.com/s/articleView?id=cc.b2c_ecdn_caching_and_fingerprinting.htm&type=5).

1. Upload the updated asset to your storefront POD.

   When you upload an updated asset to the POD, B2C Commerce generates a new fingerprint value for that asset. Changing the fingerprint also changes the URL of the updated asset. When your storefront requests the updated static asset, the URL request returns a miss in eCDN and web tier cache. This response occurs because the fingerprint is different, and the CDN doesn't recognize the new and old asset as the same. The missed request with the new fingerprint is then directed to the POD, and the asset is retrieved and cached with the new URL.
   
   > **Note:** All content assets in cache are refreshed, excluding the old content updated in this process. B2C Commerce assigns the updated content a new fingerprint that results in a new URL for the asset.
2. Refresh your site in the browser and confirm that the updated asset appears as expected.

If the updated asset doesn't appear in your browser after updating content, you can manually invalidate the Application Tier cache. Though it's rare, the asset not appearing means that something went wrong with the cache clearing process.

1. Clear the cache:
   
   - To clear the Business Manager Site cache, click App Launcher _(image: App Launcher)_, and then select **Administration > Sites > Manage Sites > Business Manager Site > Cache**, and click **Invalidate** where applicable.
   - To invalidate the cache for a specific site, click App Launcher _(image: App Launcher)_, and then select **Administration > Sites > Manage Sites > Site Name > Cache** and click **Invalidate** where applicable.
2. Refresh the site in your browser, and confirm that the updated asset appears as expected.
