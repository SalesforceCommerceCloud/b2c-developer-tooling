# Refresh a Static Asset in the eCDN Cache

_To show an updated static storefront asset before its B2C Commerce eCDN cache interval expires, upload the new version. B2C Commerce assigns the asset a new fingerprint and URL, so eCDN retrieves it. You don't need to clear the eCDN cache or file a support ticket._

[Which Salesforce Commerce Product Do I Have?](https://help.salesforce.com/s/articleView?id=commerce.comm_what_product.htm)

For more information about how caching and fingerprinting work, see [eCDN Caching and Cache Fingerprinting](https://help.salesforce.com/s/articleView?id=cc.b2c_ecdn_caching_and_fingerprinting.htm&type=5).

1. Upload the updated asset to your storefront POD.

   Because the asset has a new URL, the next storefront request misses the eCDN and web tier caches. eCDN retrieves the asset from the POD and caches it under the new URL.
2. Refresh your site in the browser and confirm that the updated asset appears as expected.
3. If the updated asset doesn't appear, invalidate the Application Tier cache.

   - To invalidate the Business Manager Site cache, click App Launcher _(image: App Launcher)_, select **Administration > Sites > Manage Sites > Business Manager Site > Cache**, and then click **Invalidate**.
   - To invalidate the cache for a specific site, click App Launcher _(image: App Launcher)_, select **Administration > Sites > Manage Sites > Site Name > Cache**, and then click **Invalidate**.
4. Refresh the site in your browser, and then confirm that the updated asset appears.
