# Clear eCDN Cache

_B2C Commerce stores static storefront content in eCDN cache or the web tier static content cache._

|  |
| --- |
| Available in: **B2C Commerce** |

eCDN serves all cached content using a unique URL. Cache purging a CDN on top of URLs from B2C Commerce isn’t necessary, because the system updates the URL when uploading new content. Aside from replicating environments to clear the cache of any static content, no action is required.

When working with eCDN cache, keep the following in mind:

- eCDN uses the Cache-Control header to persist a file in cache until that TTL expires. After the cache header expires, eCDN retrieves the new resource. eCDN caches based on the value set by the cache headers. If these headers aren’t set, eCDN enforces a default value of 30 days.
- The web adapter configures web pages using static assets from both eCDN and web tier cache sources. Regardless of the cache location, web tier or eCDN, B2C Commerce assigns each static content asset on your storefront a fingerprint value. For example, consider the following URL:
   
   `https://www.samplecustomer.com/dis/dw/image/v2/XXXX_PRD/on/demandware.static/-/Sites-customer-main-product/default/dwabb3a337/images/hi-res/shoes.jpg?sw=200=200=fitm=png>`.
   
   The value `dwabb3a337` is the asset fingerprint. The fingerprint provides a unique identifier for the asset.
- Updates to static cache occur at intervals you set. If necessary, you can update an asset held in static cache before the cache interval expiration. The process doesn’t require clearing the cache, and you can complete it without requesting a support ticket.

To clear eCDN cache:

1. Upload the updated asset to your storefront POD.

   When you upload an updated asset to the POD, the system generates a new fingerprint value for that asset. Changing the fingerprint also changes the URL of the updated asset. When your storefront requests the updated static asset, the URL request returns a miss in eCDN and web tier cache. This response occurs because the fingerprint is different, and the CDN doesn’t recognize the new and old asset as the same. The missed request with the new fingerprint is then directed to the POD, the asset is then retrieved and cached with the new URL.
   
   > **Note:** All content assets in cache are refreshed, excluding the old content updated in this process. B2C Commerce assigns the updated content a new fingerprint that results in a new URL for the asset.
2. Refresh your site in the browser and confirm that the updated asset appears as expected.

If the updated asset doesn’t appear in your browser after updating content, you can manually invalidate the Application Tier cache. Though it’s rare, the asset not appearing means that something went wrong with the cache clearing process.

1. Clear the cache:
   
   - To clear the Business Manager Site cache, click App Launcher _(image: App Launcher)_, and then select **Administration > Sites > Manage Sites > Business Manager Site > Cache**, and click **Invalidate** where applicable.
   - To invalidate the cache for a specific site, click App Launcher _(image: App Launcher)_, and then select **Administration > Sites > Manage Sites > Site Name > Cache** and click **Invalidate** where applicable.
2. Refresh the site in your browser, and confirm that the updated asset appears as expected.
