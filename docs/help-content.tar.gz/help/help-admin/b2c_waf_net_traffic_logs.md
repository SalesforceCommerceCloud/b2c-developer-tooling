# eCDN WAF Logs

_eCDN logs include information about all of your B2C Commerce network traffic, not just the traffic that the web application firewall (WAF) acts on. Use the logs to track IP-reputation–blocked traffic and to see how much of your traffic doesn't trigger WAF._

[Which Salesforce Commerce Product Do I Have?](https://help.salesforce.com/s/articleView?id=commerce.comm_what_product.htm)

Request log files at specified times for up to seven days. An email with a link to download the log is sent to your Business Manager email address. Because of General Data Protection Regulation (GDPR) restrictions, Salesforce removes log files after seven days. For this reason, we recommend that you save log files on your own server.

Log entries cover 60-minute increments of traffic requests to your storefront. You can request these 60-minute increment log files through the Open Commerce API (OCAPI). When you use OCAPI, the API returns the download URL in the API response. To avoid generating an email for every log-download API call, you can use a temporary token for downloading logs through OCAPI. For the request format, constraints, and the fields returned, see [eCDN WAF Log Fields and JSON Output](https://help.salesforce.com/s/articleView?id=cc.b2c_waf_log_fields_json_output.htm&type=5).

You can also use CDN Logpush for a more comprehensive set of logs. The CDN API stores firewall events and HTTP requests in your S3 bucket for immediate log visibility. For more information on CDN Logpush, see [Logpush Filters](https://developer.salesforce.com/docs/commerce/commerce-api/guide/cdn-zones-logpush-filter.html) and [Logpush Fields](https://developer.salesforce.com/docs/commerce/commerce-api/guide/cdn-zones-logpush-log-field.html)

## Related Content

- [eCDN WAF Log Fields and JSON Output](https://help.salesforce.com/s/articleView?id=cc.b2c_waf_log_fields_json_output.htm&type=5)
  Request B2C Commerce eCDN-WAF log files through the Open Commerce API (OCAPI). This reference covers the request constraints, an example call, the JSON log output, and the fields each log returns.
