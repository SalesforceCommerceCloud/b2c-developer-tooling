# web application firewall (WAF) and Network Traffic Logs

_The logs contain all B2C Commerce eCDN network traffic, not just the traffic that WAF identifies. Track IP-reputation blocked traffic and analyze how much of your traffic doesn’t trigger WAF settings._

Request log files at specified times for up to seven days. An email with a link to download the log is sent to your Business Manager email address. Because of General Data Protection Regulation (GDPR) restrictions, Salesforce removes log files after seven days. For this reason, we recommend that you save log files on your own server.

Log entries are in 60-minute increments of traffic requests to your storefront. You can request 60-minute increment log files through OCAPI (Open Commerce API). When using OCAPI, the API returns the URL for downloading the logs in the API response. To eliminate email generated for every log download API call for log downloads, you can use a temporary token for downloading logs through OCAPI.

> **Note:** You can also use CDN Logpush for a more comprehensive set of logs. The logs include the CDN-API to store firewall events and HTTP requests in your S3 bucket for immediate log visibility. The API supports visibility of HTTP requests and firewall events in the CDN logs

See Also

- [Logpush Filters](https://developer.salesforce.com/docs/commerce/commerce-api/guide/cdn-zones-logpush-filter.html)
- [Logpush Fields](https://developer.salesforce.com/docs/commerce/commerce-api/guide/cdn-zones-logpush-log-field.html)
