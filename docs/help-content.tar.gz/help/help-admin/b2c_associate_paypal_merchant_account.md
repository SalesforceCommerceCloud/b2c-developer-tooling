# Associate a PayPal Merchant Account with B2C Commerce

_To use Salesforce Payments with PayPal, associate your PayPal merchant account with your B2C Commerce instance._

|  |
| --- |
| Available in: **B2C Commerce** |

Prerequisites:

- To enable Salesforce Payments, contact Salesforce Customer Support.

1. In Business Manager, click App Launcher _(image: App Launcher)_, and then select **Administration > Site > Global Preferences > Salesforce Payments**.
2. Click **Add Account**.
3. Click**PayPal** and then click **Next**.
4. Select the type of PayPal merchant account that you want to use.

   - PayPal Sandbox: Select to use PayPal in a staging or development instance for testing.
   - PayPal Live: Select to use PayPal in a production instance to transact real funds.
5. Click **Next**.

   The PayPal window appears.
6. (Optional) In the PayPal window, add an existing merchant account.

   1. Enter the email address for your existing merchant account.
   2. Select the country or region for your account and click **Next**.
   3. Enter your password.
   4. Click **Agree and Consent**.
   5. Click **Return to Test Store**.
   
      Youʼre returned to the Business Manager account detail page where you can confirm that the account has been created.
7. (Optional) In the PayPal window, create a merchant account.

   1. Enter an email address for your new merchant account.
   2. Select the country or region for your account and click **Next**.
   3. Enter your first name, last name, a password, and a phone number.
   4. Review the PayPal consent forms. To give Salesforce Payments consent to perform the operations listed in the forms on your company’s behalf, accept the forms.
   5. Click **Agree and Create Account**.
   6. Click **Return to Test Store**.
   
      Youʼre returned to the Business Manager account detail page where you can confirm that the account has been created.
