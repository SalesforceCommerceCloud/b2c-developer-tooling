# Configure URL Patterns for PWA Kit and Headless Storefronts

_If you use PWA Kit or a headless storefront, override the **url** field in Field Mapping with a URL pattern so the product feed contains the correct product detail page URL for each product._

This task applies only to PWA Kit and headless storefronts. If you use SFRA or SiteGenesis, the system automatically generates correct URLs and you can skip this task.

PWA Kit and headless storefronts use different URL structures than SFRA or SiteGenesis. Because the product feed must link shoppers directly to your product detail pages, replace the default **url** mapping with a URL pattern that the system uses to generate the URL for each product in the feed.

The pattern is a URL template that contains a placeholder for the product ID. During feed generation, the system replaces the placeholder with each product's ID.

> **Important:** Placeholders use the `{fieldName}` syntax (curly braces with no dollar sign). The value inside the curly braces must match a B2C Commerce field name from the SFCC field dropdown that you see in Field Mapping. The system replaces only recognized field names; literal text and unsupported tokens pass through unchanged.

1. Click App Launcher _(image: App Launcher)_, and then select **Merchant Tools > Site > AI & Social Integrations > OpenAI**.
2. Click the **Catalog** tab.
3. In the **Field Mapping** section, find the **url** row and click **Override**.
4. Click **Override with constant value or pattern**, and then enter your URL pattern.

   Use `{id}` for the product ID. The system replaces `{id}` with each product's ID during feed generation.
   
   Example: `https://www.example.com/product/{id}`
   
   For other dynamic values, use any field name from the SFCC field dropdown in Field Mapping. Wrap the field name in curly braces—for example, `{brand}`.
   
   For step-by-step details on overrides, see [b2c_openai_feed_mapping.xml](https://help.salesforce.com/s/articleView?id=cc.b2c_openai_feed_mapping.htm&type=5).

The system saves your override and uses the URL pattern to generate product URLs in the feed. When shoppers click a product in ChatGPT, they're directed to the correct page on your PWA Kit or headless storefront.

Example URL Patterns **PWA Kit storefront:** Product URL: `https://www.mystore.com/product/{id}` **Custom headless storefront:** Product URL: `https://shop.mybrand.com/products/{id}` **Custom headless storefront with required URL slug:** Some storefronts require a human-readable slug in the URL path before the product ID, but the slug value itself is ignored by the routing logic—only its presence is required. In these cases, use a neutral placeholder like `_` to satisfy the URL structure. The slug placeholder value (here, `_`) can be any non-empty string. The storefront uses the product ID to resolve the correct page and ignores the slug segment entirely. Don't omit the slug segment—URLs without it don't resolve correctly. Product URL: `https://www.brand.com/us/en/product/_/{id}`
