# Express Checkout Considerations for B2C Commerce

_Although Express Checkout is often faster and easier to use than the Checkout payment method, features such as coupons, gift wrapping, shopper product customization, and gift card redemption aren’t always a good fit for Express Checkout._

Express Checkout options like Apple Pay and Google Pay can increase conversion on your storefront, but not if Express Checkout is made too complicated. Add Express Checkout buttons to your storefront in places where shoppers expect to find them and keep payment app interactions simple.

### Compatibility and Setup

Express Checkout options can vary by device and browser. Salesforce Payments determines which button to show, if any, for a given shopper using the APIs available in the browser. We recommend not making changes in your own client-side code.

### Apple Pay

Follow the [Apple Pay on the Web Acceptable Use Guidelines](https://developer.apple.com/apple-pay/acceptable-use-guidelines-for-websites/). If your storefront doesn’t meet acceptable use, consider not using Apple Pay. Apple also provides [Marketing Guidelines](https://developer.apple.com/apple-pay/marketing/) and [Human Interface Guidelines](https://developer.apple.com/design/human-interface-guidelines/apple-pay/). These guidelines are important if you change the presentation of Express Checkout options on your storefront. Some guidelines for error messaging aren’t supported by the W3C Payment Request API standard and aren’t available for Salesforce Payments.

All Apple devices and operating systems produced since 2016 support Apple Pay. To use Apple Pay on the web, shoppers must enable the feature, add a card to their Apple Wallet, and use the Safari browser. See the [Apple support website](https://support.apple.com/) for more details. If a shopper meets these criteria, Salesforce Payments shows an Apple Pay button for Express Checkout.

You can’t add [Stripe test cards](https://stripe.com/docs/testing#cards) to an Apple Wallet. When you use test mode on your storefront, Stripe substitutes a test card for your real card. Use any Apple ID with a real credit or debit card in your Apple Wallet, but your card isn’t charged when payments are made in test mode. To test with Salesforce Payments and Stripe, skip creating separate accounts or following other [Apple sandbox testing instructions](https://developer.apple.com/apple-pay/sandbox-testing/).

When you use test mode on your storefront with Adyen, Adyen requires you to create an Apple Sandbox Tester account. For more information, see [Alternative payment methods test credentials](https://docs.adyen.com/development-resources/test-cards-and-credentials/alternative-payment-method-credentials) and [Sandbox Testing](https://developer.apple.com/apple-pay/sandbox-testing/).

To offer Apple Pay, complete Apple’s [merchant setup steps and configuration](https://developer.apple.com/documentation/apple_pay_on_the_web/configuring_your_environment). When you use Salesforce Payments, Stripe and Adyen complete many steps for you, including merchant identification and the certificates used to encrypt payment information after you register your domains.

### Google Pay

Follow the Google Pay [Brand Guidelines](https://developers.google.com/pay/api/web/guides/brand-guidelines) and [UX best practices](https://developers.google.com/pay/api/web/guides/ux-best-practices). Salesforce Payments handles many of the technical details, but other guidelines, such as acceptable gathering and use of shopper data, are dependent on your organization.

Google Pay is available on many browsers and devices, but Stripe doesn’t support all combinations. Shoppers must enable the feature in their Google account, add a payment method, and use a browser with payment enabled. See the [Google support website](https://support.google.com/) and [Stripe paymentRequestButton documentation](https://stripe.com/docs/stripe-js/elements/payment-request-button). After a shopper meets these criteria, Stripe shows a Google Pay button for Salesforce Payments Express Checkout.

Some browsers don’t allow the Google Pay button to show if you haven’t used it before. When you complete Google Pay setup in your Google account, you visit a demo site and click a Google Pay button there. For example, [this demo site](https://rsolomakhin.github.io/pr/gp2/) is known to solve the problem. This occurrence is a known issue in Chrome.

To offer Google Pay, Google requires you to complete a [quick start guide](https://support.google.com/pay/business/answer/7530745?ref_topic=7684388). When you use Salesforce Payments, Salesforce Payments completes these steps for you.
