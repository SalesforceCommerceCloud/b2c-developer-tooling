# SCAPI Zone Support for B2C Commerce

_A SCAPI zone is the Salesforce-managed eCDN zone that fronts Salesforce Commerce API (SCAPI) traffic. Starting with B2C Commerce 26.10, the Production instance includes a subset of eCDN security controls and analytics for this zone in Business Manager and the CDN API, with no support case required._

Use the SCAPI zone to respond to abusive API traffic, such as credential stuffing against login endpoints, and to inspect HTTP and security traffic for your SCAPI hostname. Platform guardrails reject configurations that would break SCAPI routing or caching.

### What Is a SCAPI Zone?

A SCAPI zone is the eCDN zone that fronts SCAPI traffic for your realm. Identify it by its shortcode-based hostname.

**SCAPI zone hostname format:** `<shortcode>.api.commercecloud.salesforce.com`

Unlike storefront zones:

- You can't create a SCAPI zone. Salesforce auto-provisions it, and it appears in the Embedded CDN Settings zone list and the Configure Zones selector on the Production instance. For a SCAPI zone, **Add Hostname** shows 0 hostnames available.
- You can't add or remove hostnames on a SCAPI zone. The hostname and certificates are platform-managed.
- The Crypto tab is read-only. The Certificates table includes the certificate count and the Certificates table (hostname, cert status, hostname status, expiry, issuer, signature, and minimum TLS version). You can't upload, delete, renew, or otherwise manage certificates. This is the same read-only model used for the Default Domain. See [Default Domain Support for B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_default_domain.htm&type=5).
- There's one SCAPI zone for Development, Staging, and Production. A rule you add applies to all three environments unless you scope it. Scope every rule by the org ID in the URL path of the rule expression so that it doesn't affect other environments. Business Manager shows a warning banner on the Security Rules tab to remind you.
- Open and configure the SCAPI zone only on the Production instance. The zone doesn't appear in Business Manager or the CDN API on Development or Staging.
- Some rules are Salesforce-managed and locked. Platform-managed rules (for example, an allow-list for valid Managed Runtime (MRT) to SCAPI traffic that skips custom, rate-limiting, and managed WAF checks) are visible but not editable.

### Security Rules tab for a SCAPI zone

_(image: Security Rules tab for a SCAPI zone with a banner that the zone is shared across Development, Staging, and Production, custom firewall rules including a locked Salesforce-managed rule, and a rate limiting rule.)_

### Access the SCAPI Zone

There's one SCAPI zone for Development, Staging, and Production. After Salesforce provisions the zone, open it from the Production instance. The zone doesn't appear in Business Manager or the CDN API on Development or Staging.

1. In Business Manager on the Production instance, click App Launcher, and then select **Administration > Sites > Embedded CDN Settings**.
2. Locate the SCAPI zone by its `<shortcode>.api.commercecloud.salesforce.com` hostname.
3. Open the row's dropdown menu and select **Configure Zone**.

### Embedded CDN Settings — SCAPI zone in the zone list

_(image: Embedded CDN Settings zone list with a SCAPI zone row, its platform-managed hostname, certificate count, Configure Zone action, and 0 hostnames available.)_

The Configure Zones screen for a SCAPI zone provides three tabs—**Crypto** (read-only), **Security Rules** (custom rules, rate limiting rules, and IP lists, with Zone and Realm sub-tabs), and **Analytics** (HTTP and Security)—plus a **Purge Cache** button. Controls that don't apply to SCAPI zones aren't shown.

### Configure Zones — Crypto tab for a SCAPI zone

_(image: Configure Zones for a SCAPI zone with Crypto, Security Rules, and Analytics tabs and a Purge Cache button. The Crypto tab shows a read-only Certificates table with hostname, certificate status, and expiry.)_

### Controls Available on SCAPI Zones

On the Production instance, configurations that would break SCAPI routing or caching are rejected at submission time with a clear error, before they're applied. Controls that don't apply to SCAPI zones aren't shown in Business Manager and are rejected at the CDN API level.

These controls also aren't available on SCAPI zones: Speed settings, Under Attack Mode, custom error pages, Page Shield, notifications, Logpull, Logpush, Host Header Override, and cache rules (SCAPI caching is platform-managed).

### Analytics tab for a SCAPI zone

_(image: Analytics tab for a SCAPI zone showing HTTP traffic analysis for the previous 7 days and top statistics for source IP addresses, user agents, and paths.)_

### Related Tasks

The management flows for supported controls match storefront zones. For procedures, see:

- [Create a Custom Firewall Rule for an eCDN Zone](https://help.salesforce.com/s/articleView?id=cc.b2c_create_eCDN_firewall_rule.htm&type=5)
- [Verify Third-Party Requests with Secret Headers](https://help.salesforce.com/s/articleView?id=cc.b2c_verify_third_party_requests.htm&type=5)
- [Create a Rate Limiting Rule for an eCDN Zone](https://help.salesforce.com/s/articleView?id=cc.b2c_eCDN_create_rate_limiting_rule.htm&type=5)
- [Create and Manage Trusted IP Address Lists](https://help.salesforce.com/s/articleView?id=cc.b2c_manage_trusted_ip_address_lists.htm&type=5)
- [Analyze HTTP and Security Traffic for an eCDN Zone](https://help.salesforce.com/s/articleView?id=cc.b2c_analyze_eCDN_traffic.htm&type=5)
- [Purge the eCDN Cache](https://help.salesforce.com/s/articleView?id=cc.b2c_purge_ecdn_cache.htm&type=5)
- [eCDN Cache Rules and Cache Purge](https://help.salesforce.com/s/articleView?id=cc.b2c_ecdn_cache_rules_and_purge_overview.htm&type=5)
- [Configure an eCDN Zone for B2C Commerce in Business Manager](https://help.salesforce.com/s/articleView?id=cc.b2c_configuring_a_zone.htm&type=5)
