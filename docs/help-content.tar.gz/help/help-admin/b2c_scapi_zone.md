# SCAPI Zone Support for B2C Commerce

_A SCAPI zone is the Salesforce-managed eCDN zone that fronts Salesforce Commerce API (SCAPI) traffic. Starting with B2C Commerce 26.10, the Production instance includes a subset of eCDN security controls and analytics for this zone in Business Manager and the CDN API, with no support case required._

[Which Salesforce Commerce Product Do I Have?](https://help.salesforce.com/s/articleView?id=commerce.comm_what_product.htm)

Use the SCAPI zone to respond to abusive API traffic, such as credential stuffing against login endpoints, and to inspect HTTP and security traffic for your SCAPI hostname. Platform guardrails reject configurations that would break SCAPI routing or caching.

### What Is a SCAPI Zone?

A SCAPI zone is the eCDN zone that fronts SCAPI traffic for your realm. Identify it by its shortcode-based hostname.

**SCAPI zone hostname format:** `<shortcode>.api.commercecloud.salesforce.com`

Unlike storefront zones:

- You can't create a SCAPI zone. Salesforce auto-provisions it, and it appears in the Embedded CDN Settings zone list and the Configure Zones selector on the Production instance. For a SCAPI zone, **Add Hostname** shows 0 hostnames available.
- You can't add or remove hostnames on a SCAPI zone. The hostname and certificates are platform-managed.
- The Crypto tab is read-only. The Certificates table includes the certificate count and the Certificates table (hostname, cert status, hostname status, expiry, issuer, signature, and minimum TLS version). You can't upload, delete, renew, or otherwise manage certificates. This is the same read-only model used for the Default Domain. See [Default Domain Support for B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_default_domain.htm&type=5).
- There's one SCAPI zone for Development, Staging, and Production. A rule you add applies to all three environments unless you scope it. Scope every rule by the org ID in the URL path of the rule expression so that it doesn't affect other environments. Business Manager shows a warning banner on the Security Rules tab to remind you.
- Open and configure the SCAPI zone only on the Production instance. The zone doesn't appear in Business Manager or the CDN API on Development or Staging.
- Some rules are Salesforce-managed and locked. Platform-managed rules (for example, an allow-list for valid Managed Runtime (MRT) to SCAPI traffic that skips custom, rate-limiting, and managed WAF checks) are visible but not editable.

### Security Rules tab for a SCAPI zone

_(image: Security Rules tab for a SCAPI zone with a banner that the zone is shared across Development, Staging, and Production, custom firewall rules including a locked Salesforce-managed rule, and a rate limiting rule.)_

### Controls Available on SCAPI Zones

On the Production instance, configurations that would break SCAPI routing or caching are rejected at submission time with a clear error, before they're applied. Controls that don't apply to SCAPI zones aren't shown in Business Manager and are rejected at the CDN API level.

These controls also aren't available on SCAPI zones: Speed settings, Under Attack Mode, custom error pages, Page Shield, notifications, Logpull, Logpush, Host Header Override, and cache rules (SCAPI caching is platform-managed).

### Analytics tab for a SCAPI zone

_(image: Analytics tab for a SCAPI zone showing HTTP traffic analysis for the previous 7 days and top statistics for source IP addresses, user agents, and paths.)_

### Managed Runtime SCAPI Request Identification

Starting with B2C Commerce 26.10, you can lock down Shopper API requests on the Salesforce Commerce API (SCAPI) zone so that they are accepted only from your Managed Runtime (MRT) environments. Enable the **Managed Runtime SCAPI Request Identification** feature switch in Business Manager for each instance you want to protect: Development, Staging, and Production. Salesforce generates and rotates a secret, the SCAPI Identity Header (SIH). MRT attaches that header to every request it forwards to SCAPI.

The **Security Rules** tab depends on **SCAPI Zone Visibility** in Business Manager. That switch is on by default starting with B2C Commerce 26.10.

After setup finishes, a locked Salesforce-managed allow rule for that instance appears on the SCAPI zone's **Security Rules** tab. Open that tab from the Production instance. Each allow rule matches the instance's org-specific path segment, so a Production rule doesn't apply to Staging or Development.

Enabling the feature switch doesn't stop direct SCAPI traffic. On the same **Security Rules** tab, add your own custom firewall rule to block direct Shopper API requests that don't come from MRT. Don't block every SCAPI call. Admin APIs authenticate with Account Manager credentials, and blocking them breaks Admin API and B2C CLI use cases.

- Scope the rule. Use the same org-specific path segment as the allow rule, and add `/shopper`. For example, `URI Path contains` the org segment and `URI Path contains /shopper`. An unscoped rule applies to Development, Staging, and Production. The `/shopper` condition matches Shopper APIs and the SLAS path and leaves Admin API paths alone. A custom API path, `/custom/<api>/...`, doesn't contain `/shopper`. To block one custom endpoint, use the org segment and `URI Path contains /custom/<api>` instead.
- Order the rule. Place the block rule directly after that instance's allow rule. Rules evaluate in order, so a block rule above the allow rule also blocks MRT traffic.
- Choose the action. SCAPI clients can't solve a challenge, so set the action to `block`, not Managed Challenge.
- Start with `log`. Leave the rule in `log` for at least a full business cycle, about 1 to 7 days, including scheduled jobs and peak hours. Review the matches by path, user agent, and ASN. Look for legitimate Shopper API callers that reach SCAPI without going through MRT, such as native mobile apps, synthetic monitoring, and QA automation. OMS, ERP, and PIM integrations call Admin APIs, so the rule doesn't match them.
- Keep exclusions narrow. Route legitimate callers through MRT, or exclude a specific path plus a known signal, such as a client ID or a short list of fixed IPs. Don't allowlist whole IP ranges or networks.
- Time the switch. Switch to `block` only after that review, and not during a flash sale, a holiday code freeze, or another peak window.
- Plan a rollback. To roll back, set the block rule back to `log`, or disable it, before you turn off the feature switch. After you enforce the rule, watch for a spike in SCAPI zone blocks or 403 responses, for example with [anomaly detection in Log Center](https://help.salesforce.com/s/articleView?id=cc.b2c_anomaly_detection.htm&type=5).

This control closes the path that bypasses your CDN and MRT for Shopper API traffic. Continue to use rate limiting and your other bot controls. Salesforce provides the secret, rotation, and the allow rule. You own the block rule, its exclusions, and monitoring.

For setup steps, see [Restrict SCAPI Access to Managed Runtime Traffic](https://developer.salesforce.com/docs/commerce/pwa-kit-managed-runtime/guide/scapi-request-identification.html) for Composable Storefront and [Restrict SCAPI Access to Managed Runtime Traffic](https://developer.salesforce.com/docs/commerce/sfnext/guide/sfnext-scapi-request-identification.html) for Storefront Next.

### Related Tasks

The management flows for supported controls match storefront zones. For procedures, see:

- [Access the SCAPI Zone in Business Manager](https://help.salesforce.com/s/articleView?id=cc.b2c_access_scapi_zone.htm&type=5)
- [Create a Custom Firewall Rule for an eCDN Zone](https://help.salesforce.com/s/articleView?id=cc.b2c_create_eCDN_firewall_rule.htm&type=5)
- [Verify Third-Party Requests with Secret Headers](https://help.salesforce.com/s/articleView?id=cc.b2c_verify_third_party_requests.htm&type=5)
- [Create a Rate Limiting Rule for an eCDN Zone](https://help.salesforce.com/s/articleView?id=cc.b2c_eCDN_create_rate_limiting_rule.htm&type=5)
- [Create and Manage Trusted IP Address Lists](https://help.salesforce.com/s/articleView?id=cc.b2c_manage_trusted_ip_address_lists.htm&type=5)
- [Analyze HTTP and Security Traffic for an eCDN Zone](https://help.salesforce.com/s/articleView?id=cc.b2c_analyze_eCDN_traffic.htm&type=5)
- [Purge the eCDN Cache](https://help.salesforce.com/s/articleView?id=cc.b2c_purge_ecdn_cache.htm&type=5)
- [eCDN Cache Rules and Cache Purge](https://help.salesforce.com/s/articleView?id=cc.b2c_ecdn_cache_rules_and_purge_overview.htm&type=5)
- [Configure an eCDN Zone for B2C Commerce in Business Manager](https://help.salesforce.com/s/articleView?id=cc.b2c_configuring_a_zone.htm&type=5)

For developer guidance on applying these controls, including Leaked Credentials Detection and rate limiting on SLAS login, see [Security](https://developer.salesforce.com/docs/commerce/commerce-api/guide/security.html).

SCAPI caching is platform-managed. For which responses are cached, how long they stay cached, and how cache tags work, see [SCAPI Caching](https://developer.salesforce.com/docs/commerce/commerce-api/guide/server-side-web-tier-caching.html).

## Related Content

- [Access the SCAPI Zone in Business Manager](https://help.salesforce.com/s/articleView?id=cc.b2c_access_scapi_zone.htm&type=5)
  Open the Salesforce-managed SCAPI zone from the Production instance in Business Manager to configure supported security controls, view HTTP and security analytics, and purge cache for B2C Commerce.
