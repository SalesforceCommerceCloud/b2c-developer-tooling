# Set Instance Status for B2C Commerce

_Instance status is the status of payments on your B2C Commerce instance for B2C Commerce._

You set the instance status in Business Manager. Click App Launcher _(image: App Launcher)_, and then select **Merchant Tools > Ordering > Salesforce Payments** and click **Settings**. There are two modes.

- **Test**–Use Test Mode in development or sandbox instances to verify Salesforce Payments works as expected, after you modify your payment configurations or add a payment type.
- **Live**–To activate Salesforce Payments on your storefront, use Live Mode in production instances
