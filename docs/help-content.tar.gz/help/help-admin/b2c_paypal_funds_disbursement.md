# PayPal Funds Disbursement

_Salesforce Payments with PayPal implements immediate capture and funds disbursement For example, a B2C Commerce shopper completes a cart checkout and the order is approved. That shopper's payment is immediately captured and dispersed to the merchant._

The PayPal immediate capture and disbursement process follows this flow.  The shopper completes a cart checkout. The order status is set to Approved. PayPal captures the order. PayPal transfers funds from the buyer's account to the seller's PayPal account.
