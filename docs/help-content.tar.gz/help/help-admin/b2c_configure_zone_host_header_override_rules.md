# Configure Host Header Override Rules for an eCDN Zone

_Create rules that override the HTTP Host header sent to your origin server for a B2C Commerce eCDN zone, using the Configure Zones interface in Business Manager._

> **Note:** Host Header Override isn't available on SCAPI zones. See [SCAPI Zone Support for B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_scapi_zone.htm&type=5).

Use Host Header Override Rules when your origin expects a different host value than the shopper-facing hostname. This setup is common for customers using stacked CDNs or custom origin-routing patterns.

For additional background and legacy workflow details, see [Configure Host Header Override Rules](https://help.salesforce.com/s/articleView?id=cc.b2c_eCDN_configure_host_header_override.htm&type=5).

1. In Business Manager, click the App Launcher, and then select **Administration > Sites > Embedded CDN Settings**.
2. Locate the zone you want to configure and select **Configure Zone** from the dropdown menu.
3. Select the **Host Header Override Rules** tab.

   ### Host Header Override Rules tab
   
   _(image: Configure Zones Host Header Override Rules tab showing an empty state with no rules configured and a New Host Header Override Rule button)_
