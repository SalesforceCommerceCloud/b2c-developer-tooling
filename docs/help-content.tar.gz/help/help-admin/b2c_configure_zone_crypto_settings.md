# Configure Crypto Settings for an eCDN Zone for B2C Commerce

_Configure SSL/TLS and cryptography settings for an eCDN zone, including Transport Layer Security (TLS) version and HTTP Strict Transport Security (HSTS), using the Configure Zones interface in Business Manager._

Use the Crypto tab to manage TLS, certificates, and HSTS for an eCDN zone.

> **Note:** If a tab doesn't fit on screen, it appears under a **More** dropdown on the right.

> **Note:** On SCAPI zones, the Crypto tab is read-only on the Production instance. The Certificates table is visible, but you can't change TLS 1.3, HSTS, or certificate settings. Salesforce manages certificates for SCAPI zones. The SCAPI zone doesn't appear in Business Manager or the CDN API on Development or Staging. See [SCAPI Zone Support for B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_scapi_zone.htm&type=5).

1. In Business Manager, click the App Launcher, and then select **Administration > Sites > Embedded CDN Settings**.
2. Locate the zone you want to configure and select **Configure Zone** from the dropdown menu.
3. Select the **Crypto** tab.

   ### Crypto tab — SSL/TLS settings and certificates
   
   _(image: Configure Zones Crypto tab showing SSL/TLS Settings, Certificates list, HSTS Settings, and the Under Attack Mode toggle in the header.)_
   
   ### Crypto tab — certificate detail expanded
   
   _(image: Crypto tab Certificates section with a certificate row expanded to show validation method, type, hosts, issuer, signature, upload date, and minimum TLS version.)_
4. In the SSL/TLS Settings section, set **Enable TLS 1.3** on or off.

   TLS 1.3 is supported by all major browsers.
   
   > **Note:** If your zone has no custom certificates, you can't change the TLS 1.2 minimum requirement. If you click the toggle, a confirmation appears and the toggle reverts.
   
   ### TLS 1.3 setting in SSL/TLS Settings
   
   _(image: SSL/TLS Settings section showing the Enable TLS 1.3 toggle with the state indicator in the Crypto tab.)_
5. Review certificates in the **Certificates** table.

   | Column | What it shows |
   | --- | --- |
   | Hostname | The hostname or wildcard covered by the certificate. |
   | Cert Status | Certificate state, such as Active, Active - Expires Soon, Pending, or Initializing. |
   | Hostname Status | Whether the hostname has been verified at the edge. |
   | Expires On | Certificate expiration date. |
   
   The first 12 certificates are shown. Click **View All** to see the rest.
6. Manage certificates as needed.

   1. To add a certificate, click **New Certificate** and follow the prompts.
   2. To replace or delete a certificate, open the actions menu on the certificate row, and then select **Edit** or **Delete**.
   
      A confirmation dialog appears before deletion.
   3. To view certificate details, click the chevron at the start of a certificate row.
   
      The expanded view shows certificate type, hosts, issuer, validation method, expiration details, and any TXT or CNAME records or verification buttons required for unverified certificates.
   
   ### Certificate details expanded in Certificates table
   
   _(image: Certificates table with a row expanded to display additional certificate and hostname verification details.)_
7. Configure HSTS.

   1. Expand the **HSTS Settings** section.
   2. Set **Enable HSTS** on and, in the confirmation dialog, click **Enable**.
   
      The dialog explains the consequence before you continue.
   3. Click the edit pencil and configure **Time and Unit**, **Include Subdomains**, and **Preload**.
   4. Click **Save**.
   
   > **Important:** HSTS can't be turned off manually. It expires only when the configured max age passes. Make sure your full site is served over HTTPS before enabling HSTS.
   
   > **Note:** HSTS is opt-in and not enabled by default. If you don't see HSTS settings in the Crypto tab, contact your Salesforce representative.
   
   ### HSTS settings with editable max-age options
   
   _(image: HSTS Settings section showing enabled state, time value and unit, Include Subdomains, Preload options, and Save and Cancel actions.)_
   
   ### HSTS state indicators in Crypto tab
   
   _(image: HSTS Settings showing the enabled toggle and edit icons for time and unit fields in the Crypto tab.)_
   
   ### HSTS informational message when disabled
   
   _(image: HSTS Settings with disabled state and informational banner explaining that HSTS expires after max age and can't be manually disabled.)_
