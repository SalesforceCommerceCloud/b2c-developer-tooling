# Trusted IP Migration to WAF Custom Rules

_Salesforce automatically migrates your legacy B2C Commerce Trusted IP configurations to web application firewall (WAF) custom rules and Managed IP Address Lists in the new Realm Security Rules tab. Learn what the migration does and how to verify your migrated configuration._

### What Is Changing

The legacy Trusted IP configuration — previously managed via the Firewall tab in the zone settings slider — is being replaced by two components in the new Realm Security Rules tab:

- **Managed IP Address Lists:** Named lists of trusted IP addresses or CIDR ranges, scoped at the account (realm) level or zone level.
- **Custom firewall rules with skip actions:** Rules that reference your IP address lists and specify which security checks to bypass for traffic from trusted sources.

This change is part of the broader migration of eCDN zone configuration settings to the new LWC-based Configure Zones interface in Business Manager. For how trusted traffic bypasses security checks, the DDoS Layer 7 overrides, eligible zone types, and the feature switch that controls this functionality, see [eCDN Zone Security Rules](https://help.salesforce.com/s/articleView?id=cc.b2c_ecdn_security_rules.htm&type=5).

### What Salesforce Does Automatically

Salesforce automatically migrates your existing Trusted IP configurations to the new format. You don't need to recreate your trusted IP lists manually. After migration:

- Your existing account-level Trusted IP groups become account-level Managed IP Address Lists with associated custom firewall rules in the Realm Security Rules tab.
- Your existing zone-level Trusted IP groups become zone-level Managed IP Address Lists with associated custom firewall rules.
- List names are derived from the notes field of your legacy access rules. The system converts the label to a lowercase slug, replacing non-alphanumeric characters with underscores, and prepends `customer_`. For example:
   
   - A group labeled `TrustedVPN` becomes `customer_trustedvpn`
   - A group labeled `Support-Team VPN` becomes `customer_support_team_vpn`
   - A group with no label becomes `customer_` with no suffix
- Migration is idempotent. If the migration process runs more than once, existing migrated rules are detected and not duplicated. You don't need to take any action to prevent double migration.

> **Tip:** After migration, verify that your lists and rules appear correctly in **each of your storefront Zone Security Rules** tab in Business Manager. See [Realm Security Rules for eCDN Zones](https://help.salesforce.com/s/articleView?id=cc.b2c_configure_zone_realm_security_rules.htm&type=5).

> **Important:** A Cloudflare account-level skip rule doesn't bypass zone-level rules. To preserve the original behavior of Trusted IPs (which globally bypassed all checks), Salesforce creates the skip rule at every existing zone in your realm. If you create a new zone after the migration, you must add the Trusted IP skip rule to that zone manually. Confirm the Managed IP List is referenced in a skip rule on the new zone before relying on Trusted IPs for traffic to that zone.
