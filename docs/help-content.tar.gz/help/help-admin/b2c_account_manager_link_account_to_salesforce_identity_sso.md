# Link an Account Manager Account to Salesforce Identity (SSO) in B2C Commerce

_Depending on the settings of your organization, you can link Account Manager accounts to Salesforce accounts managed in Salesforce Identity. If your organization enables this capability, you can link your Account Manager account to a Salesforce account when you log in to Account Manager. To unlink your account, contact your account administrator._

[Which Salesforce Commerce Product Do I Have?](https://help.salesforce.com/s/articleView?id=commerce.comm_what_product.htm)

1. In a web browser, go to https://account.demandware.com/.
2. Enter your username (email address).
3. Click **LOG IN**.

   > **Note:** If Identity Federation with Salesforce Identity is set to **Enforced** as part of Organization configuration, you are redirected to Salesforce Identity to enter your password.
4. Enter your password.
5. Click **LOG IN**.
6. (Optional) Depending on your organization settings you may be required to verify your identity with multi-factor authentication (MFA). If you’ve already registered an MFA verification method, provide the method to finish logging in. If you haven’t registered a method, you’re prompted to do so before you’re able to log in.
7. Click **LINK WITH A SALESFORCE ACCOUNT**

   You’re now redirected to Salesforce. After you successfully log in to Salesforce, you return to Account Manager.
   
   > **Caution:** Linking your Account Manager account with a Salesforce account can change your Account Manager user name to the email address of your Salesforce account. The confirmation page shows the new user name. If you do not want your Account Manager user name changed, you can cancel this procedure and contact your account administrator.
8. Click **CONFIRM** to finish linking accounts or click **CANCEL** to cancel this procedure.

> **Note:** If Identity Federation with Salesforce Identity is set to **Allowed** as part of Organization configuration:
> 
> - New users must log in to Account Manager with MFA to complete linking their Account Manager account with Salesforce Identity. See [Register Verification Methods for Multi-Factor Authentication](https://help.salesforce.com/s/articleView?id=cc.b2c_account_manager_register_verification_methods_for_mfa.htm&type=5) for more details.
> - If a user is reset or deleted, the user’s link between Account Manager and Salesforce Identity is removed. If the user is reactivated or restored, they must log in to Account Manager with MFA to restore the link to Salesforce Identity.
> 
> If Identity Federation with Salesforce Identity is set to **Enforced**, users aren't required to do MFA with Account Manager to complete linking their Account Manager account with Salesforce Identity.
