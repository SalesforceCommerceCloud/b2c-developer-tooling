# Configure Payment Zones for B2C Commerce

_Create payment zones to assign payment methods to specific currencies and countries for B2C Commerce. After you create a payment zone, assign it to a merchant account. Then, select the payment methods for the zone._
