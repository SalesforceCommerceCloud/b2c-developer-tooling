# Replication in B2C Commerce

_Replication securely copies selected storefront data or a code version from a staging instance to a development or production instance on your Primary Instance Group (PIG). It’s a two-step procedure that first transfers the data or code version, then publishes the data or activates the code version. This topic applies to B2C Commerce._
