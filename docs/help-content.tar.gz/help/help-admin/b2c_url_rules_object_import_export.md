# URL Rules Object Import/Export in B2C Commerce

_Use the redirecturl.xsd schema file to import URL redirects. This topic applies to B2C Commerce._

*Granularity:* any rule that determines the format of URLs for the storefront.

### Business Manager Import Location

**Administration > Site Development > Site Import & Export**

### Pipelets

N/A

### Schema Elements

As of release 14.8, the schema allows multiple pipeline-aliases sections, where each section can have an optional language attribute that specifies the locale.

```
<pipeline-aliases xml:lang="x-default">
    <pipeline-alias pipeline="Home-Show">home</pipeline-alias>
</pipeline-aliases>

<pipeline-aliases xml:lang="de">
    <pipeline-alias pipeline="Home-Show">startseite</pipeline-alias>
</pipeline-aliases>
```
