# Configure URL Patterns for the Product Feed

_If you use PWA Kit or a headless B2C Commerce storefront, override the product URL field in Field Mapping with a URL pattern so the product feed contains the correct product detail page URL for each product._

This task applies only to PWA Kit and headless storefronts. If you use SFRA or SiteGenesis and the standard product URLs, B2C Commerce automatically generates correct URLs and you can skip this task.

> **Note:** The product URL field is named **url** for the OpenAI feed and **link** for the Google feed.

PWA Kit and headless storefronts use different URL structures than SFRA or SiteGenesis. Because the product feed must link shoppers directly to your product detail pages, replace the default product URL mapping with a URL pattern that B2C Commerce uses to generate the URL for each product in the feed.

The pattern is a URL template that contains a placeholder for the product ID. During feed generation, B2C Commerce replaces the placeholder with each product's ID.

> **Important:** Placeholders use the `${fieldName}` syntax (a dollar sign followed by curly braces). The value inside the braces must match a B2C Commerce field name from the SFCC field dropdown that you see in Field Mapping. B2C Commerce replaces only recognized field names; literal text and unsupported tokens pass through unchanged.

1. Click App Launcher _(image: App Launcher)_, and then select **Merchant Tools > Site > AI & Social Integrations**, and then select your channel (**OpenAI** or **Google**).
2. Click the **Catalog** tab.
3. In the **Field Mapping** section, find the product URL row (**url** for OpenAI or **link** for Google) and click **Override**.
4. Click **Override with constant value or pattern**, and then enter your URL pattern.

   Use `${id}` for the product ID. B2C Commerce replaces `${id}` with each product's ID during feed generation.
   
   Example: `https://www.example.com/product/${id}`
   
   For other dynamic values, use any field name from the SFCC field dropdown in Field Mapping. Wrap the field name in a dollar sign and curly braces. For example, `${brand}`.
   
   For step-by-step details on overrides, see [Map Product Fields for OpenAI](https://help.salesforce.com/s/articleView?id=cc.b2c_openai_feed_mapping.htm&type=5) or [Map Product Fields for Google](https://help.salesforce.com/s/articleView?id=cc.b2c_google_feed_mapping.htm&type=5).

B2C Commerce saves your override and uses the URL pattern to generate product URLs in the feed. When shoppers click a product from the channel, they're directed to the correct page on your PWA Kit or headless storefront.

Example URL Patterns **PWA Kit storefront:** Product URL: `https://www.mystore.com/product/${id}` **Custom headless storefront:** Product URL: `https://shop.mybrand.com/products/${id}` **Custom headless storefront with required URL slug:** Some storefronts require a human-readable slug in the URL path before the product ID, but the slug value itself is ignored by the routing logic, and only its presence is required. In these cases, use a neutral placeholder like `_` to satisfy the URL structure. The slug placeholder value (here, `_`) can be any non-empty string. The storefront uses the product ID to resolve the correct page and ignores the slug segment entirely. Don't omit the slug segment. URLs without it don't resolve correctly. Product URL: `https://www.brand.com/us/en/product/_/${id}`
