# Best Practices for Import/Export in B2C Commerce

_We recommend that you follow established best practices for import and export. This topic applies to B2C Commerce._

If possible, for non-catalog feeds, create import feeds containing only the differences between the current and previous feed. These feeds are referred to as delta feeds. Such feeds are smaller and quicker to import and are less vulnerable to network interruptions.

To create a delta catalog feed, you can't include fields that replace the global import mode with a field-specific import mode. For example, it isn't possible to create a delta feed for a bundled product, because the bundled-products field always uses a REPLACE semantic.

You can't roll back feeds. Therefore, it’s best practice to archive at least the last feed, so that you can reimport an older version if the new feed can't be validated. However, B2C Commerce doesn't automatically clean out archives, so you must clean out archived files. Contact customer support for a demonstration cartridge for cleaning out archived files.
