# Browser Support

_B2C Commerce supports several different browsers._

Desktop

- Microsoft Edge: Supports latest stable browser version
- Google Chrome: Supports latest stable browser version
- Mozilla Firefox: Supports latest stable browser version
- Apple Safari: Supports latest stable browser version
