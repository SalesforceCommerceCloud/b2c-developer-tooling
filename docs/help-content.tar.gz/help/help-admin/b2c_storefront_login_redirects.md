# Storefront Login Redirects

_In SiteGenesis, B2C Commerce redirects the storefront login via a 302 redirect to prevent credentials from being available with a browser refresh. Any node that requires a login sets the pipeline and parameters to use in the redirect. The `loginredirect.isml` template and the `Login-Redirect` pipeline (both in the SiteGenesis Storefront Core cartridge) perform the redirect._

> **Note:** While accessing a storefront that has multiple locales with registered user, if the preferred locale set on the customer profile in Business Manager is different than the current site locale, the user is automatically redirected to the storefront page with the preferred locale.

Redirects are used in the following pipelines:

- Checkout: COCustomer - Start
- MyAccount: Account - Show
- MyAccount: Address - Add, Delete, Edit, GetAddressDetails, List, SetDefault, DeleteAddress
- MyAccount: Login
- MyAccount: Order - History
- MyAccount: PaymentsInstruments - Delete, List
- ProductList: GiftRegistry - AddProduct, Create, Delete, Start
- Product List: Wishlist - Add, Show
