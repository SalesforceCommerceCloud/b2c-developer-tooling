# Set Up Salesforce Payments for B2C Commerce

_Salesforce Payments is a native checkout solution that supports multiple payment methods and payment gateways such as Adyen, Stripe, and PayPal. Salesforce Payments is available for use with Storefront Reference Architecture (SFRA) or Composable Storefronts._

|  |
| --- |
| Available in: **B2C Commerce** |

1. To enable Salesforce Payments, contact Salesforce Customer Support.
2. To use Salesforce Payments with a SFRA 7.0 Storefront, install `plugin_salesforcepayments` cartridge.

   See [Install the Salesforce Payments Plug-In for B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_install_salesforce_payment_plugin.htm).
3. To use Salesforce Payments with a Composable Storefront, see [Configure Salesforce Payments for Your B2C Commerce Composable Storefronts](https://developer.salesforce.com/docs/commerce/pwa-kit-managed-runtime/guide/salesforce-payments.html).
4. Configure Salesforce Payments with Adyen or Stripe.

   To configure Salesforce Payments with Adyen, contact your Salesforce account executive to enable Salesforce Payments — Adyen. See [Configure Salesforce Payments with Adyen for B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_configure_salesforce_payments_with_adyen.htm) or [Configure Salesforce Payments with Stripe for B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_configure_salesforce_payments_with_stripe.htm).
5. (Optional) Configure Salesforce Payments with PayPal.

   See [Configure Salesforce Payments with PayPal for B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_configure_salesforce_payments_with_paypal.htm).
6. Configure a payment zone.

   See [Configure Payment Zones for B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_configure_payments_zones.htm).
7. Configure site payment settings.
8. Validate Adyen or Stripe payments.

   See [Validate Adyen Payments for B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_validate_adyen_payments.htm) or [Validate Stripe Payments for B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_validate_payments_in_test_and_live_modes.htm).
9. (Optional) Test PayPal payments.

   See [Test a PayPal Configuration](https://help.salesforce.com/s/articleView?id=cc.b2c_test_a_paypal_configuration.htm).

> **Note:** Salesforce Payments doesn't support Internet Explorer.
