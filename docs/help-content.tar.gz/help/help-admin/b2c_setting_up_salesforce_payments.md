# Set Up Salesforce Payments for B2C Commerce

_Salesforce Payments is a native checkout solution that supports Adyen, Stripe, and PayPal payment gateways and multiple payment methods. Salesforce Payments is available in Storefront Reference Architecture (SFRA), Composable Storefront, Storefront Next, and SiteGenesis._

Prerequisite:

To purchase a Salesforce Payments + Commerce license and enable Salesforce Payments, contact your Salesforce account executive.

1. Install Salesforce Payments.

   See [Install a Commerce App for B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_install_commerce_app.htm&type=5).
2. Configure Salesforce Payments for your storefront.

   1. To use Salesforce Payments with an SFRA 7.0 Storefront, install the `plugin_salesforcepayments` cartridge.
   
      See [Install the Salesforce Payments Plug-In for B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_install_salesforce_payment_plugin.htm).
   2. To use Salesforce Payments with a Composable Storefront, see [Configure Salesforce Payments for Your B2C Commerce Composable Storefronts](https://developer.salesforce.com/docs/commerce/pwa-kit-managed-runtime/guide/salesforce-payments.html).
   3. To use Salesforce Payments with Storefront Next, see [Configure Salesforce Payments for Storefront Next](https://developer.salesforce.com/docs/commerce/sfnext/guide/sfnext-salesforce-payments.html).
   4. To use Salesforce Payments with SiteGenesis, see [SiteGenesis Configuration for Salesforce Payments](https://help.salesforce.com/s/articleView?id=cc.b2c_add_salesforce_payments_functionality_to_site_genesis.htm&type=5).
3. Configure a payment zone.

   See [Configure Payment Zones for B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_configure_payments_zones.htm).
4. Configure a merchant account.

   You can configure merchant accounts for either Adyen or Stripe. You can also configure PayPal in addition to Adyen or Stripe.
   
   1. To configure Salesforce Payments with Adyen, see [Configure Salesforce Payments with Adyen for B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_configure_salesforce_payments_with_adyen.htm).
   2. To configure Salesforce Payments with Stripe, see [Configure Salesforce Payments with Stripe for B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_configure_salesforce_payments_with_stripe.htm).
   3. (Optional) To configure Salesforce Payments with PayPal, see [Configure Salesforce Payments with PayPal for B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_configure_salesforce_payments_with_paypal.htm).
5. Configure payment methods.

   1. Activate a payment method.
   
      See [Activate a Payment Method for B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_activate_payment_method.htm&type=5).
   2. Configure checkout and express checkout payment methods.
   
      See [Configure Payment Methods for B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_configure_payment_methods.htm&type=5).
   3. Arrange the sequence of payment methods that appear on your storefront.
   
      See [Organize Payment Methods for B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_organize_payment_methods.htm&type=5).
   4. Choose where app components appear on your storefront.
   
      See [Customize Where Commerce App Components Appear on Your B2C Storefront](https://help.salesforce.com/s/articleView?id=cc.b2c_commerce_app_storefront_display.htm&type=5).
6. Configure advanced payment settings.

   1. Set the instance to process live or test payments.
   
      See [Set the Payments Instance Status for B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_set_instance_status.htm&type=5).
   2. Set the payment capture timing.
   
      See [Set the Payment Capture Timing for B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_payment_card_capture_timing.htm&type=5).
   3. Set the saved payment credentials.
   
      See [Set the Saved Payment Credentials for B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_payment_card_credential_storage.htm&type=5).
   4. Set the customer statement descriptor.
   
      See [Set the Customer Statement Descriptor for B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_set_customer_statement_descriptor.htm&type=5).
7. Validate payments.

   See [Validate Payments for B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_validate_payments_in_test_and_live_modes.htm).
8. If you configured Salesforce Payments with PayPal, test PayPal payments.

   See [Test a PayPal Configuration](https://help.salesforce.com/s/articleView?id=cc.b2c_test_a_paypal_configuration.htm).
