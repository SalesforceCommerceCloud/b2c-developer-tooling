# Security Managed by Customer

_Salesforce provides a variety of configurable security controls that authorized administrators can use to secure their instances on the Salesforce B2C Commerce platform. Customers can use additional controls to further customize their security footprint._

B2C Commerce provides the following types of security controls.

- IP Allowlisting to restrict application-level access, for example, setting combinations of IP and Geo IP restrictions.
- Secure communication protocols, including HTTPS and Secure File Transfer Protocol (SFTP), to enforce communication security.
- Certificate Management, which allows Business Manager administrators to upload and manage their own certificates to securely integrate with other systems.
- Two-Factor Authentication (2FA) is enforced on sensitive customer-managed interfaces.
- Customizable roles and granular entitlement to define user access roles, permissions, and well-defined user provisioning processes.
- Password and session management settings to define password settings and how sessions are managed.
- Encryption to use industry-accepted encryption products to protect customer data and communications during transmissions to B2C Commerce platform. Salesforce offers PCI Data Security Standard (DSS)-compliant encryption for supported payment field types at rest and in transit. You can encrypt additional data, if necessary.
- Audit logs to review and export data to user access logs. The audit log records all actions performed in the Control Center, regardless of which user performed the action. A user with administrator privileges can see all entries in the log.
- Trust and compliance documentation that provides further details about the B2C Commerce platform.

As best practice, consider deploying the following security controls:

- Secure design and implementation of custom code
- Secure sourcing, deployment, and maintenance of third-party integrations and extensions
- Continuous monitoring and incident response on customer and custom third-party integration assets
- Anti-abuse, fraud detection, and prevention measures
