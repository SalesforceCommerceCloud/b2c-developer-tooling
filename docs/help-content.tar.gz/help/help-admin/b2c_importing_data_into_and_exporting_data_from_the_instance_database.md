# Importing Data into and Exporting Data from a B2C Commerce Instance Database

_When you have transferred files to your instance, you are ready to import data into the B2C Commerce database on the instance._

Use the import/export feature to import most types of data used by your site. For site settings, use the Site Import/Export or data replication. For code deployment, use data replication or upload code directly from your local machine via UX Studio.
