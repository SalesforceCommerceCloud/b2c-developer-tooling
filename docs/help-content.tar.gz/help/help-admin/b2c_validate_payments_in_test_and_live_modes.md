# Validate Payments for B2C Commerce

_Set up and validate test payments in a test or live merchant account for your B2C Commerce instance. Use a merchant account associated with your B2C Commerce instance to create test payments._

- Test mode: Doesn’t use actual authorizations or captures. Uses test cards and bank accounts.
- Live mode: Uses actual authorizations and captures for credit cards and bank accounts. Uses only valid credit cards and bank accounts.

Associate a merchant account with your B2C Commerce instance, and for Stripe, onboard the account. See [Associate an Adyen Merchant Account with B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_associate_adyen_merchant_account.htm&type=5), [Associate a Stripe Merchant Account with B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_associate_stripe_merchant_account.htm&type=5), and [Onboard Your Stripe Merchant Account for B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_onboard_a_stripe_merchant_account.htm&type=5).

1. From Business Manager, go to the Storefront.
2. Add items to your cart.
3. Checkout using multi-step checkout, Pay Now, or Buy Now (Google Pay for Chrome or Android and Apple Pay for Safari or IOS).

View the order from the storefront or from your provider's dashboard to confirm that Salesforce Payments processed the payment:

- For Adyen, view the order in the Adyen Customer Area. An Adyen Payment Service Provider (PSP) reference is listed for the order.
- For Stripe, view the order in the Stripe Dashboard. A Stripe payment intent ID is listed for the order.
