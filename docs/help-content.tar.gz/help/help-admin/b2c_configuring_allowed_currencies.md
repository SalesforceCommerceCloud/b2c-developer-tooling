# Configure Allowed Currencies in B2C Commerce

_Configure the currencies that are allowed for your site._

|  |
| --- |
| Available in: **B2C Commerce** |

1. In Business Manager, click App Launcher _(image: App Launcher)_, and then select **Merchant Tools >  *site*  > Site Preferences > Currencies.**

   The allowed currencies appear in a list. The default currency can't be deleted.
2. Select one or more currencies and sort them using the arrows on the right.

   For example, select two currencies in the middle of the list and click the bottom sort arrow to move them to the bottom of the list.
3. On the Allowed Currencies page, click **Add**.
4. On the All Currencies window, select currencies to add.
5. Click **Add**.

   The added currencies appear on the Allowed Currencies page.

## Related Content

- [Currency Precision in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_currency_precision_non_standard.htm&type=5)
  Salesforce B2C Commerce follows an international standard for supported currencies. The following currencies have a different level of precision than the standard.
