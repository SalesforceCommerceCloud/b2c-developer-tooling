# Buy Now Pay Later with Afterpay for B2C Commerce

_Afterpay is available in Salesforce Payments through your Stripe Merchant account as a Checkout payment method. With Afterpay, shoppers make payment in interest-free installments. This feature is available for B2C Commerce._

Shoppers can choose to make three monthly payments or four bi-weekly payments. Afterpay is interest-free for shoppers and doesn’t require a credit check during the sign-up process. Afterpay sets initial spending limits for new customers. Spending limits for shoppers can increase as they use Afterpay.

Salesforce Payments offers Afterpay through your Stripe Merchant account. When Afterpay is active on your storefront, the product detail page and checkout cart list Afterpay as a payment option. The option includes the pay-in-3 payment amount, the pay-in-4 payment amount, and a link to information about Afterpay.

When a shopper selects to pay with Afterpay, they’re redirected to the Afterpay authorization page. After authorizing the payment, the shopper returns to your storefront order confirmation page.

To activate Afterpay for your Salesforce Reference Architecture (SFRA) storefront, see [Manage Payment Methods for B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_manage_payment_methods.htm&type=5).

Afterpay is supported in Australia, Canada, France, New Zealand, the United Kingdom, and the United States.

These merchant categories are prohibited from using Afterpay.

- Alcohol
- Digital games and apps
- Donations
- Electronics
- Flash sales
- Pre-orders
- Travel
