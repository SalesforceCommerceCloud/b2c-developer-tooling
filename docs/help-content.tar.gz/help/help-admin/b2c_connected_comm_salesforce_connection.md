# Connect Your B2C Commerce Instance to Salesforce

_Create a trusted data exchange between B2C Commerce and a Salesforce org. By connecting your B2C Commerce instance to Salesforce, you can access agentic and cross-cloud experiences, such as Shopper Agent, Merchant Agent, Shopper Profile Sync, and Shopper Notifications._

Connecting B2C Commerce to a Salesforce org requires an Enterprise or Unlimited edition Salesforce org with a Data 360 license. To log in to the B2C Commerce instance, you need to be a Business Manager Administrator. To log in to the Salesforce org, you need to be a Salesforce Admin with the ViewSetup permission.

The B2C Commerce instance has a one-to-one relationship with the Salesforce org. A B2C Commerce production instance pairs with a Salesforce production org. All other B2C Commerce instances pair with Salesforce sandbox orgs as listed in the table.

| B2C Commerce Instance Environment | Salesforce Org Type |
| --- | --- |
| Production | Production |
| Staging | Sandbox (Full or Partial Copy) |
| Development | Sandbox (Partial Copy) |
| On-Demand SandboxTo keep the sandbox active, set the time-to-live (TTL) to 0 hours. If the TTL value is greater than 0 hours, the sandbox is deleted when it reaches the TTL value. See [Time-to-Live (TTL) for On-Demand Sandboxes](https://developer.salesforce.com/docs/commerce/b2c-commerce/guide/b2c-developer-sandboxes.html#time-to-live-ttl-for-on-demand-sandboxes). | Sandbox (Developer or Developer Pro) |

> **Important:** After you’ve connected your B2C Commerce instance to a Salesforce org, you can only disconnect it by contacting Salesforce Customer Support.

1. In the navigation sidebar, click App Launcher _(image: App Launcher)_, and then select **Administration > Global Preferences > Salesforce Connection**.
2. Click **New Connection**.

   If you’re logged in to a B2C Commerce sandbox instance, a Salesforce sandbox login page appears. If you’re logged in to a B2C Commerce production instance, a Salesforce production login page appears.
3. Log in to Salesforce.
4. When prompted, click **Allow** to authorize the connection.

After the connection is successful, the connection information appears on the Salesforce Connection page.

> **Caution:** To avoid issues with your connection, avoid refreshing the connected Salesforce sandbox org. If you refreshed your connected Salesforce sandbox org and need help repairing the connection, contact Salesforce Customer Support.

_(image: Salesforce Connection screen showing an active Salesforce connection.)_
