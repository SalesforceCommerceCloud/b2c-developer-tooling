# Connect Your B2C Commerce Instance to Salesforce

_Create a trusted data exchange between your B2C Commerce instance and a Salesforce org. This connection gives you access to agentic and cross-cloud experiences, such as Shopper Agent, Merchant Agent, Shopper Profile Sync, and Shopper Notifications._

Connecting B2C Commerce to a Salesforce org requires an Enterprise or Unlimited edition Salesforce org. To log in to the B2C Commerce instance, you must be a Business Manager Administrator. Authorizing the connection in the Salesforce org requires the System Administrator profile, or a profile or permission set with equivalent access, in that org.

The B2C Commerce instance has a one-to-one relationship with the Salesforce org. A B2C Commerce production instance pairs with a Salesforce production org. All other B2C Commerce instances pair with Salesforce sandbox orgs as listed in the table.

| B2C Commerce Instance Environment | Salesforce Org Type |
| --- | --- |
| Production | Production |
| Staging | Sandbox (Full or Partial Copy) |
| Development | Sandbox (Partial Copy) |
| On-Demand SandboxTo keep the sandbox active, set the time-to-live (TTL) to 0 hours. If the TTL value is greater than 0 hours, the sandbox is deleted when it reaches the TTL value. See [Time-to-Live (TTL) for On-Demand Sandboxes](https://developer.salesforce.com/docs/commerce/b2c-commerce/guide/b2c-developer-sandboxes.html#time-to-live-ttl-for-on-demand-sandboxes). | Sandbox (Developer or Developer Pro) |

1. In the navigation sidebar, click App Launcher _(image: App Launcher)_, and then select **Administration > Global Preferences > Salesforce Connection**.
2. Click **New Connection**.

   If you’re logged in to a B2C Commerce sandbox instance, a Salesforce sandbox login page appears. If you’re logged in to a B2C Commerce production instance, a Salesforce production login page appears.
3. Log in to Salesforce with the credentials for the org you're connecting to.

   Use the credentials that match the paired org type shown in the earlier table. If you connect your B2C Commerce development or on-demand sandbox instance to a Salesforce sandbox org, enter your Salesforce sandbox credentials rather than your Salesforce production credentials. A Salesforce sandbox org's login URL differs from a production org's URL and can include a custom domain, so confirm you're on the correct login page.
   
   If the login page prompts for your email address instead of your username (now the default login experience), use the environment-type dropdown in the upper-right corner of the page to select the correct environment before you log in.
   
   If your Salesforce org and B2C Commerce instance are in different regions, or B2C Commerce can't verify the region, an advisory message appears. Review the message and verify that your configuration meets privacy and data requirements.
4. When prompted, click **Allow** to authorize the connection.

   After connecting, the [Trust and Compliance Documentation](https://www.salesforce.com/company/legal/trust-and-compliance-documentation/) applicable to that Salesforce service applies. For assistance, contact Salesforce Customer Support.

After the connection is successful, the connection information appears on the Salesforce Connection page.

> **Caution:** To prevent issues with your connection, avoid refreshing the connected Salesforce sandbox org. If you do refresh the sandbox org and issues occur, contact Salesforce Customer Support to help repair the connection.

_(image: Salesforce Connection page showing an active Salesforce connection.)_
