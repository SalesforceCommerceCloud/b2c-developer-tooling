# Monitor B2C Commerce Job Statistics

_Monitor the duration and number of executions for B2C Commerce jobs. Filter and sort the statistics._

[Which Salesforce Commerce Product Do I Have?](https://help.salesforce.com/s/articleView?id=commerce.comm_what_product.htm)

1. From the App Launcher _(image: App Launcher)_, find and select **Administration > Operations > Job Statistics**.

   When you filter the statistics by job name or site or if you sort the statistics, the page changes immediately to reflect the filter or sort options you selected. If you select a date range, click **Filter** to refresh the page.
