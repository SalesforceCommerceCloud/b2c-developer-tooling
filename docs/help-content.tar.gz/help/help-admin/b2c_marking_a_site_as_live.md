# Mark a Site as Live in B2C Commerce

_You must mark new sites as live after support enables the option._

> **Note:** Marking a site as Live is NOT reversible and you can’t change the site back to Preview status.

For more information about disabling a live site, see [ Disable a Site in Business Manager](https://developer.salesforce.com/docs/commerce/b2c-commerce/guide/b2c-managing-sites-for-dev.html#disable-a-site-in-business-manager).

1. In Business Manager click App Launcher _(image: App Launcher)_, and then select **Adminstrator****Sites****Manage Sites.**
2. Select **Online** in the **Select the Site Status** dropdown.
3. Select **Yes**.
4. Enter the case number to confirm that you’ve followed the B2C Commerce Go-Live checklist and previously opened a Support case.

   For more information, see [Open a Go Live Ticket](https://help.salesforce.com/s/articleView?id=000391578&type=1)
5. Click **Apply**.
