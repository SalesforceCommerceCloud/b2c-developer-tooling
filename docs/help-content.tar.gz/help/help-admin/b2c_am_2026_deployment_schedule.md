# Account Manager 2026 Deployment Schedule and Release Notes Archive

_The Account Manager Deployment Schedule lists all of the planned release dates for 2026, including links to past release notes._

B2C Commerce Account Manager deployment dates are subject to change but typically take place according to the following schedule.

| Deployment Dates | Release Number | Release Notes | Deployment Time |
| --- | --- | --- | --- |
| January 14 (Wed) | 3.4 | [Account Manager 3.4](https://help.salesforce.com/s/articleView?language=en_US&id=commerce.account_manager_3_4_release.htm) in *Salesforce Help* | 6:00 UTC - 8:00 UTC |
| February 11 (Wed) | 3.5 | [Account Manager 3.5](https://help.salesforce.com/s/articleView?id=commerce.account_manager_3_5_release.htm) in *Salesforce Help* | 6:00 UTC - 8:00 UTC |
| March 11 (Wed) | 3.6 | [Account Manager 3.6](https://help.salesforce.com/s/articleView?id=release-notes.rn_account_manager_3_6.htm&release=260) in *Spring ’26 Release Notes* | 6:00 UTC - 8:00 UTC |
| April 8 (Wed) | 3.7 | [Account Manager 3.7 ](https://help.salesforce.com/s/articleView?id=release-notes.rn_account_manager_3_7.htm&release=260) in *Spring ’26 Release Notes* | 5:00 UTC - 7:00 UTC |
| May 6 (Wed) | 3.8 | [Account Manager 3.8](https://help.salesforce.com/s/articleView?id=release-notes.rn_account_manager_3_8.htm&release=260) in *Spring ’26 Release Notes* | 5:00 UTC - 7:00 UTC |
| June 3 (Wed) | 3.9 | [Account Manager 3.9](https://help.salesforce.com/s/articleView?id=release-notes.rn_account_manager_first_container.htm&release=262) in *Summer ’26 Release Notes* | 5:00 UTC - 7:00 UTC |
| July 1 (Wed) | 3.1 | [Account Manager 3.10](https://help.salesforce.com/s/articleView?id=release-notes.rn_account_manager_second_container.htm&release=262) in *Summer ’26 Release Notes* | 5:00 UTC - 7:00 UTC |
| July 29 (Wed) | 3.11 | [Account Manager 3.11](https://help.salesforce.com/s/articleView?id=release-notes.rn_account_manager_third_container.htm&release=262) in *Summer ’26 Release Notes* | 5:00 UTC - 7:00 UTC |
| August 26 (Wed) | 3.12 | [Account Manager 3.12](https://help.salesforce.com/s/articleView?id=release-notes.rn_account_manager_fourth_container.htm&release=262) in *Summer ’26 Release Notes* Release status: Account Manager 3.12 was not deployed. No changes from this release were made available to customers. No customer action is required. | 5:00 UTC - 7:00 UTC |
| September 23 (Wed) | 3.13 | [Account Manager 3.13](https://help.salesforce.com/s/articleView?id=release-notes.rn_account_manager_first_container.htm&release=264) in *Winter ’27 Release Notes* | 5:00 UTC - 7:00 UTC |
| October 21 (Wed) | 3.14 | [Account Manager 3.14](https://help.salesforce.com/s/articleView?id=release-notes.rn_account_manager_second_container.htm&release=264) in *Winter ’27 Release Notes* | 5:00 UTC - 7:00 UTC |

We update these dates as soon as we’re aware of changes.
