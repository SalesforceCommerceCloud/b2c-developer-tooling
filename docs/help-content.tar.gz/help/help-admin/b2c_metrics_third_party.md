# Third Party Service Metrics

_Third Party Service metrics help website administrators and DevOps teams monitor and analyze the performance of outgoing calls made to third-party services. These metrics help identify issues with calls, such as slow-performing calls and network errors from third-party services._

### Number of Calls

The Number of Calls metric tracks the rate of calls to each external endpoint.

Use cases:

- Monitor call rates.
- Identify spikes in call rates during incidents. Higher call rates cause more load on the remote server.

### Call Duration p95

The Call Duration metric shows the duration of outgoing calls, reporting the p95 percentile.

Use cases:

- Identify outgoing calls that are long-running.
- Troubleshoot issues caused by slow performance of outgoing calls.

### Total Remote Exceptions

The Total Remote Exceptions metric tracks the number of calls to each endpoint that resulted in a network-level error, such as a socket timeout or connection reset.

Use cases:

- Identify integration problems with third-party services.
- Investigate network-related errors that occur during outgoing calls.
