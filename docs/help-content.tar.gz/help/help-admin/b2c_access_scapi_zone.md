# Access the SCAPI Zone in Business Manager

_Open the Salesforce-managed SCAPI zone from the Production instance in Business Manager to configure supported security controls, view HTTP and security analytics, and purge cache for B2C Commerce._

[Which Salesforce Commerce Product Do I Have?](https://help.salesforce.com/s/articleView?id=commerce.comm_what_product.htm)

There's one SCAPI zone for Development, Staging, and Production. After Salesforce provisions the zone, open it from the Production instance. The zone doesn't appear in Business Manager or the CDN API on Development or Staging. For what the zone is and which controls it supports, see [SCAPI Zone Support for B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_scapi_zone.htm&type=5).

1. In Business Manager on the Production instance, click App Launcher _(image: App Launcher)_, and then select **Administration > Sites > Embedded CDN Settings**.
2. Locate the SCAPI zone by its `<shortcode>.api.commercecloud.salesforce.com` hostname.

   ### Embedded CDN Settings — SCAPI zone in the zone list
   
   _(image: Embedded CDN Settings zone list with a SCAPI zone row, its platform-managed hostname, certificate count, Configure Zone action, and 0 hostnames available.)_
3. Open the row's dropdown menu and select **Configure Zone**.

The Configure Zones screen for a SCAPI zone provides three tabs—**Crypto** (read-only), **Security Rules** (custom rules, rate limiting rules, and IP lists, with Zone and Realm sub-tabs), and **Analytics** (HTTP and Security)—plus a **Purge Cache** button. Controls that don't apply to SCAPI zones aren't shown.

## Configure Zones — Crypto tab for a SCAPI zone

_(image: Configure Zones for a SCAPI zone with Crypto, Security Rules, and Analytics tabs and a Purge Cache button. The Crypto tab shows a read-only Certificates table with hostname, certificate status, and expiry.)_
