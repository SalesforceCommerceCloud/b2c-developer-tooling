# Configuring the Business Manager Site

_Configure the Business Manager site for your B2C Commerce instance._

1. In Business Manager, click App Launcher _(image: App Launcher)_, and then select **Site****Adminstrator****Manage Sites.**

   Use the sort buttons to sort your sites. Sites appear in this order throughout the Business Manager user interface.C
2. On the Storefront Sites page, in the Business Manager section, click the **Business Manager** link.
3. On the Settings tab, specify the cartridges and the cartridge path used by your site.

   See [Registering Your Cartridge](https://developer.salesforce.com/docs/commerce/b2c-commerce/guide/b2c-cartridges.html#register-a-cartridge).
   
   The HTTP/HTTPS section has been deprecated. The preferred way to configure HTTP/HTTPS hostnames is in the site aliases configuration (SEO/Aliases Configuration). The HTTP/HTTPS hostnames values configured in this section apply if the aliases configuration is empty, and are intended only to support the deprecated configuration style.
4. Click the **Cache** tab.

   See [Configure Page Cache.](https://developer.salesforce.com/docs/commerce/b2c-commerce/guide/b2c-content-cache.html#cache-configuration)
5. Click the **Hostnames** tab.

   The Allowed Hostnames list shows the hostnames that are allowed for Business Manager. Automatically included are Salesforce-provided hostnames and configured hostname aliases. You can extend the list with up to 10 additional hostnames.
   
   > **Note:** Setting the HTTPS hostname for the Business Manager site causes multiple features to *only* work using that hostname.
   
   1. Enter a new hostname.
   2. Click **Apply**.
