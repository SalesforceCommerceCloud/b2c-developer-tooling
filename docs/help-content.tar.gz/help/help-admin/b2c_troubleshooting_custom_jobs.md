# Job Alerts for B2C Commerce Custom Jobs

_Job alerts are Business Manager warnings that a custom job can slow the storefront or export orders out of sync. An alert applies to a job you create, not to one job step._

[Which Salesforce Commerce Product Do I Have?](https://help.salesforce.com/s/articleView?id=commerce.comm_what_product.htm)

These alerts appear in the Alerts section of the Business Manager homepage and in the header. Click the bell icon in the upper-right corner, and then select **Show All**. Select the alert to open Jobs.

Before you can set job alerts, create the job and add its flows and steps. See [Create and Schedule a B2C Commerce Job](https://help.salesforce.com/s/articleView?id=cc.b2c_create_job.htm&type=5) and [Add Flows and Steps for B2C Commerce Jobs](https://help.salesforce.com/s/articleView?id=cc.b2c_add_job_flows_and_steps.htm&type=5).

### B2C Commerce One Order per Transaction

A custom job can change only one order per transaction, or scalability issues can occur. Review your custom jobs. Review the source code in your custom job script to make sure that the custom job changes only one order per transaction.

Example: Your code modifies multiple orders in a transaction.

```
var order1 = OrderMgr.getOrder(parameters.orderNo1 ); 
var order2 = OrderMgr.getOrder(parameters.orderNo2 ); 
Transaction.wrap(function() { 
   order1.setExternalOrderText(aValueToBeSet);
   order2.setExternalOrderText(aValueToBeSet); 
});
```

Change your code to only modify one order per transaction.

```
var order1 = OrderMgr.getOrder(parameters.orderNo1 ); 
var order2 = OrderMgr.getOrder(parameters.orderNo2 ); 
Transaction.wrap(function() { 
   order1.setExternalOrderText(aValueToBeSet); 
});
Transaction.wrap(function() {
   order2.setExternalOrderText(aValueToBeSet); 
});
```

Small transactions on the order object reduce the internal locking time and increase throughput for the order data structures. This approach improves performance and scaling in your storefront. Potential optimistic locking exceptions are reduced to a single order. The shorter internal locking time reduces the likelihood of running into optimistic locking issues.

### B2C Commerce Order Export Alert

In B2C Commerce, this alert means order export data can be out of sync or exported twice because another process changed the order.

Alert: Because of concurrent modification by another process, order export data can be out of sync or exported twice.

Review your log messages and order export process to see if another process is modifying the order. To minimize the risk of another process modifying orders during export, delay order exports. For more information, see [Delay Order Exports for B2C Stores](https://help.salesforce.com/s/articleView?id=cc.b2c_delaying_orders.htm&type=5).
