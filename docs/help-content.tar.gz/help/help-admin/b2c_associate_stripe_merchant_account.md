# Associate a Stripe Merchant Account with Your B2C Commerce Instance Commerce

_To use Salesforce Payments with Stripe, create a Stripe merchant account directly from your B2C Commerce instance. You can also use a Stripe merchant account that’s already associated with a B2C Commerce instance._

|  |
| --- |
| Available in: **B2C Commerce** |

Prerequisites:

- To enable Salesforce Payments, contact Salesforce Customer Support.

1. In Business Manager, click App Launcher _(image: App Launcher)_, and then select **Administration > Site > Global Preferences > Salesforce Payments**.
2. Click **Add Account**.
3. Click **Stripe** and then click **Next**.
4. (Optional) Create a new merchant account.

   1. Select the country where the account-holding organization resides or where the business is legally established.
   2. Click **Add**.
5. (Optional) Add an existing merchant account.

   If you previously created a Stripe merchant account, associate the account with other B2C Commerce instances.
   
   1. Enter your merchant account ID, which you can find on your Stripe account details page.
   2. Click **Next**.
   3. Click **Verify Now**.
   
      A new tab opens on the Stripe site where a test transaction is created.
   4. To verify the account, on the Stripe site, click **Capture**.
   5. Return to Business Manager, and in the Add Merchant Account window, Click **Add**.
