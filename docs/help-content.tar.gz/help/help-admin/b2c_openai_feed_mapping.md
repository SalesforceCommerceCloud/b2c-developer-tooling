# Map Product Fields for OpenAI

_Configure how B2C Commerce product attributes map to OpenAI feed fields using the field mapping interface._

Before you configure field mappings, ensure that the OpenAI integration is set up for your site:

- [Configure Catalog and Order Feeds for Einstein](https://help.salesforce.com/s/articleView?id=cc.b2c_openai_feed_configure_einstein.htm&type=5)
- [Meet the Prerequisites](https://help.salesforce.com/s/articleView?id=cc.b2c_openai_feed_prerequisites.htm&type=5)
- [Connect to OpenAI](https://help.salesforce.com/s/articleView?id=cc.b2c_openai_feed_connect.htm&type=5)

The field mapping interface shows all OpenAI feed fields, their default mappings, and allows you to override mappings with different B2C Commerce attributes. Fields are organized into the following categories:

- **Required fields**: Require a mapping to generate a valid feed.
- **Optional fields**: Enhance product data but aren't required.
- **Non-overridable fields**: System-managed fields that are visible in the Field Mapping table but can't be changed. Example: **availability**.

By default, the system applies smart mappings to map B2C Commerce standard attributes to OpenAI fields. Override these defaults with different standard attributes or custom attributes from your catalog as needed.

Not every field has a default mapping. Default mappings are created when the system can derive the value using standard B2C Commerce attributes.

You can override a default mapping in three ways:

- **Map to a different attribute**: Select a B2C Commerce standard attribute or custom attribute whose type matches the OpenAI field's type. The system uses the attribute's value for each product.
- **Set a constant value**: Enter a fixed value, such as your brand name or a return-policy URL, that the system uses for every product in the feed.
- **Set a pattern**: Enter a pattern that resolves to a different value for each product, such as a URL template that includes the product ID. Use a pattern when the value depends on per-product data but isn't already stored in a single attribute.

> **Tip:** To preview your product data before generating the feed, go to **Products and Catalogs > Product List** and create a custom view that includes the attributes you plan to map. This helps you verify that your products have the expected values for those attributes.

1. Click App Launcher _(image: App Launcher)_, and then select **Merchant Tools > Site > AI & Social Integrations > OpenAI**.
2. Click **Catalog**.

   In the Field Mapping section, the table displays the following columns:
   
   - **Channel Field**: The OpenAI feed field name.
   - **SFCC Field**: The mapped B2C Commerce attribute (shows "Default Mapping" if using the default).
   - **Action**: An **Override** button to override a field's default mapping, and a **Reset** button to restore the field's default mappings.
   - **Required**: Indicates whether the field is required by OpenAI.
   - **Example**: Shows a sample value for the channel field.
   
   > **Note:** Fields that are required but don't have a default mapping are highlighted in red with a warning icon. You must configure these fields before the system can generate the feed.
3. (Optional) To find a specific field, type a value in the **Search** field.
4. (Optional) Click **Filter by Priority** to select a filter value (All, Required, or Optional) to control which fields are listed.
5. To override a default mapping, click **Override** next to the field.

   1. To map to a different attribute, in the dropdown, select a B2C Commerce attribute to map to this field.
   
      The list shows product attributes whose type matches the OpenAI field's type. It includes both standard product attributes and custom attributes defined in your catalog.
   2. To use a fixed value or a per-product pattern, click **Override with constant value or pattern** and enter the value or pattern.
   
      Use a constant value when every product in the feed should have the same value, such as a return-policy URL. Use a pattern when the value depends on per-product data but isn't stored in a single attribute, such as a URL template that includes the product ID.
6. To reset a field to its default mapping, click **Reset** next to the field.

The system saves your field mapping overrides. The next time the system generates the feed, it uses your configured mappings.

> **Note:** Common overrides include mapping **description** to **longDescription** for more detailed text, mapping **brand** to **manufacturer**, setting **seller_url** and **return_policy** to constant URLs, and overriding **is_eligible_search** with a custom boolean attribute (such as `c_chatGPT_eligible`) to gate search discoverability per product.
