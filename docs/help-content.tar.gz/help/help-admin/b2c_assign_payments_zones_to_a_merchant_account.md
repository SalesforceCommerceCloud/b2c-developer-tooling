# Assign Payment Zones to a Merchant Account for B2C Commerce

_Assign one or more payment zones to your merchant accounts. The default payment zone, set to all currencies and countries, is assigned to the first merchant account you create. Assign more payment zones to your merchant accounts to further customize which payment methods can be used for which zones._

1. To assign a payment zone to a merchant account from the Payment Zone page:

   1. In Business Manager, click App Launcher _(image: App Launcher)_, and then select **Administration > Site > Global Preferences > Payment Zones**.
   2. From the actions menu for your payment zone, select **Manage Merchant Accounts**.
   3. Select a payment gateway and a merchant account.
   4. (Optional) Configure PayPal as a secondary payment gateway.
   5. Click **Save**.
2. To assign a payment zone to a merchant account from the Salesforce Payments page:

   1. In Business Manager, click App Launcher _(image: App Launcher)_, and then select **Administration > Site > Global Preferences > Salesforce Payments**.
   2. Click the merchant account that you want to assign a payment zone to.
   3. In the Payment Zone section, click **Assign**.
   4. Select at least one payment zone and click **Assign**.
   
      If you don’t have any payment zones, click Create a new payment zone to [Create a Payment Zone for B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_create_a_payments_zone.htm&type=5) and add one to your account.
