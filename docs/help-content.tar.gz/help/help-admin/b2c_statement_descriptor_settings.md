# Statement Descriptor Settings for B2C Commerce

_A statement descriptor provides banks and credit card networks with a description of the credit card transaction charge. Salesforce Payments adds the description to the shopper’s bank or card statement to identify the source of the charge. When shoppers know the origin of a charge, it reduces payment disputes and chargeback requests. Salesforce Payments supports three statement descriptor settings._

### Stripe Shortened Descriptor

Your Salesforce Payments Stripe account supports using the Stripe shortened descriptor. You enter a value for the shortened descriptor on your Stripe dashboard. Commerce Payments uses the shortened descriptor as the statement_descriptor value in the Stripe Payment Intents API. When a shopper completes a credit card transaction, Commerce Payments passes the statement descriptor value to the shopper’s bank or card network. With this method, you can’t have site-specific descriptors for sites in your realm that use the same Stripe merchant account ID.

Some applications of Stripe use the Stripe shortened (prefix) value and the dynamic (suffix) value to generate dynamic statement descriptors. Salesforce Payments doesn’t support the Stripe dynamic (suffix) value as a site level descriptor.

### Site-Specific Descriptor

Use a site-specific customer statement descriptor to identify the site where a charge originated. In Business Manager, you can set a different descriptor for each site across your realm. The Business Manager descriptor overrides the Stripe statement_descriptor value. The site-specific descriptor value is used in the Stripe Payment Intents API and is passed to the shopper’s bank or card network.

### Per Transaction Descriptor

Use the Script API to set the statement descriptor for per payment applications, for example, if you want to add more detail to the description. The statement descriptor value set in the Script API overrides the descriptor value set in the Stripe dashboard and Business Manager.

## Related Content

- [Set the Customer Statement Descriptor for B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_set_customer_statement_descriptor.htm&type=5)
  Customize the description that appears on a customer’s statement to identify the source of the charge. Use different text for each site in your realm. When shoppers know the origin of a charge, it reduces payment disputes and chargeback requests.
