# View Orders Captured During Omnichannel Inventory Downtime

_To monitor the progress after reconciliation, view and track the B2C Commerce Continuous Order Capture orders captured during the Omnichannel Inventory offline mode._

1. Click App Launcher _(image: App Launcher)_, and then go to **Business Manager > Ordering > Orders**.
2. Click the **Advanced Search** tab.
3. Set the Integration State filter to **Reservation Missing**.
4. To view the history, click an order and then click the **History** tab.

Orders with the prefix `Continuous Order Capture` indicate offline, reserved, and partial or failed orders.
