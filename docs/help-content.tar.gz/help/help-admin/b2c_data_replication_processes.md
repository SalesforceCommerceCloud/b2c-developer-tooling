# Data Replication Processes in B2C Commerce

_Each data replication process copies data, metadata, and files or reverts the most recent data replication copy. This topic applies to B2C Commerce._

> **Note:** You can't use replication to copy data from staging to a developer sandbox. To populate a developer sandbox with data, export the data from staging and then import it to the sandbox.

Data replication functions at two levels:

- Global replication includes configuration information and data that applies to your entire organization.
- Site-level replication includes data belonging to one or more specified sites (such as product and catalog data, XML-based content components, and image files).

When you create a PIG, run a full global replication to each target instance before running any site replications to it.

Subsequent replication processes can include global data, site-level data, or a combination. To configure which data is included, select specific replication tasks. Review the tasks to understand the granularity at which different types of data are replicated. For example, replicate a single catalog, but you can't replicate only a specific product. Partial data replication is useful in cases such as the following.

- After preparing a new promotion, you roll out new promotion definitions, text, graphics, and coupons to the storefront.
- You update your storefront home page design with seasonal messages.
- Product prices change, so you implement new price books.

When you replicate data, the data you select replaces the corresponding data on the target instance. For example, your staging and development instances both include catalogs A, B, and C. On your staging instance, you update catalog B, delete catalog C, and add catalog D. Replicating catalogs from staging to development updates your development instance as follows:

- Catalog A is unaffected.
- Catalog B is updated.
- Catalog C is deleted.
- Catalog D is added.

> **Note:** Only the data selected for replication is overwritten on the target instance. Other data is not affected. Considering the previous example, replicating data other than catalogs wouldn’t affect catalogs A, B, and C, and wouldn’t add catalog D.

### What Data Replication Doesn’t Include

You can't replicate the following data. Instead, create or import it in development and production instances.

- Active data
- Batch processes
- Catalog and content import feeds
- Custom error pages
- Customers and customer group assignments
- Files that are uploaded but not imported
- Gift certificates
- Inventory data
- Job schedules and history
- Organization profile
- Payment information
- Order information (for example, tax and shipping)
- Sitemaps
- Source Code redemptions
- Users, roles, and permissions

### Data Replication Process Types

Data replication is a two-step process. First, data is transferred from staging to the target instance, then it’s published on the target instance. Run both steps as a single replication process, or run them separately. Running them separately can help you identify the source of any failures that occur.

There are four types of data replication processes.

> **Note:** You run all replication processes on the staging instance, even Publishing and Undo, which only affect the target instance.

| Replication Type | Description |
| --- | --- |
| Transfer | The selected data on the source instance is transferred to the target instance, but does not replace or affect the current data on the target. To update data on the target instance, run a replication process of type Publishing after the Transfer replication. |
| Transfer & Publishing | The selected data on the source instance is replicated to the target instance and immediately replaces the existing data. |
| Publishing | This process is available only after a successful Transfer process. Publishing replaces the existing data on the target instance with the previously transferred data. The replication tasks in the Publishing process must exactly match the tasks in the Transfer process. You can’t transfer data and then publish only some of it. If any of the transferred data no longer exists on the target, then the replication process fails. When you run a Publishing replication process, disable incremental indexing when you run a Publishing replication process. |
| Undo | This process is available only after a successful Transfer & Publishing or Publishing replication process. It reverts the target instance to the data that existed there before the last replication process. The undo action is no longer available for data replication processes which run prior to a GA Release. For example, a process on 24.7 cannot be undone on 24.8. This does not apply to GA Updates. For example, 24.8.1 to 24.8.2. |
