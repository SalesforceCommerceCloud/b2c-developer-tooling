# Install a Commerce App for B2C Commerce

_Install and configure a Commerce app in Business Manager to add domain functionality to your Storefront Next site._

1. Set up Storefront Next.

   1. To create a storefront with a GitHub repository, see [Create Storefront Next in Business Manager with a GitHub Repository](https://developer.salesforce.com/docs/commerce/sfnext/guide/sfnext-quick-start-create-bm-github.html).
   2. To create a storefront with local code, see [Create Storefront Next in Business Manager with Local Code](https://developer.salesforce.com/docs/commerce/sfnext/guide/sfnext-quick-start-create-bm.html). If you create a storefront with local code, Salesforce can’t automate pull requests against your storefront repository when you install a Commerce app.
2. Install a Commerce app.

   1. In Business Manager, click App Launcher _(image: App Launcher)_, and then select **Merchant Tools > Site > Commerce Apps > App Catalog**.
   2. Click **Browse All Apps**.
   3. Find the app that you want to use and click **Install**.
   
   After you install a Commerce app, Salesforce creates a pull request in your storefront’s repository.
3. To make sure that your storefront includes all the relevant app extensions, review, test, and merge the pull request.
4. Configure the app.

   For:
   
   - Approaching Discounts, see [Create a Promotion in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_creating_a_promotion.htm).
   - Basic Shipping, see [Manage Shipping Methods in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_managing_shipping_methods.htm).
   - Commerce Delivery Service, see [Configure Commerce Delivery Service for B2C Commerce](https://help.salesforce.com/s/articleView?id=commerce.om_configure_commerce_delivery_service.htm).
   - Custom apps, see [Salesforce Developer Documentation](https://developer.salesforce.com/docs/commerce/b2c-commerce/guide/developer-workflow.html).
   - Partner apps, see your provider’s documentation.
   - Salesforce Flat Tax, see [Manage Taxes in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_managing_taxes.htm).
   - Salesforce Payments, see [Set Up Salesforce Payments for B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_setting_up_salesforce_payments.htm).
5. Choose where app components appear on your storefront.

   See [Customize Where Commerce App Components Appear on Your B2C Storefront](https://help.salesforce.com/s/articleView?id=cc.b2c_commerce_app_storefront_display.htm).
