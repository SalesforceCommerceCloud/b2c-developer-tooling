# How Notification Channels Respond to Alert States

_How a notification channel in B2C Commerce responds to an alert is based on the alert state. An anomaly detection alert fires once when an anomaly is detected and doesn’t track whether a condition persists or is cleared._

| State | Meaning | Notification Channel Actions |
| --- | --- | --- |
| New | The system detects the alert condition for the first time. | Sends an email notification.  Posts a message to the configured Slack channel. Triggers a new incident in PagerDuty. |
| Ongoing | The alert condition remains active during subsequent system checks. | Sends a follow-up email notification.  Posts an update to the Slack channel. Doesn’t create a duplicate incident in PagerDuty by using the deduplication key. |
| Resolved | The alert condition clears because log hits fall below your configured threshold. | Sends a resolution email notification. Posts a resolution message to the Slack channel. Closes the corresponding PagerDuty incident. |
