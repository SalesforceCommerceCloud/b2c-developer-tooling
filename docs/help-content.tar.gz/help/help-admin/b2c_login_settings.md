# Configure Login Settings for B2C Commerce

_In Business Manager, it's important to configure user password restrictions and login lockout policies._

All the possible values make sure compliance with the Payment Card Industry Data Security Standard (PCI DSS). As part of Unified Authentication, Account Manager manages all the password policies. See [Edit an Organization in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_account_manager_edit_organization.htm&language=en_US&type=5) for details.

|  |
| --- |
| Available in: **B2C Commerce** |

To comply with the PCI DSS standards, Business Manager logs users out after 15 minutes of inactivity. You can't change this timeout value.

1. In Business Manager click App Launcher _(image: App Launcher)_, and then select **Administration > Global Preferences > Security**.
2. On the User Authentication tab, configure how many times a user can enter an incorrect login before B2C Commerce locks them out, and for how long. Both the max and the default value is six.

   By default, B2C Commerce locks the user out for 30 minutes. If you select **Forever**, the account remains locked.
3. Set the number of days after which a user is required to change their password. The default is 60 days.
4. Set the number of days before B2C Commerce deactivates an unused account. The default is 90 days.

   Seven days before deactivation, the user is sent an email, instructing them to log in to their account to avoid deactivation. The user is sent a second email one day before deactivation.
   
   If you choose less than 10 days of inactivity, the first email is sent three days before deactivation instead of seven.
5. Indicate whether a user is required to answer a security question to change their password.
6. For Enforce Password History, specify how many passwords from a user's password history B2C Commerce remembers.

   B2C Commerce checks each new password against this history to make sure the user is using a unique password. The default is to remember four passwords.
   
   Password history isn't saved until you set this value.
7. Configure the character requirement settings for passwords. See Business Manager Password Protection for limits and default values.
8. Click **Apply**.
