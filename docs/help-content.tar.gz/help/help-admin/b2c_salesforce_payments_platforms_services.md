# Salesforce Payment Platforms and Services for B2C Commerce

_Salesforce Payments supports these Payment Service Providers (PSPs) and payment methods for B2C Commerce._

|  |
| --- |
| Available in: **B2C Commerce** |

| Payment Service Provider | Payment Methods |
| --- | --- |
| Adyen | Afterpay Apple Pay Bancontact Credit cards Google Pay IDEAL Klarna SEPA debit TWINT |
| Stripe | Afterpay Amazon Pay Apple Pay Bancontact Credit cards EPS (only supported with plugin_commercepayments) Google Pay IDEAL Klarna SEPA debit |
| PayPal | PayPal Venmo |
