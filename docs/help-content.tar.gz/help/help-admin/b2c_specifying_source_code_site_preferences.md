# Specify Source Code Site Preferences

_Merchants use source codes to track customer activity and the source of incoming visits to a storefront. Salesforce B2C Commerce source-code groups enable you to use this information to manage such things as customer redirects, price books, and campaigns. Specify how you want B2C Commerce to handle source codes via site preferences._

1. In Business Manager, click App Launcher _(image: App Launcher)_, and then select **Merchant Tools >  *site*  > Site Preferences > Source Codes.**
2. On the Source Code Preferences page, define defaults for handling source code preferences. For example, specify cookie duration, a standard redirect URL, and defaults for active and inactive redirects. Specify the following settings:

   | Option | Description |
   | --- | --- |
   | URL Parameter Name | The name of the source-code parameter on the URL query string. |
   | Cookie Duration in Days | The number of days the source code is kept in a user's session (must be a number between zero and 999.) This parameter is overridden if a cookie duration is specified for a specific source code group |
   | Standard Redirect URL | Used for redirect handling, this parameter appears on the Codes tab of the source-code group, with the specified source-code specification appended. You also specify this URL in the SEO section, where you map this URL to the actual redirect URL.See the following example. |
   | Active and Inactive Redirect Defaults | Valid values are:   Home Page: URL for the home page   Category: Category ID   URL: Specific URL |
   
   Standard Redirect URL example
   
   Supply 'www.garden.com' in this field, and select **Default** for the redirect of the GARDEN source-code group. If you supply this value, this URL appears on the Codes page for the GARDEN source-code group. The URL appears in the Redirect URL field for all source-code specifications within that source-code group, with their individual source-code specification appended:
   
   | Source-Code Specification | Redirect URL |
   | --- | --- |
   | GARDENSPR | http://www.garden.com?src=GARDENSPR* |
   | GARDEN | http://www.garden.com?src=GARDEN |

To redirect customers using the *default* URL:

1. Enable storefront URLs (legacy SEO URLs), by selecting **Merchant Tools > *site* > Site Preferences > Storefront URLs.**
2. To define URL rules, select **Merchant Tools > *site* > SEO > URL Rules** (Search Support Preferences page.)
3. To specify URL redirects, select **Merchant Tools > *site* > SEO > URL Redirects.**
