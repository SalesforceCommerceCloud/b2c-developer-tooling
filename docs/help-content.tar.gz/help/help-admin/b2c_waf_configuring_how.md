# Modify eCDN WAF Settings

_The eCDN Web Application Firewall (WAF) analyzes and interprets your HTTP/s traffic to protect your B2C Commerce storefront. WAF stops application level attacks that attempt to exploit code-level vulnerabilities. Configure the security sensitivity level, and decide what action WAF takes when a suspicious web request attempts to access your storefront._

Prerequisite—Add a hostname to the embedded Content Delivery Network (eCDN), and create a zone, before configuring the WAF settings.

> **Note:** WAF is enabled by default when you create new Proxy Zones. The default settings provide a sensitivity mode of “Low” and an action of “Challenge”.

To modify eCDN WAF settings:

1. In Business Manager, click App Launcher _(image: App Launcher)_, and then select **Administration > Sites > Embedded CDN Settings**.
2. Select a zone.
3. On the WAF tab, select (check) **Enabled** to enable WAF (the default for new Proxy Zones) or deselect (uncheck) **Enabled** to disable WAF for the zone.
4. From the Action dropdown list, select an action.

   - **Simulate**—Logs the event without blocking or challenging the web request.
      
      > **Note:** For first-time users, we recommend using this mode for at least a week to analyze your incoming traffic. Review the log files to then determine an appropriate action and sensitivity level.
   - **Challenge**—If the incoming web request is suspicious, a Completely Automated Public Turing test to tell Computers and Humans Apart (CAPTCHA) challenge response is required before proceeding.
   - **Block**—Stop the request from reaching your server.
5. From the Sensitivity dropdown list, select a **sensitivity level**.

   WAF becomes more suspicious (likely blocks more requests), when sensitivity is set to a higher level. Conversely, WAF becomes less suspicious (likely lets more traffic through), when sensitivity is set to a lower level. We typically recommend using a medium or high sensitivity setting. However, based on your log analysis, you can raise or lower the sensitivity level. These adjustments enable you to manage when WAF detects too many real shoppers as bad actors, or you aren’t adequately detecting bad actors.
   
   > **Note:** Selecting the **Off** option disables the OWASP rule set.
   
   HTTP Requests
   
   - **Low**—Threat score of 60 and higher
   - **Medium**—Threat score of 40 and higher
   - **High**—Threat score of 25 and higher
   
   Ajax Requests
   
   - **Low**—Threat score of 120 and higher
   - **Medium**—Threat score of 80 and higher
   - **High**—Threat score of 65 and higher
6. For one or more dates, select a **Time** (All times are based on local browser times) and click **Request Log**.

   When the log file is available for download, an email is sent to your Business Manager email account with a link. Download the log to analyze your traffic and adjust the sensitivity accordingly.
