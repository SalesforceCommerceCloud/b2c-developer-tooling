# SiteGenesis CSS Modifications for Salesforce Payments

_CSS styling is a critical element of B2C Commerce SiteGenesis page layout, and definitions._

Form Modifications

- `shippingaddress.xml`
- Skin multi-step checkout to have the same border color as SiteGenesis
- Skin the multi-step checkout error element that shows for example, card declined
- Fix the PayPal button z-index issue
- Set express checkout button widths in mini cart
- Change to horizontal button layout for express checkout in product pages

> **Note:** SiteGenesis supports styling site components with basic CSS. If your site uses a custom user experience and branding, simple CSS doesn't always support a custom experience. The CSS modifications represented in these samples show only simple style changes.
