# Global Preferences for B2C Commerce

_Configure global preferences for the entire organization, and sometimes, override those preferences at the site level. Global preferences include setting the time zone, locale, and sequence numbers for a site. This topic applies to B2C Commerce._

## Related Content

- [Configure Organization Locales for B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_configuring_organization_locales.htm&type=5)
  Salesforce B2C Commerce is structured as an organization containing one or more sites (storefronts). Define localization settings for both entities.

- [Cross Cloud Trust for B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_cross_cloud_trust.htm&type=5)
  Tenant groups enable easy configuration and trust setup across clouds and services. A Salesforce super tenant can add a B2C Commerce realm as a member of its tenant group. Members of a tenant group can share data among themselves without requiring configuration of various one-way trust relationships. This simplifies creation of data sharing policies. An anchor tenant creates a tenant group. For B2C Commerce, the anchor tenant is always a Salesforce tenant and is called as a super tenant. The super tenant owns the tenant group and its memberships. Creation of supertenant and tenant groups is done in Salesforce. Salesforce is also responsible for adding or removing members from the tenant group. Salesforce initiates a two-way handshake with B2C Commerce to add it to a tenant group. This two-way handshake involves the B2C Commerce cross-cloud tenant group provisioning service. Each B2C Commerce tenant can be a member of only one tenant group.

- [Security Settings for B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_security.htm&type=5)
  Configure Business Manager security settings. Configuring login settings only applies to accounts that haven't migrated to unified authentication. Unified authentication links the login of all Business Manager instances to the Account Manage login. As of 19.5, all new instances are linked to the Account Manager login.

- [Migration to Unified Authentication Via Account Manager](https://help.salesforce.com/s/articleView?id=cc.b2c_unified_login_via_account_manager.htm&type=5)
  When you migrate to unified authentication, your users can log in to their Business Manager instances through Account Manager. Unified authentication streamlines the login process. Users receive a single set of login credentials to access all Business Manager instances. As a result, your users have fewer credentials to remember. This applies for administrators who are manually migrating users to unified authentication. This doesn’t apply to administers who started using B2C Commerce after October of 2019 because their organizations automatically use unified authentication.

- [Configure Page Meta Tags in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_configuring_page_meta_tags.htm&type=5)
  Create page meta tags, which can be used within catalogs and libraries to create rule base page meta tag content.

- [Manage Sequence Numbers in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_managing_sequence_numbers.htm&type=5)
  Salesforce B2C Commerce uses sequence numbers as unique identifiers for automatically generated object instances.

- [Configure Retention Settings for B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_configuring_retention_settings.htm&type=5)
  Configure the lifetime of inventory and product price records that no longer reference products. You can also configure the lifetime for lists created by anonymous shoppers to retain this information for a longer time period. This information is typically for wish lists and gift registries.

- [Site Time Zone for B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_site_time_zone.htm&type=5)
  Use Business Manager to set the time zone for interactions with users, per site.

- [Site Brand and Billing Entity in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_site_brand_and_billing_entity.htm&type=5)
  Use Business Manager to set the site brand and billing entity, so you can analyze GMV reports.

- [Set Instance Time Zone in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_instance_time_zone.htm&type=5)
  Set the time zone for tasks that aren’t site-specific.

- [Configure OAuth2 Providers for B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_configuring_oauth2_providers.htm&type=5)
  Use Business Manager to configure OAuth2 providers, but you must first register your site with your selected providers.

- [Create Global Custom Preferences for B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_creating_global_custom_preferences.htm&type=5)
  In Salesforce B2C Commerce, you can create global custom preferences, and then view and edit them. Custom preferences enable organization developers to make properties of the system modules configurable in Business Manager.

- [Set Feature Switches (Toggles) in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_feature_switches.htm&type=5)
  Salesforce B2C Commerce sometimes introduces new features that are disabled by default, because they can disrupt your existing sites.
