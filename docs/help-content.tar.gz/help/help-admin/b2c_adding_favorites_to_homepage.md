# Add Favorites to Business Manager

_To make your work faster and more efficient, save B2C Commerce Business Manager modules as favorites. Add up to 20 site-specific or global modules to the Business Manager home page. Site-specific modules are only available for the selected site._

1. In Business Manager, select a site.
2. Click **Add your favorite Business Manager modules to your homepage.**
3. Select up to 20 modules from the list. Only the modules that you have permission to access appear.
4. Click **Apply**.
5. Return to the home page to see your new favorites displayed in the Favorites section.
6. To change your favorites, click the edit icon in the Favorites section.
