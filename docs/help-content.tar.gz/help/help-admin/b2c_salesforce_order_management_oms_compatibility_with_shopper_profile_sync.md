# Salesforce Order Management (OMS) Compatibility with Shopper Profile Sync

_Shopper Profile Sync is compatible out of the box with Salesforce Order Management System (OMS). When both features are enabled, they work together to maintain a single source of truth for shopper identities._

- **Shared Duplication Rules:** Both Shopper Profile Sync and OMS use the same duplicate rules when creating person accounts in the Salesforce org. OMS logic prioritizes matching based on the explicit B2C Commerce identifiers (CommerceCustomerReference and CommerceOrganizationReference). If an exact system match isn't found, the system falls back to standard duplicate rules (such as matching by email or name), ensuring both systems consistently deduplicate against the same person account record.

### OMS Shopper Provisioning

During order ingestion, if a shopper doesn't exist in the Salesforce org, OMS provisions a new person account. As part of this provisioning, OMS automatically populates the necessary sync reference fields—customerId, realmId, and customerListId—which map directly to CommerceCustomerReference, CommerceOrganizationReference, and CommerceGroupReference. This guarantees that shoppers created by OMS can later be recognized and synchronized by B2C Commerce via Change Data Capture (CDC) events.
