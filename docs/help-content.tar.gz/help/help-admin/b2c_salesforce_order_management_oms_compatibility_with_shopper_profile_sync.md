# Salesforce Order Management (OMS) Compatibility with Shopper Profile Sync

_B2C Commerce Shopper Profile Sync is compatible out of the box with Salesforce Order Management System (OMS). When both features are enabled, they work together to maintain a single source of truth for shopper identities._

- **Shared Duplication Rules:** Both Shopper Profile Sync and OMS use the same duplicate rules when creating person accounts in the Salesforce org. OMS logic prioritizes matching based on the explicit B2C Commerce identifiers (CommerceCustomerReference and CommerceOrganizationReference). If an exact system match isn't found, the system falls back to standard duplicate rules (such as matching by email or name), ensuring both systems consistently deduplicate against the same person account record.

### Turn On B2C Integration Data Matching Rules

For OMS to use your org's matching and duplicate rules when it identifies shoppers during order ingestion, turn on the **B2C Integration Data Matching Rules** option in your connected Salesforce org. When this option is inactive, Order Management identifies an existing shopper by matching only the shopper's name or email address, which can result in duplicate person accounts.

1. From **Setup**, in the **Quick Find** box, enter `Order Management`, and then select **Order Management**.
2. Switch the **B2C Integration Data Matching Rules** option to **Active**.

> **Note:** This option applies only when the matching rules and their associated person account duplicate rules are active. To set up these rules, see [Set Up Person Account Duplicate Rules for Shopper Profile Sync](https://help.salesforce.com/s/articleView?id=cc.b2c_set_up_person_account_duplicate_rules_for_shopper_profile_sync.htm&type=5).

### OMS Shopper Provisioning

During order ingestion, if a shopper doesn't exist in the Salesforce org, OMS provisions a new person account. As part of this provisioning, OMS automatically populates the necessary sync reference fields—customerId, realmId, and customerListId—which map directly to CommerceCustomerReference, CommerceOrganizationReference, and CommerceGroupReference. This guarantees that shoppers created by OMS can later be recognized and synchronized by B2C Commerce via Change Data Capture (CDC) events.

### Permission Set Updates When Turning On Shopper Profile Sync

When you turn on Shopper Profile Sync in an org that already has OMS turned on, Salesforce automatically grants Read/Write field-level security on the Order Management B2C Service permission set for these three Account fields:

- CommerceCustomerReference
- CommerceGroupReference
- CommerceOrganizationReference

> **Important:** If your org uses a CI/CD pipeline to deploy permission sets from source control, those deployments can overwrite the automatic field-level security grants and prevent B2C Commerce from synchronizing shopper profiles with OMS. To prevent this, ensure that your source-controlled version of the Order Management B2C Service permission set includes Read/Write access to CommerceCustomerReference, CommerceGroupReference, and CommerceOrganizationReference.
