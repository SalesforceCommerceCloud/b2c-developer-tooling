# Prerequisites for OpenAI Product Feed Integration

_Before configuring the OpenAI product feed integration, ensure your site meets the requirements. Salesforce provides the SFTP credentials, which you enter in Business Manager to connect._

### Site Requirements

Verify that your B2C Commerce site meets these requirements before using the OpenAI product feed integration:

- **Locale**: The site has `en_US` configured as one of its locales. The locale doesn't need to be the site default, but the site must have `en_US` configured. If `en_US` isn't the site default locale, turn on the **Multi-Locale** option in the Einstein configuration.
- **Currency**: The site has `USD` configured as one of its currencies. The currency doesn't need to be the site default.

### Supported Storefronts

The OpenAI product feed integration supports the following storefront architectures:

- SFRA (Storefront Reference Architecture)
- SiteGenesis
- PWA Kit
- Headless storefronts

If you use PWA Kit or a headless storefront, configure a URL pattern so the feed includes the correct product detail page URL for each product. See [b2c_openai_feed_pwa_urls.xml](https://help.salesforce.com/s/articleView?id=cc.b2c_openai_feed_pwa_urls.htm&type=5).

### SFTP Credentials

Salesforce provides SFTP credentials. You don't need to obtain SFTP credentials from the OpenAI Merchant Center. Enter the credentials in Business Manager to connect. See [b2c_openai_feed_connect.xml](https://help.salesforce.com/s/articleView?id=cc.b2c_openai_feed_connect.htm&type=5).

> **Restriction:** SFTP credentials can be entered only on production instances, and the daily feed sync runs only on production. You can configure General Settings (other than SFTP), field mappings, product filter rules, and the feed preview on any non-production instance—development, staging, or sandbox.

If you turn on the feed using the SFTP credentials that Salesforce provides, the system automatically uploads the feed to OpenAI after generation. See [b2c_openai_feed_enable.xml](https://help.salesforce.com/s/articleView?id=cc.b2c_openai_feed_enable.htm&type=5).
