# Automating File Transfer Through Scripts in B2C Commerce

_Use B2C Commerce scripts to pull files into the cartridge._

External systems, such as inventory or ordering systems, can use the WebDAV interface to upload and download files using the following format:

`https://<instance>/on/demandware.servlet/​webdav/​<organization>​/Impex/src.`

The WebDAV interface supports binary files (plain XML) and compressed files.

## Creating File Transfer Pipelines in B2C Commerce

_File transfer pipelines use B2C Commerce script to create a B2C Commerce FTP, HTTP, or WebDAV client and GET or POST files from an external system to the B2C Commerce instance. You can delete files from the external system after they’re successfully imported._

To expose a private pipeline to a third party that uploads files, create a public subpipeline that calls the private subpipeline. This approach allows scheduled jobs and on-demand calls to use the same pipeline.

## Creating File Transfer Scripts in B2C Commerce

_Use WebDAVClient, FTPClient, or HTTPClient in your file transfer script to move files from your backend system into B2C Commerce._

We recommend that the file names for transfer include the date. This convention allows the pipeline to identify if the correct file for import is in the correct location. The pipeline can then remove files from the archive efficiently. This approach requires you to create a script that can generate the expected file name for comparison to the actual file name. For example, the pipeline expects the catalog-jul-08.xml file and instead finds jun-08.xml, it can generate an error.

The least complicated file transfer pipeline to write is that for a WebDAV connection with an HTTP GET or POST, because such a pipeline doesn't require you to create an SSL connection.

### Zipping and Unzipping Files Using B2C Commerce Script

_If you have large files, we recommend that you zip them for file transfer. To automate the zip process when using a pipeline to transfer files, create scripts. This topic applies to B2C Commerce._

The B2C Commerce API supports the creation and extraction of .zip files.

- File.zip (File outputZipFile) creates a new .zip file from the contents of this file. If the file is a directory, the .zip file is created from the contents of files in the directory. If the output .zip file exists, it's replaced with a new .zip file. Empty subdirectories aren’t zipped. Zip entry names (pathnames) are made relative to this file. This approach facilitates unzipping the contents into a different directory.
- File.unzip(File root) extracts the content of this .zip file into the location designated by the root. If the .zip file contains directories, those directories are created as needed. If a file exists, it's overwritten.

Example:

```
var catalog: File = new File('/catalog');
catalog.zip('/temp/catalog.zip');
var catalogZip : File = new File('/temp/catalog.zip');
catalogZip.unzip('/temp/catalog'); // /temp/catalog created to store unzipped contents.
```

### Using WebDAVClient to Integrate Backend Systems with B2C Commerce

_B2C Commerce implements a WebDAV client in the B2C Commerce Script API to enable developers to access remote locations via the WebDAV protocol._

Accessing the Import/Export WebDAV share requires *File Transfer Manager* privileges.

The WebDAVClient class is the actual client, while the WebDAVFileInfo class is used to store information about the files at the remote destination. Use the WebDAVClient class to synchronize directories from a remote server with the B2C Commerce file system or to export files out of the B2C Commerce system. The client supports the following common WebDAV methods:

- OPTIONS
- GET
- PUT
- MKCOL
- MOVE
- COPY
- PROPFIND

The names of the script methods correspond exactly with the names of the WebDAV methods. The methods propfind() and list(), used to get information about remote files and directories, return instances of WebDAVFileInformation, which encapsulate this information.

> **Note:** This client can't be used to access the B2C Commerce server via the WebDAV protocol.

Example:

```
var webdavClient : WebDAVClient = new
WebDAVClient("http://mywebdav.server.com","myusername","mypassword");
 var getString : String = webdav.get("http://mywebdav.server.com/myData.xml","UTF-8");
 var message : String;
 if(webdavClient.succeeded()){
   message = webDavClient.statusText;
 }
 else{
 // error handling
   message="An error occurred with status code "+webdavClient.statusCode;
 }
 var data : XML = new XML(getString));
```

For more information, see the section on classes and methods.

### Using FTPClient to Integrate Backend Systems with B2C Commerce

_B2C Commerce implements an FTP client in the B2C Commerce Script API to enable developers to access remote locations via the FTP protocol. The FTPClient class can be used to pull or push files that don't require secure transmission. Because it isn't a secure transfer protocol, we recommend that you use the FTPClient only for sandboxes._

The FTPClient class supports the FTP commands CD, GET, PUT, DEL, MKDIR, RENAME, and LIST. Because the RMD command isn't supported, it isn't possible to delete directories using the B2C Commerce FTP client.

The FTP connection is established using passive transfer mode (PASV). The transfer of files can be text or binary.The FTPClient.setTimeout method sets the socket, data channel, and script timeouts for the FTP call. Each timeout is set to this value, so the total timeout can be longer than the value set.

Example:var ftp : FTPClient = new dw.net.FTPClient(); ftp.connect("http://www.myinstance.com", "username", "password"); var data : String = ftp.get("simple.txt");

To use the FTPClient class, contact Salesforce Support to have a firewall rule installed. Include the following information in your support case:

- Target IP
- Port number
- POD number for your instance

### Using HTTPClient to Integrate Backend Systems with B2C Commerce

_Use the HTTPClient class to create an HTTP client. This topic applies to B2C Commerce._

The HTTPClient class supports the following HTTP methods:

- GET
- POST
- HEAD
- PUT
- DELETE

> **Important:** For security reasons, we recommend that you always use HTTPS when connecting to external servers. A Certificate Authority (CA) that B2C Commerce recognizes signs the certificate at the external server. Import more CAs in Business Manager.

```
var httpClient : HTTPClient = new HTTPClient();
httpClient.setTimeout(2000);
var message : String;
httpClient.open('GET', 'http://www.myinstance.com/feed.xml');
httpClient.send();

if (httpClient.statusCode == 200)
{
     message = httpClient.text;
}
else
{
    // error handling
    message="An error occurred with status code "+httpClient.statusCode;
}
```
