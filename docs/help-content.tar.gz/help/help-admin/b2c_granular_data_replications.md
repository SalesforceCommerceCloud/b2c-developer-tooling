# Granular Data Replication

_Granular Replication is meant to complement and enhance existing B2C Commerce data replications, and not replace it._

The granular replication feature addresses the need to make small updates to existing content in production on an as-needed basis. Make granular data updates for these three replication groups:

- Products: Update specific products from staging to production.
- Price Books: Update specific price table entries from staging to production.
- Content Assets: Update specific content assets from staging to production.

Watch this video to see how to use granular replication.

If you can’t watch the video in full screen, open this link in a new tab: [Use Granular Replication](https://salesforce.vidyard.com/watch/SwPFKZcE94jzWyxUS6G79w).

## Related Content

- [Enable Granular Replications for Your B2C Commerce Site](https://help.salesforce.com/s/articleView?id=cc.b2c_enable_granular_replication_for_your_site.htm&type=5)
  Turn on granular replications in your staging and production B2C Commerce instances to make small updates to existing content on an as-needed basis.

- [Assign Granular Replication Permissions](https://help.salesforce.com/s/articleView?id=cc.b2c_assign_granular_replication_permissions.htm&type=5)
  Replicate specific B2C Commerce products from staging to production.

- [Replicate Products with Granular Replication](https://help.salesforce.com/s/articleView?id=cc.b2c_replicate_products_with_granular_replication.htm&type=5)
  Replicate products and product images from staging to production on your B2C Commerce site.

- [Replicate Prices with Granular Replication](https://help.salesforce.com/s/articleView?id=cc.b2c_replicate_price_books_with_granular_replication.htm&type=5)
  Replicate specific prices from staging to production on your B2C Commerce site.

- [Replicate Content Assets with Granular Replication](https://help.salesforce.com/s/articleView?id=cc.b2c_replicate_content_assets_with_granular_replication.htm&type=5)
  Replicate specific content assets from staging to production on your B2C Commerce site.

- [Publish Specific Page Designer Pages with Granular Replication](https://help.salesforce.com/s/articleView?id=cc.b2c_publish_specific_pages.htm&type=5)
  After you turn on granular replications and organize the B2C Commerce Page Designer pages that you want to replicate into a content library asset folder, run small, targeted replications multiple times a day without the expense and complexity of a full data replication.

- [Review Granular Replication Status](https://help.salesforce.com/s/articleView?id=cc.b2c_review_granular_replications.htm&type=5)
  Use the Granular Replication table to review past, ongoing, and upcoming granular replication jobs on your B2C Commerce site.
