# Granular Data Replication

_Granular Replication is meant to complement and enhance existing data replications, and not replace it._

The granular replication feature addresses the need to make small updates to existing content in production on an as-needed basis. Make granular data updates for these three replication groups:

- Products: Update specific products from staging to production.
- Price Books: Update specific price table entries from staging to production.
- Content Assets: Update specific content assets from staging to production.
