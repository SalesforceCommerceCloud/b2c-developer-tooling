# Support for DomainKeys Identified Mail (DKIM) Authentication

_Salesforce B2C Commerce provides an out-of-the-box solution on our first-party Point of Deployment (POD) that customers can use for their email requirements. This service provides support for DKIM and SPF authentication. DKIM is an email authentication protocol that adds a cryptographic digital signature to outgoing emails. With DKIM, receivers can verify that the domain owner authorized the email and that it wasn’t altered in transit. DKIM helps reduce spam and phishing emails._

[Which Salesforce Commerce Product Do I Have?](https://help.salesforce.com/s/articleView?id=commerce.comm_what_product.htm)

### DKIM Authentication Requirements for Google, Yahoo, and Microsoft

- Google announced that, starting in 2024, it requires both Sender Policy Framework (SPF) and DKIM for users who send 5,000+ emails per day. See [Email sender guidelines](https://support.google.com/mail/answer/81126?hl=en).
- Yahoo announced similar plans for Q1 2024. See [More Secure, Less Spam Enforcing Email Standards for a Better Experience](https://blog.postmaster.yahooinc.com/post/730172167494483968/more-secure-less-spam).
- Likewise, Microsoft announced authentication requirements with DKIM, DMARC, and SPF for bulk senders. See [Strengthening Email Ecosystem: Outlook’s New Requirements for High‐Volume Senders](https://techcommunity.microsoft.com/blog/microsoftdefenderforoffice365blog/strengthening-email-ecosystem-outlook%E2%80%99s-new-requirements-for-high%E2%80%90volume-senders/4399730).

To ensure compliance with the bulk sender authentication requirements, here are the high-level steps.

- Generate a private-public key pair for DKIM. See [b2c_generate_private_key.xml](https://help.salesforce.com/s/articleView?id=cc.b2c_generate_private_key.htm&type=5)
- To reflect the new public key, update your DNS records. See [b2c_deploy_dkim.xml](https://help.salesforce.com/s/articleView?id=cc.b2c_deploy_dkim.htm&type=5).
- Import your private key in Business Manager. See [b2c_deploy_dkim.xml](https://help.salesforce.com/s/articleView?id=cc.b2c_deploy_dkim.htm&type=5).
   
   - The key is used for all of your outgoing emails, and it satisfies Google, Yahoo, and Microsoft requirements.
   - Specifying your key is required only one time per instance.
- Test your changes in your development or staging instance before introducing them to production.

In this section:

## Related Content

- [Configure DKIM for B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_deploy_dkim.htm&type=5)
  Major email providers, including Google, Microsoft, and Yahoo, now require DomainKeys Identified Mail (DKIM) authentication. Configuring DKIM is essential to ensure that your emails reach customer inboxes and aren’t rejected or flagged as spam. Configure DKIM to verify that the emails come from the domain that they claim to be from.

- [Generate a Private-Public Key Pair](https://help.salesforce.com/s/articleView?id=cc.b2c_generate_private_key.htm&type=5)
  DKIM authentication requires you to specify a private key in Business Manager in B2C Commerce. Generate a private key in a terminal with these commands.
