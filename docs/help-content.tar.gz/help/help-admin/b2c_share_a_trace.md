# Share a Trace (Beta)

_Share a link to a specific B2C Commerce trace or search and filter selections with a colleague._

The Traces page captures your search and filter selections in a shareable link, so you can send a colleague the same view.

1. Set the search and filters you want to share.
2. Click **Copy link**.

   The link is copied to your clipboard.
3. Send the link to your colleague.

When your colleague opens the link, the Traces page shows the same filtered view.
