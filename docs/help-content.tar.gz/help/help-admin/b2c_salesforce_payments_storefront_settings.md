# Salesforce Payments B2C Commerce Storefront Settings

_To configure your storefront payment experience, use the Business Manager Payments module for B2C Commerce. Select express and multi-step payment methods, and the payment services for each method._
