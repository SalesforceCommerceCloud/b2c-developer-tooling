# Salesforce Payments B2C Commerce Storefront Settings

_To configure your storefront payment experience, use the Business Manager Payments module for B2C Commerce. Select express and multi-step payment methods, and the payment services for each method._

## Related Content

- [Payment Methods for B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_payment_methods.htm&type=5)
  With Salesforce Payments, you can offer shoppers Checkout, Express Checkout, or both payment methods on your storefront. If you offer Checkout, shoppers can purchase items using Afterpay, Amazon Pay, Bancontact, credit cards, EPS, iDEAL, Klarna, PayPal, SEPA Debit, TWINT, or Venmo. If you offer Express Checkout, shoppers can purchase items using Amazon Pay, Apple Pay, Google Pay, PayPal, or Venmo.

- [Using Venmo with PayPal for B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_offer_venmo_with_paypal.htm&type=5)
  Salesforce Payments supports Venmo as an express and multi-step checkout method. With Venmo, you can offer your shoppers a digital wallet payment option that they link to a credit card, debit card, bank transfer, or Venmo funds bank. Using Venmo on your Salesforce Reference Architecture (SFRA) storefront requires a PayPal integration with Salesforce Payments. This feature applies to B2C Commerce.

- [Buy Now and Pay Now Checkout Methods for B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_buy_now_pay_now_checkout_methods.htm&type=5)
  Salesforce Payments has two express checkout experiences: Pay Now and Buy Now. Pay Now requires a current shopper basket while Buy Now ignores the current basket.

- [Buy Now and Pay Later Payment Services for B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_buy_now_pay_later_checkout_services.htm&type=5)
  The buy now, pay later payment option for B2C Commerce makes it convenient for shoppers to purchase items in all price ranges. Salesforce Payments offers Buy Now, Pay Later payment through Klarna and AfterPay.

- [Create Orders Automatically Using Stored Payment Methods](https://help.salesforce.com/s/articleView?id=cc.b2c_stored_payments_for_auto_ordering.htm&type=5)
  Set up a site to automatically create orders in an off-session transaction by reusing payment information stored in tokens. An off-session transaction doesn’t require the buyer to be online to complete a purchase. A site can use off-session tokens to automate orders for recurring payments, such as subscriptions or installments, or one-click reordering.

- [Validate Adyen Payments for B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_validate_adyen_payments.htm&type=5)
  Set up and validate test payments in a test or live Adyen merchant account for your B2C Commerce instance. Use an Adyen merchant account associated with your B2C Commerce instance to create test payments.

- [Validate Stripe Payments for B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_validate_payments_in_test_and_live_modes.htm&type=5)
  Set up and validate test payments in a test or live Stripe merchant account for your B2C Commerce instance. Use a Stripe merchant account associated with your B2C Commerce instance to create test payments.

- [Test a PayPal Configuration](https://help.salesforce.com/s/articleView?id=cc.b2c_test_a_paypal_configuration.htm&type=5)
  After you integrate a PayPal merchant account with Salesforce Payments and add the PayPal merchant account to your site, test your configuration in a sandbox.

- [PayPal Funds Disbursement](https://help.salesforce.com/s/articleView?id=cc.b2c_paypal_funds_disbursement.htm&type=5)
  Salesforce Payments with PayPal implements immediate capture and funds disbursement For example, a shopper completes a cart checkout and the order is approved. That shopper’s payment is immediately captured and dispersed to the merchant.
