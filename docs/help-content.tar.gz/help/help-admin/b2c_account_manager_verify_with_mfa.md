# Verify Your Identity with Multi-Factor Authentication in B2C Commerce

_Multi-factor authentication (MFA) is a simple, effective mechanism for enhancing login security and safeguarding your users’ accounts against security threats. MFA is part of the B2C Commerce login experience and can’t be turned off._

[Which Salesforce Commerce Product Do I Have?](https://help.salesforce.com/s/articleView?id=commerce.comm_what_product.htm)

MFA requires users to enter two or more pieces of evidence – or factors – to prove they’re who they say they are. One factor is something a user knows, such as their username and password combination. Other factors are verification methods that a user has in their possession, such as an authenticator app or security key. Tying user access to multiple, different types of identity verifiers decreases the risk of account compromise.

Account Manager asks you to verify your identity using a supported verification method. If you have multiple verification methods registered, Account Manager opens the last used method. If you want to verify your identity with another registered verification method, you can choose another verification method.

Depending on the MFA verification method settings for your organization, you can choose between phishing-resistant methods and standard verification methods.

### Phishing-Resistant Methods

Phishing-resistant methods use FIDO2/WebAuthn to bind your credentials to Account Manager, so an attacker can’t reuse them on a spoofed site.

**Passkey**

If you registered a passkey for your account, use the passkey to log in to B2C Commerce applications. At the prompt, unlock your device or authenticator with the method you set up (biometric such as Touch ID, Face ID, or Windows Hello, a device PIN, or a pattern) to approve the sign-in. Passkeys can be device-bound or synced across the devices you’ve signed in to with the same platform account.

**Security Key**

If you registered a Fast Identity Online (FIDO) U2F or WebAuthn (FIDO2) compatible security key for your account, use the security key to log in to B2C Commerce applications. At the prompt, insert your security key into the appropriate port on your computer or mobile device. If it has a button, touch the button. Security keys aren’t a biometric device, even though some have a button that requires your touch to activate the device.

**Platform Biometric Authenticator**

If your organization allows built-in platform authenticators, use the biometric sensor on your computer or mobile device (such as Touch ID, Face ID, or Windows Hello) to verify your identity at the prompt.

### Standard Verification Methods

**Salesforce Authenticator App**

If you connected the Salesforce Authenticator app (version 3 or later) to your account, use the app to log in to B2C Commerce applications. Account Manager sends a push notification to your mobile device. When you get the notification, open the app, verify the activity details, and tap **Approve** on your mobile device. Salesforce Authenticator also supports TOTP.

> **Note:** Keep the Salesforce Authenticator app on a secure mobile device. To secure the mobile device, use a PIN, Face ID, or Touch ID, as supported by the mobile device.

**One-Time Password Generator App**

If you connected a third-party authenticator app (such as Google Authenticator or Microsoft Authenticator) to your account, use it to log in to B2C Commerce applications. Use any authenticator app that generates a temporary code called a time-based one-time password (TOTP). The code value changes periodically. Account Manager asks you to insert the temporary code, and click **Verify**.
