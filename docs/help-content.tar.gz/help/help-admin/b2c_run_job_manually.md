# Run a B2C Commerce Job Manually

_Execute a B2C Commerce job manually as needed._

[Which Salesforce Commerce Product Do I Have?](https://help.salesforce.com/s/articleView?id=commerce.comm_what_product.htm)

To schedule the job to run automatically, see [Create and Schedule a B2C Commerce Job](https://help.salesforce.com/s/articleView?id=cc.b2c_create_job.htm&type=5).

1. To manually run a job created in the new job framework:

   1. From the App Launcher _(image: App Launcher)_, find and select **Administration > Operations > Jobs**.
   2. Select the job, and click **Run**. On the job page, click **Run Now**. If the job has parameters, click **Run with Parameters**, and then click **Run Now**.
2. To run a pipeline job manually:

   1. From the App Launcher _(image: App Launcher)_, find and select **Administration > Operations > Jobs (Deprecated)**.
   2. Select the job, and click **Run**.
