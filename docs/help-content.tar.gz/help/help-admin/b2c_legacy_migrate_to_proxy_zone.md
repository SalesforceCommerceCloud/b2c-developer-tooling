# Migrate to a Proxy Zone for B2C Commerce

_To enhance security, improve load balancing, and comply with regulatory requirements, migrate legacy zones to proxy zones._

Legacy/Orange-to-Orange (O2O) conflict

If you already have an active legacy zone (via eCDN or as an existing Cloudflare customer/O2O) for the fully qualified domain name (FQDN), for example, `merchantsite.com`, the legacy zone takes priority over the Proxy zone. In this scenario, wildcard custom hostnames do not work. See [Hostname priority](https://developers.cloudflare.com/ssl/reference/certificate-and-hostname-priority/#hostname-priority)

> **Note:** Legacy zones are shared across Development, Staging, and Production instances. Perform the migration on each instance (Dev/Stg/Prod) and then **delete the Legacy zone from the Production instance after it has been successfully migrated on all instances**.

1. In Business Manager, click App Launcher _(image: App Launcher)_, and then select**Administration > Sites > Embedded CDN Settings**
2. Select the legacy zone you want to migrate.
3. Click Migrate to Proxy Zone.
4. Wait for the proxy zone status to show Verified and the new proxy zone hostnames to show.

Upload a certificate or use automatic certificates for the new hostnames.

> **Note:** If your zone currently points to an apex/root domain, see [Configure root domains with the B2C Commerce platform's eCDN](https://help.salesforce.com/s/articleView?id=000391603&type=1), What can I do if I don't want to redirect my APEX/Root domain to a subdomain?
