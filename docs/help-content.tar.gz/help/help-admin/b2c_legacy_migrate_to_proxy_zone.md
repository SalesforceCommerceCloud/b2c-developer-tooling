# Migrate a Legacy Zone to a Proxy Zone

_Start the migration of a B2C Commerce legacy zone to a proxy zone in Business Manager or with the CDN-API. Proxy zones use standard eCDN configuration and the latest security features and prevent common hierarchy-assignment issues. This migration is required to move to Hyperforce, which doesn't support legacy zones._

[Which Salesforce Commerce Product Do I Have?](https://help.salesforce.com/s/articleView?id=commerce.comm_what_product.htm)

> **Important:** The August 15, 2026 deadline to migrate from legacy eCDN zones to proxy zones has passed. Legacy zones and HTTP-only traffic aren't supported. Salesforce is removing unused legacy zones.

This task is the first step of the migration. For the full sequence, see [Proxy Zone Migration Overview](https://help.salesforce.com/s/articleView?id=cc.b2c_migrating_proxy_zones.htm&type=5).

**Legacy/Orange-to-Orange (O2O) conflict:** If you already have an active legacy zone (through eCDN or as an existing Cloudflare customer/O2O) for the fully qualified domain name (FQDN), such as `merchantsite.com`, the legacy zone takes priority over the proxy zone. In this scenario, wildcard custom hostnames don't work. See [Hostname priority](https://developers.cloudflare.com/ssl/reference/certificate-and-hostname-priority/#hostname-priority).

> **Note:** Legacy zones are shared across Development, Staging, and Production instances. Perform the migration on each instance (Dev/Stg/Prod) and then **delete the Legacy zone from the Production instance after it has been successfully migrated on all instances**.

1. In Business Manager, click App Launcher _(image: App Launcher)_, and then select**Administration > Sites > Embedded CDN Settings**
2. Select the legacy zone you want to migrate.
3. Click **Migrate to Proxy Zone**.
4. Wait for the proxy zone status to show **Verified** and the new proxy zone hostnames to appear.

Upload a certificate or use automatic certificates for the new hostnames. Then continue with [Configure Proxy Zone Settings](https://help.salesforce.com/s/articleView?id=cc.b2c_legacy_configure_proxy_zone_settings.htm&type=5).

> **Note:** If your zone currently points to an apex/root domain, see [Configure root domains with the B2C Commerce platform's eCDN](https://help.salesforce.com/s/articleView?id=000391603&type=1) for what to do if you don't want to redirect your apex/root domain to a subdomain.
