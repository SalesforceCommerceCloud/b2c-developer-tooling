# Clear Secure File Transfer Protocol (SFTP) Known Good Hosts for B2C Commerce

_Business Manager remembers hosts previously used for SFTP. Clear these remembered known hosts._

|  |
| --- |
| Available in: **B2C Commerce** |

1. In Business Manager click App Launcher _(image: App Launcher)_, and then select **Administration > Global Preferences > Security** and select the Misc tab.
2. Click **Clear** for the Clear SFTP Known Good Hosts File setting.
