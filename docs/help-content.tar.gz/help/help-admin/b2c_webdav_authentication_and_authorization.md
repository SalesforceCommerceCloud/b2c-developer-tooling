# WebDAV Authentication and Authorization in B2C Commerce

_WebDAV is a protocol that enables you to upload and download data or code files. A merchant sends WebDAV requests to your instance’s WebDAV server. The merchant’s WebDAV client can be a Business Manager user or an API client for machine-to-machine interaction._

When the merchant's WebDAV client is a Business Manager user, such as Cyberduck, Salesforce B2C Commerce performs authentication using Basic Auth (username and password). To specify authorization rules in Business Manager, configure per-folder rules in the Roles module (WebDAV Permissions tab).

When the merchant’s WebDAV client is an API client, B2C Commerce performs authentication using an authorization token minted by Account Manager. To get an authorization token, the API client presents its client-id and client-secret to Account Manager. To specify authorization rules in Business Manager, configure per-folder rules in the WebDAV Client Permissions module.

Additionally, the OAuth 2.0 Authorization Code Grant can be used for WebDAV. For more information, see the [Authorization Code Grant](http://tools.ietf.org/html/rfc6749#section-1.3.1) section in the Internet Engineering Task Force (IETF) specification. In this scenario, your user on the Account Manager needs to have the role *Business Manager Administrator* or *Business Manager User* assigned together with a tenant filter, which matches the instance you will use the OAuth token for.
