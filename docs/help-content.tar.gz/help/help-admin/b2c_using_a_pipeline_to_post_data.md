# Using a Pipeline to POST Data in B2C Commerce

_We have provided sample code to post data results in an HTTP client using B2C Commerce script._

var httpSvc : HTTPClient = new HTTPClient(); httpSvc.open( "POST", "http://localhost/on/demandware.store/Sites-YourShopHere-Site/default/ Test-Get");`httpSvc.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");` `httpSvc.send("data=aaaa")`;The content type is important. If the content type isn’t correct, the target system sometimes doesn’t decode it correctly, and the target system doesn't see any post data.

### Allowing File Upload by Customers

Create a template and script to upload files to the instance. Use this approach, for example, to allow customers to upload their photo for customer profiles

First, create the template for the upload:

```
<form
action="${URLUtils.url('FileUpload-Upload')}"
enctype="multipart/form-data" method="post" style="padding-left: 10px">
<input
size="40" name="image" type="file" /> <input type="submit"
name="add" value="add" /> </form>The form encode type must be multipart/form-data
and the method must be post.
```

The script that does the upload

```
importPackage( dw.system ); 
importPackage( dw.web ); 
importPackage( dw.io ); 
importPackage( dw.util ); 

function execute( pdict : PipelineDictionary ) : Number { 
    var filename : String; 
    var params : HttpParameterMap = pdict.CurrentHttpParameterMap; 
    var files : LinkedHashMap = new LinkedHashMap(); //callback function
    var closure : Object = function(field, ct, oname){ 
        filename = oname; 
        return new File( File.IMPEX + "/" + oname);
        }; 
    files = params.processMultipart(closure); 
    return PIPELET_NEXT; 
}
```

The variable closure is a callback function. The api calls the function, passing in the fieldname of the file input, the content type, and the file name that was uploaded via the multipart form. This callback is passed into the processMultipart method. The return is a Map of the files that were uploaded.

The callback is called for each file that you upload. If you’re uploading five files, the callback is called five times and the return Map contains all five file references.
