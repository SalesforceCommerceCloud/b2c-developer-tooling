# Create Orders Automatically Using Stored Payment Methods

_Set up a site to automatically create orders in an off-session transaction by reusing payment information stored in tokens. An off-session transaction doesn’t require the buyer to be online to complete a purchase. A site can use off-session tokens to automate orders for recurring payments, such as subscriptions or installments, or one-click reordering._

When you configure a site for off-session reuse, all credit cards and SEPA debit accounts are set up for reuse, not just the payment methods that registered shoppers elect to save.

To authorize recurring payments or reauthorize payments for delayed order fulfillment, use these B2C Script API methods.

- SalesforcePaymentsMgr.confirmPaymentIntent (order, paymentMethod, statementDescriptor). Enables the site’s custom code to create an order and pass it to the Script API with a payment method that’s configured for future off-session reuse. The API confirms the charge to the card or bank account for the new order.
- SalesforcePaymentsMgr.getOffSessionPaymentMethods. Returns a collection of payment methods, which the SalesforcePaymentsMgr.confirmPaymentIntent method can reuse.
