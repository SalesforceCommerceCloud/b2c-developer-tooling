# Data Replication in B2C Commerce

_Data replication copies data, metadata, and files from staging to a development or production instance. This topic applies to B2C Commerce._
