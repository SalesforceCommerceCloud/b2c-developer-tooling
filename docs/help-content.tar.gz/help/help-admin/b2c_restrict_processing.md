# Restriction of Processing: Restrict How to Process Personal Data in B2C Commerce

_When situations require you to do so, prevent the processing of your customers’ data. We give guidance to help you restrict forms of data processing. That way, you can work toward complying with the laws that are important to your company. This topic applies to B2C Commerce._

Prevent the processing of your shoppers’ data when situations require you to do so. Data subjects can request that a merchant stops accessing or modifying personal data. The merchant needs to make sure that personal data is not further processed by any party. We give guidance on how to restrict forms of data processing. That way, you can work toward complying with the laws that are important to your company. For instance, a shopper has a dispute and asks that their information is not accessed until their dispute is resolved.

> **Note:** As new data protection and privacy solutions are launched, B2C Commerce will provide specific documentation to help merchants understand how these new features can be used to help with compliance. This will cover existing tools and also extend to new release items. This page will be updated as more restriction of processing functionality is made available. Check back for updates in future 2018 releases!

Many data protection and privacy regulations can require you to restrict processing of shoppers’ personal data. We’ve listed a few of the regulations that are important to many companies collecting and processing their shoppers’ data.

- General Data Protection Regulation (GDPR)
- Personal Information Protection Act (PIPA), Japan
- Privacy Act, Australia
- Personal Information Protection and Electronic Documents Act (PIPEDA), Canada

If you encounter situations that require you to restrict data processing for any of your shoppers, review these common requests and the procedures related to them.

| Product | Common Shopper Request | Actions to Consider | Things to Consider |
| --- | --- | --- | --- |
| Salesforce B2C Commerce | I want you to stop accessing or processing my personal data until we can resolve a dispute. | [Export a copy of the shopper's data](https://help.salesforce.com/s/articleView?id=cc.b2c_customer_snapshots.htm&type=5) and maintain it in a secure and restricted location. [Delete the shopper's personal data and associated orders](https://help.salesforce.com/s/articleView?id=cc.b2c_data_deletion.htm&type=5) from the Commerce Cloud system. | Shopper data cannot be deleted if it has any associated open orders. Investigate any open orders and resolve them with the shopper. To access a shopper's data when that shopper has no associated account, such as when they browsed the storefront and started a basket without actually placing an order, you must contact Support. If such a shopper wants to delete their data, you can inform them that deleting all [B2C Commerce-related cookies](https://help.salesforce.com/s/articleView?id=cc.b2c_local_data_storage.htm&type=5) from their browser will disassociate them from any data stored in B2C Commerce. |
