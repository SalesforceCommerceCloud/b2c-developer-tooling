# Administering Your Organization for B2C Commerce

_As an administrator, you control users and permissions. You’re responsible for import and export, third-party integration, batch processing, and data replication. Use the Control Center to manage instances. You can also manage client certificates within your environment._

## Related Content

- [Access Alerts for Your B2C Commerce Site](https://help.salesforce.com/s/articleView?id=cc.b2c_access_alerts_for_your_site.htm&type=5)
  Find all tasks and notifications in the Alerts section of your Business Manager homepage. See all tasks and notifications for your site in the Alerts module. Alerts can be shown in the Business Manager homepage or header, or sent directly to Slack channels.

- [Access WebDAV Files for B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_access_files_webdav.htm&type=5)
  Use the folder browser in Business Manager to easily view and download WebDAV files. You can also use a third-party WebDAV client to view, download, upload, and delete WebDAV files.

- [Change the User Interface Locale for Business Manager](https://help.salesforce.com/s/articleView?id=cc.b2c_business_manager_locale.htm&type=5)
  The Business Manager user interface for B2C Commerce supports multiple languages.

- [Cross-site Request Forgery (CSRF) Preferences for B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_csrf_preferences.htm&type=5)
  To protect pages from CSRF attacks, Business Manager injects tokens into requests and logs failed validations. Use the log entries to troubleshoot failed requests.

- [Support Cookie SameSite Attribute Changes for B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_cookie_attribute.htm&type=5)
  Many browser vendors, for example Google Chrome, have introduced a new default cookie attribute setting of SameSite=Lax. Previously, the SameSite cookie attribute defaulted to SameSite=None. When SameSite is set to None, cookies require the Secure attribute indicating that they require an encrypted HTTPS connection.

- [Enforce HTTPS for B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_enforce_https.htm&type=5)
  Enable the Enforce HTTPS setting to redirect incoming page requests that use HTTP to HTTPS. Configure the setting per site or for all sites of an instance. When you enable Enforce HTTPS globally, you can't configure it at the site level. If you disable the global preference, the site-specific settings return to their previous values.

- [Business Manager Email Configurator](https://help.salesforce.com/s/articleView?id=cc.b2c_business_manager_email_configurator.htm&type=5)
  Use the optional email settings to define your own SMTP server for B2C Commerce customer and platform email delivery.

- [JavaScript and Objects in HTML Attributes for B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_javascript_in_html_attributes.htm&type=5)
  For security reasons, only Business Manager users with strong authentication, such as through multi-factor authentication with Account Manager, can include JavaScript and objects embedded with `iframe`, `object`, `applet`, or `embed` tags in the HTML attributes of a database object.

- [Global Preferences for B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_global_preferences.htm&type=5)
  Configure global preferences for the entire organization, and sometimes, override those preferences at the site level. Global preferences include setting the time zone, locale, and sequence numbers for a site.

- [Site Preferences in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_site_preferences.htm&type=5)
  Use site preferences to control the behavior of individual Salesforce B2C Commerce sites. Configure various site preferences.

- [Managing Sites in Business Manager](https://help.salesforce.com/s/articleView?id=cc.b2c_managing_sites_in_bm.htm&type=5)
  In Business Manager, you can manage various aspects of sites, such as the B2C Commerce storefront sites, the Business Manager site itself, and the global static cache.

- [Manage Custom Caches Using Business Manager](https://help.salesforce.com/s/articleView?id=cc.b2c_manage_custom_caches_bm.htm&type=5)
  You enable or disable caching, monitor custom cache statistics, and clear caches for your B2C Commerce storefront, all from the Custom Caches page.

- [Scheduling Instance Backups in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_scheduling_instance_backups.htm&type=5)
  Schedule instance backups.

- [Connect Your B2C Commerce Instance to Salesforce](https://help.salesforce.com/s/articleView?id=cc.b2c_connected_comm_salesforce_connection.htm&type=5)
  Create a trusted data exchange between your B2C Commerce instance and a Salesforce org. This connection gives you access to agentic and cross-cloud experiences, such as Shopper Agent, Merchant Agent, Shopper Profile Sync, and Shopper Notifications.

- [Shopper Profile Sync](https://help.salesforce.com/s/articleView?id=cc.unified_shopper_profile_sync.htm&type=5)
  Shopper Profile Sync connects your B2C Commerce shopper data with records in your Salesforce org. This integration automatically syncs registered shoppers as person accounts and provides a unified view of each customer across Commerce, Service, and other Salesforce apps.

- [Set Up Eventing in B2C Commerce (Pilot)](https://help.salesforce.com/s/articleView?id=cc.b2c_configure_event_types.htm&type=5)
  Use eventing in B2C Commerce to receive notifications when certain data or processing events occur in your Commerce Cloud environment. You enable event types and configure connectors in Business Manager; B2C Commerce routes events directly to your configured connectors.
