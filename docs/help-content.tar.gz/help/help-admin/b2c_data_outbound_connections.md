# Outbound Connections Allowlist in B2C Commerce

_Connections from B2C Commerce to an external cloud provider over a private internet are referred to as outbound connections. To ensure the security and integrity of your B2C Commerce realm, Salesforce Customer Support approves all outbound connections. To control which destinations your data can be sent to, add new endpoints to your outbound connections allowlist. Send data from B2C Commerce to any of the endpoints on the allowlist, including third party providers such as Secure File Transfer Protocol (SFTP), FTP, WebDAV, and HTTP and HTTPS._

To allow outbound connections, send a request to Salesforce Customer Support to add new rules to the firewall on each Point of Delivery (POD). While adding rules to the firewall, keep in mind these points.

- TCP ports 22, 80, 443, and 587 are open by default for B2C Commerce and don’t require a separate firewall rule.
- Firewall rules can use only IP addresses and not domain names.
- You can add rules for ports between 1024 and 65,536. Ports below 1024 aren’t eligible for new rules, with the exception of port 21.
- We recommend that you have no more than five IP:Port pairs per realm. However, if there’s a business need, you can request up to ten IP:Port pairs per realm.
- Avoid making firewall changes during POD maintenance.
- Avoid making requests to add reserved IP addresses to the allowlist, as these requests are denied by Salesforce Customer Support. The reserved IP addresses include, but are not limited to these IP address ranges.
   
   | LARGEST CIDR BLOCK | SUBNET MASK | IP ADDRESS RANGE | NUMBER OF IPs (HOSTS) |
   | --- | --- | --- | --- |
   | 10.0.0.0/8 | 255.0.0.0 | 10.0.0.0 - 10.255.255.255 | 16,777,216 |
   | 172.16.0.0/12 | 255.240.0.0 | 172.16.0.0 - 172.31.255.255 | 1,048,576 |
   | 192.168.0.0/16 | 255.255.0.0 | 192.168.0.0 - 192.168.255.255 | 65,536 |

## Related Content

- [Configure an Outbound Connections Allowlist in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_data_config_outbound_connections.htm&type=5)
  Any URL that is already configured in service credentials is automatically added to your allowlist. Follow this process to configure new endpoints and add them to your allowlist.
