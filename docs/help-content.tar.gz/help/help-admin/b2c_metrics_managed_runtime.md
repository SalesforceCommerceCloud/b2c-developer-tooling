# Managed Runtime Metrics

_For teams that operate B2C Commerce experiences based on Composable Storefront, Managed Runtime metrics help website administrators, DevOps teams, and security professionals monitor and optimize performance, security, and resource utilization. These CDN and application metrics are crucial for optimizing website performance, security, and reliability. By actively monitoring these metrics, website administrators can detect issues early, enhance caching efficiency, reduce costs, and improve the user experience._

### Request Count

The Request Count metric tracks the number of overall HTTP requests served by the Managed Runtime CDN, including cached and uncached responses for pages, static assets and proxied API requests.

> **Caution:** Customers who are stack eCDN or a third-party CDN rely on requests counts from stacked CDN for accuracy, as responses cached upstream won’t be represented.

Use cases:

- To analyze shopper engagement, track the number of requests over time.
- Correlate with marketing efforts to evaluate the success of promotions or SEO strategies.
- Monitor bot activity if there are unusually high requests from non-human traffic.

### Cache Hits

The Cache Hits metric measures the number of requests served directly from the Managed Runtime CDN cache instead of the Composable Storefront application. A higher count indicates effective caching, reducing load on the application server.

> **Caution:** Customers who are stack eCDN or a third-party CDN rely on cache hit metrics from the stacked CDN for accuracy, as responses cached upstream won't be counted.

Use cases:

- To optimize performance, increase cache hit ratios and reduce application server load.
- Reduce bandwidth costs because serving content from CDN cache avoids repeated application server requests.
- Identify cache configuration issues where expected pages, assets, and APIs aren't being cached properly.
- To improve content delivery, ensure frequently accessed content remains in CDN cache for faster load times.

### Error Rate

The Error Rate metric tracks the number of error requests from the Composable Storefront application.

- `401` (Unauthorized): Requests that require authentication.
- `403` (Forbidden): Requests that aren't permitted.
- `404` (Not Found): Requests that attempt to access a page, static asset or other resource that doesn’t exist.
- `502` (Bad Gateway): Failures communicating with the application server.
- `503` (Service Unavailable): The application server isn't available to service requests.
- `504` (Gateway Timeout): The application server took too long to respond, usually due to exceeding maximum response time limits.

Use cases:

- To monitor website reliability, track the trend of successful to failed requests.
- Identify client-side issues, such as broken links leading to `404` errors.
- Detect server-side failures that can require action, such as application downtime or misconfigurations.

### SSR Invocations

The SSR Invocation metric tracks the number of server-side rendering requests from the Composable Storefront application.

Use cases:

- To optimize performance, monitor slower, more expensive server-side rendering responses compared to cached CDN responses.
- Monitor bot activity if there are unusually high application requests from non-human traffic.

### Request Time

The Request Time metric tracks the time spent in milliseconds responding to server-side rendering requests from the Composable Storefront application.

- `P50`—The average time spent responding to requests.
- `P95`—95th percentile of application requests responded in less than this time.
- `P99`—99th percentile of application requests responded in less than this time.

Use case:

- To optimize performance, monitor for slow application response times, to identify areas of optimization and potential issues with the latency of external API integrations
