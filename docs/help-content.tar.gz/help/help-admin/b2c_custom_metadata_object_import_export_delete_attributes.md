# Delete Existing Attribute Definitions and Attribute Groups

_Delete a custom objects attribute definitions and attribute groups using an import file._

|  |
| --- |
| Available in: **B2C Commerce** |

> **Caution:** The import file must contain all definitions that you want to use. B2C Commerce removes any definitions currently stored but not included in the import file, and they aren’t available after import. If the import file validation or the import fails, nothing is deleted.

1. Click App Launcher _(image: App Launcher)_, and then select **Administration  > Site Development  >  Import/Export**.
2. In the Import/Export page, in the Meta Data section, click **Import**.
3. Select the file to import.
4. To use this feature, check the **Delete existing attribute definitions and attribute groups not contained in the import file** box.

   For custom and system object types that the import file specifies, this updates all existing custom attribute definitions and custom attribute groups before removing the definitions and groups not specified in the import file. The option is useful if you want to replace all your existing attribute and group definitions with what your import file defines and remove obsolete groups and definitions.
