# Create a Role in B2C Commerce

_A role is a named group of permissions. For example, group all of the permissions related to catalog management into a role called Catalog Manager. Next, assign this role to the user whose job it is to manage the catalog._

Watch this video to see how to create a role in B2C Commerce.

If you can’t watch the video in full screen, open this link in a new tab: [Create a Role in B2C Commerce](https://salesforce.vidyard.com/watch/ZUSt3ukp6bPUdbaN7JuEoM).

The SiteGenesis application contains several roles predefined for your convenience, such as the Administrator role. You can import and export these roles. Use the roles without modification or customize them to suit your application needs. If necessary, remove the roles and create your own set of roles. Make sure you grant at least one user with access to the Roles and Permissions module.

To manage roles and permissions, you must have permissions to the Roles & Permissions module. To add a user and to manage user login and credential information, you must have permissions to the Users module. To assign or unassign roles to users, you must have permissions to both the Users module and the Roles & Permissions module.

If you don't have a user with access to the Roles and Permissions module, contact B2C Commerce Support to reinstate access to this module.

> **Note:** A list of assigned roles also appears on the Roles page of a user definition.

1. Click App Launcher _(image: App Launcher)_, and then select **Administration > Organization > Roles & Permissions**.

   Roles marked with a yellow triangle are security-sensitive. They have permission to manage users or access roles or both. Use care when changing these roles so you don't give access privileges to the wrong users.
2. Click **New**.
3. On the General tab, define or edit general information and click **Apply**.

   A role's ID is limited to:
   
   - letters (including non-Latin)
   - numbers
   - whitespace
   - special characters: `_ ! " & \ ' ( ) + - . , / : < > ? @ [ ]`
   
   B2C Commerce rejects IDs with not-allowed characters; the access role can't be created or imported.
4. On the Users tab, select users and click **Assign**.

   To use the Users tab to assign users to a role, you must also have permissions to the Users module.

## Assign Business Manager Module Permissions

_Assign each role access to B2C Commerce Business Manager Modules._

1. Click App Launcher _(image: App Launcher)_, and then select **Administration > Organization > Roles & Permissions**
2. Select a role.
3. On the **Business Manager Module** tab, select the context in which you want to assign permissions.

   Click **Select Context** if you have already specified context and you want to change it. To revert from individual sites to `Organization`, uncheck **All Sites** before checking **Organization**.
4. Click **Apply**.
5. Select **Read** or **Write** per module to enable or disable permissions.

   If a user has read-only permission, they can see the respective module, but can't create, edit, or configure settings in that module. This also applies to access via B2C Commerce API calls.
6. Click **Update**.

## Assign Functional Permissions

_Functional permissions let a role perform an action in B2C Commerce._

1. Click App Launcher _(image: App Launcher)_, and then select **Administration > Organization > Roles & Permissions**.
2. Select a role.
3. On the Functional Permissions select the context in which you want to assign permissions.

   Click **Select Context** if you have already specified context and you want to change it. To revert from individual sites to Organization, uncheck **All Sites** before checking **Organization**.
4. Assign functional permissions to your role.

   All sites are listed. Any user can select a site without having permission. However, if a user doesn't have access to the Business Manager modules within that site, they only see an empty navigation bar.
5. Click **Update**.

   All permissions are cumulative.

## Assign WebDAV Permissions

_When selecting a WebDAV permission ending with an asterisk ('/catalogs/*', '/libraries/*' or '/dynamic/*') or '(all other folders)', the permission is granted for all future subfolders automatically. To prevent this behavior check the sub-permissions manually in B2C Commerce Business Manager._

1. Click App Launcher _(image: App Launcher)_, and then select **Administration > Organization > Roles & Permissions**.
2. Select a role.
3. On the WebDAV Permissions tab, grant read or write access to specific folders.

   See [WebDAV Permissions](https://help.salesforce.com/s/articleView?id=cc.b2c_using_web_dav_permissions.htm&type=5).
4. Click **Update**.

## Assign Locale Permissions

_Assign permissions on individual locales to a role in B2C Commerce Business Manager. A user with no permission on a locale can't view or edit localized attributes in that locale._

1. Click App Launcher _(image: App Launcher)_, and then select **Administration > Organization > Roles & Permissions**.
2. Select a role.
3. On the Locale Permissions page, click a locale link, for example, **de**.
4. Grant read or write access to specific locales (using the checkboxes) and click **Update**.
5. On the *Local* - General tab, view general read-only information about the locale.
6. Configure the Fallback Locale.

   For example, set it to Default or disable it.
7. On the **Regional Settings** tab, specify number and currency settings.
8. Click **Apply** to save your settings.

## Assign a Price Adjustment Limit

_Assign limits per user for manual price adjustments in B2C Commerce Business Manager. You can select a context of one, multiple, or all sites for which the limits apply._

Access limits programmatically via the Script API, `dw.order.LineItemCtnr.verifyPriceAdjustmentLimits()`.

A price adjustment limits violation check is done during manual price adjustment creation by Open Commerce API (OCAPI), as follows:

```
POST /baskets/\{basket_id\}/price_adjustments
```

Price adjustment limits are imported and exported through the site import/export.

1. Click App Launcher _(image: App Launcher)_, and then select **Administration > Organization > Roles and Permissions** > and select *Administrator*.
2. On the **Price Adjustment Limits** tab, select the context in which you want to assign permissions.
3. Click **Apply**.
4. To add a limit, click **Add**.
5. On the Add Price Adjustment Limit window, select a type (Item, Shipping, or Order), a currency, and a value.

   Price adjustment limits validation considers only the access roles with price adjustment [permissions](https://developer.salesforce.com/docs/commerce/b2c-commerce/guide/b2c-setting-permissions-for-csc.html) configured. Only price adjustment limits that are assigned to an access role with a specific type of price adjustment permission are considered when a manual price adjustment is validated. The type of price adjustment permission, item, order, or shipping, depends on the type of the manual price adjustment. To prevent all users with access to a role from creating unlimited manual item price adjustments, define price adjustment limits to access roles with an item, order, or shipping price adjustment permission.
6. To change the context, click **Select Context**.

   When you change context from one to multiple sites, for example, you can see unassigned limits.
7. To assign a limit, check the box next to the limit and click **Update**.
8. To unassign a limit, clear the box next to the limit and click **Update**.
9. To revert changes, click **Revert** before you click **Update**.

   When you click **Update**, your changes can't be reverted.
