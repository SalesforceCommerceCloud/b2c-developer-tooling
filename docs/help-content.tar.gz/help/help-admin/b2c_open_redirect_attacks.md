# Open Redirect Attacks in B2C Commerce

_When a web application trusts user input as a redirect destination, an attacker can use that input to redirect users to a website that they control and steal their information._

### How Open Redirect Attacks Occur

An attack works like this.

1. The attacker tricks the customer into visiting a seemingly trustworthy link with a redirect parameter, for example, `myshop.com/?next=evil.com`.
2. The myshop.com site returns the login page to the user.
3. The user enters the username and password for myshop.com.
4. The user logs in to sometrustedshop.com.
5. The browser forwards and redirects the user to evil.com.
6. The attacker steals the user’s credentials.

### How to Mitigate Against an Open Redirect Attack

Consider this vulnerability when you use the Internet Store Markup Language (ISML) template <isredirect> element, or when providing user-entered data directly or indirectly to `dw.system.Response.redirect`.

Follow these best practices.

- Avoid redirects.
- Force local redirects.
- Don’t let users enter the URL as the destination.
- Validate the URL, if you can't avoid user input.
- Map any destination input to a value rather than to the actual URL.
- Create a list of trusted URLs to sanitize input.
- Notify users about the redirect, and ask them to click a link to confirm.
