# Onboard Your Stripe Merchant Account for B2C Commerce

_After you associate a Stripe merchant account with your B2C Commerce instance onboard the account. The Stripe onboarding process collects business information such as names, addresses, and bank accounts. The steps vary based on the merchant account country._

|  |
| --- |
| Available in: **B2C Commerce** |

1. In Business Manager, click App Launcher _(image: App Launcher)_, and then select **Administration > Site > Global Preferences > Salesforce Payments**.
2. Click the Stripe merchant account that you want to onboard.
3. In the Merchant Account Setup section, click **Go to Stripe**.

   The system redirects you to the Stripe site. To complete the onboarding process, follow the instructions on the Stripe site. When the onboarding process is complete, youʼre returned to Business Manager.
