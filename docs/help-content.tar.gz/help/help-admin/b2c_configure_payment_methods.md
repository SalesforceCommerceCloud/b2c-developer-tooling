# Configure Payment Methods for B2C Commerce

_Configure payment methods for each payment zone based on your payment provider, region, and currency configuration. The checkout and express checkout payment methods that you configure appear on the checkout page in your Storefront Reference Architecture (SFRA), Composable Storefront, or Storefront Next site._

Before adding payment methods to a payment zone, make sure that your merchant account has at least one checkout type enabled.

1. In Business Manager, click App Launcher _(image: App Launcher)_, and then select **Merchant Tools > Site > Commerce Apps > App Catalog**.
2. In the Installed Apps section, for Salesforce Payments, click **Manage**.
3. In the Merchant Account card, select a payment zone.

   The payment zone you select determines the available payment methods.
4. To add checkout payment methods, in the Checkout Payment Methods card, select **Add Checkout Payment**.

   _(image: Add a checkout payment method.)_
5. To add express checkout payment methods, in the Express Payment Methods card, select **Add Express Payment**.

   _(image: Add an express checkout payment method.)_
6. Choose which payment methods you want to offer.

   Offer at least one Checkout payment method. You can deselect all Express Checkout payment methods. Your site can use multiple currencies. During checkout, payment is based on the currency of the shopper's basket. See [Multi-Currency Sites in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_multi_currency_sites.htm).
7. Save your changes.
