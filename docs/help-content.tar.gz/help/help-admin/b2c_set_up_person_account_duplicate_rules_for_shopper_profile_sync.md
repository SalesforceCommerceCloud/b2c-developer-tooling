# Set Up Person Account Duplicate Rules for Shopper Profile Sync

_The Shopper Profile Sync feature keeps all registered shoppers in sync between B2C Commerce and the connected Salesforce org. Use matching and duplicate rules in Salesforce to prevent duplicate person accounts when Shopper Profile Sync creates or updates shopper records._

Salesforce recommends using three duplicate rules, each backed by its own matching rule, to make sure that Shopper Profile Sync properly handles person accounts.

- **Registered Shopper Duplicate Rule**: Matches on Commerce Customer Reference and Commerce Organization Reference. This rule identifies a registered shopper's own registered account within a specific B2C Commerce realm by their customer ID.
- **Guest Shopper Duplicate Rule**: Matches on Email, Commerce Group Reference, and Commerce Organization Reference, and only against records with a blank Commerce Customer Reference. This rule surfaces existing guest accounts within the same realm and customer list, and never matches a registered shopper's account—the blank Commerce Customer Reference is what keeps guest and registered shopper records apart.
- **Registered Shopper Claims Guest Shopper Duplicate Rule**: Matches on Email, Commerce Group Reference, and Commerce Organization Reference. This rule lets a newly registered shopper claim an existing guest account within the same realm and customer list so registration can stamp the customer reference onto it.

The matching rules surface candidate records, and then Shopper Profile Sync selects which record to use: an exact reference match first, otherwise the first record with blank reference fields.

You create the three matching rules first, and then select them when you create the corresponding duplicate rules.

1. Log in to your [connected Salesforce org](https://help.salesforce.com/s/articleView?id=cc.b2c_connected_comm_salesforce_connection.htm&language=en_US&type=5).
2. Navigate to **Setup > Data > Duplicate Management > Matching Rules**.
3. Click **New Rule**.
4. For Object, select **Person Account** and click **Next**.
5. Create the Registered Shopper matching rule.

   1. Enter a name. For example, Registered Shopper Matching Rule.
   2. Enter a description. For example, Exact match on Commerce reference fields for registered shoppers.
   3. For Matching Criteria, add Commerce Customer Reference (Exact Match, Match Blank = false) and Commerce Organization Reference (Exact Match, Match Blank = false).
   4. Click **Add Filter Logic** and enter `1 AND 2`.
   5. Click **Save**.
   6. Click **Activate**.
6. From Matching Rules, click **New Rule**.
7. For Object, select **Person Account** and click **Next**.
8. Create the Guest Shopper matching rule.

   1. Enter a name. For example, Guest Shopper Matching Rule.
   2. Enter a description. For example, Email match for guest shoppers within the same realm and customer list, excluding registered shoppers.
   3. For Matching Criteria, add Email (Exact Match, Match Blank = false), Commerce Customer Reference (Exact Match, Match Blank = true), Commerce Group Reference (Exact Match, Match Blank = false), and Commerce Organization Reference (Exact Match, Match Blank = false).
   4. Click **Add Filter Logic** and enter: 1 AND 2 AND 3 AND 4.
   5. Click **Save**.
   6. Click **Activate**.
9. From Matching Rules, click **New Rule**.
10. For Object, select **Person Account** and click **Next**.
11. Create the Registered Claims Guest matching rule.

   1. Enter a name. For example, Registered Claims Guest Matching Rule.
   2. Enter a description. For example, Email match to let a newly registered shopper claim an existing guest account within the same realm and customer list.
   3. For Matching Criteria, add Email (Exact Match, Match Blank = false), Commerce Group Reference (Exact Match, Match Blank = false), and Commerce Organization Reference (Exact Match, Match Blank = false).
   4. Click **Add Filter Logic** and enter: 1 AND 2 AND 3.
   5. Click **Save**.
   6. Click **Activate**.
12. Go to **Data > Duplicate Management > Duplicate Rules**.
13. Click **New Rule > Person Account**.
14. Create the Registered Shopper Duplicate Rule.

   1. Enter a name. For example, Registered Shopper Duplicate Rule.
   2. Enter a description. For example, Duplicate rule for registered shoppers from B2C Commerce.
   3. Under Rule Details, for Record-level security, select **Bypass sharing rules**.
   4. Set the Action On Create to **Allow (no alert, report)**.
   5. Set the Action On Edit to **Allow (no alert, report)**.
   6. For Matching Rules, select the **Registered Shopper Matching Rule** created in step 5.
   7. Under Conditions, add: Commerce Customer Reference NOT EQUAL TO null.
   8. Click **Save**.
   9. Click **Activate**.
   
   _(image: Registered Shopper Duplicate Rule configuration in Salesforce Setup)_
15. From Duplicate Rules, click **New Rule > Person Account**.
16. Create the Guest Shopper Duplicate Rule.

   1. Enter a name. For example, Guest Shopper Duplicate Rule.
   2. Enter a description. For example, Duplicate rule for guest shoppers from B2C Commerce for OMS.
   3. Under Rule Details, for Record-level security, select **Bypass sharing rules**.
   4. Set the Action On Create to **Allow (no alert, report)**.
   5. Set the Action On Edit to **Allow (no alert, no report)**.
   6. For Matching Rules, select the **Guest Shopper Matching Rule** created in step 8.
   7. Under Conditions, add: Commerce Customer Reference EQUALS null.
   8. Click **Save**.
   9. Click **Activate**.
   
   _(image: Guest Shopper Duplicate Rule configuration in Salesforce Setup)_
17. From Duplicate Rules, click **New Rule > Person Account**.
18. Create the Registered Shopper Claims Guest Shopper Duplicate Rule.

   1. Enter a name. For example, Registered Shopper Claims Guest Shopper Duplicate Rule.
   2. Enter a description. For example, Duplicate rule for registered shopper to claim a guest shopper.
   3. Under Rule Details, for Record-level security, select **Bypass sharing rules**.
   4. Set the Action On Create to **Allow (no alert, report)**.
   5. Set the Action On Edit to **Allow (no alert, no report)**.
   6. For Matching Rules, select the **Registered Claims Guest Matching Rule** created in step 11.
   7. Under Conditions, add: Commerce Customer Reference NOT EQUAL TO null.
   8. Click **Save**.
   9. Click **Activate**.
   
   _(image: Registered Shopper Claims Guest Shopper Duplicate Rule configuration in Salesforce Setup)_
