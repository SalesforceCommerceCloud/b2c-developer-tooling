# SiteGenesis Configuration for Salesforce Payments

_With some limitations, add Salesforce Payments to SiteGenesis._

Adding Salesforce Payments to your SiteGenesis instance:

- Adds the Salesforce Payments multi-step checkout functionality to the SiteGenesis Checkout page
- Adds PayPal express checkout to the SiteGenesis Checkout page
- Adds Salesforce Payments express checkout to the SiteGenesis cart
- Adds PayPal express checkout to the SiteGenesis mini-cart

To integrate Salesforce Payments with SiteGenesis, you modify the following B2C SiteGenesis instance components.
