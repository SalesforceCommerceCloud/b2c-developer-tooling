# SiteGenesis Configuration for Salesforce Payments

_With some limitations, add Salesforce Payments to SiteGenesis on your B2C Commerce site._

Adding Salesforce Payments to your SiteGenesis instance:

- Adds the Salesforce Payments multi-step checkout functionality to the SiteGenesis Checkout page
- Adds PayPal express checkout to the SiteGenesis Checkout page
- Adds Salesforce Payments express checkout to the SiteGenesis cart
- Adds PayPal express checkout to the SiteGenesis mini-cart

To integrate Salesforce Payments with SiteGenesis, you modify the following B2C SiteGenesis instance components.

## Related Content

- [SiteGenesis Cartridges](https://help.salesforce.com/s/articleView?id=cc.b2c_cartridges.htm&type=5)
  A cartridge is a mechanism for packaging and deploying program code and data in B2C Commerce. You use cartridges to extend business functionality or integrate with external systems. A cartridge can deliver generic or application-specific functionality.

- [SiteGenesis Controllers](https://help.salesforce.com/s/articleView?id=cc.b2c_controlers.htm&type=5)
  Controllers are server-side scripts that handle B2C Commerce storefront requests. Controllers manage the flow of data in your application, and create ViewModels to process each storefront request as a route and generate an appropriate response. For example, in a storefront application, clicking a category menu item or entering a search term triggers a controller that renders a page.

- [SiteGenesis Models and Views](https://help.salesforce.com/s/articleView?id=cc.b2c_models_and_views.htm&type=5)
  In B2C Commerce SiteGenesis, the controllers integrate into Models and Views. All scripts are Common JS modules with defined and documented exports to avoid polluting the global namespace.

- [SiteGenesis Server-Side Scripts](https://help.salesforce.com/s/articleView?id=cc.b2c_server_side_scripts.htm&type=5)
  Server-side scripts in B2C Commerce SiteGenesis handle client-side requests. All scripts are CommonJA modules with defined exports.

- [SiteGenesis Client-Side Scripts](https://help.salesforce.com/s/articleView?id=cc.b2c_client_side_scripts.htm&type=5)
  Client-side js in B2C Commerce SiteGenesis performs functions that don't require information from the server.

- [SiteGenesis Templates, Forms, and CSS for Salesforce Payments](https://help.salesforce.com/s/articleView?id=cc.b2c_sitegenesis_templates_forms_and_css_for_salesforce_payments.htm&type=5)
  Developers create Salesforce B2C Commerce storefront pages using Internet Store Markup Language (ISML) templates, CSS, and B2C Commerce forms, resulting in HTML that renders on the browser. Use these technologies to customize the look and feel of your storefront.
