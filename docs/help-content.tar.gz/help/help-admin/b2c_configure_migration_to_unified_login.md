# Migrate Users to Unified Authentication via Account Manager

_To let your users log in to their instances via Account Manager, migrate them to Unified Authentication. After you migrate them, users manage only one set of login credentials. To increase security on your instances, use Account Manager's two-factor authentication. This topic applies to B2C Commerce._

|  |
| --- |
| Available in: **B2C Commerce** |

We provide several stages for this migration, to gradually introduce the change to your users. Before beginning migration, we recommend that you export a backup file with your user data. allowlist all hostnames used for Business Manager, even if you've disabled the Permit allowlisted Hostnames Only setting in the security module.

Once your first user migrates to unified authentication, you can't deactivate unified authentication. To revert to local authentication, contact support.

1. In Business Manager, click App Launcher _(image: App Launcher)_, and then select **Administration > Global Preferences > Security** and select the User Authentication tab.
2. Select which migration phase you want for your organization.

   1. No Unified User Authentication
   
      All users log in to their instances using their specific instance login credentials.
   2. Unified User Authentication Supported
   
      Provide power users with a link that lets them link their instance and Account Manager accounts.
   3. Unified Authentication Encouraged
   
      A prompt appears when users log in to their instances, instructing them to link their instance and Account Manager accounts. Users can still log in without linking their accounts.
   4. Unified Authentication Mandatory
   
      A prompt appears when users log in to their instances, instructing them to link their instance and Account Manager accounts. Users can’t log in until they've linked their accounts.
   5. Unified Authentication Only
   
      Users can only log into their instance via Account Manager's login. At this point, you’ve to manually provide a link to any users who haven't linked their accounts.
3. Enter roles that you want all migrated users to automatically have.
4. See the migration status, including how many users have migrated to unified login and what percentage of your users have migrated.
5. Click **Apply**.

## Related Content

- [Manually Migrate Users to Unified Authentication](https://help.salesforce.com/s/articleView?id=cc.b2c_manually_migrate_users_to_unified_authentication.htm&type=5)
  Sometimes users can't link their Business Manager and Account Manager profiles. When the two accounts have different email address, a user can't migrate to unified authentication. However, you can manually migrate the user from Business Manager to Account Manager. This applies for administrators who are manually migrating users to unified authentication. This doesn’t apply to administrators who started using B2C Commerce after October of 2019 because their organizations automatically use unified authentication.

- [Revert Users from Unified Authentication](https://help.salesforce.com/s/articleView?id=cc.b2c_revert_a_user_from_unified_login.htm&type=5)
  With Unified Authentication, your users can log into Business Manager via Account Manager. Unified Authentication streamlines the login process and reduces the number of login credentials the users have. You can't revert migrated users to the Business Manager login using Business Manager. Instead, to revert affected users, export the users, modify the file, and reimport the users. This applies for administrators who are manually migrating users to unified authentication. This doesn’t apply to administers who started using B2C Commerce after October of 2019 because their organizations automatically use unified authentication.
