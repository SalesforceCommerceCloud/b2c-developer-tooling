# Test a PayPal Configuration

_After you integrate a PayPal merchant account with Salesforce Payments and add the PayPal merchant account to your B2C Commerce site, test your configuration in a sandbox._

Before you test your PayPal account, set up your PayPal account for testing.

1. Test the PayPal Buy Now option.

   1. Launch the storefront instance you want to test.
   2. Select a product for purchase, and confirm that the PayPal Buy Now option is active.
   3. Click **PayPal Buy Now**.
   4. Log in to the PayPal buyer account that you set up for testing.
   5. Select the payment method that you set up for testing.
   6. Confirm that the purchase total is correct, and complete the PayPal transaction.
   7. In the Checkout window, confirm that PayPal and the correct PayPal account is listed as the payment method. Click **Place Order**.
   8. In the Order Confirmation page, confirm the products and totals are correct and that PayPal and the correct account is listed as the payment method.
2. Test PayPal with the Multistep checkout option.

   1. Launch the storefront instance that you want to test.
   2. Add a product to the shopping cart.
   3. Click **Checkout**.
   4. In the Checkout window, click **Next: Payment**.
   5. Complete the checkout fields, select PayPal as the payment method, and then complete the transaction.
   6. In the Order Confirmation page, confirm the products and totals are correct and that PayPal and the correct PayPal account are listed as the payment method.
3. For each PayPal payment type, verify that the PayPal buyer account recorded the transaction.

   1. Log in to the PayPal buyer account that you set up for testing.
   2. Confirm that the test transactions are listed and that the totals are correct.
