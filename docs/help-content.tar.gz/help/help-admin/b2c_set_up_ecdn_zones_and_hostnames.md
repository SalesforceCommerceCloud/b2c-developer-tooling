# Set Up eCDN Zones and Hostnames

_Create embedded CDN (eCDN) zones and add the hostnames that route your Salesforce B2C Commerce storefront traffic through the CDN. Use Default Domain for a Salesforce-managed hostname, or add your own custom hostnames and site URL aliases._

Set up eCDN for a storefront by creating a zone, adding its hostnames, and configuring how storefront URLs resolve. The tasks in this section cover each step.

## Related Content

- [Create an eCDN Zone](https://help.salesforce.com/s/articleView?id=cc.b2c_creating_a_zone.htm&type=5)
  The embedded CDN (eCDN) configuration is organized around zones. A zone represents a root or apex domain (for example, `example.com`). A hostname is a subdomain of a specific zone (for example, `www.example.com`). Create a zone in Business Manager to route your B2C Commerce storefront traffic through the eCDN.

- [Add Hostnames to an eCDN Zone](https://help.salesforce.com/s/articleView?id=cc.b2c_adding_hostnames.htm&type=5)
  You can configure subdomains of the same zone on the same Salesforce B2C Commerce instance, or on different instances of different realms of the same retailer.

- [Configure Wildcard Custom Hostnames](https://help.salesforce.com/s/articleView?id=cc.b2c_add_wildcard_custom_hostname.htm&type=5)
  Use a single wildcard custom hostname (for example, `*.merchantsite.com`) to cover multiple subdomains and reduce onboarding and management overhead in B2C Commerce eCDN via Business Manager.

- [Default Domain Support for B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_default_domain.htm&type=5)
  Default Domain is a Salesforce-managed, eCDN-enabled hostname provided for each B2C Commerce instance (development, staging, and production), so you can test without manual DNS, custom domain registration, or certificate management. Use the Default Domain for developer testing, load testing, and preproduction review, whether you're working alongside an existing custom branded domain (for example, www.example.com) or haven't set one up yet.

- [SCAPI Zone Support for B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_scapi_zone.htm&type=5)
  A SCAPI zone is the Salesforce-managed eCDN zone that fronts Salesforce Commerce API (SCAPI) traffic. Starting with B2C Commerce 26.10, the Production instance includes a subset of eCDN security controls and analytics for this zone in Business Manager and the CDN API, with no support case required.

- [Configure Site URL Aliases for .my Domains](https://help.salesforce.com/s/articleView?id=cc.b2c_configure_site_url_aliases_for_my_domains.htm&type=5)
  Prevent cross-origin (CORS) errors after your B2C Commerce storefront moves to the `.my` Default Domain, manually add the `.my` hostname to your site URL aliases file.

- [eCDN Step in Storefront Fast Setup](https://help.salesforce.com/s/articleView?id=cc.b2c_fast_storefront_setup_ecdn.htm&type=5)
  The Storefront Next Fast Setup workflow in Business Manager for B2C Commerce automatically provisions an eCDN Default Domain zone as part of storefront creation via the `SetupEcdnForStorefront` job step.
