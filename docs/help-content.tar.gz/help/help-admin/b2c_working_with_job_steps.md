# Using Job Steps

_The job framework includes some out-of-the-box system steps. When you use system steps in a job flow, no coding is required, although most job steps require that you configure some parameters. If there’s no system step that does what you want to do, have a developer create a custom job step. This topic applies to B2C Commerce._

For details about the system job steps that are available to use in jobs, refer to [B2C Commerce Job Steps](https://salesforcecommercecloud.github.io/b2c-dev-doc/docs/current/jobstepapi/html/index.html).
