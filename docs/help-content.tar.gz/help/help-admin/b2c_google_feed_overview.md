# Catalog Feed Integration with Google

_Syndicate your B2C Commerce product catalog to Google for product discovery, enabling shoppers to find your products in Google Shopping ads and free listings._

The Google catalog feed integration gives B2C Commerce merchants the ability to share their product catalogs with Google. When shoppers search for products on Google, your products can appear in Google Shopping ads and free listings. Shoppers who select one of your products go straight to your storefront's product detail page (PDP) to complete their purchase.

### How the Product Feed Is Generated and Uploaded for Google

The integration uses Commerce Cloud's scheduled job infrastructure to generate a canonical product feed from your catalog currently assigned to the site you are in, informed by merchant mapping of catalog attributes to Google's feed requirements. B2C Commerce uploads the feed to Google's infrastructure using a Secure File Transfer Protocol (SFTP) connection, which is then consumed by Google to enrich the discovery experience in Google Shopping.

> **Important:** You retrieve your SFTP credentials from Google Merchant Center, and then enter them in Business Manager when you connect to Google.

To configure the feed integration in Business Manager, you:

- [Configure General Settings (SFTP credentials and price/image overrides)](https://help.salesforce.com/s/articleView?id=cc.b2c_google_feed_general_settings.htm&type=5)
- [Connect to Google](https://help.salesforce.com/s/articleView?id=cc.b2c_product_feed_connect.htm&type=5)
- [Map B2C Commerce product attributes to Google feed fields](https://help.salesforce.com/s/articleView?id=cc.b2c_google_feed_mapping.htm&type=5)
- [Override default mappings with custom attributes](https://help.salesforce.com/s/articleView?id=cc.b2c_product_feed_custom_attributes.htm&type=5)
- [Configure product filter rules to control which products sync to Google](https://help.salesforce.com/s/articleView?id=cc.b2c_product_feed_product_filter.htm&type=5)
- [Preview the product feed and verify field mappings before turning on the daily sync](https://help.salesforce.com/s/articleView?id=cc.b2c_product_feed_preview.htm&type=5)
- [Turn on or turn off the daily feed sync](https://help.salesforce.com/s/articleView?id=cc.b2c_google_feed_enable.htm&type=5)

You can configure field mappings, product filter rules, and the feed preview on any non-production instance—development, staging, or sandbox—or on production. The SFTP connection and the daily feed sync run only on production instances.

### Managing Products in Google

The product feed sent to Google reflects the products that match your configured product filter rules. By default, the rules match products that are online and searchable, but you can adjust them to fit how your catalog is organized. Manage which products appear in Google in two ways:

- **Adjust the filter rules**: To change the criteria that decide which products are included, configure include and exclude rules in the Product Filter section. See [../product_feeds/b2c_product_feed_product_filter.xml](https://help.salesforce.com/s/articleView?id=cc.b2c_product_feed_product_filter.htm&type=5).
- **Update product data**: To add, remove, or update individual products under the current rules, manage products in the Products and Catalogs section of Business Manager. For example, with the default rules, set a product to offline or not searchable to remove it from the feed.

B2C Commerce automatically excludes master products, variation groups, and product sets from the feed, exporting only individual variant products (SKUs) and standalone products. Variants inherit attribute data from their variation group or master product.

Google treats the latest feed as the source of truth. Changes take effect after the next daily feed sync.

### Tracking Google Traffic

When shoppers click through from Google to your storefront, the referral includes attribution data. Use the Traffic Dashboard in Reports & Dashboards to view Google as a referrer source and measure traffic from this channel.

### Benefits of the Product Feed for Google

The Google catalog feed integration offers these benefits:

- **Increased visibility**: Your products gain increased relevance in the discovery experience through Google Shopping ads and free listings.
- **Increased merchant control**: The Google catalog feed integration provides accurate product data from the merchant directly, rather than from any public website that may be inaccurate, biased, or outdated.
- **New traffic channel**: Drive qualified, high-intent traffic from Google to your storefront.
- **Smart defaults**: Default field mappings reduce configuration time and maximize compliance with Google's product feed requirements, while allowing customization.
- **Flexible mapping**: Map both standard and custom product attributes to ensure the proper data from your catalog is being sent.

### Product Feed Limitations for Google

The following limitations apply to the Google catalog feed integration:

- The integration is available for US sites only.
- Sites must have `en_US` configured as a locale and `USD` configured as a currency. These don't need to be the site defaults.
- Google redirects shoppers to the merchant's PDP for checkout. Shoppers can't complete checkout directly in Google.

### Set Up the Product Feed for Google

First complete the [common product feed setup](https://help.salesforce.com/s/articleView?id=cc.b2c_product_feed_setup.htm&type=5): prerequisites, Einstein configuration, channel partner connection, URL patterns, custom attributes, product filter rules, and feed preview. Then configure these Google-specific settings and turn on the feed:

## Related Content

- [Configure Product Feed General Settings for Google](https://help.salesforce.com/s/articleView?id=cc.b2c_google_feed_general_settings.htm&type=5)
  On the General Settings tab, enter the SFTP credentials that Google Merchant Center provides to connect your store. Optionally, set global overrides for the price and image columns that apply to every row in your feed.

- [Map Product Fields for Google](https://help.salesforce.com/s/articleView?id=cc.b2c_google_feed_mapping.htm&type=5)
  Configure how B2C Commerce product attributes map to Google feed fields using the field mapping interface.

- [Turn On the Product Feed for Google](https://help.salesforce.com/s/articleView?id=cc.b2c_google_feed_enable.htm&type=5)
  Turn on the daily sync to start generating and uploading your B2C Commerce product feed to Google. Before you turn on the daily sync, rigorously review the default field mappings and make any overrides.
