# Set Exit Status Rules for B2C Commerce Jobs

_A B2C Commerce job runs steps that execute various tasks. Set what job steps do when they finish running._

[Which Salesforce Commerce Product Do I Have?](https://help.salesforce.com/s/articleView?id=commerce.comm_what_product.htm)

Before you can set exit status rules, create the job and add its flows and steps. See [Create and Schedule a B2C Commerce Job](https://help.salesforce.com/s/articleView?id=cc.b2c_create_job.htm&type=5) and [Add Flows and Steps for B2C Commerce Jobs](https://help.salesforce.com/s/articleView?id=cc.b2c_add_job_flows_and_steps.htm&type=5).

From the App Launcher _(image: App Launcher)_, find and select **Administration > Operations > Jobs**, and then open the job.

On the job page, click the **Job Steps** tab and open the step.

Job step exit status codes indicate whether a job step has executed successfully.

1. In **Exit Status Rules**, click **Add Rule** for each exit status, and select the action for that status.

   Typically, exit code ERROR indicates that the job step has failed. Exit code OK indicates success. By default, the exit code ERROR maps to the **Stop Job** action. All other exit codes map to the **Continue** action by default. Under **Continue With**, **Next Step** is selected.
2. For each exit status code and * in the **On** field, select an **Action**.

   * is a wildcard that indicates any exit status code without a rule.
   
   - **Stop Job**: No more job steps are executed. The entire job execution has failed. If the step is part of a parallel flow and other steps are still executing in parallel to the failed step, the job execution fails when the parallel steps finish executing.
   - **Stop Flow**: Subsequent job steps in the same flow are skipped and execution continues with the next flow.
   - **Continue**: If there are more steps in the same flow, execution continues with the next step in the flow. If there aren't any more steps in the same flow, execution continues with the next step of the next flow.
   - **Continue With**: Select a step in the same flow. **Next Step** runs the following step.
3. Click **Add Rule** to add another exit status rule.
4. Click **Assign**.
