# Secure Communications in B2C Commerce

_Secure communications are crucial to prevent attackers from reading or changing sensitive information, for example, credit cards, personally identifiable information (PII), and credentials. Within Salesforce B2C Commerce, you can secure these interactions using the following secure protocols._

| Interaction | Between... | Via... |
| --- | --- | --- |
| Storefront | Shoppers and your storefront. | Transport Layer Security (TLS) |
| Business Manager | Users and Business Manager.This interaction is always secured by the site and doesn’t require a separate configuration. | TLS |
| Web Services | Your instance and an external web service. | Simple Object Access Protocol (SOAP) over TLS, HTTPS, Secure File Transfer Protocol (SFTP) |
| File Upload | Your instance and an external system. | WebDAV over TLS (recommended), HTTPS, SFTP |
