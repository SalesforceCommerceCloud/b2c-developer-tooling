# SiteGenesis Templates, Forms, and CSS for Salesforce Payments

_Developers create Salesforce B2C Commerce storefront pages using Internet Store Markup Language (ISML) templates, CSS, and B2C Commerce forms, resulting in HTML that renders on the browser. Use these technologies to customize the look and feel of your storefront._

## Related Content

- [SiteGenesis Templates Modifications for Salesforce Payments](https://help.salesforce.com/s/articleView?id=cc.b2c_sitegenesis_template_modifications.htm&type=5)
  B2C Commerce uses Internet Store Markup Language (ISML) templates to generate dynamic storefront pages. An ISML template consists of standard HTML markup, ISML tags, and script expressions.

- [SiteGenesis Forms Modifications for Salesforce Payments](https://help.salesforce.com/s/articleView?id=cc.b2c_sitegenesis_forms_modifications_for_salesforce_payments.htm&type=5)
  Forms can persist form data during a session and store it in system objects or custom objects. Localize the shippingaddress.xml forms to support PayPal on B2C Commerce SiteGenesis.

- [SiteGenesis CSS Modifications for Salesforce Payments](https://help.salesforce.com/s/articleView?id=cc.b2c_sitegenesis_css_modifications_for_salesforce_payments.htm&type=5)
  CSS styling is a critical element of B2C Commerce SiteGenesis page layout, and definitions.
