# SiteGenesis Templates, Forms, and CSS for Salesforce Payments

_Developers create Salesforce B2C Commerce storefront pages using Internet Store Markup Language (ISML) templates, CSS, and B2C Commerce forms, resulting in HTML that renders on the browser. Use these technologies to customize the look and feel of your storefront._
