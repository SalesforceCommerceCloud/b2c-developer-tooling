# Source Code Object Import/Export in B2C Commerce

_Import and export source code groups and source codes using XML documents formatted with the sourcecode.xsd and promotion.xsd schemas._

### Business Manager Import Location

Import multiple source-codes from an external tool using an XML file format.

*Granularity:* selected source-code groups.

**Online Marketing  >  Import & Export**

### Pipelets

ImportSourceCodes

ExportSourceCodes

*Granularity:* passed source-code groups.
