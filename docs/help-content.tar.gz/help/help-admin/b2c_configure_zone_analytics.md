# Analytics for an eCDN Zone

_View HTTP and security traffic metrics for an eCDN zone, including the Traffic Analysis timeline chart and top statistics, using the Configure Zones interface in Business Manager._

### What's New in Configure Zones Analytics

The Analytics tab in Configure Zones includes new capabilities, not only a move from the legacy Business Manager experience. The Traffic Analysis timeline chart is new and helps you view traffic trends over time for the selected range.

For broader eCDN analytics concepts, see [Analyze eCDN Traffic](https://help.salesforce.com/s/articleView?id=cc.b2c_analyze_eCDN_traffic.htm&type=5).

### Accessing Zone Analytics

To view analytics for a zone:

1. In Business Manager, click the App Launcher, and then select **Administration > Sites > Embedded CDN Settings**.
2. Locate the zone you want to view and select **Configure Zone** from the dropdown menu.
3. Select the **Analytics** tab.

### Analytics tab — Traffic Analysis chart and Top Statistics

_(image: Configure Zones Analytics tab showing HTTP and Security metric toggles, the Traffic Analysis timeline chart displaying request volume over the previous 7 days, and the Top Statistics table with Source IP Addresses, User Agents, and Paths)_
