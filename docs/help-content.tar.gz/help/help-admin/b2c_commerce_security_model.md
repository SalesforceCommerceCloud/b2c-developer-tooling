# B2C Commerce Security Model

_Salesforce B2C Commerce security is a partnership between Salesforce and our B2C Commerce customers. As always, Trust is our #1 value at Salesforce. We’re committed to delivering the highest standard in system availability, performance, and security._
