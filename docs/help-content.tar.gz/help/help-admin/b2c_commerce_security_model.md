# B2C Commerce Security Model

_Salesforce B2C Commerce security is a partnership between Salesforce and our B2C Commerce customers. As always, Trust is our #1 value at Salesforce. We’re committed to delivering the highest standard in system availability, performance, and security._

## Related Content

- [Shared Responsibility Model](https://help.salesforce.com/s/articleView?id=cc.b2c_shared_responsibility_model.htm&type=5)
  Ecommerce sites and platforms are attractive cyber attack targets. Cyber attackers look for locations where they can try to exfiltrate sensitive data, such as credit cards, personally identifiable information (PII), and credentials. The ordering workflow also offers an attractive attack surface for cybercriminals to try to enrich themselves. They can create fake orders, adjust coupons and promotions, and deny service to legitimate customers.

- [Security Managed by Salesforce](https://help.salesforce.com/s/articleView?id=cc.b2c_security_managed_by_salesforce.htm&type=5)
  Salesforce ensures that security is a focus of B2C Commerce development and provides secure development and platform-level security.

- [Security Managed by Customer](https://help.salesforce.com/s/articleView?id=cc.b2c_security_managed_by_customer.htm&type=5)
  Salesforce provides a variety of configurable security controls that authorized administrators can use to secure their instances on the Salesforce B2C Commerce platform. Customers can use additional controls to further customize their security footprint.
