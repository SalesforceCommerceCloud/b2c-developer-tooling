# Audit Log Events

_Account Manager B2C Commerce audit log events are available in Log Center and provide visibility into changes to users, API clients, and organizations._

[Which Salesforce Commerce Product Do I Have?](https://help.salesforce.com/s/articleView?id=commerce.comm_what_product.htm)

Log Center publishes audit log events for all Account Manager activities, including changes to user accounts, API client configurations, organization settings, and role assignments.

Audit events include information about:

- What entity was modified (target)
- Who made the change (actor)
- What type of action occurred (create, update, delete, role assignment)
- When the change was made
- Which organization the change is associated with

For detailed information about accessing and using Account Manager audit log events, including filtering options, common use cases, and Log Center Query Language (LCQL) examples, see [Account Manager Audit Log Events](https://help.salesforce.com/s/articleView?id=cc.b2c_account_manager_log_center.htm) in the Log Center documentation.
