# Import and Export Transaction Handling and Feed Size in B2C Commerce

_B2C Commerce designs standard imports to handle feeds of arbitrary sizes. As with every transactional system, the size of a transaction is bounded. Standard behavior for imports that 's triggered through the Business Manager and triggered when you execute an import pipelet, is to commit after each object._

Modify this behavior for import pipelets. If the import pipelet is embedded in an explicit transaction (transaction boundaries can be defined in a pipeline at transitions), the enclosing transaction commits all changes.

Group imports of different object types (for example, catalog and content data) or other changes in a single transaction. B2C Commerce handles transaction sizes of up to 1,000 business objects. Make sure that the limit isn't exceeded.

We recommend that you use the standard behavior, committing after each object, whenever possible. Try to use this method when importing into a non-production environment. If the import fails (for example, some of the objects are imported and some aren’t), repeat the import. In a Production environment, however, always avoid inconsistencies. If you’re importing to a Staging instance, then replicating to Production isn't possible. Embed the import into Production in an explicit transaction.

## File Size and Transfer Restrictions in B2C Commerce

_B2C Commerce includes file size limits and transfer restrictions._

#### Upload Limits

If you do a WebDAV push into a B2C Commerce instance, the upload limit is 500 MB. But how much you can upload also varies by the speed and quality of your connection. If it takes too long to transfer the file, the connection sometimes times out. Salesforce recommends zipping files for upload. If you have difficulty uploading a file under 500 MB, contact B2C Commerce customer support.

#### Download Limits

If you download into a file, keep file sizes under 200 MB for FTP or WebDAV. The file sizes if you download into a string are much smaller.

#### FTPClient Size Limitations

dw.net.FTPClient now enforces size limits for file fetches. These size limits can be passed in as arguments for dw.net.FTPClient.get() or they can be defaulted.

- The default size for a get operation that returns a string is dw.net.FTPClient.DEFAULT_GET_STRING_SIZE (2 Mb).

- The default for a get operation that creates a local file is dw.net.FTPClient.DEFAULT_GET_FILE_SIZE (10 Mb).

- The maximum download size for a string is dw.net.FTPClient.MAX_GET_STRING_SIZE (10 Mb) and for a file is dw.net.FTPClient.MAX_GET_FILE_SIZE(200 Mb).

> **Note:** The size limitations are for compressed files. The uncompressed files can be much larger.

#### HTTPClient Size Limitations

The HTTP client doesn't have a file size limitation.

####  Restrictions on External XML Entities and the DTD Declaration

For all XML imports (catalog, customer, inventory, and so on) you can't use external XML entities and the DTD declaration. They’ve been deactivated (as of 13.3.3) to prevent XML External Entities (XXE) attacks.

```
<?xml version="1.0" encoding="UTF-8"?> <!DOCTYPE catalog [ <!ENTITY remote SYSTEM "http://remote.apt.vsecurity.org/"> ]>
```

#### Compressed Feeds

XML file sizes can be reduced significantly through compression. Compressed feeds can sometimes help overcome upload size limits and shorten upload and download times on slow network links.

The standard import support files are compressed with the gzip algorithm natively. An explicit gunzip at the instance is unnecessary. Simply provide a file name such as catalog.xml.gz to the import pipelet or select a gzipped file (extension must be .gz) in the Business Manager.

Feeds can be zipped and unzipped (zip compression, not gzip compression) on a single file basis within Import and Export sections in the Business Manager. Also, the Business Manager automatically unzips .zip files during an upload. You can programmatically zip/unzip files via the APIs dw.io.File.zip and dw.io.File.unzip.

#### Static Files

The persistent objects in the catalog and content library are supplemented with static files, typically product images. The static files are stored in the instance file system. The XML feeds contain database objects only. To export and import or download and upload static files, use the WebDAV interface. B2C Commerce also lets you zip/unzip multiple files to reduce the number of download and upload operations via the APIs dw.io.File.zip and dw.io.File.unzip.

#### Size and Runtime Limits

Imports and exports are designed to deal with an arbitrary number of objects in a feed. Some customers work with feeds containing many hundreds of megabytes. The import and export processes support large datasets via chunking techniques, where only the currently processed items exist in memory. While import and export files don't have size limits, size limits sometimes exist for uploading to an instance.

The system imposes a timeout for requests to a B2C Commerce instance. If the application server doesn't respond within five minutes, the web server closes the connection. Large imports or exports, however, typically run longer than five minutes. To avoid a request timeout, insert import/export pipelets in a job pipeline and execute it asynchronously. There are no run-time limits for job pipelines.

### Using WebDAV in B2C Commerce

_Every B2C Commerce instance has both an embedded WebDAV Server and a WebDAV Client._

The WebDAVClient class uses a server implemented on the merchant remote system. WebDAV uses either an HTTP or HTTPS connection. If you use WebDAV and HTTPS, you’re PCI-compliant when transferring files to staging or production instances.

The WebDAV server resets the timestamp for a rename, copy, modify, or create operation to the time and date of the operation for uploaded files and directories.

For a sandbox instance, copy and paste files from a Windows machine into your cartridge. There’s a WebDAV client integrated into the Windows operating system and a WebDAV server integrated into your cartridge.

When you use the WebDAV COPY command to copy a file’s content into itself, the destination is excluded. The destination is excluded because it exists (see the following note). The exclusion prevents a recursive infinite copy that fills the file system.

For example, an attempt to execute a recursive copy of the following structure:

```
folder/path/content
folder/path/content/c1
folder/path/content/c2

cp folder/path/content --> folder/path/content/targetfolder  
```

Results in:

```
folder/path/content
folder/path/content/c1
folder/path/content/c2
folder/path/content/targetfolder/c1
folder/path/content/targetfolder/c2
```

In the example, `targetfolder` doesn’t exist in the destination folder (as is recursively the case).

If a folder of the same name as the destination folder exists in the source, nothing is copied and no error appears. This behavior differs from [https://datatracker.ietf.org/doc/html/rfc4918](https://datatracker.ietf.org/doc/html/rfc4918) Request for Comments (RFC) 4918 webDAV standard where a recursive copy is done as long as it’s possible at the source system.

##### B2C Commerce WebDAV Server and B2C Commerce WebDAV Client Don’t Communicate

Connect to either the WebDAV client or the WebDAV server from any computer wherever WebDAV is installed, except from a B2C Commerce instance. The B2C Commerce WebDAV client can't connect to the B2C Commerce WebDAV server in its own instance or other instances.

WebDAV directories

B2C Commerce offers secure access to certain file system locations via WebDAV. For example:

Cartridges `https://<domain>/on/demandware.servlet/webdav/Sites/Cartridges`

Log files `https://<domain>/on/demandware.servlet/webdav/Sites/Logs`

Security Log files `https://<domain>/on/demandware.servlet/webdav/Sites/Securitylogs`

Import/Export `https://<domain>/on/demandware.servlet/webdav/Sites/Impex`

Troubleshooting

When attempting to access these locations, you could receive an "Access Denied" error. These WebDAV locations enforce an SSL connection to make sure that the transfer of your files is secure. Don’t openly transfer your storefront code (and import files such as orders or customer data) without encryption. When you attempt to connect to these locations unencrypted (http), the B2C Commerce application denies you access. If you’re trying to access the WebDAV locations via a browser, remember to use HTTPS in your URL, which uses SSL and is secure. If you’re attempting to connect via a WebDAV client such as Total Commander, remember to select the SSL option when setting up the connection.

#### WebDAV Timestamp Reset in B2C Commerce

_The WebDAV server resets the timestamp for a rename, copy, modify, or create operation to the time and date of the operation for uploaded files and directories. This reset also applies to a remote unzip operation._

The timestamp reset is important because when the image manager requests an image, it always pulls the latest image available.

### Using FTP in B2C Commerce

_Create an FTP client within your instance using the B2C Commerce script class FTPClient. B2C Commerce also supports secure FTP (sFTP), which is recommended for moving files with sensitive information._

Using FTP to move data between merchant systems and B2C Commerce isn't secure, because the FTP connection isn't encrypted. We don’t recommend using FTP on staging or production systems. The connection isn't PCI-compliant, unless you write custom code to encrypt and decrypt the data before and after transfer.

> **Note:** By default, the FTPclient get method uses the "ISO-8859-1" encoding. However, Use an overloaded version of the method to specify UTF encoding instead.

### Using HTTPS with B2C Commerce

_Make sure that a valid certificate has been purchased and is properly installed on the production or staging system._

Confirm that certificates meet the following requirements:

- Issued by an official trust center
- Expiration date in the future
- Assigned to domain names

Two types of certificates are possible:

- A certificate created by a trusted authority explicitly for the customer (the customer's DNS name at the second level of the certificate chain). This type of certificate requires that only the customer's certificate file is installed.
- A certificate created as a subcertificate of a general certificate owned by a company action as a trusted authority (the customer's DNS name at the third level of the certificated chain). This type of certificate requires that both the customer's certificate file and the certificate file representing the general certificate of the second level is installed.

#### Use the B2C Commerce Certificate on Your Backend System

_For staging, customers can use the B2C Commerce wildcard, self-signed certificate. Generally, we don’t recommend this approach because it's more complicated than other methods of file transfer._

###### To Use the B2C Commerce Self-Signed Certificate:

First, install the certificate on your backend system.

Second, change the host file to the IP of the backend system.

Third, use the Java Framework to create a Trust Manager and override the host name verifier.
