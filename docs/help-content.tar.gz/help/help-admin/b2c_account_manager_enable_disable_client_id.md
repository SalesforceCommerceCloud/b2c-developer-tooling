# Enable and Disable an API Client ID in B2C Commerce

_Account administrators can use Account Manager to enable or disable an existing API client. Disabling a client blocks its access to the APIs without deleting the client, so you can re-enable it later._

[Which Salesforce Commerce Product Do I Have?](https://help.salesforce.com/s/articleView?id=commerce.comm_what_product.htm)

1. Log into Account Manager.
2. Click **API Client**.

   The **API Clients** page opens, showing a list of API clients. For each client, the page shows the API client ID, display name, and status.
3. Click the ID of the API client you want to enable or disable.

   The **API Client** page opens.
4. Modify the value of the **Enabled** field in the **Access Control** section, checking it to enable the API client or unchecking it to disable the API client.
5. Click **Save**.
