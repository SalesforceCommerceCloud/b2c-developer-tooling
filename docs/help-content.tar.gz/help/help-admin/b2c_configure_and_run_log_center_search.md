# Configure and Run a Log Center Search

_Search for messages from system and custom code._

1. Start Log Center.
2. From the Search Tab, select **New Search**.
3. On the left-hand side of the page, set filters to narrow your search.
4. Conduct a search in one of the following ways.

   - To conduct a basic search, enter one or more search terms in the search text field and click the search icon.
   - To conduct an advanced search, click the **LCQL** checkbox next to the search text field. Select one or more query fields and enter query text in parentheses. Press the space bar after a closing parenthesis to select the AND or OR operator. To execute the search, click the search icon.
   
   For more information about the LCQL (Log Center Query Language) syntax used in advanced searches, click the question mark (?) near the search icon.
5. To save the search, click the down arrow next to the search icon and select **Save search**. To retrieve it later, click App Launcher _(image: App Launcher)_, and then select **Search > Manage Saved Searches** from the main menu.

   You can share the URL of a saved search with other users.
6. To configure ongoing notifications for the search, follow these steps.

   1. Click **Enable notification**.
   2. Enter the name of the search.
   3. Select the time interval.
   
      To save the search notification settings without sending any notifications, click **Disable**.
   4. To send a notification every time the search returns any results, select **Always Send Notification**. To only send notifications when the search returns at least some results, set the **Threshold** to that number.
   5. To send a test notification, click the test icon.
