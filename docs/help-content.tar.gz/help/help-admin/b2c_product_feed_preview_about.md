# About the Product Feed Preview

_The Product Feed Preview shows you the resolved feed data, including missing required fields, before you turn on the daily feed sync. Use it to verify your field mappings, identify B2C Commerce products with errors, and download a sample CSV._

The Product Feed Preview is a self-service validation tool on the Catalog tab of the channel configuration page. It applies your field mappings, your product filter rules, and the system-level exclusions to a sample of your catalog, and shows the resulting feed entries. Use the preview to catch field-mapping problems and missing data before B2C Commerce uploads the feed to the channel partner.

### What the Preview Shows

For each product included in the preview, B2C Commerce shows the resolved value for every Channel Field in the feed, which are the same values that the daily feed sync sends to the channel partner. Use the columns in the preview table to spot-check titles, image URLs, prices, availability values, and the channel-specific fields (such as **is_eligible_search** for OpenAI or **included_destination** for Google).

Products with missing or invalid required fields appear with an error icon. Hover over the icon to see which fields are affected, then return to the Field Mapping section to fix them. For the OpenAI feed, see [Map Product Fields for OpenAI](https://help.salesforce.com/s/articleView?id=cc.b2c_openai_feed_mapping.htm&type=5). For the Google feed, see [Map Product Fields for Google](https://help.salesforce.com/s/articleView?id=cc.b2c_google_feed_mapping.htm&type=5).

### Hostname for Non-Production Environments

In non-production environments, product URLs aren't visible in the preview by default. Click **Enter Hostname** and provide the storefront hostname you want the preview to use. After you enter a hostname, B2C Commerce uses it to construct the product URL column for each product (**url** for OpenAI or **link** for Google). The hostname applies to the preview only; it doesn't change how the daily feed sync constructs URLs in production.

In production environments, the hostname is pre-populated from the Host field on the Einstein Status Dashboard, and the product URL column is visible by default. See [Configure Catalog and Order Feeds for Commerce Cloud Einstein Deployment](https://help.salesforce.com/s/articleView?id=cc.b2c_product_feed_configure_einstein.htm&type=5).

### Master Products and Variants

The preview shows master products as expandable rows. Click a master product row to see its variants. The preview shows up to 100 variants per master product. Variants inherit attribute data from their master product unless you override the inheritance with a custom mapping.

> **Note:** B2C Commerce never includes master products themselves in the feed sent to the channel partner. Master products appear in the preview only as containers for their variants.

### What's Excluded from the Preview

If a product you expect to see isn't in the preview, one of the following exclusions applies:

- **System exclusions**: B2C Commerce always excludes master products, variation groups, and product sets. Variants and standalone products appear in the feed.
- **Filter rule exclusions**: Products that don't match your include rules, or that match an exclude rule, aren't shown.
- **Site catalog assignment**: The product isn't assigned to the active catalog for the current site.
- **Variant cap**: Up to 100 variants are shown per master product.
- **Inactive catalogs**: Products in inactive catalogs aren't included.

### Sample CSV Download

To export the resolved feed data for offline review, click **Download Sample**. B2C Commerce generates a CSV file that contains the resolved feed values currently shown in the preview. Error indicators are visible in the preview UI only and aren't included in the downloaded CSV. Use the CSV to share the feed data with stakeholders or to compare resolved values across catalog updates.
