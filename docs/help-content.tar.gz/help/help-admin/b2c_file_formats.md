# File Formats in B2C Commerce

_B2C Commerce only accepts XML import files that conform to B2C Commerce schema files. Older versions of B2C Commerce allowed preprocessing of comma-separated value (CSV) files, but B2C Commerce no longer supports this feature._

Although you can create scripts using the CSVFileReader class to translate between CSV and XML, use a third-party program instead to process .csv files into the required XML format. It's faster and more efficient to transform a file using a .NET or a Java platform with a large amount of memory allocated to the processing.

### B2C Commerce-Produced File Formats

B2C Commerce always exports files in XML format, except for coupon codes, which export to CSV format.

### File Transfer

Before you can import a file, transfer it from a merchant system to a B2C Commerce instance. After you export a file, transfer it from the B2C Commerce instance to your backend system.

Transfer files using WebDAV, FTP, or HTTPS. FTPS (FTP over SSL/TLS) isn't supported for integrating external systems with B2C Commerce.

### Site Import and Export File Format for Import

To create a .zip file for import using Site Import and Export, first create a folder.

Inside the folder, add the xml files you want to import. Make sure the xml files have the standard name for importing objects of that type and conform to the schema for the object type.

Also add a text file that contains version information in the following format: ########################################### # Generated file, do not edit. # Copyright (c) 2022 by Salesforce, Inc. ########################################### 22.5.0

Compress the folder and give it the same name as the folder it contains. If you're using a Mac, compress the folder on the command line and don't use the Compress Folder functionality in the right-click menu. B2C Commerce treats compressed folders as an invalid format.

### Data Validation in B2C Commerce

If you import a file manually through Business Manager, validation of the XML import file against the B2C Commerce schema is automatic. If you create a custom pipeline to import the file, Include the ValidateXML pipelet for the XML import file to be validated.

Most B2C Commerce schemas specify all the elements in the schema as optional. Use this approach to include only the elements you want in each feed. However, no data validation is done to check element dependencies, with a few exceptions.

For example, if you import products and category assignments and the categories referred to in the assignments don't exist, the category assignments are ignored and reported to the log.
