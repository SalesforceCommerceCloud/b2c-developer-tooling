# OCAPI Client Authentication and Authorization in B2C Commerce

_Open Commerce API (OCAPI) provides a RESTful interface that OCAPI clients consume (custom code). So, what about client authentication and authorization for OCAPI?_

### OCAPI Client Authentication

For authentication, an Account Manager administrator provisions a new client in the Account Manager with client credentials. Unlike with user authentication, you can provision OCAPI clients only in Account Manager, which enables them to authenticate against any Business Manager instance in the organization.

### OCAPI Client Authorization

Unlike with global authentication, you specify an OCAPI client's authorization rules in a local Business Manager instance. That instance can have unique authorization rules. If you want the same authorization rules on multiple instances, you manually provision this or, more likely, export from the first instance and import to the second instance. As with user authorization, when you create a client in Account Manager, that client isn’t given any permissions. When they authenticate, they can’t access any OCAPI endpoints. This follows the best practice of deny-by-default.

Unlike with user authorization, OCAPI authorization isn’t role-based. Instead, you configure it as a set of authorization rules and configure it separately for the OCAPI Shop API and for the OCAPI Data API. Specify the rules for a particular site or for all sites on the instance. To follow the principle of least privilege, create several clients, with each client given only the authorization rules they need for their job.
