# Configure Product Filter Rules for the Product Feed

_Add include and exclude rules in the Product Filter rule builder to control which products from your B2C Commerce catalog sync to your product feed for OpenAI or Google._

Before you configure product filter rules, set up the product feed integration for your site:

- [Configure Catalog and Order Feeds for Commerce Cloud Einstein Deployment](https://help.salesforce.com/s/articleView?id=cc.b2c_product_feed_configure_einstein.htm&type=5)
- [Meet the Prerequisites](https://help.salesforce.com/s/articleView?id=cc.b2c_product_feed_prerequisites.htm&type=5)
- [Connect to the Channel Partner](https://help.salesforce.com/s/articleView?id=cc.b2c_product_feed_connect.htm&type=5)

To understand how include and exclude rules combine, see [Product Filter Rules for the Product Feed](https://help.salesforce.com/s/articleView?id=cc.b2c_product_feed_product_filter.htm&type=5).

By default, the rule builder includes one include rule with two preloaded conditions—**Online** = `true` and **Searchable** = `true`—that match the original feed eligibility behavior. Modify, remove, or add to these defaults to control which products sync to your product feed for OpenAI or Google.

Each site maintains its own independent filter configuration.

1. Click App Launcher _(image: App Launcher)_, and then select **Merchant Tools > Site > AI & Social Integrations**, and then select your channel (**OpenAI** or **Google**).
2. Click **Catalog**.
3. Locate the **Product Filter** section.

   The Product Filter section shows the active include and exclude rules. New installations show one include rule with the default **Online** = `true` and **Searchable** = `true` conditions.
4. (Optional) Modify any existing include rule.

   1. To remove a condition, click the delete icon next to it.
   
      For example, to include offline products, remove the **Online** = `true` condition.
   2. To change a condition's value, edit the operator or value field.
5. (Optional) To add an include rule, click **Add Include Rule** and configure the first condition.

   A new rule group appears with an empty condition row.
   
   1. Select a filter type from the dropdown.
   
      Choose from product ID, brand, category, price, inventory, online, searchable, or custom attribute. For the full list of filter types, see [Product Filter Rules for the Product Feed](https://help.salesforce.com/s/articleView?id=cc.b2c_product_feed_product_filter.htm&type=5).
   2. Select an operator and enter a value.
   
      Operators vary by filter type. For example, brand supports equals and not equals; price and inventory support comparisons such as greater than or equal to.
6. (Optional) To require a product to match more than one condition, add more conditions to the same rule group.

   Conditions within a rule group use AND logic—a product matches the group only when all conditions are true.
   
   Example: To include only Nike products priced at $50.00 or more, add a Brand condition with the value `Nike`, and then add a Price condition with the operator `≥` and the value `50`.
7. (Optional) To include products that satisfy any of multiple independent conditions, add another include rule.

   Rule groups use OR logic—a product matching any group is included.
   
   Example: To include both Men's Products and Women's Products, click **Add Include Rule** and add a custom attribute condition `c_groupName = Men's Products`. Click **Add Include Rule** again and add a second condition `c_groupName = Women's Products`.
8. (Optional) To remove products that match specific criteria, click **Add Exclude Rule** and configure the exclude conditions.

   Exclude rules override include rules. A product matching any exclude rule is removed from the feed, even if it satisfies an include rule.
   
   Example: To exclude clearance items, add an exclude rule with the custom attribute condition `c_onSale = true`.
9. Click **Save**.

B2C Commerce saves your filter rules. The next daily feed sync uses these rules to determine which products to include in the product feed.

After you configure filter rules, control how the products that pass those rules appear in each channel:

- **OpenAI**: To control whether products are discoverable in ChatGPT search, configure the **is_eligible_search** field mapping. See [Map Product Fields for OpenAI](https://help.salesforce.com/s/articleView?id=cc.b2c_openai_feed_mapping.htm&type=5).
- **Google**: To control where products appear in Google, such as Shopping ads or free listings, configure the **included_destination**, **excluded_destination**, and **pause** field mappings. See [Map Product Fields for Google](https://help.salesforce.com/s/articleView?id=cc.b2c_google_feed_mapping.htm&type=5).
