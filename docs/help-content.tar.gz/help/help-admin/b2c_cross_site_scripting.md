# Cross-Site Scripting in B2C Commerce

_Cross-site scripting (XSS) enables attackers to inject client-side JavaScripts into a webpage viewed by a targeted user. To prevent malicious attacks through content manipulation, you must properly encode all user-provided content._

For example, pay close attention to how you use the Salesforce B2C Commerce Internet Store Markup Language (ISML) templates and script APIs when dealing with user-entered data.

ISML templates provide two ways to print variable values. You can use `${...}` and replace the ellipsis with the variable to be displayed **or** you can use the `<isprint>` tag.

If you use a script expression such as ${pdict.ProductSearchResult.searchPhrase} in an ISML template, where the content type is set as follows, the script result is automatically HTML encoded.

```
<iscontent type="text/html" charset="UTF-8" compact="true">...</iscontent>
```

However, if you use the same expression in an ISML template that’s included via `<isinclude template=">` and no content type is set in the included ISML snippet, B2C Commerce assumes that the content type *text/plain* and no HTML encoding takes place. This is inconsistent and can lead to XSS problems.

To correct this, you must explicitly set the content type or use `<isprint value="{}"/>` to make sure that you encode the resulting HTML.

Here's an example of an insecure `<isprint>` tag.

`<isprint value="${pdict.ProductSearchResult.searchPhrase}"/>`

Do not use HTML encoding for scenarios. The `isprint` tag has an encoding attribute to encode user-entered data. Here's a secure example of using an `<isprint>` tag.

`<isprint value="${pdict.ProductSearchResult.searchPhrase}" encoding="jshtml"/>`

In summation, use only the appropriate encoding for its respective designed context.
