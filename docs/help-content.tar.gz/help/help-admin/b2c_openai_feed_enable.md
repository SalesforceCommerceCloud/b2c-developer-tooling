# Turn On the Product Feed for OpenAI

_Turn on the daily sync to start generating and uploading your B2C Commerce product feed to OpenAI. Before you turn on the daily sync, rigorously review the default field mappings and make any overrides._

Also make sure that you:

- [Meet the Prerequisites](https://help.salesforce.com/s/articleView?id=cc.b2c_product_feed_prerequisites.htm&type=5)
- [Connect to OpenAI](https://help.salesforce.com/s/articleView?id=cc.b2c_product_feed_connect.htm&type=5)
- [Review and configure field mappings](https://help.salesforce.com/s/articleView?id=cc.b2c_openai_feed_mapping.htm&type=5)

> **Note:** The **Enable Daily Feed Sync** toggle doesn't appear until you connect to OpenAI.

The **Enable Daily Feed Sync** toggle controls whether the Einstein feed generation job generates and uploads your product feed to OpenAI. When turned on, B2C Commerce generates the feed daily and uploads it automatically.

1. Click App Launcher _(image: App Launcher)_, and then select **Merchant Tools > Site > AI & Social Integrations > OpenAI**.
2. Click **Catalog**, and turn on the **Enable Daily Feed Sync** toggle.

When the product feed sync to OpenAI is turned on, the Einstein feed generation job generates your product feed according to its schedule and uploads it to OpenAI via Secure File Transfer Protocol (SFTP).

The job writes the feed to the impex folder as one or more shard files, where each shard contains up to 500,000 products. There's no limit on the number of shards. In the impex folder, the shard files use the naming pattern `catalog-snapshot-<locale>-<timestamp>.shard_<nnn>.csv.gz`, where `<locale>` is the feed locale (such as `en_US`), `<timestamp>` is the feed run time in the format `yyyyMMddHHmmss`, and `<nnn>` is the three-digit shard number (`1`, `2`, and so on). The job also writes a manifest file named `manifest-<locale>-<timestamp>.json` to the same folder that lists every shard file and the total product count.

The job writes the feed files and manifest to the impex folder at `/src/feeds/openai/<site>/`. Delta (incremental) runs write to a `delta` subfolder in the same location. To view the files, in Business Manager, click App Launcher, select **Administration > Site Development > Development Setup**, click **Import/Export**, and then open `src/feeds/openai/<site>/`.

> **Note:** The feed file names in the impex folder differ from the file names that OpenAI receives. When the job uploads the feed over SFTP, it renames each shard to `sf-<tenant>-<site>-snapshot.shard_<nnn>.csv.gz` and adds an empty `__COMPLETE` marker file to indicate that all shards are uploaded. When you review the feed locally, look for the `catalog-snapshot-` file names.

**Manual Review Mode:** To generate and review the feed without uploading it to OpenAI, turn off the **Enable OpenAI Feed SFTP Upload** feature switch. With this switch turned off, the job generates the feed and writes it to the impex folder, but doesn't upload it to OpenAI. Review the `catalog-snapshot-<locale>-<timestamp>.shard_<nnn>.csv.gz` shard files and the `manifest-<locale>-<timestamp>.json` file at `/src/feeds/openai/<site>/`. Once you're satisfied with the feed configuration, turn the switch back on to allow uploads.

To access the feature switch, click App Launcher _(image: App Launcher)_, and then select **Administration > Global Preferences > Feature Switches**. Search for "OpenAI".
