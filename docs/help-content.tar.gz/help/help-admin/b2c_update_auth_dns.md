# Update Authoritative DNS for an eCDN Zone

_Point your B2C Commerce storefront's DNS records at your embedded CDN (eCDN) zone. Get the DNS CNAME record value from the `getZonesInfo` name property or from Business Manager, and then update the record with your authoritative DNS provider._

Complete this task after you upload or create a certificate for your zone and your hostname status is **Active**. If you're migrating a legacy zone to a proxy zone, see [Update Authoritative DNS](https://help.salesforce.com/s/articleView?id=cc.b2c_legacy_update_auth_dns.htm&type=5) instead.

Update the record with whichever provider hosts your authoritative DNS. The steps below use the Cloudflare dashboard as the example; the exact labels differ by provider.

1. Log in to your DNS provider account. This example uses Cloudflare.
2. Search for your zone and select it from the list.
3. On the **DNS** tab, locate the hostname that you want to map.
4. Replace all text after "is an alias of" with the DNS CNAME from Business Manager.
5. In the **Status** column, click the cloud until it shows a gray cloud with the tooltip "DNS Only."

   > **Note:** In Cloudflare, a gray cloud means DNS-only (no proxying). This step shows one of several possibilities. Your experience depends on your DNS provider.
6. Look up the public hostname, including any stacked third-party CDN, and confirm that the CNAME matches the zone target in Business Manager.

If the same root domain is hosted with your DNS provider in a different account, point that DNS at the new zone as well. The root domain (also called the apex domain) is the domain without a subdomain, such as `merchantsite.com` rather than `www.merchantsite.com`. Pointing it at the new zone directs traffic to the new zone instead of the standard (root) zone.
