# Jobs for B2C Commerce

_Jobs automate routine tasks or long-running processes, such as importing and exporting data, replicating data or code, or building a search index. Jobs can use preconfigured system steps, or a developer can create custom job steps. Run jobs manually as needed or schedule them to run at a specific time or on a recurring basis._

A job step tells the job what to do. Each job flow contains at least one step. The job framework includes preconfigured job steps that require no coding for common processes. If there's no system step that does what you need, have a developer create a custom job step.

For details about system job steps, see [B2C Commerce Job Steps](https://salesforcecommercecloud.github.io/b2c-dev-doc/docs/current/jobstepapi/html/index.html).

## Related Content

- [Job Flows](https://help.salesforce.com/s/articleView?id=cc.b2c_job_flows.htm&type=5)
  A flow controls the sequence in which B2C Commerce executes job steps. Every job must contain at least one flow. Each flow must contain at least one step.

- [Job Flow Scope](https://help.salesforce.com/s/articleView?id=cc.b2c_scope.htm&type=5)
  Each flow has a scope, either the entire organization, all B2C Commerce storefront sites, specific storefront sites, or sites that you pass to the job at execution time using the Open Commerce API (OCAPI) data API. Some job steps, such as CreateSitemap, can execute only in the context of a site. Other job steps, such as ExecuteDataReplication, can execute only in the context of the organization. If you try to assign a job step to a flow that has a scope the step doesn't support, the step shows an error.

- [Creating Jobs in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_creating_jobs.htm&type=5)
  Use Business Manager to create a job. We recommend that you use the new job framework to create jobs, but the legacy, deprecated functionality is also available in Business Manager.

- [Run a Job Manually](https://help.salesforce.com/s/articleView?id=cc.b2c_run_job_manually.htm&type=5)
  Execute a B2C Commerce job manually as needed.

- [Managing Jobs](https://help.salesforce.com/s/articleView?id=cc.b2c_job_management.htm&type=5)
  After you create jobs, use B2C Commerce Business Manager to manage them.

- [Legacy Jobs](https://help.salesforce.com/s/articleView?id=cc.b2c_legacy_jobs.htm&type=5)
  We recommend that you use the new job framework to create and manage jobs, but the legacy, deprecated functionality is also available in B2C Commerce Business Manager.
