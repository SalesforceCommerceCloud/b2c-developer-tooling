# Jobs for B2C Commerce

_Jobs automate routine tasks or long-running processes, such as importing and exporting data, replicating data or code, or building a search index. Jobs can use ready-made system steps, or a developer can create custom job steps. Run jobs manually as needed or schedule them to run at a specific time or on a recurring basis._

[Which Salesforce Commerce Product Do I Have?](https://help.salesforce.com/s/articleView?id=commerce.comm_what_product.htm)

The jobs you create are custom jobs. B2C Commerce provides system jobs. A system job ID starts with sfcc-, and those jobs do not appear in the Jobs list.

A job step tells the job what to do. Ready-made system steps cover common processes and need no coding. For the list, see [B2C Commerce Job Steps](https://salesforcecommercecloud.github.io/b2c-dev-doc/docs/current/jobstepapi/html/index.html).

A custom job can use system steps, custom steps, or both. If no system step does what you need, have a developer create a custom job step. In the step list, a custom step's type ID starts with custom. See [Create Custom Job Steps](https://developer.salesforce.com/docs/commerce/b2c-commerce/guide/b2c-custom-job-steps.html).

## Related Content

- [B2C Commerce Job Flows](https://help.salesforce.com/s/articleView?id=cc.b2c_job_flows.htm&type=5)
  A flow controls the sequence in which B2C Commerce executes job steps. Every job must contain at least one flow. Each flow must contain at least one step.

- [Where a B2C Commerce Job Flow Runs](https://help.salesforce.com/s/articleView?id=cc.b2c_scope.htm&type=5)
  Each job flow has a scope: the organization, all storefront sites, specific storefront sites, or sites passed in when the job runs. Some job steps, such as CreateSitemap, can execute only in the context of a site. Other job steps, such as ExecuteDataReplication, can execute only in the context of the organization. If you try to assign a job step to a flow that has a scope the step doesn't support, the step shows an error.

- [Configure B2C Commerce Jobs](https://help.salesforce.com/s/articleView?id=cc.b2c_creating_jobs.htm&type=5)
  Create B2C Commerce jobs with the new job framework. Pipeline jobs from the earlier framework remain in Business Manager.

- [Run a B2C Commerce Job Manually](https://help.salesforce.com/s/articleView?id=cc.b2c_run_job_manually.htm&type=5)
  Execute a B2C Commerce job manually as needed.

- [Enable, Disable, or Delete a Job in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_enable_disable_delete_job.htm&type=5)
  Turn a B2C Commerce job schedule on or off, or delete the job. Turning the schedule off stops automatic runs, and you can still run the job manually.

- [View B2C Commerce Job History](https://help.salesforce.com/s/articleView?id=cc.b2c_view_job_history.htm&type=5)
  View the B2C Commerce job history page to see information about jobs, including status, end time, and duration.

- [Monitor B2C Commerce Job Statistics](https://help.salesforce.com/s/articleView?id=cc.b2c_monitor_job_stats.htm&type=5)
  Monitor the duration and number of executions for B2C Commerce jobs. Filter and sort the statistics.

- [Legacy B2C Commerce Jobs](https://help.salesforce.com/s/articleView?id=cc.b2c_legacy_jobs.htm&type=5)
  A legacy job runs a pipeline and is still available under Jobs (Deprecated). Use the new job framework to create and manage jobs.
