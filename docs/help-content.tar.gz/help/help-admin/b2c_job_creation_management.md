# Jobs for B2C Commerce

_Jobs automate routine tasks or long-running processes, such as importing and exporting data, replicating data or code, or building a search index. Jobs can use preconfigured system steps, or a developer can create custom job steps. Run jobs manually as needed or schedule them to run at a specific time or on a recurring basis._

A job step tells the job what to do. Each job flow contains at least one step. The job framework includes preconfigured job steps that require no coding for common processes. If there's no system step that does what you need, have a developer create a custom job step.

For details about system job steps, see [B2C Commerce Job Steps](https://salesforcecommercecloud.github.io/b2c-dev-doc/docs/current/jobstepapi/html/index.html).
