# B2C Commerce Releases and Deployment Schedules

_Learn when new B2C Commerce functionality appears in Help and in your instances, and where to find release notes and deployment schedules._

Help describes new functionality as soon as a preview release is available. That functionality reaches production instances about two weeks later, when the preview becomes the GA release. Until then, the updated Help doesn't apply to your production instance.

To learn about new features and find links to updated Help topics, see [B2C Commerce Release Notes](https://help.salesforce.com/s/articleView?id=release-notes.rn_b2c.htm).

B2C Commerce has its own deployment schedule that lists the dates the releases become available in your instances. Account Manager follows a separate deployment schedule because it updates independently of B2C Commerce releases.

## Related Content

- [B2C Commerce 2027 Deployment Schedule](https://help.salesforce.com/s/articleView?id=cc.b2c_commerce_2027_deployment_schedule.htm&type=5)
  To uphold our commitment to customer trust and to make sure that our B2C Commerce releases meet our rigorous standards, we deploy the B2C Commerce major releases to customers in phases. See the Deployment table for information about which instances are included in each major release phase.

- [B2C Commerce 2026 Deployment Schedule](https://help.salesforce.com/s/articleView?id=cc.b2c_commerce_2026_deployment_schedule.htm&type=5)
  To uphold our commitment to customer trust and to make sure that our B2C Commerce releases meet our rigorous standards, we deploy the B2C Commerce major releases to customers in four phases. See the Deployment table for information about which instances are included in each major release phase.

- [Account Manager 2027 Deployment Schedule](https://help.salesforce.com/s/articleView?id=cc.b2c_am_2027_deployment_schedule.htm&type=5)
  The Account Manager Deployment Schedule lists all of the planned release dates for 2027.

- [Account Manager 2026 Deployment Schedule and Release Notes Archive](https://help.salesforce.com/s/articleView?id=cc.b2c_am_2026_deployment_schedule.htm&type=5)
  The Account Manager Deployment Schedule lists all of the planned release dates for 2026, including links to past release notes.
