# Creating Import/Export Pipelines in B2C Commerce

_In addition to importing a file, you can also use your import/export pipeline to update search indexes, archive files, and copy bad import files to a specific directory._

Because jobs can't pass parameters to a pipeline, specify the names of files to import in the pipeline itself.
