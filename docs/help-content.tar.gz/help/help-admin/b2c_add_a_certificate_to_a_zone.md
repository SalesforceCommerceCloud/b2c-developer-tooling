# Add an SSL Certificate to an eCDN Zone and Configure DNS Mapping

_Add SSL certificates to your hostnames for Zones, and map DNS values from B2C Commerce to your DNS provider account. Add eCDN managed certificates and self-managed certificates._

When mapping endpoints, keep the following in mind:

- The DNS Request for Comments (RFC) doesn’t support pointing root domains directly to B2C Commerce. When directing root domains to the eCDN CNAME alias, you must use an external service to redirect from the root domain to the subdomain.
- When setting up redirects, make sure to set them up for both HTTP and HTTPS.
- To permanently serve traffic from the root domain (yourcompany.com) instead of a subdomain (www.yourcompany.com), use a DNS-level solution to direct root domains to the eCDN CNAME alias.
- Legacy zones and proxy zones require a valid SSL certificate.

## Related Content

- [Add Managed SSL Certificates](https://help.salesforce.com/s/articleView?id=cc.b2c_add_managed_ssl_certificates.htm&type=5)
  Add eCDN managed SSL certificates to your hostnames for zones, and map your origin endpoints.

- [Add Self-Managed SSL Certificates](https://help.salesforce.com/s/articleView?id=cc.b2c_add_self_managed_ssl_certificates.htm&type=5)
  Add self-managed SSL certificates to your hostnames for Zones, and map your origin endpoints.
