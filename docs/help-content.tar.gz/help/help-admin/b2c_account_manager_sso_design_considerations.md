# Design Considerations

_Keep these design considerations in mind when you integrate B2C Commerce Account Manager and other Salesforce applications with your identity provider._

[Which Salesforce Commerce Product Do I Have?](https://help.salesforce.com/s/articleView?id=commerce.comm_what_product.htm)

## Related Content

- [Provisioning Users in Account Manager](https://help.salesforce.com/s/articleView?id=cc.b2c_account_manager_sso_provisioning_users.htm&type=5)
  The current version of single sign-on (SSO) doesn’t yet support deletion of user accounts between B2C Commerce Account Manager and Salesforce Identity. An Account Manager admin creates a profile and assigns access for each user to applications like Business Manager or Control Center.

- [Bulk Migration or Creation of Account Manager Users](https://help.salesforce.com/s/articleView?id=cc.b2c_account_manager_sso_bulk_migration.htm&type=5)
  An open source tool, Salesforce Commerce Cloud (SFCC)-CI CLI (https://github.com/SalesforceCommerceCloud/sfcc-ci) provides user management bulk actions in B2C Commerce Business Manager and Account Manager.

- [Partners and Single Sign-On to Salesforce](https://help.salesforce.com/s/articleView?id=cc.b2c_account_manager_sso_partners_and_sso.htm&type=5)
  Your company security policies drive partner login through your IDP (Identity Provider). Some IDPs offer guest logins that don’t require a license. Alternatively, your partners can log into B2C Commerce apps with their existing Account Manager credentials.
