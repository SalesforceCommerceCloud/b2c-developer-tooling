# Design Considerations

_Keep these design considerations in mind when you integrate B2C Commerce Account Manager and other Salesforce applications with your identity provider._

[Which Salesforce Commerce Product Do I Have?](https://help.salesforce.com/s/articleView?id=commerce.comm_what_product.htm)
