# Troubleshooting the Omnichannel Inventory Integration

_If you experience any of these problems with your Omnichannel Inventory integration, try these steps. This topic applies to B2C Commerce._

### Warnings Appear at the Top of the Omnichannel Inventory Status page:

These warnings indicate a configuration issue. Contact Salesforce Support.

### Commerce API Issues

Verify that you acquired an appropriate Account Manager token for calling the Commerce API. For example:

```
curl -k --data 'grant_type=client_credentials&scope=SALESFORCE_COMMERCE_API:clientId' --user 'username:password' -X POST 'https://{AccountManagerURL}/dwsso/oauth2/access_token'
```

Check that your URIs correctly use your B2C Commerce realm’s short code in the hostname and your tenant group ID as the org ID. For example:

```
https://{ShortCode}.api.commercecloud.salesforce.com/inventory/availability/v1/organizations/{TenantGroupId}/availability-records/actions
```

### Salesforce Sandbox Org Issues

- Before refreshing a Salesforce sandbox org that’s integrated with a B2C Commerce instance, log a case with Salesforce Customer Support. Support reconnects the refreshed org to your B2C Commerce instance.

### In OCI Cache Enabled Mode, No Cache Status Information Appears for Any Inventory Lists:

Select a single inventory list and try to determine why it isn’t synchronized.

- Verify that the inventory list ID includes only valid characters and exactly matches the External Reference of the associated location or location group.
- Use the Omnichannel Inventory API to check the availability of a known product on that list.

### In OCI Cache Enabled Mode, Cache Status Information Appears for Some, but Not All, Inventory Lists:

Identify whether any of the unsynchronized inventory lists are part of the combined stream. If so, check whether they were added after that stream’s most recent full import.

Select a single inventory list and try to determine why it isn’t synchronized.

- Verify that the inventory list ID includes only valid characters and exactly matches the External Reference of the associated location or location group.
- Use the Omnichannel Inventory API to check the availability of a known product on that list.

### Future Inventory Data for an Individual product record Seems Incorrect:

Remember the calculation of visible future values for a product inventory record in B2C Commerce. The displayed future quantity is the sum of all future quantities for that product, but the future date is the date of its earliest future quantity.

### Reservations Exist for products That Aren’t in Omnichannel Inventory:

Check the inventory lists for the associated order product lines. If the **Default in Stock** setting is on, then this behavior is expected.

### Availability Data Import Doesn’t Work:

Check the format of your import data file.

- Separate the top-level entries with line feeds, not commas. Put each entry on a single line.
- When the system reads a location entry, it assigns the subsequent inventory entries to that location until it reads another location entry.
- For each location entry, specify `"mode":"UPDATE"`.
- Each inventory record entry requires a unique recordId. Best practice is to use a universally unique identifier (UUID). The recordId protects against importing duplicate data.
- Each inventory record entry requires an effectiveDate.
- Each futures entry requires a nonzero quantity and a future expectedDate.
- The system only creates or updates entries that 's included in the data. It doesn’t delete entries that 'sn’t included. However, if an included entry has an empty value, the system deletes that value.
- When using the Connect API, the import file size limit is 10 MB. Use JSON format. For larger data sets, use the headless Commerce API or split the data into multiple files.
- When using the headless Commerce API, the import file size limit is 100 MB. For larger data sets, compress the file using GZIP or split the data into multiple files.

### Availability Data Values Seem Incorrect:

Use the following questions as a guide. If you contact Salesforce Support, provide the relevant answers.

- Inventory Lists:
   
   - Does the ID match the External Reference of the associated location or location group?
   - Does the correct Location Type appear? The integration automatically sets it to **Location**, **Group**, or **N/A**.
   - If Default In Stock is on, are any products not defined in Omnichannel Inventory? Default In Stock treats undefined products as always available.
   - In Business Manager, on the Omnichannel Inventory Integration Status page, when was the Last Cache Update for the list?
- Product Inventory Records:
   
   - Are the SKU and Product Type set correctly?
   - Is the product part of a bundle or set?
   - In Omnichannel Inventory, is the product inventory record defined correctly? (Use the Omnichannel Inventory API to get the data.)
   - In Omnichannel Inventory, does the product inventory record have Safety Stock defined? The safety stock isn’t visible in B2C Commerce, but is considered in Available To Fulfill (ATF) and Available to Order (ATO) calculations. In B2C Commerce, the values are Stock Level and Available To Sell (ATS). For example:
      
      - Omnichannel Inventory Product Record: Allocation=10, Futures=2, Safety Stock=1, Reserved=5
      - ATF/Stock Level: Allocation - Safety Stock - Reserved = 10-1-5 = 4
      - ATO/ATS: ATF + Futures = 4+2 = 6
   - Does B2C Commerce contain any unplaced orders in Created status that are older than 30 days? If so, do any of them include the product? In that case, failing those orders can resolve the issue.
      
      > **Note:** To avoid this issue, use the **Auto-Fail Orders** setting in the site Order Preferences.
- Baskets and Orders:
   
   - Does your implementation request temporary inventory reservations for baskets? Remember that they’re included in availability calculations.
   - Which orders include incorrect products? What are their numbers and statuses? Remember that canceling an order cancels its inventory reservations.

### To Pause or Turn off the Integration:

If you experience serious issues with the integration, or want to disconnect your B2C Commerce instance from Omnichannel Inventory, log a case with Salesforce Customer Support. Before doing so, consider these recommendations:

- Plan to identify which inventory reservations are made in each system and handle them appropriately.
- If you plan to turn on the integration again, maintain the Omnichannel Inventory data import processes. To keep the data cache up to date when you turn the integration back on, keep them active.
