# B2C Commerce Sites and Storefronts

_In B2C Commerce, a site is the application and associated code that runs a storefront. A storefront is the user's online experience. A site can have multiple storefronts with different URLs for different brands, locales (with currency and tax differences), or multiple channels. If you’re referring to a specific URL, B2C Commerce uses the term storefront._

### Site Architecture Scenarios

When designing your site, your architect must consider the following:

- The geographical relationship between storefronts and the teams that maintain them
- Data shared between sites, such as product data, tax and payment information, user roles and permissions, promotions, or application code
- Whether the storefront must be localized for different market locales or restructured for them
- Data that remains separately controlled due to corporate structure or legal requirements
- Whether customer, basket, or transaction data carries over from one storefront to the next
   
   Example: An apparel retailer lets customers shop simultaneously at both their adult and children's sites. But a retailer with two different customer bases, such as a book publisher for religious books and fantasy fiction, can prevent crossover.

### One Site, One Storefront

The simplest scenario is one site and one storefront that it supports.

### One Site, Multiple Storefronts

If you have many storefronts and a single team maintaining them, manage them more easily as a single site, even if the products are different for each site. Similarly, to share baskets between storefronts, the storefronts must be part of a single site. If you’re deploying many localized sites with similar branding and products, it's faster and easier to manage new storefronts as an extension of an existing site.

### Multiple Sites, Multiple Storefronts

You can have multiple sites, each of which supports multiple storefronts. You can also choose to share site data, such as customer data, between sites.

### Site Definition

A live site is defined as a listing in the Manage Sites screen on the merchant's production instance of Business Manager with a status set to Online, not including those sites with other statuses or sites that 's been deleted.
