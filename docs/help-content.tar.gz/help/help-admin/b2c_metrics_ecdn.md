# Embedded Content Delivery Network (eCDN) Metrics

_HTTP traffic metrics help website administrators, DevOps teams, and security professionals monitor and optimize performance, security, and resource utilization. These eCDN metrics are crucial for optimizing website performance, security, and reliability. By actively monitoring these metrics, website administrators can detect issues early, enhance caching efficiency, reduce costs, and improve the user experience._

### eCDN Metrics on On-Demand Sandboxes (ODS)

Log Center shows HTTP status codes `502`–`530` from the eCDN layer for ODS zones, the same as for production environments. Use these metrics to monitor traffic, detect anomalies, and troubleshoot issues on ODS instances.

Because ODS uses a shared zone model, metrics reflect aggregate traffic across all ODS instances in the realm rather than per-instance traffic. To narrow results to a specific instance, apply a site context filter in the analytics dashboard — each error type then appears per site.

_(image: eCDN metrics dashboard for an ODS zone showing Success and Errors, Cache Hit Percentage, and Total Requests charts over a one-day period.)_

_(image: eCDN metrics dashboard for an ODS zone with a tooltip showing data point details on the Success and Errors chart.)_

### Success and Errors

The Success and Errors metric tracks the number of successful HTTP requests (`2XX` status codes) and error requests (`4XX` and `5XX` status codes).

- `2XX` (Success): Indicates that the request was successfully received, understood, and processed by the origin or Cloudflare cache.
- `4XX` (Client Errors): Indicates issues with the client request, such as bad request, unauthorized, forbidden, or not found.
- `5XX` (Server Errors): Indicates failures at the origin server, including internal server errors, bad gateway, and service unavailable responses.

Use cases:

- To monitor website reliability, track the ratio of successful to failed requests.
- Identify client-side issues, such as broken links leading to `404` errors.
- Detect server-side failures that require action, such as origin downtime or misconfigurations.
- To improve API reliability, ensure minimal `5XX` errors for API consumers.

### Cache Hit Percentage

The Cache Hit Percentage metric measures the percentage of requests served directly from eCDN cache instead of the origin server. A higher percentage indicates effective caching, reducing load on the origin server.

Use cases:

- To optimize performance, increase cache hit ratios and reduce origin server load.
- Reduce bandwidth costs because serving content from eCDN cache avoids repeated origin requests.
- Identify cache configuration issues where expected assets, such as static files, aren’t being cached properly.
- To improve content delivery, ensure frequently accessed content remains in eCDN cache for faster load times.

### Total Requests

The Total Requests metric is the total number of HTTP(S) requests received by eCDN for a domain, including cache hits and misses.

Use cases:

- Monitor traffic trends to understand spikes or drops in website visits.
- To analyze DDoS threats, detect sudden surges in requests.
- To evaluate marketing campaign effectiveness, correlate traffic spikes with campaigns.
- To monitor API usage, track request counts on API endpoints.

### Total Bandwidth

The Total Bandwidth metric measures the total amount of bandwidth used by all requests, including cache hits and misses. This metric tracks how much data is transferred between users and eCDN, or between eCDN and the origin.

Use cases:

- To optimize bandwidth costs, increase cache hit rates and use compression (Brotli, Gzip).
- Detect unusual traffic patterns that can indicate abuse, such as scraping or bot attacks.
- To plan for scalability, monitor bandwidth consumption trends over time.
- To reduce load on the origin server, optimize content delivery through eCDN caching and compression.

### Total Page Views

The Total Page Views metric measures the total number of page views received. A page view is counted each time a user loads a page.

Use cases:

- To analyze user engagement, track the number of pages viewed over time.
- Correlate with marketing efforts to evaluate the success of promotions or SEO strategies.
- Monitor bot activity if there are unusually high page views from non-human traffic.
- Compare with unique visitors to determine how many pages each visitor views on average.

### Unique Visitors

The Unique Visitors metric measures the total number of distinct users who have accessed the website over a given period. eCDN typically identifies unique visitors using IP addresses and cookies.

Use cases:

- To measure actual audience size, distinguish individual users from repeat visits.
- To analyze visitor retention, compare unique visitor counts over different periods.
- Detect anomalies in traffic patterns, such as bot activity or sudden increases in new visitors.
- Understand geographic distribution of visitors for localization and content targeting strategies.
