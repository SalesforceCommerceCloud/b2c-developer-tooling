# Enforce HTTPS for B2C Commerce

_Enable the Enforce HTTPS setting to redirect incoming page requests that use HTTP to HTTPS. Configure the setting per site or for all sites of an instance. When you enable Enforce HTTPS globally, you can't configure it at the site level. If you disable the global preference, the site-specific settings return to their previous values. This topic applies to B2C Commerce._

When you enable Enforce HTTPS as a global preference, you also enable some behaviors that don’t activate when you select Enforce HTTPS for a site:

- The server can set the Secure flag for cookies. Some modern browsers require cookies to be marked with the Secure flag when certain cross-site behavior is requested (the SameSite cookie attribute is set to None). The Secure flag signals the browser not to send the cookie over an unencrypted HTTP connection. The browser doesn’t send the cookie over an HTTP channel. For details about this behavior, search for information about *cookie attribute SameSite=None*.
- The storefront uses secure session cookies instead of a combination of session cookies and secure tokens to avoid incorrect (false positive) session hijacking detections.
- HTTP requests to Open Commerce API (OCAPI)'s session bridge aren't accepted.

> **Important:** Enable the global Enforce HTTPS preference to let browsers send cookies with cross-site requests. If you don’t enable the global Enforce HTTPS preference, cross-site scenarios fail with some modern browsers.

When Enforce HTTPS is enabled for a site (either at the global or site level), URL generation for that site always uses HTTPS. Hard-coded and absolute URLs are unaffected, so if you enable the setting for a site where the setting was previously disabled, make sure that you change hard-coded or absolute URLs in your HTML appropriately. You don't need to change the URLUtils method. URLUtils.http generates URLs with the HTTPS protocol.

### Benefits of Enabling Enforce HTTPS

HTTPS prevents intruders from passively listening to communications between your website and your users. Other reasons to enforce HTTPS include:

- Users expect a private and secure online experience while visiting your site.
- Some updates, such as HTTP/2, are supported only over HTTPS and only in some browsers.
- Sites can get a boosted search ranking when using HTTPS because Google uses HTTPS as a ranking signal.
- Google Analytics blocks HTTPs-to-HTTP referral data.

### Online Impact

After you enforce HTTPS, you can initially experience a drop in organic search traffic. According to Google, fluctuations in organic search traffic can occur with any significant site change. Your page rank, or *link juice*, however, isn't negatively affected by HTTP to HTTPS redirects. According to Google, during 301 or 302 redirects from HTTP to HTTPS, no page ranking is lost.

Search keywords in Google Analytics don't change with HTTPS. You can still see the search queries in the Google Search Console.

To view how many HTTPS pages Google indexed, you can verify HTTP and HTTPS separately in the Google Search Console. You can also use Index Status for a broad look or check the sitemaps indexed counts for sitemap URLs.

The timing of the change from HTTP to HTTPS within the Google index depends on the size of your site and the speed of crawling. Moving from HTTP to HTTPS URLs in Google's search index takes place on a per-URL basis. Google doesn't provide fixed-crawl frequency data.

### robots.txt File

HTTPS sites use a robots.txt file, so when you enable Enforce HTTPS, confirm the following.

- The `robots.txt` is reachable or serves a 404 result code.
- The `robots.txt` file isn't blocking HTTPS URLs.
- The `robots.txt` file contains no references to XML sitemaps using absolute URLs with HTTP.
