# SiteGenesis Controllers

_Controllers are server-side scripts that handle storefront requests. Controllers manage the flow of data in your application, and create ViewModels to process each storefront request as a route and generate an appropriate response. For example, in a storefront application, clicking a category menu item or entering a search term triggers a controller that renders a page._

To support the Salesforce Payments functionality in SiteGenesis, you add or modify the following controllers to modify Checkout, Cart, Mini-Cart, and Product Detail Pages.

**Controller Modifications**

`Cart.js–Controller that adds and removes products and coupons in the cart. Also provides functions for the continue shopping button and minicart.`

- Add the `paymentHelpers` script from `plug-in_commercepayments`
- Use it to create a payment request, and support data for express checkout in the mini cart

`COBilling.js–Controller for the billing logic. It’s used by both the single shipping and the multishipping functionality and is responsible for payment method selection and entering a billing address.`

- Use to remove credit card and other payment information from the billing step (checkout page two)

`COSsummary.js–Controller that implements the last step of the checkout. A successful handling of billing address and payment method selection leads to this controller. It provides the customer with a last overview of the basket before confirming the final order creation.`

- Use to remove validation of payment information no longer provided on the billing step
- Use to create a payment request to present multi-step checkout on the summary step (checkout page three)
