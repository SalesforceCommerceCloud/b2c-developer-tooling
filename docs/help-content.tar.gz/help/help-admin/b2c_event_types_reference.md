# B2C Commerce Event Types Reference

_Find the event you want to subscribe to. Each row links to the page that documents the headers, payload, and example for that event._

The B2C Commerce eventing framework supports replication events, a shopper registered event, and an order placed event. Custom events that you declare in a cartridge are documented separately in [Custom Events](https://help.salesforce.com/s/articleView?id=cc.b2c_event_custom.htm&type=5). Use this table to find a platform event, then go to the linked page for its payload reference.

### Shared references

The following pages apply to multiple event types.

- [Common HTTP Headers](https://help.salesforce.com/s/articleView?id=cc.b2c_event_common_headers.htm&type=5) — the standard `x-sf-cc-*` headers included with every event.
- [Replication Group IDs](https://help.salesforce.com/s/articleView?id=cc.b2c_event_replication_groups.htm&type=5) — the organization, site, and repository group identifiers used in replication event payloads.
- [Replication Error States](https://help.salesforce.com/s/articleView?id=cc.b2c_event_replication_error_states.htm&type=5) — the `errorState` values reported by failed process-level replication events.
