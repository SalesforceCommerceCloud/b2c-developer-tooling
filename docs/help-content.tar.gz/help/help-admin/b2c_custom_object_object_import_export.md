# Custom Object Import/Export in B2C Commerce

_Gain a better understanding of the elements in the customobject.xsd and considerations when creating values for them. This topic applies to B2C Commerce._

### Business Manager Import Location

*Granularity:* selected custom objects.

**Custom Objects > Import & Export**

### Pipelets

ImportCustomObjects

ExportCustomObjects

*Granularity:* passed custom objects.
