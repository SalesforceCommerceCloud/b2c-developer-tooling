# Create a Rate Limiting Rule for an eCDN Zone

_Configure a rate limiting rule to specify rate limits for requests that match a particular expression and then perform an action when requests reach those rate limits. Rate limiting rules improve B2C Commerce storefront availability, target specific traffic patterns and combat threats, such as bots._

> **Note:** Rate limiting rules are available on SCAPI zones. There's one SCAPI zone for Development, Staging, and Production. Configure it only from the Production instance. It doesn't appear in Business Manager or the CDN API on Development or Staging. Scope every rule by the org ID in the URL path so that it doesn't affect other environments. See [SCAPI Zone Support for B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_scapi_zone.htm&type=5).

1. In Business Manager, click App Launcher _(image: App Launcher)_, and then select **Administration > Sites > Embedded CDN Settings**.
2. Locate the zone you want to configure, and select **Configure Zone** from the dropdown menu.

   _(image: Embedded CDN Settings zone list with Configure Zone selected from the zone actions menu)_
3. From the Security Rules tab, click **New Rate Limiting Rule**. To switch to a different zone from this tab, select another name from the **Zone** dropdown.

   _(image: Security Rules tab showing Custom Firewall Rules with New Custom Rule and Rate Limiting Rules with New Rate Limiting Rule)_
4. Enter a **Rule Name**. For example, "Rate limit requests from user_agent_x."

   _(image: New Rate Limiting Rule form with Rule Name, Field, Operator, Value, Set Rate Limit, Also apply rate limiting to cached assets selected, Matching Characteristics, and Choose action)_
5. (Optional) If you want the rule to be active when you save it, select **Enable Rule Upon Saving**. If you’re not ready to activate the rule yet, you can create it first. When you’re ready, return to the Security Rules tab and enable your rule from the list.
6. Use the visual dropdown interface to enter the rule expression: select a **Field** and an **Operator**. If the field uses a **Value**, then select or enter it. To add conditional logic, use the **And** or **Or** buttons. To manually enter the expression, click **Edit Expression**.

   To match verified bots or leaked credentials, select one of these fields.
   
   - **Known Bot**
   - **Verified Bot Category**
   - **Authentication Detected**
   - **Username Leaked**
   - **Password Leaked**
   - **Username and Password Leaked**
   - **Similar Credentials Leaked**
   
   Boolean fields, such as **Known Bot** and the leaked credentials fields, don't include a **Value**. Select **is** or **is not**. If the field matches the request, then the rule action applies. For **Verified Bot Category**, select an operator such as **is in**, then select a category from **Value**.
   
   **Known Bot** and **Verified Bot Category** aren't Bot Score or other Cloudflare Bot Management fields. Bot Score and the `cf.bot_management.*` fields require your own Cloudflare setup (orange-to-orange, or O2O) and a Cloudflare Bot Management entitlement.
   
   _(image: New Rate Limiting Rule named Leaked Credentials Check Rate limits with Field set to Username and Password Leaked, Operator set to is, and Value empty)_
7. In **Set Rate Limit**, enter the number of **Requests** and select a **Period**.
8. (Optional) To control whether cached asset requests count toward the rate limit, use the **Also apply rate limiting to cached assets** checkbox.

   The checkbox is selected by default. When the checkbox is selected, the rule counts cached asset requests and requests that reach your origin server. This default helps prevent content scraping, protect intellectual property, and block distributed denial-of-service (DDoS) attacks that target the edge. Deselect the checkbox so that the rate limit applies only to non-cached requests.
9. (Optional) To define the request criteria that you want to rate limit, select **Use Custom Counting Expression**. This parameter defines when to increment the rate counter, which tracks the number of requests per period. When the rate counter exceeds the defined requests per period limit, the rule executes its action.

   1. If the counting expression isn’t provided, the counting expression is the same as the rule expression.
   2. The counting expression supports the option to rate limit based on HTTP response code, which isn’t possible using only the rule expression. For more examples of when to use a custom counting expression, see [Rate Limiting Rules FAQ](https://developer.salesforce.com/docs/commerce/commerce-api/guide/cdn-rate-limiting-rules.html#rate-limiting-rules-faq) in the *B2C Commerce API Developer Guide*.
10. Under **Matching Characteristics**, select a characteristic from **Field** to determine how incoming requests are grouped into rate counters.

   Requests with the same values for the defined characteristics are grouped together and share a rate counter.
   
   - **IP** — Group requests by source IP address.
   - **IP with NAT support** — Group requests by source IP address with network address translation (NAT) accounted for.
   
   For example, if you use **IP** as the rule’s characteristic and the rate of requests from a single IP address exceeds the defined limit, further requests from that IP address are rate limited. Requests from other IP addresses don’t share the same rate counter, so the request rate of one IP address doesn’t affect the request rate of other IP addresses.
11. From **Choose action**, select an action. For example, **Block** or **Log**.

   For more information, see [Rule Actions](https://developer.salesforce.com/docs/commerce/commerce-api/guide/cdn-zones-custom-rules.html#rule-actions) in the *B2C Commerce API Developer Guide*.
   
   To monitor matching traffic before you enforce a challenge or block, select **Log**. After you review the results, change the action.
12. Define how the action applies.

   - **Action for Selected Duration** — After the rate limiting criteria are met, the action applies to further requests matching the rule expression for the period you specify. Select a duration from the dropdown menu.
   - **Throttle Requests over Maximum Configured Rate** — Requests that exceed the configured maximum rate are throttled. The chosen action applies to those excess requests, while requests within the limit are still allowed.
13. Click **Save**.

Bot and Leaked Credentials Expression Fields When you author a rule expression in Business Manager, select these fields. The same fields are available for custom firewall rules and rate limiting rules. **Known Bot** (`cf.client.bot`) — Boolean. True when the request is a verified search-engine crawler (Googlebot, Bingbot, and so on). Returns the same result as `cf.bot_management.verified_bot` but, unlike the `cf.bot_management.*` fields, doesn't require a Cloudflare Bot Management entitlement. Use **Known Bot** for verified bot detection. **Verified Bot Category** (`cf.verified_bot_category`) — String. Identifies the purpose or type of the verified bot and, like **Known Bot**, is available without a Cloudflare Bot Management entitlement. Select a category from **Value**, such as Search Engine Crawler or AI Crawler. Use an operator such as **is in** to match one or more categories. **Authentication Detected** (`cf.waf.auth_detected`) — Boolean. Cloudflare detects authentication material on the request. **Username Leaked** (`cf.waf.credential_check.username_leaked`) — Boolean. The submitted username appears in a known leak. **Password Leaked** (`cf.waf.credential_check.password_leaked`) — Boolean. The submitted password appears in a known leak. **Username and Password Leaked** (`cf.waf.credential_check.username_and_password_leaked`) — Boolean. The exact username and password pair appears in a known leak. **Similar Credentials Leaked** (`cf.waf.credential_check.username_password_similar`) — Boolean. A similar version of the username and password credentials detected in the request was previously leaked. Boolean fields such as **Known Bot** and the Leaked Credentials Detection fields don't include a **Value**. Select **is** or **is not**. If the field matches the request, then the rule action applies. **Known Bot** and **Verified Bot Category** aren't Bot Score or other Cloudflare Bot Management fields. Bot Score and the `cf.bot_management.*` fields require your own Cloudflare setup (orange-to-orange, or O2O) and a Cloudflare Bot Management entitlement. Pair **Known Bot** and **Verified Bot Category** with a custom robots.txt file. Publish crawl policy for AI crawlers in robots.txt, then enforce it with a custom firewall or rate limiting rule. See [Generate a Robots.txt File with Business Manager for B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_generating_a_robots_txt_file.htm&type=5). Leaked Credentials Detection inspects credentials submitted in login requests. For headless and API logins (SLAS and OCAPI), it scans the `Authorization` header for HTTP Basic Authentication credentials. For browser-based form logins (SFRA `/Account-Login` and storefront `/login`), Salesforce registers a custom detection location on the zone so that the same fields populate for those form logins. Apply the leaked credentials fields on SFRA `/Account-Login`, storefront `/login`, OCAPI login endpoints, and SLAS login (for example, `/shopper/auth/v1/organizations/{organizationId}/oauth2/login`). These fields cover the classic storefront login form and headless integrations. For OCAPI or SLAS logins, a challenge page isn't presented to the shopper. Handle the API response so the shopper receives instructions to reset their password. Rate limit high-volume login POSTs but allow verified search crawlers through. Set 10 requests per 60 seconds per `ip.src`, with the `managed_challenge` action. (http.request.uri.path contains "/Account-Login" and http.request.method eq "POST" and not cf.client.bot) **Rate Limit Login Requests After Leaked Credentials** Use Leaked Credentials Detection as a trigger for rate limiting on a path such as `/Account-Login`. After an IP submits leaked credentials that meet the threshold, issue a managed challenge to all subsequent login requests from that IP for the selected duration, whether those later requests contain leaked credentials. This rule issues a **Managed Challenge** to all `/Account-Login` POST requests for 1 hour from an IP address that submitted two leaked credentials in the last minute. **Rule Name**: Rate Limit Leaked Credentials **Enable Rule Upon Saving**: selected **Set Rate Limit**: 2 **Requests** per **Period** of 1 minute **Use Custom Counting Expression**: selected **Matching Characteristics**: IP with NAT support **Choose action**: **Managed Challenge** **Action for Selected Duration**: 1 hour Rule expression: (ends_with(http.request.uri.path, "/Account-Login") and http.request.method eq "POST") Counting expression (include the login path and POST method so that leaked-credential submissions on other endpoints don't increment this counter): (ends_with(http.request.uri.path, "/Account-Login") and http.request.method eq "POST" and cf.waf.credential_check.username_and_password_leaked)

After you create the rule, it appears in the list of Rate Limiting Rules on the Security Rules tab. From the list, you can turn the rule on or off (if you selected **Enable Rule Upon Saving**, your rule is on by default). The Rate Limiting Rules list also shows the number of requests that matched each rule in the past 24 hours. Click this number to view detailed traffic analytics. See [Analyze HTTP and Security Traffic for an eCDN Zone](https://help.salesforce.com/s/articleView?id=cc.b2c_analyze_eCDN_traffic.htm&type=5)
