# Create a Custom Hostname with a Custom Certificate

_When you migrate a legacy zone to a proxy zone, a certificate is automatically created with the validation method set to "http". If you need a different validation method, delete the generated certificate and add a custom one. Create the custom certificate in Business Manager for B2C Commerce or use the `addCertificateForZone`API._

1. In Business Manager, click App Launcher _(image: App Launcher)_, and then select **Administration > Sites > Embedded CDN Settings**.
2. Select the proxy zone from the hostnames list and click **Certificate**.
3. On the Crypto tab, select a zone from the list.
4. Click the **settings icon** on the certificate you want to update.
5. Select **Self-Managed Certificate**.
6. Paste the certificate and private key information from your Certificate Authority provider.
7. Select the hostname to assign the certificate to.
8. Click **Update Certificate**.

   _(image: Update self-managed certificate.)_
