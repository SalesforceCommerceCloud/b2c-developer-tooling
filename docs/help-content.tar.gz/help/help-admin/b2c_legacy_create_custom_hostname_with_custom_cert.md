# Create a Custom Hostname with a Custom Certificate

_When you migrate a legacy zone to a proxy zone, a certificate is automatically created with the validation method set to "http". If you need a different validation method, delete the generated certificate and add a custom one. Create the custom certificate in Business Manager for B2C Commerce or use the `addCertificateForZone` API._

This task is part of the proxy zone migration sequence. See [Legacy Zones and Proxy Zone Migration](https://help.salesforce.com/s/articleView?id=cc.b2c_migrating_proxy_zones.htm&type=5).

Complete this task only if the auto-generated, HTTP-validated certificate doesn't meet your needs, for example, when you require a specific validation method or you're using a certificate from your own Certificate Authority (CA). Replace the generated certificate with a self-managed (custom) certificate on the new proxy zone.

1. In Business Manager, click App Launcher _(image: App Launcher)_, and then select **Administration > Sites > Embedded CDN Settings**.
2. Select the proxy zone from the hostnames list and click **Certificate**.
3. On the Crypto tab, select a zone from the list.
4. Click the **settings icon** on the certificate you want to update.
5. Select **Self-Managed Certificate**.
6. Paste the certificate and private key information from your Certificate Authority provider.
7. Select the hostname to assign the certificate to.
8. Click **Update Certificate**.

   _(image: Update self-managed certificate.)_

Continue with [Update Authoritative DNS](https://help.salesforce.com/s/articleView?id=cc.b2c_legacy_update_auth_dns.htm&type=5).
