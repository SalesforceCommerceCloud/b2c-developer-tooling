# Catalog Feed Integration with OpenAI

_Syndicate your B2C Commerce product catalog to OpenAI's ChatGPT for product discovery, enabling shoppers to find and browse your products through conversational AI._

The OpenAI catalog feed integration gives B2C Commerce merchants the ability to share their product catalogs with ChatGPT. When shoppers ask ChatGPT for product recommendations, ChatGPT can access your product feed and recommend products from your catalog. Shoppers who select a recommended product go straight to your storefront's product detail page (PDP) to complete their purchase.

### How the Product Feed Is Generated and Uploaded for OpenAI

The integration uses Commerce Cloud's scheduled job infrastructure to generate a canonical product feed from your catalog currently assigned to the site you are in, informed by merchant mapping of catalog attributes to OpenAI's feed requirements. B2C Commerce uploads the feed to OpenAI's infrastructure using a Secure File Transfer Protocol (SFTP) connection, which is then consumed by OpenAI to enrich the discovery experience in ChatGPT.

> **Important:** OpenAI onboards your merchant account and provides your SFTP credentials. You enter these credentials in Business Manager when you connect to OpenAI.

To configure the feed integration in Business Manager, you:

- [Configure General Settings (SFTP credentials and seller information)](https://help.salesforce.com/s/articleView?id=cc.b2c_openai_feed_general_settings.htm&type=5)
- [Connect to OpenAI](https://help.salesforce.com/s/articleView?id=cc.b2c_product_feed_connect.htm&type=5)
- [Map B2C Commerce product attributes to OpenAI feed fields](https://help.salesforce.com/s/articleView?id=cc.b2c_openai_feed_mapping.htm&type=5)
- [Override default mappings with custom attributes](https://help.salesforce.com/s/articleView?id=cc.b2c_product_feed_custom_attributes.htm&type=5)
- [Configure product filter rules to control which products sync to ChatGPT](https://help.salesforce.com/s/articleView?id=cc.b2c_product_feed_product_filter.htm&type=5)
- [Preview the product feed and verify field mappings before turning on the daily sync](https://help.salesforce.com/s/articleView?id=cc.b2c_product_feed_preview.htm&type=5)
- [Turn on or turn off the daily feed sync](https://help.salesforce.com/s/articleView?id=cc.b2c_openai_feed_enable.htm&type=5)

You can configure field mappings, product filter rules, and the feed preview on any non-production instance—development, staging, or sandbox—or on production. The SFTP connection and the daily feed sync run only on production instances.

### Managing Products in ChatGPT

The product feed sent to ChatGPT reflects the products that match your configured product filter rules. By default, the rules match products that are online and searchable, but you can adjust them to fit how your catalog is organized. Manage which products appear in ChatGPT in two ways:

- **Adjust the filter rules**: To change the criteria that decide which products are included, configure include and exclude rules in the Product Filter section. See [Configure Product Filter Rules](https://help.salesforce.com/s/articleView?id=cc.b2c_product_feed_product_filter.htm&type=5).
- **Update product data**: To add, remove, or update individual products under the current rules, manage products in the Products and Catalogs section of Business Manager. For example, with the default rules, set a product to offline or not searchable to remove it from the feed.

B2C Commerce automatically excludes master products, variation groups, and product sets from the feed, exporting only individual variant products (SKUs) and standalone products. Variants inherit attribute data from their variation group or master product.

OpenAI treats the latest feed as the source of truth. Changes take effect after the next daily feed sync.

### Tracking ChatGPT Traffic

When shoppers click through from ChatGPT to your storefront, the referral includes attribution data. Use the Traffic Dashboard in Reports & Dashboards to view ChatGPT as a referrer source and measure traffic from this channel.

ChatGPT automatically adds `utm_source=chatgpt.com` to every link from your feed, so you can identify ChatGPT referrals in your analytics. ChatGPT doesn't add a `utm_medium` value, so Salesforce recommends adding `utm_medium=feed` to the product **url** field in Field Mapping to distinguish traffic that comes from your product feed from other ChatGPT referrals. For example: `https://www.example.com/product/${id}?utm_medium=feed`. To configure the product URL, see [Map Product Fields for OpenAI](https://help.salesforce.com/s/articleView?id=cc.b2c_openai_feed_mapping.htm&type=5). If you use PWA Kit or a headless storefront, see [Configure URL Patterns for the Product Feed](https://help.salesforce.com/s/articleView?id=cc.b2c_product_feed_pwa_urls.htm&type=5).

### Benefits of the Product Feed for OpenAI

The OpenAI catalog feed integration offers these benefits:

- **Increased visibility**: Your products gain increased relevance in the discovery experience through ChatGPT's conversational interface.
- **Increased merchant control**: Compared to the current way products are discovered in ChatGPT, the OpenAI catalog feed integration provides more accurate product data from the merchant directly, rather than from any public website that may be inaccurate, biased, or outdated.
- **New traffic channel**: Drive qualified, high-intent traffic from ChatGPT to your storefront.
- **Smart defaults**: Default field mappings reduce configuration time and maximize compliance with OpenAI's product feed requirements, while allowing customization.
- **Flexible mapping**: Map both standard and custom product attributes to ensure the proper data from your catalog is being sent.

### Product Feed Limitations for OpenAI

The following limitations apply to the OpenAI catalog feed integration:

- Sites must have `en_US` configured as a locale and `USD` configured as a currency. These don't need to be the site defaults.
- OpenAI redirects shoppers to the merchant's PDP for checkout. Shoppers can't complete checkout directly in ChatGPT.

### Set Up the Product Feed for OpenAI

First complete the [common product feed setup](https://help.salesforce.com/s/articleView?id=cc.b2c_product_feed_setup.htm&type=5): prerequisites, Einstein configuration, channel partner connection, URL patterns, custom attributes, product filter rules, and feed preview. Then configure these OpenAI-specific settings and turn on the feed:

## Related Content

- [Configure Product Feed General Settings for OpenAI](https://help.salesforce.com/s/articleView?id=cc.b2c_openai_feed_general_settings.htm&type=5)
  On the General Settings tab, enter your SFTP credentials and the seller information that OpenAI requires to list your B2C Commerce products. Optionally, set global overrides for the price and image columns that apply to every row in your feed.

- [Map Product Fields for OpenAI](https://help.salesforce.com/s/articleView?id=cc.b2c_openai_feed_mapping.htm&type=5)
  Configure how B2C Commerce product attributes map to OpenAI feed fields using the field mapping interface.

- [Turn On the Product Feed for OpenAI](https://help.salesforce.com/s/articleView?id=cc.b2c_openai_feed_enable.htm&type=5)
  Turn on the daily sync to start generating and uploading your B2C Commerce product feed to OpenAI. Before you turn on the daily sync, rigorously review the default field mappings and make any overrides.
