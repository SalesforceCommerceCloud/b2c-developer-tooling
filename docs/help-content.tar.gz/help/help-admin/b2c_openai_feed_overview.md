# OpenAI Product Feed Integration

_Syndicate your B2C Commerce product catalog to OpenAI's ChatGPT for product discovery, enabling shoppers to find and browse your products through conversational AI._

The OpenAI product feed integration gives B2C Commerce merchants the ability to share their product catalogs with ChatGPT. When shoppers ask ChatGPT for product recommendations, ChatGPT can access your product feed and recommend products from your catalog. Shoppers who select a recommended product go straight to your storefront's product detail page (PDP) to complete their purchase.

### How It Works

The integration uses Commerce Cloud's scheduled job infrastructure to generate a canonical product feed from your catalog currently assigned to the site you are in, informed by merchant mapping of catalog attributes to OpenAI's feed requirements. The system uploads the feed to OpenAI's infrastructure using a Secure File Transfer Protocol (SFTP) connection, which is then consumed by OpenAI to enrich the discovery experience in ChatGPT.

> **Important:** Salesforce, in coordination with OpenAI, creates the merchant in ChatGPT Merchant Center and generates SFTP credentials. Salesforce securely provides these credentials to you. You enter these credentials when you connect to OpenAI.

To configure the feed integration in Business Manager, you:

- [Configure General Settings (SFTP credentials and seller information)](https://help.salesforce.com/s/articleView?id=cc.b2c_openai_feed_general_settings.htm&type=5)
- [Connect to OpenAI](https://help.salesforce.com/s/articleView?id=cc.b2c_openai_feed_connect.htm&type=5)
- [Map B2C Commerce product attributes to OpenAI feed fields](https://help.salesforce.com/s/articleView?id=cc.b2c_openai_feed_mapping.htm&type=5)
- [Override default mappings with custom attributes](https://help.salesforce.com/s/articleView?id=cc.b2c_openai_feed_custom_attributes.htm&type=5)
- [Configure product filter rules to control which products sync to ChatGPT](https://help.salesforce.com/s/articleView?id=cc.b2c_openai_feed_product_filter.htm&type=5)
- [Preview the product feed and verify field mappings before turning on the daily sync](https://help.salesforce.com/s/articleView?id=cc.b2c_openai_feed_preview.htm&type=5)
- [Turn on or turn off the daily feed sync](https://help.salesforce.com/s/articleView?id=cc.b2c_openai_feed_enable.htm&type=5)

You can configure field mappings, product filter rules, and the feed preview on any non-production instance—development, staging, or sandbox—or on production. The SFTP connection and the daily feed sync run only on production instances.

### Managing Products in ChatGPT

The product feed sent to ChatGPT reflects the products that match your configured product filter rules. By default, the rules match products that are online and searchable, but you can adjust them to fit how your catalog is organized. Manage which products appear in ChatGPT in two ways:

- **Adjust the filter rules**: To change the criteria that decide which products are included, configure include and exclude rules in the Product Filter section. See [b2c_openai_feed_product_filter.xml](https://help.salesforce.com/s/articleView?id=cc.b2c_openai_feed_product_filter.htm&type=5).
- **Update product data**: To add, remove, or update individual products under the current rules, manage products in the Products and Catalogs section of Business Manager. For example, with the default rules, set a product to offline or not searchable to remove it from the feed.

The system automatically excludes master products, variation groups, and product sets from the feed, exporting only individual variant products (SKUs) and standalone products. Variants inherit attribute data from their variation group or master product.

OpenAI treats the latest feed as the source of truth. Changes take effect after the next daily feed sync.

### Tracking ChatGPT Traffic

When shoppers click through from ChatGPT to your storefront, the referral includes attribution data. Use the Traffic Dashboard in Reports & Dashboards to view ChatGPT as a referrer source and measure traffic from this channel.

### Key Benefits

- **Increased visibility**: Your products gain increased relevance in the discovery experience through ChatGPT's conversational interface.
- **Increased merchant control**: Compared to the current way products are discovered in ChatGPT, this integration provides more accurate product data from the merchant directly, rather than from any public website that may be inaccurate, biased, or outdated.
- **New traffic channel**: Drive qualified, hight-intent traffic from ChatGPT to your storefront.
- **Smart defaults**: Default field mappings reduce configuration time and maximize compliance to OpenAI's product feed requirements, while allowing customization.
- **Flexible mapping**: Map both standard and custom product attributes to ensure the proper data from your catalog is being sent.

### Limitations

The following limitations apply to the OpenAI product feed integration:

- Sites must have `en_US` configured as a locale and `USD` configured as a currency. These don't need to be the site defaults.
- OpenAI redirects shoppers to the merchant's PDP for checkout. Shoppers can't complete checkout directly in ChatGPT.
