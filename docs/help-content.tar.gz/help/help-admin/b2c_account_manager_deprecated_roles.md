# Removal of Deprecated Roles in Account Manager

_Some Account Manager roles are deprecated and have been removed from the system. Deprecated roles no longer provide access to B2C Commerce services, and their removal doesn't affect functionality or user access. Starting the week of September 28, 2026, these roles are fully removed from Account Manager. After removal, the roles can't be assigned to users or API clients by any process._

[Which Salesforce Commerce Product Do I Have?](https://help.salesforce.com/s/articleView?id=commerce.comm_what_product.htm)

Starting in Account Manager 3.9, Account Manager gradually unassigns deprecated roles from all users. The unassignment process is scheduled over several months, after which Account Manager plans to remove the roles entirely.

Account Manager retired these roles in phases:

- [Account Manager 1.46.0](https://help.salesforce.com/s/articleView?id=commerce.account_manager_rn_deprecated_roles.htm) — The roles were announced as deprecated.
- [Account Manager 3.7](https://help.salesforce.com/s/articleView?id=release-notes.rn_account_manager_deprecated_roles.htm&release=260) (April 2026) — Account Manager began labeling the roles as DEPRECATED on the User Details page.
- [Account Manager 3.9](https://help.salesforce.com/s/articleView?id=release-notes.rn_account_manager_removes_deprecated_roles.htm&release=262) (June 2026) — An automatic job began removing the roles from all users and API clients, and no new assignments were possible from the UI.
- Week of September 28, 2026 — Account Manager removed the roles from the system as the final step of the cleanup.

These roles are deprecated:

- Appdynamics User
- CQuotient Configurator Administrator
   
   - This role isn’t required for access to Einstein. Einstein only requires an Account Manager account to log in. Control permissions within the Configurator app itself.
- Documentation User
- Business Manager Partner
- Order Management Admin
   
   - This role applied to the legacy Commerce Cloud Order Management product, which was retired on July 31, 2022.
- Order Management User
   
   - This role applied to the legacy Commerce Cloud Order Management product, which was retired on July 31, 2022.
- Shopper Login and API Access Service (SLAS) Organization Admin (for API client)
   
   - This role is assignable only to API clients, not to users, and gives no extra access. The active role for users, SLAS Organization Administrator, isn’t deprecated.
- SLAS Trusted Agent Read Only
- SLAS Trusted Agent Read Write
- XChange User
- statuspage.io User
