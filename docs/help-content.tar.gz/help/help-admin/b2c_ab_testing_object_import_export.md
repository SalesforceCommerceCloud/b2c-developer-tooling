# A/B Test Object Import and Export in B2C Commerce

_Use the abtest.xsd schema to import and export A/B tests._

When using the abtest.xsd schema, all A/B test child elements are optional to allow support for different import modes. Run an Update mode import to update certain attributes of an A/B test, but not affect other attributes of the test. Or run a Delete mode import, where you only specify the ID of the A/B test to delete. In both cases, omit the irrelevant elements from the file.

The `<participation>` element supports a *replace* semantic. In Update or Merge modes, omit this element so that the related attributes of an A/B test remain unchanged. If you include the element, provide its contents in their entirety. For example, the `<participation>` element also requires the `<trigger>` and the `<expiration>` elements.

Export A/B test results from the test results page in `.csv` format for later analysis, typically within a spreadsheet application.

| Object Information | Details |
| --- | --- |
| Schema file | abtest.xsd |
| Business Manager import and export location | Manually import or export A/B test configurations by clicking App Launcher _(image: App Launcher)_**Merchant Tools > Online Marketing > Import & Export Online Marketing**.Use the **A/B Tests (XML)** setting. |
| Pipelets | ExportABTests ImportABTests |
