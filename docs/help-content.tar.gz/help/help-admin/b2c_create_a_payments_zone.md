# Create a Payment Zone for B2C Commerce

_Create a payment zone and assign one or more currencies and countries to it._

|  |
| --- |
| Available in: **B2C Commerce** |

To configure a payment zone for specific geographic regions, specify currencies and countries for the zone. If there’s no payment zone suitable for shoppers in a specific region, the merchant account uses the default payment zone, which supports any currency and country. Alternatively, create a payment zone that supports any currency and country. The payment zone that you create takes precedence over the default payment zone. The merchant account needs to match the region where you want to do business.

1. In Business Manager, click App Launcher _(image: App Launcher)_, and then select **Administration > Site > Global Preferences > Payment Zones**.
2. Click **New**.
3. Enter a name for the payment zone.
4. Select at least one currency and country for the payment zone.
5. Click **Create**.
