# Configure HSTS for B2C Commerce

_HTTP Strict Transport Security (HSTS) secures your site by instructing web browsers to access your domain using only HTTPS. HSTS prevents attackers from using downgrade attacks against your site. For extra security, enable preload, which forces web browsers to open your site in HTTPS the first time it's requested. Read the Internet Engineering Task Force (IETF) on HSTS for more information._

|  |
| --- |
| Available in: **B2C Commerce** |

Web browsers check your site's HTTP header for information on HSTS. When the web browser reads a max age for HSTS, the browser doesn't check the header again until the max age has expired. Because a web browser checks the header only after the max age has passed, you can't manually disable HSTS. You can change the max age at any time, but you can update HSTS only on an HTTPS connection. Because of this, if your site contains insecure material, your changes to the max age don't apply.

> **Caution:** If your site contains insecure content and HSTS is enabled, that content doesn't display on your shoppers' web browsers, making your site impossible to view. Because you can't manually disable HSTS for sites with insecure material, it’s extremely important that you make sure your site is fully secure before enabling HSTS. To test your site, enable HSTS for short periods of time, starting with a few seconds and then longer.

> **Note:** Different web browsers implement HSTS at their own discretion.

1. To enable the HSTS option, click App Launcher _(image: App Launcher)_, and then select **Administration > Feature Switches** and enable **HSTS settings for eCDN zones**.
2. Select **Administration > Sites > Embedded CDN Settings.**
3. Click **Configure Zones**.
4. On the Crypto tab, click **Enable**.

   HSTS isn't active on your site until you set a max age and click Apply. Before you proceed, review the confirmation dialog text: "Enable HSTS for this zone? Make sure your site is fully HTTPS-ready before continuing."
5. Set the max age.
6. Select whether HSTS applies to subdomains.
7. Select whether you want to enable preload.

   Although there are several steps to officially register your site for preloading, some web browsers enable preload once they've received the preload tag in the header. Only enable preload after your entire site is secure. Preload can take up to a month to disable.
8. Click **Apply**.
