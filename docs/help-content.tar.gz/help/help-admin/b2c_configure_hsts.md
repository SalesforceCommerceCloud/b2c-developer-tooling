# Configure HSTS for an eCDN Zone

_Enable HTTP Strict Transport Security (HSTS) for a B2C Commerce eCDN zone to make web browsers connect to your domain over HTTPS only. Set the max age, choose whether HSTS applies to subdomains, and optionally enable preload._

[Which Salesforce Commerce Product Do I Have?](https://help.salesforce.com/s/articleView?id=commerce.comm_what_product.htm)

> **Note:** HSTS isn't available on SCAPI zones. See [SCAPI Zone Support for B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_scapi_zone.htm&type=5).

Before you enable HSTS, make sure your site is fully HTTPS-ready. Because of how the max age works, you can't simply switch HSTS off later. For details, see [HTTP Strict Transport Security (HSTS) for eCDN](https://help.salesforce.com/s/articleView?id=cc.b2c_manage_hsts.htm&type=5).

> **Caution:** If your site contains insecure content and HSTS is enabled, that content doesn't display in your shoppers' web browsers, potentially making your site impossible to view. To test your site, enable HSTS for short periods, starting with a few seconds and then longer.

1. To enable the HSTS option, click App Launcher _(image: App Launcher)_, and then select **Administration > Global Preferences > Feature Switches** and enable **HSTS settings for eCDN zones**.
2. Select **Administration > Sites > Embedded CDN Settings**.
3. Locate your zone and select **Configure Zone** from the dropdown menu.
4. On the Crypto tab, click **Enable**.

   HSTS isn't active on your site until you set a max age and click **Apply**. Before you proceed, review the confirmation dialog text: "Enable HSTS for this zone? Make sure your site is fully HTTPS-ready before continuing."
5. Set the max age.
6. Select whether HSTS applies to subdomains.
7. Select whether to enable preload.

   Although there are several steps to officially register your site for preloading, some web browsers enable preload once they've received the preload tag in the header. Enable preload only after your entire site is secure. Preload can take up to a month to disable.
8. Click **Apply**.
