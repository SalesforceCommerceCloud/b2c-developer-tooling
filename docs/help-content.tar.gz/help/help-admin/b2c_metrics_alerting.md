# Metrics Alerting (Beta)

_Send a notification when a supported B2C Commerce metric crosses a warning or critical threshold. Use Metrics Alerting in Log Center to watch application, sales, API, and storefront health, and route the notification to email, Slack, PagerDuty, or Microsoft Teams._

> **Note:** Metrics Alerting is a pilot or beta service that is subject to the Beta Services Terms at [Agreements - Salesforce.com](https://www.salesforce.com/company/legal/agreements/) or a written Unified Pilot Agreement if executed by Customer, and applicable terms in the [Product Terms Directory](https://ptd.salesforce.com/). Use of this pilot or beta service is at the Customer's sole discretion.

Metrics Alerting is available as an open beta. No additional license is required. When a metric breaches a warning or critical threshold, Log Center sends a notification to the channels on the alert. A notification can take up to one minute after the breach. If the alert stays open, then Log Center repeats the notification every four hours. When the metric no longer breaches the threshold, the alert resolves and Log Center sends a resolution notification.

Review metric definitions and trends on the [Metrics Dashboard](https://help.salesforce.com/s/articleView?id=cc.b2c_metrics_dashboard.htm&type=5). Create alerts from the metrics listed on the Metrics tab. The beta catalog doesn't include every dashboard metric. Embedded CDN (eCDN) metrics stay on the dashboard.

Each alert uses one metric and one rule from the catalog. A rule is the condition for that metric, such as a value above the threshold. For a metric family that supports filters, such as Open Commerce API (OCAPI), you can limit the alert to selected values. Leave a filter empty to alert on the combined value for that metric.

### Metric Families in the Beta Catalog

The Metrics tab lists the metrics you can select in each family.

| Metric Family | Examples |
| --- | --- |
| [Overall Application](https://help.salesforce.com/s/articleView?id=cc.b2c_metrics_overall_app.htm&type=5) | Total platform requests, storefront requests, sessions, response time, emails sent, and system workload. |
| [Sales](https://help.salesforce.com/s/articleView?id=cc.b2c_metrics_sales.htm&type=5) | Orders, basket creations, and basket updates. |
| Third Party Service | Call volume, 95th-percentile call duration, and remote exceptions. |
| OCAPI | Call volume, average duration, and errors. Some OCAPI metrics include Category and API filters. |
| [B2C Commerce API (SCAPI)](https://help.salesforce.com/s/articleView?id=cc.b2c_metrics_scapi.htm&type=5) | Calls, request latency, response counts by status code, and cache-hit statistics. |
| [SCAPI Hooks](https://help.salesforce.com/s/articleView?id=cc.b2c_metrics_scapi_hooks.htm&type=5) | Hook execution times and hook errors. |
| [Managed Runtime](https://help.salesforce.com/s/articleView?id=cc.b2c_metrics_managed_runtime.htm&type=5) | Request count, cache hits, error rate, server-side rendering invocations, and request time. |
| Controller | Pipeline execution volume and average duration. |

### Notification Channels

Enter up to five email addresses on the alert. For Slack, PagerDuty, and Microsoft Teams, select a notification configuration that you already created. Log alerts, anomaly detection, and metric alerts share those configurations.

A notification configuration applies to one or more realms. An alert can use that configuration only when the configuration includes every realm selected on the alert.

The same Log Center roles that can create a log or anomaly alert can create a metric alert, and only for the realms that the role can access. See [Access Control for Log Center Alerts](https://help.salesforce.com/s/articleView?id=cc.b2c_access_control_for_log_center_alerts.htm&type=5).

A metric alert doesn't count toward the limit of 50 log-based alerts.

To create an alert, see [Create a Metric Alert in Log Center](https://help.salesforce.com/s/articleView?id=cc.b2c_create_a_metric_alert.htm&type=5).

## Related Content

- [Create a Metric Alert in Log Center](https://help.salesforce.com/s/articleView?id=cc.b2c_create_a_metric_alert.htm&type=5)
  Notify your team when a supported B2C Commerce metric crosses a warning or critical threshold.
