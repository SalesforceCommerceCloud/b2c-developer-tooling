# Create a Slack Channel for Log Center Alerts

_To keep your teams aligned during incidents, set up Slack notifications in B2C Commerce._

1. In your Slack workspace, create an incoming webhook and copy the URL. See [Sending messages using incoming webhooks](http://google.com/url?q=https://docs.slack.dev/messaging/sending-messages-using-incoming-webhooks/&sa=D&source=docs&ust=1781175543711587&usg=AOvVaw3AQPcwgpbVzaTPa6wxTPaG).
2. In the Log Center, on the Alerts tab, go to **Notification Channel Configurations**.
3. Click **Create Configuration**.
4. For Type, select **Slack**.
5. Select at least one realm that can use the channel.

   A notification channel must be assigned to at least one realm. The selected realms control where you can use the channel. Admin and support roles control who can configure or manage it.
6. Enter your webhook URL, and then click **Save Configuration**.
