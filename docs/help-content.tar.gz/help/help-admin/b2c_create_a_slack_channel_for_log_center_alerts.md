# Create a Slack Channel for Log Center Alerts

_To keep your teams aligned during incidents, set up Slack notifications in B2C Commerce._

1. In your Slack workspace, create an incoming webhook and copy the URL. See [Sending messages using incoming webhooks](http://google.com/url?q=https://docs.slack.dev/messaging/sending-messages-using-incoming-webhooks/&sa=D&source=docs&ust=1781175543711587&usg=AOvVaw3AQPcwgpbVzaTPa6wxTPaG).
2. In the Log Center, on the Alerts tab, go to **Notification Channels**.
3. Click **Create Channel**.
4. For Type, select **Slack**.
5. Select the applicable realms, or leave the field empty to create a channel that’s visible only to admin and support roles.
6. Enter your webhook URL. Click **Create Channel**.
