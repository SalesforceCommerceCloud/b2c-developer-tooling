# Modify eCDN Managed Ruleset Settings

_Created by the eCDN security team, this ruleset provides fast and effective protection for all of your applications. The eCDN security team updates the ruleset frequently to cover new vulnerabilities and reduce false positives. The default setting for the rule set is enabled._

Select the action to perform–The default is recommended. The available actions are:

- Block (Default)
- Managed challenge
- JS challenge
- Log
- Legacy captcha

When you define an action for the ruleset, you override the default action defined for each rule. To remove the action override, set the ruleset action to Default.

_(image: Embedded CDN Settings)_

_(image: WAFv2 Managed Ruleset Settings)_
