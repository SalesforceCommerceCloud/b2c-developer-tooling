# Data Upload in B2C Commerce

_Data upload refers to transferring data files from an external system to your instance’s file system. Upload data such as import files, images, and snapshots manually or programmatically. Use Business Manager to transfer data manually. As always, any interaction with Business Manager occurs over HTTPS. Custom code performs data transfer programmatically. In this case, while several file transfer protocols are supported, use only the secure protocols: WebDAV over Transport Layer Security (TLS) (recommended), HTTPS, or Secure File Transfer Protocol (SFTP)._
