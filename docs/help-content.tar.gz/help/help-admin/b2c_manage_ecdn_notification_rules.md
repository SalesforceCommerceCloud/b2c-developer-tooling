# Manage Notification Rules

_Pause, resume, edit, or delete the eCDN notification rules that target a zone on your B2C Commerce storefront. The Notifications table shows every rule that targets the current zone, along with the destination it delivers to, the full zone list, and an Enabled toggle._

[Which Salesforce Commerce Product Do I Have?](https://help.salesforce.com/s/articleView?id=commerce.comm_what_product.htm)

To create the rules that appear in this table, see [Create a Notification Rule](https://help.salesforce.com/s/articleView?id=cc.b2c_create_ecdn_notification_rule.htm&type=5).

_(image: Notifications table showing a notification rule Slack Webhook - Logpush Job Alert with zone list and Enabled toggle, with actions menu expanded displaying Edit and Delete options)_

1. On the **Notifications** tab, find the rule you want to manage in the Notifications table.
2. To pause or resume delivery without losing the rule, flip the **Enabled** switch on the row.
3. To change the destination, zone selection, or enabled state, open the row's actions menu and select **Edit**.
4. To remove the rule entirely, open the row's actions menu, select **Delete**, and confirm.

   Deletion asks for explicit confirmation because it can't be undone. If you only want to mute the rule temporarily, use the **Enabled** toggle instead.
   
   _(image: Delete confirmation dialog with message Are you sure you want to delete the notification Slack Webhook - Logpush Job Alert? This action can't be undone, with Cancel and OK buttons)_
