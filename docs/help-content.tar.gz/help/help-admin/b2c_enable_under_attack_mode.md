# Enable Under Attack Mode for an eCDN Zone

_Turn on Under Attack Mode from the Configure Zone screen in Business Manager to present a challenge to every visitor to your B2C Commerce storefront during an active DDoS attack. Use it only as a last resort._

> **Note:** Under Attack Mode isn't available on SCAPI zones. See [SCAPI Zone Support for B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_scapi_zone.htm&type=5).

Under Attack Mode is a toggle in the top right corner of all tabs in the Configure Zone screen. When enabled, Cloudflare slows down visits to the targeted storefront and presents a Completely Automated Public Turing test to tell Computers and Humans Apart (CAPTCHA) challenge to every unique visitor before allowing access to the site. For background, see [eCDN Zone Settings in Business Manager](https://help.salesforce.com/s/articleView?id=cc.b2c_configuring_a_zone.htm&type=5).

1. In Business Manager, click App Launcher _(image: App Launcher)_, and then select **Administration > Sites > Embedded CDN Settings**.
2. Locate the zone you want to configure, open the zone's actions menu on the right side of the zone row, and select **Configure Zone**.

   The Configure Zone screen opens for the selected zone.
   
   ### Configure Zone option in zone actions menu
   
   _(image: Embedded CDN Settings page showing a zone row actions menu with Configure Zone and Configure Routing Rules options.)_
3. Turn on the **Under Attack Mode** toggle in the zone header, and in the confirmation dialog, click **Enable**.

   ### Under Attack Mode toggle in zone header
   
   _(image: Configure Zone header showing the Under Attack Mode toggle at the top right above zone tabs.)_

Under Attack Mode shows an interstitial challenge to every visitor before allowing access to your storefront.

To turn off Under Attack Mode, switch the toggle off. No confirmation is required.

To customize the challenge page shown while Under Attack Mode is on, see the **I am under attack Page** in [Configure Custom Error Pages for an eCDN Zone](https://help.salesforce.com/s/articleView?id=cc.b2c_configure_zone_custom_error_pages.htm&type=5).
