# Configure Catalog and Order Feeds for Commerce Cloud Einstein Deployment

_Before you can use the OpenAI or Google catalog feed integration, configure Einstein catalog feeds. If your B2C Commerce site already uses Einstein features, you can skip this task._

You need Business Manager administrator permissions to configure Einstein feeds.

The OpenAI and Google catalog feed integrations rely on Commerce Cloud Einstein catalog feeds. If you haven't configured Einstein feeds before, set up the catalog and order feeds as described in [Configure a Commerce Cloud Einstein Deployment](https://help.salesforce.com/s/articleView?id=cc.b2c_configure_einstein_deployment.htm&type=5), and apply the product feed settings below as you go.

> **Note:** Configure catalog and order feeds only on production instances.

The product feed integration uses only the catalog feed. Order feeds aren't required for product feed syndication. Configure the order feed only if you use other Einstein features that need it, such as Commerce Insights or Product Recommendations.

In the **Host** field, enter the storefront hostname for the current site, such as `www.mycompany.com`. The product feed uses this hostname to construct the product URL column for each product—the **url** column for the OpenAI feed or the **link** column for the Google feed—so shoppers who click through from ChatGPT or Google land on your storefront. If the field already shows a value such as `staging-realm-pod.demandware.net`, that's the instance hostname, not your storefront hostname. Replace it with the storefront hostname before you save. Don't include the URL scheme (`https://`).

If you select **Out-of-Stock Products** when you define feed actions, the product feed uses that setting to include or exclude out-of-stock products in the feed.

For a walkthrough of the Einstein deployment steps, see the video [Configure Catalog and Order Feeds for Commerce Cloud Einstein Deployment](https://youtu.be/5YKKqpNuqds?si=kwSoyakQjLI9JX9n).
