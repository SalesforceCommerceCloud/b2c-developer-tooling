# Add a Self-Managed SSL Certificate for B2C Commerce

_Add a self-managed SSL certificate to a hostname for a zone, validate it, and map DNS so the hostname's traffic routes to its zone. You upload and renew self-managed certificates yourself._

> **Note:** Self-managed SSL certificates aren't available on SCAPI zones. Salesforce manages the SCAPI hostname and certificates. See [SCAPI Zone Support for B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_scapi_zone.htm&type=5).

[Which Salesforce Commerce Product Do I Have?](https://help.salesforce.com/s/articleView?id=commerce.comm_what_product.htm)

For the DNS mapping rules, validation methods, and certificate limits, see [DNS Mapping for eCDN Zones](https://help.salesforce.com/s/articleView?id=cc.b2c_dns_mapping_for_ecdn_zones.htm&type=5).

To upload a self-managed certificate with the CDN Zones API instead, see [eCDN Custom Certificates](https://developer.salesforce.com/docs/commerce/commerce-api/guide/cdn-zones-custom-certs.html) in the developer documentation.

> **Restriction:** You can add up to 5 self-managed certificates per realm.

1. In Business Manager, click App Launcher _(image: App Launcher)_, and then select **Administration > Sites > Embedded CDN Settings**.
2. Click **Certificates** or **Settings** for the zone to which you're adding a certificate.
3. On the Crypto tab, select the zone from the list.
4. Click **Add Certificate**.
5. Select **Self-Managed Certificate**.

   _(image: Upload Custom Certificate dialog with Self-Managed Certificate selected, showing certificate and private key fields and assignment details)_
6. Enter the SSL certificate and private key information from your certificate provider.
7. Select the hostname to which you want to assign the SSL certificate.

   > **Note:** Self-managed wildcard certificates require SANs for both the root domain and the wildcard hostname. See [Configure Wildcard Custom Hostnames](https://help.salesforce.com/s/articleView?id=cc.b2c_add_wildcard_custom_hostname.htm&type=5).
8. Click **Upload Certificate**.
9. Copy the displayed verification text into your own DNS portal.
10. To check the status of hostname validation, click **Verify HostName**.

   Verification can take up to six hours.
11. Map DNS so that the hostname's traffic routes to its zone.

   See [Map DNS to an eCDN Zone](https://help.salesforce.com/s/articleView?id=cc.b2c_map_dns_to_ecdn_zone.htm&type=5).
