# Add Self-Managed SSL Certificates

_Add self-managed SSL certificates to your B2C Commerce hostnames for Zones, and map your origin endpoints._

> **Note:** Self-managed SSL certificates aren't available on SCAPI zones. Salesforce manages the SCAPI hostname and certificates. See [SCAPI Zone Support for B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_scapi_zone.htm&type=5).

To add Self-managed SSL certificates to your hostnames and map DNS values from B2C Commerce to your DNS provider account:

On the Crypto tab, click the chevron at the start of a certificate row to expand certificate details, including certificate type, hosts, issuer, validation method, expiration details, and any TXT or CNAME records or verification actions required for unverified certificates.

When mapping endpoints, keep the following in mind:

- The DNS Request for Comments (RFC) doesn’t support pointing root domains directly to B2C Commerce. When directing root domains to the eCDN CNAME alias, you must use an external service to redirect from the root domain to the subdomain.
- When setting up redirects, make sure to set them up for both HTTP and HTTPS.
- To permanently serve traffic from the root domain (yourcompany.com) instead of a subdomain (www.yourcompany.com), use a DNS-level solution to direct root domains to the eCDN CNAME alias.

1. In Business Manager, click App Launcher _(image: App Launcher)_, and then select **Administration > Sites > Embedded CDN Settings**.
2. Click **Certificates or Settings** for the zone to which you’re adding a certificate.
3. On the Crypto tab, select the zone from the list.
4. Click **New Certificate**.
5. Select **Self-Managed Certificate**.

   _(image: Upload Custom Certificate dialog with Self-Managed Certificate selected, showing certificate and private key fields and assignment details)_
6. Enter the SSL certificate and private key information from your certificate provider.
7. Select the hostname to which you want to assign the SSL certificate.

   > **Note:** Self-managed wildcard certificates require SANs for both the root domain and the wildcard hostname. See [Wildcard Custom Hostnames](https://help.salesforce.com/s/articleView?id=cc.b2c_add_wildcard_custom_hostname.htm&type=5).
8. Click **Upload Certificate**.
9. Copy the displayed verification text into your own DNS portal.
10. To check the status of hostname validation, click **Verify HostName**. Verification can take up to six hours.
11. After the hostname is active, create a CNAME record that points traffic, by SSL for SaaS V2, to the new zone.
12. Configure the DNS mapping for the zone:

   1. Log in to your DNS provider account.
   2. Search for your zone and select it from the list.
   3. On the DNS tab, locate the hostname that you want to map.
   4. Replace all text after “is an alias of” with the DNS CNAME from Business Manager.
   5. In the Status column, click the cloud until it shows a gray cloud with the tooltip “DNS Only”.
   
   > **Note:** If you already have the same root domain with your DNS provider in a separate account, it’s required to point the DNS to the new zone and not the standard or root zone. The purpose is to prove intent that you want traffic to come to the new zone rather than the standard or root zone.
