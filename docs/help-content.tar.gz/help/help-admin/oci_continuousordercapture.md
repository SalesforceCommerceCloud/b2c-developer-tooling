# B2C Commerce Continuous Order Capture for Omnichannel Inventory

_Turn on Continuous Order Capture to accept customer orders and maintain business continuity even if connectivity to Omnichannel Inventory is lost. When the service is unavailable, Continuous Order Capture automatically transitions to an offline mode and accepts transactions without immediate inventory reservations. By independently reconciling pending reservations and providing real-time recovery alerts, this feature protects your storefront from downtime while minimizing overselling risks._

Continuous Order Capture provides real-time monitoring of Omnichannel Inventory services. If a disruption occurs, the system maintains continuity through these steps:

- Automatically switches to offline mode and accepts orders based on the last known inventory data.
- Reduces the Available-To-Order (ATO) value after each order to prevent overselling.
- Marks orders as Reservation Missing. A background job processes the offline orders, reserves inventory, reports any overselling, and removes the Reservation Missing state when successful.
- For systems configured with Salesforce Order Management, B2C Commerce holds orders from flowing to Salesforce Order Management until Omnichannel Inventory recovers and inventory is reconciled.
