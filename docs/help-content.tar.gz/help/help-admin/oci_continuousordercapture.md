# B2C Commerce Continuous Order Capture for Omnichannel Inventory

_Turn on Continuous Order Capture to accept customer orders and maintain business continuity even if connectivity to Omnichannel Inventory is lost. When the service is unavailable, Continuous Order Capture automatically transitions to an offline mode and accepts transactions without immediate inventory reservations. By independently reconciling pending reservations and providing real-time recovery alerts, this feature protects your storefront from downtime while minimizing overselling risks._

Continuous Order Capture provides real-time monitoring of Omnichannel Inventory services. If a disruption occurs, the system maintains continuity through these steps:

- Automatically switches to offline mode and accepts orders based on the last known inventory data.
- Reduces the Available-To-Order (ATO) value after each order to prevent overselling.
- Marks orders as Reservation Missing. A background job processes the offline orders, reserves inventory, reports any overselling, and removes the Reservation Missing state when successful.
- For systems configured with Salesforce Order Management, B2C Commerce holds orders from flowing to Salesforce Order Management until Omnichannel Inventory recovers and inventory is reconciled.

## Related Content

- [Enable Continuous Order Capture for B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.oci_enablecoc.htm&type=5)
  To maintain business continuity, accept orders during Omnichannel Inventory service interruptions. Enabling this feature makes sure of uninterrupted sales but requires accepting the risk of potential overselling while Omnichannel Inventory for B2C Commerce is offline.

- [Capturing Offline Orders and Inventory Reconciliation](https://help.salesforce.com/s/articleView?id=cc.oci_cocinventoryrecon.htm&type=5)
  During Omnichannel Inventory service interruptions, Continuous Order Capture queues B2C Commerce orders to maintain business continuity. The system accepts orders based on the last known inventory data. To avoid overselling, B2C Commerce automatically decrements the Available-To-Order (ATO) value immediately after each order is created. The system marks these orders as Reservation Missing until Omnichannel Inventory recovers. After the connection is restored, the system automatically reconciles the inventory and creates reconciliation reports.

- [View Orders Captured During Omnichannel Inventory Downtime](https://help.salesforce.com/s/articleView?id=cc.oci_cocsomb2c.htm&type=5)
  To monitor the progress after reconciliation, view and track the B2C Commerce Continuous Order Capture orders captured during the Omnichannel Inventory offline mode.
