# Security Best Practices for Administrators in B2C Commerce

_You can use Business Manager to secure your site and ensure a safe online shopping environment for your customers. Doing so also secures Business Manager and prevents attackers from removing the security controls you previously configured._
