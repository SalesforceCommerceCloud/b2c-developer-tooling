# Security Best Practices for Administrators in B2C Commerce

_You can use Business Manager to secure your site and ensure a safe online shopping environment for your customers. Doing so also secures Business Manager and prevents attackers from removing the security controls you previously configured._

## Related Content

- [Determine How to Block Attacks in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_determine_how_to_block_attacks.htm&type=5)
  While Salesforce B2C Commerce provides security protections, customers are responsible for configuring security controls and for not removing security controls that are enabled by default. You must consider all of these aspects to maintain the security of your B2C Commerce instance.

- [Network Access Restrictions in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_network_access_restrictions.htm&type=5)
  The network level is the first line of defense against attackers trying to access your assets. Salesforce B2C Commerce uses two mechanisms: one for storefronts and one for Business Manager.

- [Secure Communications in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_secure_communications.htm&type=5)
  Secure communications are crucial to prevent attackers from reading or changing sensitive information, for example, credit cards, personally identifiable information (PII), and credentials. Within Salesforce B2C Commerce, you can secure these interactions using the following secure protocols.

- [Secure Storage in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_secure_storage.htm&type=5)
  Salesforce B2C Commerce stores many types of sensitive information, the most important being credit card details. Credit card encryption, key generation, and re-encryption are automatic, and merchants undergoing a PCI audit can monitor this process.

- [Authentication and Authorization in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_authentication_and_authorization.htm&type=5)
  Authentication and authorization are key security concepts. To configure security controls, you need access to Business Manager.

- [Security Event Auditing in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_security_event_auditing.htm&type=5)
  Salesforce B2C Commerce provides various log files, including a security log. The security log contains log entries for Business Manager logins.

- [Denial-of-Service Protection in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_denial_of_service_protection.htm&type=5)
  In a denial-of-service (DoS) attack, the attacker attempts to deny computer resources to a network’s users. Attackers usually accomplish this by overwhelming the target computer system’s resources with unauthorized requests, which prevent valid users from accessing the network.

- [Data Privacy and Protection in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_data_privacy_and_protection.htm&type=5)
  The Salesforce B2C Commerce Services have a robust data security and privacy program in place. For information on Data Privacy and Protection and related topics, see the referenced resources.
