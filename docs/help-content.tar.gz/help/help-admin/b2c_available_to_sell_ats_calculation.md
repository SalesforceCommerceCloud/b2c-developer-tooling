# Available to Sell (ATS) Calculation

_In B2C Commerce, the product availability presented to storefront customers is defined as the available to sell (ATS) quantity._

The ATS calculation depends on the product type: standard, variation, base product, product set, or product bundle.

> **Important:** If you use Salesforce Omnichannel Inventory, then Omnichannel Inventory performs all availability calculations and sends read-only availability data to B2C Commerce. Individual inventory records in B2C Commerce are read-only.

### Standard Product ATS Calculation

ATS represents the quantity of a product allocated for sale that hasn’t shipped and that isn’t being held for pending orders, plus its quantity available for backorders and preorders. In general, the ATS is the sum of the allocation and preorderBackorderAllocation, reduced by the turnover and the (optional) on order quantity. By default, it's equal to the number of units of a product that are allocated to sell (the `allocation` value).

> **Note:** When using Omnichannel Inventory, the preorderBackorderAllocation quantity is the sum of the future restock quantities, and the on order quantity isn’t used.

The following are some key formulas:

| Value | Formula |
| --- | --- |
| ATS | ATS = max(0, allocation + preorderBackorderAllocation - turnover – on-order) |
| Stock level | StockLevel = max(0, allocation - turnover – on-order) |
| Available for shipping | Available for shipping = max(0, allocation - turnover ) |

Turnover represents a running count of a product's unit sales since the last inventory update. The optional On Order quantity represents the quantity that’s ordered but isn't yet exported for shipping. The turnover doesn't include the On Order quantity.

> **Note:** On Order Inventory isn’t compatible with Omnichannel Inventory.

When products are added to the shopping cart, they aren’t subtracted from ATS. Adjustments to ATS only occur at final checkout. Adding a product to the shopping cart doesn't reserve the product or guarantee its availability at checkout.

> **Note:** Business Manager shows the number of units of a product that are available to sell (ATS). Click App Launcher _(image: App Launcher)_, and then select **Site > Products and Catalogs > Inventory > Inventory List > Records**tab.

If a merchant chooses to use B2C Commerce to calculate the ATS value between inventory updates, the following conditions must apply:

- The product must have a product inventory record
- The product's Perpetual field isn’t checked (`perpetual = false`).

If the customer supports backorders or pre-orders, the product's Pre-Order/Backorder Handling field is set to `Pre-Order` or `Backorder` (`backorderable = true` or `preorderable = true`)

> **Note:** When using Omnichannel Inventory, the preorderable flag is always false, and the backorderable flag is true if the product has any future restocks in Omnichannel Inventory.

A change to a product's `turnover`, `allocation`, or `preorderBackorderAllocation` values result in a recalculation of ATS. When the allocation level is reset, the turnover value is set to zero, but the on-order value isn't changed.

### Base Product and Variation ATS Calculation

A base product doesn't have its own product record. Instead, the availability of a base product is calculated based on the availability of all variations. As long as a single variation is available, the base product is still considered available. In previous versions of B2C Commerce, a single product record was used to calculate ATS for base product and is still included for legacy applications.

### Product Bundle ATS Calculation

A product bundle can have its own product record in addition to the inventory records for the bundled products. This approach lets the merchant control the availability of bundles independent from the availability of the bundled products. The availability of the bundle is calculated differently. How ATS is calculated depends on whether the bundle itself has an inventory record and whether the Use Bundle Inventory Only option is selected on the Inventory List page.

If the bundle itself doesn't have an inventory record, and the Use Bundle Inventory Only option isn't set:

- The availability of a product bundle is calculated based on the availability of the bundled products.
- Placing an order that contains a bundle decrements the stock level of all bundled products
- When one bundled product becomes unavailable, the bundle becomes unavailable.

If the bundle itself doesn't have an inventory record, and the Use Bundle Inventory Only option is set:

- The bundle availability isn't calculated. Instead, the inventory list Default in-stock option defines whether the bundle is available or not. If this option is set, the bundle is always available, otherwise is it never available.

If the bundle itself has an inventory record, and the Use Bundle Inventory Only option isn't set:

- The availability of a product bundle is calculated based on the availability of the bundled products and the availability of the bundle itself.
- Placing an order that contains a bundle decrements the stock level of the bundle (only if the bundle has an inventory record) and all bundled products.
- When one bundled product becomes unavailable, the bundle becomes unavailable.

If the bundle itself has an inventory record, and the Use Bundle Inventory Only option is set:

- The availability of a product bundle is calculated based on the availability of the inventory record of the bundle only. The inventory records of the products in the bundle don't affect the availability calculation.
- Placing an order that contains a bundle decrements the stock level of the bundle, but not the bundled products.
- Only when the inventory record for the bundle itself becomes unavailable does the bundle become unavailable. If the bundled products aren’t available, the bundle is available.

### Product Set ATS Calculation

A product set doesn’t have its own product record. Instead, the availability of a product set is calculated based on the availability of all set products. As long as a single set product is available, the product set is still considered available. In previous versions of B2C Commerce, a single product record was used to calculate ATS for product sets and is still included for legacy applications.
