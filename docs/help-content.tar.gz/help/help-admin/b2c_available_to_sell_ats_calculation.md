# Available to Sell (ATS) Calculation

_The available to sell (ATS) quantity is the number of units of a product that B2C Commerce can sell, calculated from allocation, preorder and backorder allocation, turnover, and on-order values. The formula varies by product type: standard, variation, base product, product set, and product bundle. This quantity feeds the orderable and in-stock status covered in Availability Calculation._

The ATS calculation depends on the product type: standard, variation, base product, product set, or product bundle.

> **Important:** If you use Salesforce Omnichannel Inventory, then Omnichannel Inventory performs all availability calculations and sends read-only availability data to B2C Commerce. Individual inventory records in B2C Commerce are read-only.

### Standard Product ATS Calculation

ATS represents the quantity of a product allocated for sale that hasn’t shipped and that isn’t being held for pending orders, plus its quantity available for backorders and preorders. In general, the ATS is the sum of the allocation and preorderBackorderAllocation, reduced by the turnover and the (optional) on order quantity. By default, it's equal to the number of units of a product that are allocated to sell (the `allocation` value).

> **Note:** When using Omnichannel Inventory, the preorderBackorderAllocation quantity is the sum of the future restock quantities, and the on order quantity isn’t used.

The following are some key formulas:

| Value | Formula |
| --- | --- |
| ATS | ATS = max(0, allocation + preorderBackorderAllocation - turnover – on-order) |
| Stock level | StockLevel = max(0, allocation - turnover – on-order) |
| Available for shipping | Available for shipping = max(0, allocation - turnover ) |

Turnover represents a running count of a product's unit sales since the last inventory update. The optional On Order quantity represents the quantity that’s ordered but isn't yet exported for shipping. The turnover doesn't include the On Order quantity.

> **Note:** On Order Inventory isn’t compatible with Omnichannel Inventory.

When products are added to the shopping cart, they aren’t subtracted from ATS. Adjustments to ATS only occur at final checkout. Adding a product to the shopping cart doesn't reserve the product or guarantee its availability at checkout.

> **Note:** Business Manager shows the number of units of a product that are available to sell (ATS). Click App Launcher _(image: App Launcher)_, and then select **Site > Products and Catalogs > Inventory**. Open an inventory list, and then click **Records**.

If a merchant chooses to use B2C Commerce to calculate the ATS value between inventory updates, the following conditions must apply:

- The product must have a product inventory record
- The product's Perpetual field isn’t checked (`perpetual = false`).

If the customer supports backorders or pre-orders, the product's Pre-Order/Backorder Handling field is set to `Pre-Order` or `Backorder` (`backorderable = true` or `preorderable = true`)

> **Note:** When using Omnichannel Inventory, the preorderable flag is always false, and the backorderable flag is true if the product has any future restocks in Omnichannel Inventory.

A change to a product's `turnover`, `allocation`, or `preorderBackorderAllocation` values result in a recalculation of ATS. When the allocation level is reset, the turnover value is set to zero, but the on-order value isn't changed.

### Base Product and Variation ATS Calculation

A base product doesn’t have its own product record, so it has no ATS quantity of its own. In previous versions of B2C Commerce, a single product record was used to calculate ATS for a base product, and that record is still included for legacy applications. For information about how a base product’s availability and search ranking resolve from its variation products, see [b2c_availability_calculation.xml](https://help.salesforce.com/s/articleView?id=cc.b2c_availability_calculation.htm&type=5).

### Product Bundle ATS Calculation

A product bundle can have its own product record in addition to the inventory records for the bundled products. Whether the bundle has its own inventory record, and whether the Use Bundle Inventory Only option is selected on the Inventory List page, determines which stock levels an order decrements.

- If the bundle has no inventory record and Use Bundle Inventory Only isn’t selected, placing an order that contains the bundle decrements the stock level of all bundled products.
- If the bundle has an inventory record and Use Bundle Inventory Only isn’t selected, placing an order decrements the stock level of both the bundle and all bundled products.
- If the bundle has an inventory record and Use Bundle Inventory Only is selected, placing an order decrements the stock level of the bundle only, not the bundled products.

For information about how these same options determine whether a bundle is orderable or in-stock, see [b2c_availability_calculation.xml](https://help.salesforce.com/s/articleView?id=cc.b2c_availability_calculation.htm&type=5).

### Product Set ATS Calculation

A product set doesn’t have its own product record, so it has no ATS quantity of its own. In previous versions of B2C Commerce, a single product record was used to calculate ATS for a product set, and that record is still included for legacy applications. For information about how a product set’s availability and search ranking resolve from its set products, see [b2c_availability_calculation.xml](https://help.salesforce.com/s/articleView?id=cc.b2c_availability_calculation.htm&type=5).
