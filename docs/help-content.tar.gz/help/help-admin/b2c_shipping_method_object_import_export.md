# Shipping Method Object Import/Export in B2C Commerce

_Use the shipping.xsd schema file to import shipping methods. This topic applies to B2C Commerce._

### Business Manager Import Location

*Granularity:* selected shipping methods.

**Ordering  >  Import & Export**

### Pipelets

ImportShippingMethods

ExportShippingMethods

*Granularity:* passed shipping methods.

### Schema Elements

Product Shipping Line Items

The order.xsd export format supports the product shipping line items via these types:

```
<xsd:complexType name="complexType.ProductLineItem">
<xsd:complexType name="complexType.ProductShippingLineItem">
<xsd:simpleType name="simpleType.ProductShippingCostType">
```

The shipping.xsd schema file (shipping methods section) also represents the item-level shipping costs and exclusions.

Trimmed Whitespace

When editing the product rules of promotions and shipping methods, it's possible to enter IDs for Products, Price Books, Brands, or Catalog Categories with leading and trailing white spaces. Business Manager trims the IDs when saving a product rule. The promotion and shipping method export also trims the IDs contained in the product rules of existing promotions or shipping methods

Call Center API - Order Export

For applications that use the Call Center APIs, order export reports the following status codes:

- EXPORT_STATUS_NOTEXPORTED: Optional date when an order can be exported (exportAfter).
   
   This status code is the initial status after the order is created. An export after date can already be defined, which is used when the order status changes to *READY.*
   
   Result: An order can't be exported with this status.
- EXPORT_STATUS_READY: Optional date when an order can be exported (exportAfter).
   
   This status code indicates that the order is validated and ready for export to an external system. The export can happen unless the order *exportAfter* attribute represents a date in the future. If the attribute represents a date in the future, the order is essentially *on-hold.* During order modification, *exportAfter* prevents an order from being exported prematurely.
   
   Result: An order can be exported with this status.
- EXPORT_STATUS_EXPORTED: This status code is the final state after an order has been exported.
   
   Result: This status indicates that an order has been exported.
- EXPORT_STATUS_FAILED: Indicates that an order export to a third-party system failed. The status indicates that exporting this order failed. Correct the problem manually before exporting the order again.
   
   Result: This status indicates that an attempted order export failed.

The *exportAfter* time can be set only in the status EXPORT_STATUS_NOTEXPORTED or EXPORT_STATUS_READY. However, the time is only evaluated in the state EXPORT_STATUS_READY. The time delays the actual export of an order, which otherwise is ready for export.
