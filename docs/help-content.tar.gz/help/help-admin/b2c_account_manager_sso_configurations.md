# B2C Commerce Configurations

_Complete SSO configuration._

[Which Salesforce Commerce Product Do I Have?](https://help.salesforce.com/s/articleView?id=commerce.comm_what_product.htm)

Follow the steps in [Identity Federation with Salesforce Identity in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_account_manager_identity_federation.htm&type=5) to complete SSO Configuration

- [Configure Account Manager for Identity Federation in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_account_manager_configure_account_manager_for_identity_federation.htm)
- [Activate the Connection Between Account Manager and Salesforce in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_account_manager_activate_the_connection_between_account_manager_and_salesforce.htm&type=5)
- [Install Account Manager in Your Salesforce Org in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_account_manager_activate_the_connection_between_account_manager_and_salesforce.htm)

## Related Content

- [Set up and Integrate OKTA with Salesforce Identity](https://help.salesforce.com/s/articleView?id=cc.b2c_account_manager_sso_integrate_okta.htm&type=5)
  This guide serves as a general integration overview for B2C Commerce. For precise instructions, Salesforce advises consulting the most up-to-date integration documentation specific to your Identity Provider (IDP), such as Okta.

- [Configure an Azure AD Security Assertion Markup Language (SAML) Provider](https://help.salesforce.com/s/articleView?id=cc.b2c_account_manager_sso_configure_azure.htm&type=5)
  This guide serves as a general integration overview for B2C Commerce. For precise instructions, Salesforce advises consulting the most up-to-date integration documentation specific to your Identity Provider (IDP), such as Azure IDP.

- [Configure Duo as an Authentication Provider](https://help.salesforce.com/s/articleView?id=cc.b2c_account_manager_sso_configure_duo.htm&type=5)
  This guide serves as a general integration overview for B2C Commerce. For precise instructions, Salesforce advises consulting the most up-to-date integration documentation specific to your Identity Provider (IDP), such as Duo.
