# B2C Commerce Configurations

_Complete SSO configuration._

[Which Salesforce Commerce Product Do I Have?](https://help.salesforce.com/s/articleView?id=commerce.comm_what_product.htm)

Follow the steps in [Identity Federation with Salesforce Identity in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_account_manager_identity_federation.htm&type=5) to complete SSO Configuration

- [Configure Account Manager for Identity Federation in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_account_manager_configure_account_manager_for_identity_federation.htm)
- [Activate the Connection Between Account Manager and Salesforce in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_account_manager_activate_the_connection_between_account_manager_and_salesforce.htm&type=5)
- [Install Account Manager in Your Salesforce Org in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_account_manager_activate_the_connection_between_account_manager_and_salesforce.htm)
