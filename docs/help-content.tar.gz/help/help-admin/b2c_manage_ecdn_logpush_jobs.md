# Manage Logpush Jobs

_Pause, edit, or delete the eCDN Logpush jobs configured for a zone on your B2C Commerce storefront. The Logpush table on the Logs tab lists every job configured for the zone, with a header counter such as Logpush (2) and You have used 2 out of 2 Logpush jobs._

[Which Salesforce Commerce Product Do I Have?](https://help.salesforce.com/s/articleView?id=commerce.comm_what_product.htm)

To create the jobs that appear in this table, see [Create a Logpush Job](https://help.salesforce.com/s/articleView?id=cc.b2c_create_ecdn_logpush_job.htm&type=5). The Logpush table shows these columns.

- **Dataset**: The dataset being pushed (HTTP Requests, Firewall Events, or Page Shield Events).
- **Destination**: A short summary of the destination, including provider logo, bucket or site, and any encryption flag.
- **Status**: Pushing when delivery is healthy, Pending when the destination hasn't been validated, or an error state.
- **Enabled**: Toggle the job on or off without deleting it.
- **Actions**: Per-row actions menu with Edit and Delete.

1. On the **Logs** tab, find the job you want to manage in the Logpush table.
2. To pause delivery without losing the configuration, switch the **Enabled** toggle off.

   The job remains in the table and counts toward the 2-job limit.
3. To change the destination, dataset, filter, or directives, open the row's actions menu and select **Edit**.

   A confirmation appears before destination-changing edits.
4. To permanently remove the job, open the row's actions menu, select **Delete**, and confirm.

   A confirmation appears before delete.
