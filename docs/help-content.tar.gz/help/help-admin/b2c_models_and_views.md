# SiteGenesis Models and Views

_In B2C Commerce SiteGenesis, the controllers integrate into Models and Views. All scripts are Common JS modules with defined and documented exports to avoid polluting the global namespace._

The controllers integrate into Models and Views. All scripts are Common JS modules with defined and documented exports to avoid polluting the global namespace.

**Model and View Modifications**

`CartModel.js`–Model for cart functionality. Creates a CartModel class with payment, shipping, and product helper methods.

- Adjust the `validatePaymentInstruments` function for use with validating Stripe or PayPal objects.

**`CartView.js`**–View used to render the cart. This view makes sure the coupons, shipments, and basket calculation are up to date before rendering the cart.  Require the `paymentHelpers` script from `plug-in_commercepayments` To present express checkout on cart page, use it to create a payment request and supporting data
