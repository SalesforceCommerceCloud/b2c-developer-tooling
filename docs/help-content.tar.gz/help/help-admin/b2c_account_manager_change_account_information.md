# Change Account Information in B2C Commerce

_Change your account information with Account Manager. You can't change your email address, but you can change other account values, such as your business phone number. Also, depending on the multi-factor authentication (MFA) verification method settings of your organization, you can register methods for verifying your identity when logging in to B2C Commerce applications._

[Which Salesforce Commerce Product Do I Have?](https://help.salesforce.com/s/articleView?id=commerce.comm_what_product.htm)

1. Log into Account Manager.
2. Click **Account Details**.

   The Account Details page shows several fields whose values you can modify: First Name, Last Name, Business Phone, Mobile Phone, Home Phone, and Preferred Language.
3. After you change the field values, click **Update**.

   A message appears indicating that your account details are successfully updated.
4. Click **Continue**.
