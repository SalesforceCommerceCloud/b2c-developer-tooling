# Configure B2C Commerce Alerts in Business Manager and Slack

_Set up notifications for your organization in Business Manager and Slack. Configure updates, such as security vulnerabilities, campaign and promotion updates, or site alerts, to appear on your Business Manager homepage. You can also send updates directly to your Slack workspaces._

|  |
| --- |
| Available in: **B2C Commerce** |

1. In Business Manager, click App Launcher _(image: App Launcher)_, and then select **Administration > Operations > Notifications**.
2. On the Settings tab, select whether you want an alert to show on your Business Manager homepage or heading.
3. Select one or more Slack Channels to send alerts to.

   Changes are saved automatically.
