# Replicate Products with Granular Replication

_Replicate products and product images from staging to production._

|  |
| --- |
| Available in: **B2C Commerce** |

Turn on Granular Replication. See [Enable Granular Replications for Your B2C Commerce Site](https://help.salesforce.com/s/articleView?id=cc.b2c_enable_granular_replication_for_your_site.htm&type=5).

1. In Business Manager, click App Launcher _(image: App Launcher)_, and then select **Merchant Tools > Site > Products and Catalogs > Products**.

   You can’t replicate products that don’t yet exist on production instances.
2. Enter the product name or ID, and click **Find**.
3. Select the product to replicate.

   To update the product before you replicate it, lock the product for editing. Make your changes, and then unlock the product.
4. Click **Publish**.

   _(image: Click Publish for a product.)_
   
   _(image: A message appears stating that the product is queued for publication.)_
   
   _(image: Click Publish from the Product Search list.)_
