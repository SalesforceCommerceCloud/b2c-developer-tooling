# Manage Salesforce B2C Commerce Users

_When you add new B2C Commerce users (for example, Business Manager users), assign roles that restrict access to only the modules they need. When an administrator views the list of users, they can see when a user last logged in and the number of days since then. This information appears in the instance's timezone._
