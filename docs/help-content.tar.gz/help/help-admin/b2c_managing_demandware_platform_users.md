# Manage Salesforce B2C Commerce Users

_When you add new B2C Commerce users (for example, Business Manager users), assign roles that restrict access to only the modules they need. When an administrator views the list of users, they can see when a user last logged in and the number of days since then. This information appears in the instance's timezone._

## Related Content

- [Change User Information in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_changing_user_information.htm&type=5)
  Both users and administrators can edit user information in B2C Commerce.
