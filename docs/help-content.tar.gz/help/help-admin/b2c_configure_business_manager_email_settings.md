# Configure Business Manager Email Settings

_To define your own SMTP server for customer and platform email delivery, configure email settings. This topic applies to B2C Commerce._

|  |
| --- |
| Available in: **B2C Commerce** |

1. In Business Manager, click App Launcher _(image: App Launcher)_, and then select **Administration > Operations > Email Settings**.
2. Click the **Use customer email configuration** checkbox.
3. Enter username.
4. Enter password.
5. Enter hostname.

   > **Note:** Make sure the SMTP server supports STARTTLS.
6. Use the default port 587.
7. Enter a From address.
8. (Optional) To use the defined server for your customer and platform emails, check **Use for all email**.

   > **Note:** When Use for all email isn’t checked, only outgoing customer email uses the configured server, such as email that you generate to send to your shoppers. All platform email continues to use the default SMTP server that Salesforce provides.
