# Manually Migrate Users to Unified Authentication

_Sometimes users can't link their Business Manager and Account Manager profiles. When the two accounts have different email address, a user can't migrate to unified authentication. However, you can manually migrate the user from Business Manager to Account Manager. This applies for administrators who are manually migrating users to unified authentication. This doesn’t apply to administrators who started using B2C Commerce after October of 2019 because their organizations automatically use unified authentication._

|  |
| --- |
| Available in: **B2C Commerce** |

1. In Account Manager, click **User**.
2. Select the user.
3. Copy the User ID.
4. In Business Manager, click App Launcher _(image: App Launcher)_, and then select **Administration > Organization > Users**.
5. Select the user.
6. Paste the User ID in the Account Manager User ID field.
7. Click **Apply**.
