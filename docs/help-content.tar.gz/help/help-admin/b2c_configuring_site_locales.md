# Configure Site Locales for B2C Commerce

_Salesforce B2C Commerce is structured as an organization containing one or more sites (storefronts). Define locale settings in Business Manager for these two entities, first at the organization level and then at the site level._

|  |
| --- |
| Available in: **B2C Commerce** |

Other areas where you can assign locales:

- When adding or changing Business Manager users and user information
- Taxation jurisdiction and rates
- URLs and sitemaps
- Products and content
- System objects

1. Configure organization settings (Do this step first).
2. To add currencies to your site, select **Merchant Tools**** *site* **** *site* ** **Site Preferences** **Currencies**.

   1. Add the currency
   2. Click **Add**.
3. To configure locales for your site, click App Launcher _(image: App Launcher)_, and then select **Merchant Tools >  *site*  > Site Preferences > Locales**.

   1. Identify which active locales are allowed in storefront requests of a particular site.
   2. If a locale isn't included in the storefront request, mark one locale as the default to use.
   3. Now select the newly added local, **fr_NL**.
4. Add custom site preferences, such as shown in the SiteGenesis application by clicking App Launcher _(image: App Launcher)_, and then selecting **Merchant Tools >  *site*  > Site Preferences > Custom Preferences**.

   1. Configure the default country code.
   2. Configure the store lookup unit (km (kilometers) or mi (miles)).
5. To configure date format for site locales, click App Launcher _(image: App Launcher)_, and then select **Administration > Global Preferences > Locals**

   1. Select the Regional Setting.
   2. (Available with the 24.2 Release) Modify the date setting to match the date format for the local or regional context.
   
   The setting also sets the date format of the returned date value for the Script API method `dw.util.Calendar.getFirstDayOfWeek()`.
