# Create a Data Replication Process in B2C Commerce

_Trigger a data replication process manually, schedule it to run at a specified time or recur at a specified interval, or create a job to run it._

[Which Salesforce Commerce Product Do I Have?](https://help.salesforce.com/s/articleView?id=commerce.comm_what_product.htm)

1. Click App Launcher _(image: App Launcher)_, and then select **Administration > Replication > Data Replication**. A list of existing data replication processes appears.
2. Copy an existing process, or create one from scratch.

   - To copy an existing process, select it in the list, then click **Copy**. Select multiple processes and copy them all at once. To modify a generated process, click its process ID to open its details page, then click **Edit**.
   - To create a replication process from scratch, click **New**, then continue with the steps to configure it.
3. The system generates a process ID. Enter a different ID.
4. From the dropdown list, select a target instance.
5. (Optional) Enter a description.
6. From the dropdown list, select a page cache invalidation strategy.

   - Invalidate: (Default) The page cache gets refreshed on the target instance at the end of the replication process.
      
      > **Note:** Clearing the cache temporarily degrades your site’s performance.
   - Invalidate Impacted Cache Partitions: Any page cache partitions with assigned replication tasks that match those selected for the current replication process are invalidated. The rest of the storefront’s page caches. remains untouched.
   - Don’t Invalidate: The page cache doesn’t get refreshed. Select this option during times of high traffic. However, if you don't refresh the cache, shoppers can see outdated content on the storefront. Use this option with caution.
7. From the dropdown list, select an activation type. Remember that data is replicated in its state at the time the process runs, not the time when the process is defined.

   | Option | Description |
   | --- | --- |
   | Manual | The process runs when you manually trigger it. |
   | Automatic | You schedule a single time when the process runs. Selecting this option displays date and time fields. The default value is the next midnight. |
   | Recurring | You schedule a recurring time when the process runs. Selecting this option displays interval, date, and time fields. The default value is every day at midnight. |
   | Job Step | The process is available to run as part of a job. |
8. From the dropdown list, select a notification email trigger. To enter multiple recipient email addresses, separate them with commas.

   | Option | Description |
   | --- | --- |
   | -None- | No emails are sent. |
   | When Process Ends | Sends an email to the specified addresses when the process ends, whether it succeeds or fails. If it hangs, then no email is sent. |
   | When Process Fails | Sends an email to the specified addresses only if the process fails. If the process succeeds or hangs, then no email is sent. |
   | Periodically | Enter an interval in minutes. While the process is running, emails are sent to the specified addresses at that interval until the process finishes. An email is also sent when the process succeeds or fails. |
   
   The email notifications contain the start and end time of the process, the target system, the replication type, and the included replication tasks. If there’s a failure, they also include an error code. Each process in a recurring series sends its own notification.
9. Click **Next**.
10. From the dropdown list, select a replication type.
11. Select the replication tasks to include. See [b2c_data_replication_tasks.xml](https://help.salesforce.com/s/articleView?id=cc.b2c_data_replication_tasks.htm&type=5).

   Site-level replication tasks for new sites are disabled until you successfully run a replication that includes their global-level site tasks.
12. Click **Next** and review the process details.
13. Click **Create** or **Schedule** to create the process. If you selected Manual activation, click **Start** to create the process and immediately run it.

   After the data replication process has begun, it can't be deleted.
