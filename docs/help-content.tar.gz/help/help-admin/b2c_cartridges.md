# SiteGenesis Cartridges

_A cartridge is a mechanism for packaging and deploying program code and data. You use cartridges to extend business functionality or integrate with external systems. A cartridge can deliver generic or application-specific functionality._

Salesforce Payments is a plug-in cartridge for Salesforce Reference Architecture (SFRA). Because SiteGenesis doesn’t easily support cartridges, overlaying the Payments cartridge on SiteGenesis isn’t a feasible solution. As a workaround, add the `app_storefront_core:plug-in_commercepayments` cartridge to your cartridge path for use as a library.

Example:

my_sitegenesis_override:app_storefront_controllers:app_storefront_core:plug-in_commercepayments

Adding the `app_storefront_core:plug-in_commercepayments` cartridge doesn’t work in all instances.
