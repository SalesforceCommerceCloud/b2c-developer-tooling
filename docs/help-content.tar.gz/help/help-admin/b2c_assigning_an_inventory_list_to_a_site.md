# Assign an Inventory List to a Site

_Assign an inventory list to one or more B2C Commerce sites._

A site can be assigned to only one inventory list.

1. Click App Launcher _(image: App Launcher)_, and then select **Merchant Tools > Site > Products and Catalogs > Inventory**.

   If you see unavailable fields, you have read-only permission. You can search for inventory lists and view their details. You can't modify, delete, or create inventory lists. If you have mixed permission to access one module (via different roles), the higher-level access is granted. See your administrator if you require write access.
   
   For read-only access, the role still needs the functional permissions, either `Manage_Inventory` (for all inventory lists globally) or `Manage_Site_Inventory` for selected sites.
2. Click **Edit** for an inventory list.
3. Select the **Site Assignments** tab.
4. Select the site to which you want to assign the inventory list.

   If the site has another list already assigned, that list is unassigned.
5. Click **Apply**.

   Assign an inventory list to more than one site at a time. The initial site import can import the assignments of inventory lists to certain sites. Each site can reference the ID of an inventory list. If so, to activate the assignment, create (or import) an inventory list with the same ID referenced by the individual assignment of the imported sites. If an inventory list is removed, the site assignment remains and activates again once you create an inventory list with the same ID.
