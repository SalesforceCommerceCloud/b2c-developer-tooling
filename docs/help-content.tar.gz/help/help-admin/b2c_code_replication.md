# Code Replication in B2C Commerce

_Code replication transfers a code version from staging to a development or production instance and activates it on the target instance. This topic applies to B2C Commerce._

## Related Content

- [Code Replication Processes in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_code_replication_processes.htm&type=5)
  Each code replication process transfers a code version, activates a transferred code version, transfers and activates a code version, or reverts the active code version on the most recent target instance. This topic applies to B2C Commerce.

- [Create a Code Replication Process in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_create_code_replication_process.htm&type=5)
  Trigger a code replication process manually, schedule it to run at a specified time, or create a job to run it.

- [Undo a Code Replication Process in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_undo_code_replication_process.htm&type=5)
  When you undo a code replication, the target instance reverts to the previously active code version. Only run an undo process after a code replication process of type Activation or Transfer & Activation.
