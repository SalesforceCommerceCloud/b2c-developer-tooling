# Code Replication in B2C Commerce

_Code replication transfers a code version from staging to a development or production instance and activates it on the target instance. This topic applies to B2C Commerce._
