# Configure Commerce Intelligence Preferences for IP Filtering

_Internal performance and load testing tools can contaminate the data you see in Reports and Dashboards, making it difficult to distinguish between generated traffic and actual customer behavior. Specify IP address ranges to filter out traffic from your internal testing tools, ensuring that your analytics reflect genuine customer interactions._

|  |
| --- |
| Available in: **B2C Commerce** |

IP filtering applies to customer-focused analytics that track visitor behavior and business metrics (such as traffic, sales, and conversion reports), but does not affect technical performance reports that monitor system operations (such as pipeline performance, cache hit ratios, response times, and robot traffic).

> **Note:** IP filtering applies only to future data collected after you configure the IP ranges. Previously collected data is not affected.

1. In Business Manager, click App Launcher _(image: App Launcher)_, and then select **Merchant Tools >  *site*  > Site Preferences > Intelligence Platform**.
2. In **IP Ranges to Filter:**, enter one or more comma-separated [IPv4 CIDR](https://en.wikipedia.org/wiki/Classless_Inter-Domain_Routing#CIDR_notation) blocks (for example, 192.168.1.0/24).
3. Click **Apply**.
