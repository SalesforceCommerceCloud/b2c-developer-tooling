# cross-site request forgery (CSRF) Protection in Business Manager

_A CSRF attack is a technique used by malicious attackers to force a victim to make a protected request to B2C Commerce Business Manager ― a request that can severely disrupt your eCommerce business._

### CSRF Attacks

All Business Manager pages are automatically protected from CSRF attacks. Whenever a Business Manager page makes a request to the B2C Commerce server, the page automatically injects a special CSRF token into the request. When the server receives the request, the server determines whether the request is trying to perform a protected (potentially harmful) action. If the request tries to perform such an action, the server automatically validates the injected token. If it can successfully validate the token, the server completes the protected action and returns the expected response; otherwise, starting in 17.4 in SIGs and 17.5 in PIGs, the server logs a warning and in some cases returns an error page.

If you see an error page, follow the given steps and retry the page where the error occurred. If the retry succeeds, you can ignore the error; but if the retry fails and you see the error again, you're likely experiencing* ―* and being protected from* ―* a CSRF attack. In this case, contact your security department.

Not all CSRF-related errors or log entries indicate an attack. If you're a Salesforce admin, troubleshoot CSRF log entries to investigate their underlying causes and determine an appropriate course of action. In some cases, if you're using a custom Business Manager extension, a developer needs to modify the extension's custom code to properly insert CSRF tokens. In other cases, you can choose to allowlist either a specific pipeline or user agent.

### Troubleshooting CSRF Log Entries

CSRF log entries have the following format:

Pipeline CSRF Token not valid[*reason*]: *pipeline*: (*token*|*no_token*):: Referer/Origin:* URL*:: UserAgent: *agent*

Where:

- *reason* is a string explaining why the validation failed. Some possible reasons are:
   
   - Origin validation*―* the request came from a website that isn't a Business Manager page.
   - No token*―* the request was made without a CSRF token.
   - CSRF token validation*―* the token is incorrect for this user, or it has timed out (1-hour timeout).
   - Exception occurred*―* something unexpected happened during processing (this error is a catch-all).
- *pipeline* is the name of the pipeline in the request.
- *token* is the token received by the server (if one was sent in the request).
- *no_token* is a string indicating that no token can be found in the request: "CSRF Token doesn't exist."
- *URL* is a URL indicating where the request originated.
- *agent* is the first 32 characters of the user agent.

To find these entries in your log files, search for the string "Pipeline CSRF Token."

See [Log Center](https://help.salesforce.com/s/articleView?id=cc.b2c_log_center.htm&type=5).

The server creates log entries whenever it expects a valid CSRF token, but either can't find one, or finds an invalid one. These situations can cause log entries:

| Situation | Possible remedy |
| --- | --- |
| The Business Manager user was attacked. If the user reached the error page after visiting another site, the other site tried to make a protected request to Business Manager, and the framework has properly protected against the attack. | The Business Manager user reports this attack to their security department. |
| The Business Manager user wasn't attacked, and the log entry suggests that no token was found. A likely cause is that the automatic token injection failed to inject properly in custom Business Manager extensions. B2C Commerce has discovered several places where this can happen, including:  A URL formed inside of a JavaScript variable, as an argument for a JavaScript method, or as an onclick handler. A URL formed inside of a `<meta>` tag, in particular, refresh. A URL formed inside of an `<isset>` or custom-defined tags. A URL defined inside of a pipeline, pipeline dictionary, or code. | To manually add the token, the developer uses the `dw.web.URL.appendCSRFTokenBM()` method. For example, the developer can change the following code: <meta http-equiv="refresh" content="0; URL=${dw.web.URLUtils.url('ViewAccount-Show').toString()}"> to this: <meta http-equiv="refresh" content="0; URL=${dw.web.URLUtils.url('ViewAccount-Show').**appendCSRFTokenBM()**.toString()}"> |
| The Business Manager user was not attacked, and the log entry suggests that the token was invalid. Because tokens become invalid after 60 minutes, it's possible for the user to return to an old browser tab and make a request that fails to validate. This can also occur on a small number of pages that update the data shown within that page without navigating to another page within Business Manager. | The Business Manager user can refresh the page where the error occurred. |
| The Business Manager user wasn't attacked, but instead of making the request to the server from a Business Manager, the user made the request from an email, a bookmark, or a separate website. | To let users make requests from emails, bookmarks, or separate websites, it's recommend to create a new start node in the pipeline that serves as a safe redirect to the desired page. A developer performs this task. When the developer completes this task, an administrator can [allowlist](https://help.salesforce.com/s/articleView?id=cc.b2c_configure_csfr_allowlist_settings.htm&type=5) the redirect pipeline-start node combination. This disables CSRF validation for that start node for all users. |
| The Business Manager user wasn't attacked, but the request can't be protected or hasn’t been protected yet. | An administrator can use a CSRF [allowlist](https://help.salesforce.com/s/articleView?id=cc.b2c_configure_csfr_allowlist_settings.htm&type=5) to temporarily disable validation on either the pipeline or pipeline/start node combination. This is generally **not recommended**. |
| An automated script collects data from a Business Manager instance, or imports data for automated testing. | An administrator can use a CSRF [allowlist](https://help.salesforce.com/s/articleView?id=cc.b2c_configure_csfr_allowlist_settings.htm&type=5) to allow the User-Agent of the script. It's *strongly* recommended that if you use this approach, use a non-browser User-Agent string. This disables the validation logic for all requests where the User-Agent exactly matches that allowlisted value.  Alternatively, customers can choose to give the automated scripts knowledge of the CSRF token (which B2C Commerce embeds in every Business Manager page) and use the token in script-based requests. This mimics the behavior of browser-based navigation and is the recommended approach. |
