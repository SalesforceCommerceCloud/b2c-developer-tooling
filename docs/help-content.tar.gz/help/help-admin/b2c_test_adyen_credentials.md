# Test Your Adyen Merchant Account Credentials for B2C Commerce

_Validate your payment gateway credentials for your Adyen merchant account._

1. In Business Manager, click App Launcher _(image: App Launcher)_, and then select **Administration > Site > Global Preferences > Salesforce Payments**.
2. Click into the Adyen merchant account that you want to test.
3. Select **Credentials**.
4. Enter the Client Key and the API Key.

   Find your payment gateway credentials in your providerʼs dashboard. To maintain a secure connection between B2C Commerce and your Adyen payment gateway, regularly update your API key.
5. To validate that your credentials are correct, click **Test Gateway Connection**.
