# Omnichannel Inventory Data Synchronization

_Visible inventory availability data is eventually consistent, meaning that an update can take time (usually a few seconds) to be reflected in the UI or API. Therefore, when B2C Commerce makes an inventory reservation in Omnichannel Inventory, you can’t assume that availability data immediately reflects the quantities assigned to that reservation. However, Omnichannel Inventory accepts a reservation request only if it actually has inventory available to fulfill that order._

> **Important:** The inventory data cache is limited to 100,000,000 records.
