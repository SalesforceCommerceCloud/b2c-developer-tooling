# Manage Sections and Modules in a Custom B2C Business Manager App

_Organize your custom Business Manager app by creating sections, adding modules, and dragging modules between sections to reorder them._

_(image: Menu with Add Pages, Create New Section, Rename, and Delete options)_

1. Next to a section, click the ellipsis icon.
2. Choose an action:

   - **Add Pages** — Opens the page selector, where you filter by app or section and select modules to add.
   - **Create New Section** — Adds a new section to your modules.
   - **Rename** — Updates the section name.
   - **Delete** — Removes the section and its modules from your custom app's left navigation.
