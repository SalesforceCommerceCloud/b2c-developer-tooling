# Fail Securely

_Fail securely means implementing decision logic that puts systems into a secure state when errors occur. Handling errors securely ensures that the error path, such as exceptions, doesn’t disclose additional information that wouldn’t be available otherwise. Attackers can use this additional information to learn how to attack the system._

Here are some best practices.

- Don't use an error message that discloses information about the web server configuration because it can help an attacker identify potential weaknesses.
- Use a generic “username or passphrase is invalid” message instead of “username not found” or “password is incorrect” to prevent user enumeration.
