# Save a Search Rule

_Save search filter settings in B2C Commerce Log Center to use when needed. For example, use a search rule to set up recurring notifications._

1. From the Search page, select the Search dropdown and select **Save Search**.
2. Enter a search rule name.
3. (Optional) Enable notification.

   1. Enter a time interval for how often you want to run the search rule.
   2. Enter a Threshold for the total number of times you want to run the search rule.
4. Enter additional email addresses for individuals to receive the notification.
5. Save.
