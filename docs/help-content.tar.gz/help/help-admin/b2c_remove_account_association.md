# Remove a Merchant Account from B2C Commerce

_Remove a merchant account from your B2C Commerce instance to end the association between them. You can't remove a merchant account that serves as the default for a payment zone until you reassign that default to a different merchant account. After removal, B2C Commerce clears the account from all payment zones._

1. In Business Manager, click App Launcher _(image: App Launcher)_, and then select **Administration > Site > Global Preferences > Salesforce Payments**.
2. Locate the merchant account that you want to remove.
3. From the actions menu, click **Remove**.
