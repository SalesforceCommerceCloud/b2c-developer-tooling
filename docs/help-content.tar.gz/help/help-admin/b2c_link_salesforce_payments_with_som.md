# Link Salesforce Payments for B2C Commerce with Salesforce Order Management

_To integrate your existing B2C Commerce merchant account with Salesforce Order Management, first link your B2C merchant account to a merchant account and a Payment Gateway record for Salesforce Payments on the core Salesforce platform. The same Stripe or PayPal account you established for your B2C merchant account gets linked to the new records on the core platform._

If your merchant accounts are linked to a Stripe account, Order Management can capture payments and issue refunds. If your merchant accounts are linked to a PayPal account, Order Management can only issue refunds.

To integrate the two products, a Payments license and an Order Management license are required. You can also use a Connected Commerce license.

To integrate Payments and Order Management:

1. Enable Salesforce Payments and Order Management on the same core Salesforce platform org.
2. From the Payments app on the Salesforce platform, follow the merchant account guided setup to add a merchant account that connects to an existing Stripe or PayPal account. This payment gateway account must be an account established for your B2C Commerce merchant account. Don’t create a new Stripe or PayPal account.

   > **Note:** The Stripe and PayPal accounts that you link the merchant account to must be an account established for Salesforce and not a standard account purchased through Stripe or PayPal.

After an order is placed, Order Management handles the post-purchase experience from order creation to fulfillment and delivery.
