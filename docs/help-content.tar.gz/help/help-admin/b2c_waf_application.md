# eCDN Web Application Firewall

_Embedded Content Delivery Network (eCDN) Web Application Firewall (WAF) helps protect your storefront using extra layer 7 protection._

### WAF on On-Demand Sandboxes (ODS)

All standard WAF capabilities are available on ODS Default Domain zones, including the OWASP ruleset, eCDN Managed ruleset, custom firewall rules, bot protection, DDoS mitigation, and rate limiting. Configure these via the Business Manager eCDN UI or CDN API.

Because ODS uses a shared zone model, WAF rules configured on the zone apply to all ODS instances in the realm. Rules are not scoped per instance. Plan rule changes carefully to avoid unintended impact across instances.

> **Important:** ODS zones don't have a default Block All firewall rule. Unlike some production zones, ODS zones are open by default. Add explicit rules as needed to restrict access.

For more information about Default Domain availability on ODS and the shared zone model, see [Default Domain Support for B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_default_domain.htm).

## Related Content

- [web application firewall (WAF) Protection](https://help.salesforce.com/s/articleView?id=cc.b2c_waf_protection.htm&type=5)
  Enabled by default when creating proxy zones, WAF is a layered approach to security and an important component of a multitiered approach to bad actor mitigation.

- [OWASP WAFv2 Managed Ruleset](https://help.salesforce.com/s/articleView?id=cc.b2c_waf_owasp_wafv2_managed_ruleset.htm&type=5)
  When responding to a potential web application threat, eCDN web application firewall (WAF) looks at each incoming request, assigns the request a threat score, and responds appropriately. Each incoming request that triggers an OWASP rule increases the overall threat score. Some rules impact the score more than others.

- [eCDN WAFv2 Managed Ruleset](https://help.salesforce.com/s/articleView?id=cc.b2c_waf_ecdn_wafv2_managed_ruleset.htm&type=5)
  Created by the eCDN security team, this ruleset provides fast and effective protection for all of your applications. The eCDN security team updates the ruleset frequently to cover new vulnerabilities and reduce false positives.

- [eCDN WAFv2 Exposed Credentials Check](https://help.salesforce.com/s/articleView?id=cc.b2c_waf_ecdn_wafv2_exposed_credentials_check.htm&type=5)
  Deploy an automated credential check on your end-user authentication endpoints. For any credential pair, the eCDN web application firewall (WAF) performs a lookup against a public database of stolen credentials. Created by the CDN security team, this ruleset provides fast and effective protection for all of your applications. The CDN security team updates the ruleset frequently to cover new vulnerabilities and reduce false positives.

- [Using web application firewall (WAF) for the First Time](https://help.salesforce.com/s/articleView?id=cc.b2c_waf_using_waf_first_time.htm&type=5)
  When using WAF for the first time, we recommend that you run WAF in Log or Simulate mode for at least one week.

- [Modify eCDN OWASP WAFv2 Settings](https://help.salesforce.com/s/articleView?id=cc.b2c_waf_modify_ecdn_owsap_wafv2_settings.htm&type=5)
  When responding to a potential web application threat, eCDN web application firewall (WAF) looks at each incoming request, assigns the request a threat score, and responds appropriately. Each incoming request that triggers an OWASP rule increases the overall threat score. Some rules impact the score more than others.

- [Modify eCDN Managed Ruleset Settings](https://help.salesforce.com/s/articleView?id=cc.b2c_waf_modify_ecdn_wafv2_ruleset_settings.htm&type=5)
  Created by the eCDN security team, this ruleset provides fast and effective protection for all of your applications. The eCDN security team updates the ruleset frequently to cover new vulnerabilities and reduce false positives. The default setting for the rule set is enabled.

- [Modify eCDN Exposed Credentials Check Settings](https://help.salesforce.com/s/articleView?id=cc.b2c_waf_ecdn_wafv2_exposed_credentials_check_settings.htm&type=5)
  Deploy an automated credential check on your end-user authentication endpoints. For any credential pair, the eCDN web application firewall (WAF) performs a lookup against a public database of stolen credentials. Created by the CDN security team, this ruleset provides fast and effective protection for all of your applications. The CDN security team updates the ruleset frequently to cover new vulnerabilities and reduce false positives.

- [web application firewall (WAF) and Network Traffic Logs](https://help.salesforce.com/s/articleView?id=cc.b2c_waf_net_traffic_logs.htm&type=5)
  The logs contain all eCDN network traffic, not just the traffic that WAF identifies. Track IP-reputation blocked traffic and analyze how much of your traffic doesn’t trigger WAF settings.

- [Modify eCDN WAF Settings](https://help.salesforce.com/s/articleView?id=cc.b2c_waf_configuring_how.htm&type=5)
  The eCDN Web Application Firewall (WAF) analyzes and interprets your HTTP/s traffic to protect your storefront. WAF stops application level attacks that attempt to exploit code-level vulnerabilities. Configure the security sensitivity level, and decide what action WAF takes when a suspicious web request attempts to access your storefront.

- [eCDN-web application firewall (WAF) Log OCAPI References](https://help.salesforce.com/s/articleView?id=cc.b2c_waf_log_ocapi_references.htm&type=5)
  Request eCDN-WAF log files from Open Commerce API (OCAPI). Each realm supports up to 24 pending log request downloads.A minimum period of five minutes is now enforced for retrieving WAF logs.
