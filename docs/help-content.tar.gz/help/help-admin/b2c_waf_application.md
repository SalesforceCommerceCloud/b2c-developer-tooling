# eCDN WAF on On-Demand Sandboxes

_B2C Commerce On-Demand Sandbox (ODS) Default Domain zones support the full embedded CDN (eCDN) web application firewall (WAF) feature set. Because ODS uses a shared zone model, plan rule changes carefully. The rules apply to every ODS instance in the realm._

[Which Salesforce Commerce Product Do I Have?](https://help.salesforce.com/s/articleView?id=commerce.comm_what_product.htm)

All standard WAF capabilities are available on ODS Default Domain zones, including the OWASP ruleset, the eCDN Managed ruleset, custom firewall rules, bot protection, DDoS mitigation, and rate limiting. Configure these settings through the Business Manager eCDN UI or the CDN API. For information about what each managed ruleset does, see [eCDN WAF Managed Rulesets](https://help.salesforce.com/s/articleView?id=cc.b2c_waf_managed_rulesets.htm&type=5).

Because ODS uses a shared zone model, WAF rules configured on the zone apply to all ODS instances in the realm. Rules aren't scoped per instance, so plan rule changes carefully to avoid unintended impact across instances.

> **Important:** ODS zones don't have a default Block All firewall rule. Unlike some production zones, ODS zones are open by default. Add explicit rules as needed to restrict access.

For more information about Default Domain availability on ODS and the shared zone model, see [Default Domain Support for B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_default_domain.htm).
