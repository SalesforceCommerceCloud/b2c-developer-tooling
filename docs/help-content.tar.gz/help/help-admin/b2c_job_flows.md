# B2C Commerce Job Flows

_A flow controls the sequence in which B2C Commerce executes job steps. Every job must contain at least one flow. Each flow must contain at least one step._

[Which Salesforce Commerce Product Do I Have?](https://help.salesforce.com/s/articleView?id=commerce.comm_what_product.htm)

Sequential flows execute one after the other. Sibling flows execute in parallel. Combine sequential and parallel flows in a job.

For example, use sibling parallel flows to download catalog files, followed by a sequential flow that imports catalog files, followed by another set of sibling parallel flows that download price files, followed by another sequential flow that imports the price files. The job can finish with a sequential flow that reindexes and replicates to production.

In the Business Manager UI, sequential flows take up the width of the page (1) and execute in the order shown, from top to bottom. Sibling flows appear next to each other and run simultaneously as long as system resources are available (2).

_(image: Job flows in the Business Manager UI, including the button to configure a step for a single sequential flow (1) and multiple sibling flows (2).)_

If parallel execution isn't possible, for example, when multiple steps access the same resources at the same time, configure sibling flows to execute sequentially. Sequential sibling flows execute from left to right.

If system resources aren't available, B2C Commerce executes sibling flows sequentially. If a job step doesn't support parallel execution, B2C Commerce executes the sibling flows sequentially. For example, the ExecutePipeline system step that supports legacy pipelines is always executed sequentially to avoid database conflicts.
