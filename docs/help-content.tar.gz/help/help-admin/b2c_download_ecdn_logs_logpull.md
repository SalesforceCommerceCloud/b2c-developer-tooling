# Download Logs with Logpull

_Use Logpull to download recent eCDN request logs for a zone on your B2C Commerce storefront on demand. Logs are available for the past 7 days only._

[Which Salesforce Commerce Product Do I Have?](https://help.salesforce.com/s/articleView?id=commerce.comm_what_product.htm)

To stream logs continuously to a customer-owned destination instead, see [Create a Logpush Job](https://help.salesforce.com/s/articleView?id=cc.b2c_create_ecdn_logpush_job.htm&type=5).

1. On the **Logs** tab, in the **Logpull** section, select one or more dates.

   Use **Select All Dates** to pick the full week.
2. For each selected date, choose an hour from the **Time** dropdown.
3. Click **Request Logs**.

The download link is delivered when the request is processed.
