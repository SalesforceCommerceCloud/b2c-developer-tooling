# Create a Microsoft Teams Channel for Log Center Alerts

_In B2C Commerce, use a Microsoft Teams notification channel to send Log Center alerts to a Teams chat or channel through a Power Automate workflow._

Create a Power Automate workflow that receives an HTTP request and posts the request body as an Adaptive Card in the target Teams chat or channel. Copy the generated workflow URL.

1. In Log Center, go to Alerts and select **Notification Channel Configurations**.
2. Click **Create Configuration**.
3. Enter a name and an optional description for the channel.
4. For Type, select **Microsoft Teams**.
5. Select at least one realm that can use the channel.

   A notification channel must be assigned to at least one realm. The selected realms control where you can use the channel. Admin and support roles control who can configure or manage it.
6. Paste the Power Automate workflow URL in the **Secret** field.

   > **Important:** Keep the workflow URL secure. It’s a credential for the workflow. Don’t share it in tickets, chat messages, source control, or screenshots.
7. Select **Save Configuration**.
8. When you create or edit a supported Log Center alert, including an anomaly detector, select the Microsoft Teams notification channel.

   Microsoft Teams supports anomaly detector alerts and other supported Log Center alert types when Microsoft Teams delivery is turned on for the environment.

Log Center sends the alert details to the configured workflow, which posts an Adaptive Card in Microsoft Teams for each alert state. See [How Notification Channels Respond to Alert States](https://help.salesforce.com/s/articleView?id=cc.b2c_how_notification_channels_respond_to_alert_states.htm&type=5).

If you replace or recreate the workflow, then update the notification channel configuration with the new URL.
