# Data Privacy and Protection in B2C Commerce

_The Salesforce B2C Commerce Services have a robust data security and privacy program in place. For information on Data Privacy and Protection and related topics, see the referenced resources._

Related Topics

- [Data Protection and Privacy in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_data_protection_and_privacy.htm&type=5)
- [Set Privacy Preferences for B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_setting_privacy_preferences.htm&type=5)
- [Consent Management for B2C Commerce](https://help.salesforce.com/s/articleView?id=xcloud.consent_management_commerce.htm&type=5)
