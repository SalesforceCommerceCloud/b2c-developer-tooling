# Configure Page Shield Policies for an eCDN Zone

_Configure Page Shield policies that detect and identify supply chain attacks affecting your B2C Commerce storefront, using the Configure Zones interface in Business Manager._

You can configure up to 5 Page Shield policies per zone.

> **Note:** Page Shield isn't available on SCAPI zones. See [SCAPI Zone Support for B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_scapi_zone.htm&type=5).

Page Shield policies help detect client-side script changes and potential supply chain risks on storefront pages. These controls are frequently used to support PCI Data Security Standard (DSS) 4.0.1 client-side security monitoring requirements.

For additional policy design guidance and legacy workflow details, see [Configure eCDN Page Shield Policy](https://help.salesforce.com/s/articleView?id=cc.b2c_configure_eCDN_page_shield_policy.htm&type=5).

1. In Business Manager, click the App Launcher, and then select **Administration > Sites > Embedded CDN Settings**.
2. Locate the zone you want to configure and select **Configure Zone** from the dropdown menu.
3. Select the **Page Shield Policies** tab.

   ### Page Shield Policies tab
   
   _(image: Configure Zones Page Shield Policies tab showing an empty state with no policies configured, a policy usage counter (0 out of 5 available), and a New Policy button)_
