# Code Replication Processes in B2C Commerce

_Each code replication process transfers a code version, activates a transferred code version, transfers and activates a code version, or reverts the active code version on the most recent target instance. This topic applies to B2C Commerce._

Code replication is a two-step process. First, a code version is transferred from staging to the target instance, then it’s activated on the target instance. Run both steps as a single replication process, or run them separately. Running them separately can help you identify the source of failures.

> **Note:** You run all replication processes on the staging instance, even Code Activation and Undo, which only affect the target instance.

> **Note:** To move code from a sandbox to staging, use [code deployment](https://developer.salesforce.com/docs/commerce/b2c-commerce/guide/b2c-code-deployment.html).

Transferring a code version creates a code version on the target instance with the same name. If a code version with that name exists on the target, then B2C Commerce appends a timestamp and index number to it. For example, if you replicate a code version named "version1" and a version of that name exists on the target instance, then the new version name can be something like "version1_05032018-1".

There are four types of code replication processes:

| Replication Type | Description |
| --- | --- |
| Code Transfer | The selected code version on the source instance is transferred to the target instance, but isn’t made active. The current active version on the target remains active. Run a Code Activation replication process to make the replicated version active on the target instance. |
| Code Transfer & Activation | The selected code version on the source instance is transferred to the target instance and is immediately made the active version on the target. |
| Code Activation | This process is available only after a successful Code Transfer process. Activation makes the transferred code version the active version on the target instance. If it’s already active, then nothing happens. If it no longer exists on the target instance, then the replication process fails. |
| Undo | This process is available only after a successful Code Transfer & Activation or Code Activation replication process. It reverts the active code version on the target instance to the version that was active before the prior code replication process. If the version to be reverted is no longer active, then nothing happens. If it no longer exists on the target instance, or if the previously active code version no longer exists, then the replication process fails. |
