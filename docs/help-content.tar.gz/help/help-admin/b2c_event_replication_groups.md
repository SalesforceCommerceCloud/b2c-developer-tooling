# Replication Group IDs

_Replication events carry one or more replication groups in their payload. Each replication group identifies a unit of data that participated in the replication. Use this page to look up what a given group ID covers._

### Replication group schema

### Organization-level group IDs

`type` = `ORGANIZATION`

### Site-level group IDs

`type` = `SITE`

### Repository-level group IDs

`type` = `REPOSITORY`. Repository-scoped groups identify a specific named resource — the `domain` field carries the resource name.
