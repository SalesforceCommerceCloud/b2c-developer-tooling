# Reinstall Commerce Apps After Upgrading to B2C Commerce Version 26.7

_When you upgrade to version 26.7, Commerce apps installed on B2C Commerce version 26.6 no longer appear as installed on the Commerce Apps page in Business Manager, even if you didn’t remove them._

B2C Commerce version 26.7 introduces a new staged table called `COMMERCEFEATURESTATE2`. However, the information in the previous table doesn't migrate to the new table, so you must reinstall and reconfigure each Commerce app that you installed before version 26.7.

After you reinstall the Commerce apps on the staging instances, first publish your changes to production using code replication. Then replicate the data using the `SITE_COMMERCE_FEATURE_STATE` replication group.

During version 26.7 rollout, your original `COMMERCEFEATURESTATE` table remains in place. The COMMERCEFEATURESTATE table will be removed in a future release. If you need historical install metadata, contact Salesforce Customer Support.
