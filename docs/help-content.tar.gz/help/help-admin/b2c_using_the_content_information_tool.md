# Identify Content to Edit with the Content Information Tool

_To determine the source of content assets in the B2C Commerce storefront and get a link to edit the content in Business Manager, use the Content Information Tool. The Content Information Tool doesn't support Page Designer pages._

1. Select the site to view and click **Toolkit.**

   A new tab opens showing the storefront, with the Storefront Toolkit icons in the upper right corner.
2. Click the Content Information Tool icon. _(image: Content Information Tool icon)_
3. Navigate to the page that you want to inspect.
4. To see links that you can click to edit content in Business Manager, move your mouse over the storefront.
