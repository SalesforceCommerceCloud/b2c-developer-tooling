# Enable Shop the Store

_Enable Shop the Store for up to ten B2C stores. With this feature, shoppers can search in-store inventory online. Either import store inventory lists or integrate with Omnichannel. Shoppers can then browse store-specific inventory and conveniently pick-up purchases from a preferred location._

> **Note:** For performance reasons, we recommend that you turn on the Shop the Store Inventory feature switch and Shop the Store only when in use.

- Make sure you are a Business Manager user with permissions to manage search indexes, stores, and inventory lists.
- Create stores and import store objects into Business Manager. See [Create Stores in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_creating_stores.htm&language=en_US&type=5).
- Import store inventory lists or integrate with Omnichannel. See [Import an Inventory List](https://help.salesforce.com/s/articleView?id=cc.b2c_importing_an_inventory_list.htm&language=en_US&type=5) and [Inventory Management Using Omnichannel Inventory](https://help.salesforce.com/s/articleView?id=cc.b2c_inventory_management_omnichannel_inventory.htm&type=5).
- Assign store inventory lists to stores. See [Associate a Store with an Inventory List](https://help.salesforce.com/s/articleView?id=cc.b2c_associating_a_store_with_an_inventory_list.htm&language=en_US&type=5).
- Set up a store selector. For PWA kit, see [Boost In-Store Sales with Store Locator](https://developer.salesforce.com/docs/commerce/pwa-kit-managed-runtime/guide/store-locator.html).

1. Enable the Shop the Store Inventory switch. Request your Admin to perform these steps:

   1. In Business Manager, click App Launcher _(image: App Launcher)_, and then select **Administration > Global Preferences > Feature Switches**.
   2. Enable **Shop the Store Inventory**.
   3. Save your changes.
2. In Business Manager, click App Launcher _(image: App Launcher)_, and then select **Merchant Tools > Site > Search > Search Preferences**.
3. Enable **Shop the Store**.
4. Click App Launcher _(image: App Launcher)_, and then navigate to **Merchant Tools > Search > Search Indexes**, and review the inventory index.

Build the feature in development models: Site Genesis, Salesforce Reference Architecture (SFRA), PWA kit, or headless using the related APIs. When a shopper searches for a product online, Shop the Store uses one of these development models to retrieve products available at a store.

- Set up the feature in your composable storefront app using [PWA Kit 3.11](https://github.com/SalesforceCommerceCloud/pwa-kit/releases/tag/v3.11.0) and later. See [Expand Shopping Options with In-Store Pickup](https://developer.salesforce.com/docs/commerce/pwa-kit-managed-runtime/guide/instore-pickup.html).
- To build the feature using [Shopper Search](https://developer.salesforce.com/docs/commerce/commerce-api/references/shopper-search?meta=Summary) API, retrieve up to ten store inventory list IDs using the *ilids* URL parameter.
- If you’re using Shopper Commerce API (SCAPI), see [Product search](https://developer.salesforce.com/docs/commerce/commerce-api/references/shopper-search?meta=productSearch) to retrieve up to ten store inventory list IDs using the *ilids* URL parameter.
- If you’re using ScriptAPI, see [ProductSearchModel](https://salesforcecommercecloud.github.io/b2c-dev-doc/docs/current/scriptapi/html/api/class_dw_catalog_ProductSearchModel.html). [setStoreInventoryFilter](https://salesforcecommercecloud.github.io/b2c-dev-doc/docs/current/scriptapi/html/index.html?target=class_dw_catalog_ProductSearchModel.html) filters the search result by one or more inventory list IDs and retrieves a mapping between a store name and an inventory list.

To look up store inventory information, add up to ten store inventory list IDs to the inventory field in Search Index Query Testing. See [Run Queries on the Product Index](https://help.salesforce.com/s/articleView?id=cc.b2c_running_queries_on_the_product_index.htm&language=en_us&type=5).
