# Get Cache Status Using the Cache Information Tool in B2C Commerce

_To get information about cached and uncached components on a page, use the Cache Information Tool. Cache is disabled for Storefront Toolkit users, but the Cache Information tool shows you caching information about components as if you’re viewing the storefront without the toolkit. Use this information to determine the cost of caching portions of a page. The Cache Information Tool shows caching information for pipeline calls or controllers for the page itself and remote includes. The Cache Information Tool doesn't show static content caching, so caching information for third parties doesn't appear. Local includes aren't cacheable, so information about local includes doesn't appear._

1. Select the site you want to view and click **Toolkit.**

   A new tab opens showing the storefront, with the Storefront Toolkit icons in the upper right corner.
2. Click the Cache Information Tool icon. _(image: Cache Information Tool icon)_
3. Navigate to the page that you want to inspect.

   In the Storefront Toolkit, no components are cached, but a green cache icon appears on components that the actual storefront caches. The Cached Until time indicates how long the component is cached. A red cache icon is displayed on components that aren’t cached in the storefront. If you have disabled caching in Business Manager by clicking App Launcher _(image: App Launcher)_, and then selecting **Administration > Sites > Manage Sites**, the information shown reflects status as if caching were enabled.
4. For details about the cache status, click a red or green icon.

   The Processing Time shows the cost of a page component in terms of application server processing time.
