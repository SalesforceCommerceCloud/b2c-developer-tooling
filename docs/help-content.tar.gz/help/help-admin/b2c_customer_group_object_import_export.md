# Customer Group Object Import/Export in B2C Commerce

_You can use the elements in the customergroup.xsd and considerations when creating values for them. This topic applies to B2C Commerce._

*Granularity:* selected customer groups.

### Business Manager Import Location

** *site*  > Merchant Tools > Customers > Import & Export > Customer Groups**

** *site*  > Administration > Site Development Customer Groups > Site Import/Export > Export > expand site > Customer Groups**

### Pipelets

ImportCustomerGroups

ExportCustomerGroups

*Granularity:* passed customer groups.

### System Customer Groups

System customer groups `Registered`, `Unregistered`, and `Everyone` are imported as part of the standalone customer groups import and as part of the site import.

They’re also included in site export (to view, click App Launcher _(image: App Launcher)_, and then select **Administration > Site Import & Export**). All data on an instance, including the custom attributes of system customer groups, is contained in a site export archive. The archive can be versioned or used to set up other instances in a realm.

### Group Assignments Not Supported

Import & Export doesn't support customer to customer group assignments. Use the customer import & export for that purpose. For this reason, the customer to customer group assignments are preserved when you delete or replace a static customer group using the import.

### Dynamic Customer Groups Using Session Custom Attributes

B2C Commerce applies a special conversion when importing dynamic customer groups with:

- A rule condition that evaluates on a session custom attribute
- The operator of the rule condition is `is equal`
- The condition values and the session custom attributes are numeric or Boolean-like data.

For numeric conditions, the following import:

```
<condition>
    <attribute-path>session.custom.myAttribute</attribute-path>
    <operator>is-equal</operator>
    <string>1.0</string>
    <string>2.0</string>
    <string>3.0</string>
</condition>
```

Is converted to the following in an export:

```
<condition>
    <attribute-path>session.custom.myAttribute</attribute-path>
    <operator>is-equal</operator>
    <number>1.0</number>
    <number>2.0</number>
    <number>3.0</number>
</condition>
```

For *boolean* conditions, the following import:

```
<condition>
    <attribute-path>session.custom.myAttribute</attribute-path>
    <operator>is-equal</operator>
    <string>true</string>
</condition> 
```

Is converted to the following in an export:

```
<condition>
    <attribute-path>session.custom.myAttribute</attribute-path>
    <operator>is-true</operator>
</condition> 
```

## Dynamic Customer Group Import/Export in B2C Commerce

_Dynamic customer groups can be imported and exported via the (existing) customer group import/export. This topic applies to B2C Commerce._

> **Note:** A dynamic customer group export includes a group's rule, not the actual customer assignments. Similarly, the import includes the rule, not the actual membership data. Therefore, the import of dynamic customer groups relies on a background segmentation process that runs later to establish customer membership for newly imported groups.

The customer import currently imports the explicit customer group assignments. Because membership in dynamic customer groups is calculated dynamically, the customer import denies assignments to dynamic customer groups and the export omits such assignments.

The customergroup.xsd schema has a rule element:

```
<xsd:complexType name="complexType.CustomerGroup" mixed="false">
    <xsd:sequence>
        <xsd:element name="description" type="xsd:string" minOccurs="0" maxOccurs="1" />
        <!--- new element capturing the membership rule; if defined the customer group becomes a dynamic customer group. If not defined it becomes a customer group with explicit assignments--->
        <xsd:element name="rule" type="Rule" minOccurs="0" maxOccurs="1" />
        <xsd:element name="custom-attributes" type="sharedType.CustomAttributes" minOccurs="0" maxOccurs="1" />
    </xsd:sequence>
    <xsd:attribute name="group-id" type="simpleType.Generic.NonEmptyString.256" use="required" />
</xsd:complexType>
```

The schema also has the following complex types related to dynamic groups:

```
<xsd:complexType name="Rule" mixed="false">
<xsd:complexType name="ConditionGroups" mixed="false">
<xsd:complexType name="ConditionGroup" mixed="false">
<xsd:complexType name="DateCondition" mixed="false">
<xsd:complexType name="DateRange" mixed="false">
<xsd:complexType name="RelativeDateRange" mixed="false">
<xsd:complexType name="StringCondition" mixed="false">
<xsd:complexType name="IntCondition" mixed="false">
<xsd:complexType name="IntRange" mixed="false">
<xsd:complexType name="BooleanCondition" mixed="false">
```

Active data not provided by B2C Commerce must be imported. Active merchandising data doesn't have a schema. Instead, a merchant defines a feed format and can manually import a .csv file in Business Manager or automate the import using the new ImportActiveData pipelet.

To enable import for an active data attribute, assign it to a feed. An attribute can only be assigned to exactly one feed. A merchant can set up a maximum of five import feeds for the ProductActiveData object or the CustomerActiveData object, minus any feeds reserved for the system. There are no import modes for feeds.

Import files uploaded for import through Business Manager are stored in a new directory named *activedata*. This directory is placed in the following location relative to the existing Impex source directory in WebDAV:

`/Sites/Impex/src/activedata/a-product-active-data-file.csv`

Site Export includes XML files containing the non-system active data feeds for a site if you select that site for export. Site Import checks for files in an import archive with names and in locations that fit Site Export. If any are found, Site Import validates and imports them.

## Customer Segmentation Import/Export in B2C Commerce

_The CustomerGroup element in the slot.xsd schema supports customer segmentation. This topic applies to B2C Commerce._

```
<!- slot configuration ->
<xsd:complexType name="SlotConfiguration" mixed="false">
    <xsd:sequence>
...
      <xsd:element name="customer-groups" type="CustomerGroups" minOccurs="0" maxOccurs="1" />           
...
</xsd:complexType>
<!- customer group ->
<xsd:complexType name="CustomerGroups" mixed="false">
    <xsd:sequence>
      <xsd:element name="customer-group" type="CustomerGroup" minOccurs="0" maxOccurs="unbounded" />
    </xsd:sequence>
</xsd:complexType>
<xsd:complexType name="CustomerGroup" mixed="false">
    <xsd:attribute name="group-id" type="Generic.NonEmptyString.256" use="required" />
</xsd:complexType> 
```
