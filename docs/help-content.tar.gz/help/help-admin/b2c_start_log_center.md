# Access Log Center

_Access Log Center from a browser or from Business Manager._

1. Access Log Center from a browser.

   1. Open a browser.
   2. Enter the Log Center URL.
   3. Log in with your username and password.
2. Access Log Center from Business Manager.

   1. Click App Launcher _(image: App Launcher)_, and then select **Administration > Site Development > Development Setup**
   2. In the Log Files section, click **Log Center**.
   
      No username or password is required.
