# User Authentication for B2C Commerce

_Always use unified authentication in Salesforce B2C Commerce if you’re an administrator. Traditionally, we always used local user authentication, but a local user can perform only a local login into the Business Manager instance on which their credentials were created. After a site migrates to unified authentication, the site requires unified authentication on Account Manager, where a user can perform a global login into any Business Manager instance in their organization._

### Local Authentication

For local user authentication, an admin, or an existing user with appropriate permissions, provisions a new user in Business Manager, and stores the user’s credentials on the instance. If you want a user to log in to several instances, you must create an account for them on each instance. The primary security controls relate to user password policy and login lockout policy. These settings have reasonable default values that you can modify depending on your policy requirements.

To enhance security, increase password length from eight characters (default) to 12 characters. Update customer lists configured prior to Release 17.5.

### Unified Authentication

Unified user authentication is where Account Manager manages all the Business Manager users in a multi-site org. Users must use their Account Manager credentials to log in to Business Manager. Account Manager handles all user-related actions, including password changes and resets. These processes ignore the corresponding Business Manager settings.

The primary security controls are the user password, login, and lockout policies. You can modify the default values depending on your policy requirements. Unlike with Business Manager, Account Manager uses two-factor authentication (2FA). This significantly improves security because an attacker now requires access to both the password and the user’s 2FA application to gain access.
