# Assign Granular Replication Permissions

_Replicate specific products from staging to production._

|  |
| --- |
| Available in: **B2C Commerce** |

1. In Business Manager, click App Launcher _(image: App Launcher)_, and then select **Administration > Organization > Roles & Permissions**.
2. Create a Merchandiser role or edit an existing role.

   1. To create a role, enter an ID and description.
   2. Click **Apply**.
3. Select the **Functional Permissions** tab.
4. For context, select **Organization**.
5. Enable access to the `Granular_Replication_Publish_Objects` permission.
6. Select other merchandiser permissions as desired.
7. Click **Update**.

   _(image: Select Granular_Replication_Publish_Objects.)_
