# Verify Third-Party Requests with Secret Headers

_Use secret headers as an alternative to maintaining the firewall allowlist for verified third-party servers on storefront, Default Domain, and SCAPI zones in B2C Commerce. A secret header is an extra HTTP header typically attached at the CDN level._

> **Note:** Create the custom rule on the eCDN zone that fronts the traffic: a storefront zone, the Default Domain, or the SCAPI zone. Custom rules, including secret header checks, are available on all three. There's one SCAPI zone for Development, Staging, and Production. Configure it only from the Production instance. It doesn't appear in Business Manager or the CDN API on Development or Staging. Scope every SCAPI rule by the org ID in the URL path so that it doesn't affect other environments. See [SCAPI Zone Support for B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_scapi_zone.htm&type=5), [Default Domain Support for B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_default_domain.htm&type=5), and [Create a Custom Firewall Rule for an eCDN Zone](https://help.salesforce.com/s/articleView?id=cc.b2c_create_eCDN_firewall_rule.htm&type=5).

For example: x-extra_header_name: extra_header_value.

To verify incoming requests, the eCDN layer checks and validates the presence of the header. An eCDN custom rule checks for the header and blocks malicious traffic that doesn’t include the header. All requests that fail the header check return a 403 response code. See [eCDN Custom Rule](https://developer.salesforce.com/docs/commerce/commerce-api/guide/cdn-zones-custom-rules.html).
