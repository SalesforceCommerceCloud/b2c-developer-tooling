# Verify Third-Party Requests with Secret Headers

_Use secret headers as an alternative to maintaining the firewall allowlist for verified third-party servers. A secret header is an extra HTTP header typically attached at the CDN level._

For example: x-extra_header_name: extra_header_value.

To verify incoming requests, the eCDN layer checks and validates the presence of the header. An eCDN custom rule checks for the header and blocks malicious traffic that doesn’t include the header. All requests that fail the header check return a 403 response code. See [eCDN Custom Rule](https://developer.salesforce.com/docs/commerce/commerce-api/guide/cdn-zones-custom-rules.html).
