# Disconnect a Cross Cloud Tenant Group for B2C Commerce

_To disconnect a cross cloud tenant group, clear the tenant group information from the B2C Commerce database._

|  |
| --- |
| Available in: **B2C Commerce** |

As best practice, we recommend that the Salesforce org initiate the disconnect for the org. After the tenant group information is cleared, Pair your B2C Commerce instance with another Salesforce tenant and include your instance in the tenant group owned by that Salesforce org.

If the Salesforce org isn’t available to initiate the disconnect, you can clear the target group information with the Disconnect option in Business Manager Cross Cloud Trust.

> **Note:** The Disconnect button only displays if your instance of B2C Commerce is configured with a tenant group.

To view the cross-cloud tenant group settings:

1. In Business Manager, click App Launcher _(image: App Launcher)_, and then select **Administration > Global Preferences > Cross Cloud Trust**.
2. Select the **Tenant Group** tab.
3. Confirm that the listed tenant group is the group you want to disconnect.
4. Click **Disconnect**.
