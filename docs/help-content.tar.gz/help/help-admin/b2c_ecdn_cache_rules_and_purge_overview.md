# eCDN Cache Rules and Cache Purge

_Cache rules control which content is eligible for caching at the eCDN edge, and cache purge selectively invalidates cached content by tag or path. Both capabilities are available in Business Manager for your B2C Commerce storefront._

[Which Salesforce Commerce Product Do I Have?](https://help.salesforce.com/s/articleView?id=commerce.comm_what_product.htm)

Use cache rules to control which content is eligible for caching at the eCDN edge. By default, eCDN caches only static content based on file extension and doesn't cache HTML pages or JSON responses. Cache rules make HTML pages and JSON responses eligible for edge caching, which is a prerequisite for using cache purge by specific tags or paths.

Use cache purge to selectively invalidate cached content by cache tag or path directly from Business Manager, using the **Purge Cache** button.

> **Important:** Cache rules make content eligible for caching, but they don't force caching. Your origin must still return appropriate `Cache-Control` (or `Expires`) response headers for eligible content to be cached.

To configure cache rules and purge the cache, in Business Manager, go to **Administration > Sites > Embedded CDN Settings**, and then select **Configure Zone** for the zone that you want. Cache rules and the **Purge Cache** button are available at zone scope for these zone types.

### Purge Cache for SCAPI Zones

For B2C Commerce SCAPI zones, only cache purge is available, and only from the Production instance. Cache rules aren't supported. There's one SCAPI zone for Development, Staging, and Production. The zone doesn't appear in Business Manager or the CDN API on Development or Staging. For the full SCAPI zone control matrix, see [SCAPI Zone Support for B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_scapi_zone.htm&type=5).

- SCAPI caching is a platform-managed capability. To prevent changes to SCAPI caching behavior, cache-rule self-service is disabled for these zones.
- You can't define tags for SCAPI. SCAPI sets cache tags automatically when a response is cached.
- B2C Commerce synchronizes SCAPI cache invalidation automatically.
- Purge SCAPI zone content by tag or by path from the Production instance.

### How B2C Commerce eCDN Decides What to Cache

By default, when no cache rules are configured, eCDN caches by file extension only. Common static extensions (images, JS, CSS, fonts, video, documents, and archives) are cached. eCDN doesn't cache HTML, JSON, XML, or TXT responses by default (except `robots.txt`). The maximum cacheable object size is 5 GB.

A response is cached only when all of these conditions are true.

- The request method is GET.
- The response has no `Set-Cookie` header.
- The response has `Cache-Control: public` with `max-age > 0`, or a future `Expires` date. When multiple values are present, the precedence is `s-maxage`, then `max-age`, then `Expires`.

A response isn't cached if any of these conditions are true.

- `Cache-Control` is `private`, `no-store`, `no-cache`, or `max-age=0`.
- No `Cache-Control` header is present.
- A `Set-Cookie` header is present.
- The request method isn't GET.

> **Note:** A cache rule doesn't override these conditions. By default, eCDN skips HTML and JSON responses based on their file type. A cache rule only removes that restriction. The response must still meet every preceding condition to be cached.

### Best Practices for B2C Commerce eCDN Caching

- Cache HTML and JSON deliberately. Make dynamic content eligible only where the response is genuinely shared across shoppers and safe to cache. Never cache personalized or authenticated responses. Make sure that those responses carry `Set-Cookie` or `Cache-Control: private`.
- Use cache tags for coordinated invalidation. Stamp related content with shared tags (for example, by product, category, or content asset) so that you can purge a logical group in one request instead of listing paths.
- Exclude tracking parameters from the cache key (for example, `gclid` and `utm_campaign`) to maximize the cache hit ratio.
- Verify caching with the `Cf-Cache-Status` response header. A value of `HIT` confirms edge caching. A value of `MISS` or `DYNAMIC` indicates that the content wasn't served from cache.
- Test in a sandbox first. ODS Default zones support cache rules and purge, so you can validate rule behavior on a sandbox before you apply it to production.

### Troubleshooting B2C Commerce eCDN Caching

If eCDN isn't caching content as expected, check for these issues.

- Origin headers: Confirm that the response sends `Cache-Control: public, max-age>0` (or a future `Expires`).
- `Set-Cookie`: Remove the `Set-Cookie` header from cacheable responses. It suppresses caching.
- Request method: Confirm that the request uses `GET`. eCDN caches only `GET` requests.
- Expression accuracy: Confirm that the rule expression matches the request path/extension.
- Rule enabled: Confirm that the rule's **Enabled** flag is on.
- `Cf-Cache-Status` header: Check this header to see whether the edge served the response from cache. `HIT` means it did. `MISS`/`DYNAMIC` means it didn't.

## Related Content

- [Create an eCDN Cache Rule](https://help.salesforce.com/s/articleView?id=cc.b2c_create_ecdn_cache_rule.htm&type=5)
  Create a cache rule to make HTML pages and JSON responses eligible for caching at the eCDN edge for your B2C Commerce storefront. By default, eCDN caches only static content based on file extension.

- [Purge the eCDN Cache](https://help.salesforce.com/s/articleView?id=cc.b2c_purge_ecdn_cache.htm&type=5)
  Selectively invalidate content in the B2C Commerce eCDN cache by cache tag or path directly from Business Manager.
