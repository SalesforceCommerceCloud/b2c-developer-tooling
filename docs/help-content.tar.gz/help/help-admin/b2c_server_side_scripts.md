# SiteGenesis Server-Side Scripts

_Server-side scripts handle client-side requests. All scripts are CommonJA modules with defined exports._

Server-side scripts handle client-side requests. All scripts are CommonJA modules with defined exports.

**Server-side Scripts Modifications**

**`cart/calculate.js`**  Copy code from Salesforce Reference Architecture (SFRA) base to make sure all shipments in the Basket have a shipping method before applying shipping cost, as part of the larger cart calculation script Without this change the Pay Now use case doesn’t work in mini cart, and possibly the cart. Without customization, SiteGenesis doesn’t apply the default shipping method, which results in N/A shipping cost. Pay Now isn’t available for an unorderable basket

`payment/common.js`  Copy code from plug-in_commercepayments Use the copied code to validate the payment instrument in the basket, allowing for potential gift certificate line items to also be present
