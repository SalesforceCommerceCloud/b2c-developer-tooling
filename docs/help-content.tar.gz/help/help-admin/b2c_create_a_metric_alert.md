# Create a Metric Alert in Log Center

_Notify your team when a supported B2C Commerce metric crosses a warning or critical threshold._

For Slack, PagerDuty, or Microsoft Teams, create the notification configuration before you create the alert.

- [Create a Slack Channel for Log Center Alerts](https://help.salesforce.com/s/articleView?id=cc.b2c_create_a_slack_channel_for_log_center_alerts.htm&type=5)
- [Create a PagerDuty Channel for Log Center Alerts](https://help.salesforce.com/s/articleView?id=cc.b2c_create_a_pagerduty_channel_for_log_center_alerts.htm&type=5)
- [Create a Microsoft Teams Channel for Log Center Alerts](https://help.salesforce.com/s/articleView?id=cc.b2c_create_a_microsoft_teams_channel_for_log_center_alerts.htm&type=5)

Metrics Alerting is available as an open beta. For the metric families, notification timing, and who can create an alert, see [Metrics Alerting (Beta)](https://help.salesforce.com/s/articleView?id=cc.b2c_metrics_alerting.htm&type=5).

1. Log in to Log Center. For the ways to access Log Center, including from Business Manager, see [Access Log Center](https://help.salesforce.com/s/articleView?id=cc.b2c_start_log_center.htm&type=5).
2. On the Alerts tab, go to **Alert Management**.
3. Click **Create Alert**, and then select the **Metrics** tab.
4. Enter an alert name and, optionally, a description. Select one or more realms, and select every tenant that the alert covers.
5. Select a metric family and a metric.
6. (Optional) To alert on selected values only, set the filters that appear for that metric.

   Some metric families, such as Open Commerce API (OCAPI), show filters after you select the metric. For OCAPI, the filters include **Category** and **API**. Select one or more values. Leave a filter empty to alert on every value combined.
7. From **Rule**, select the condition for the metric.

   For example, for system workload, select the rule that checks whether the value is above the threshold. If you set filters, select the rule that matches those filters.
8. Enter the warning and critical threshold values.

   The **Metric Preview** chart shows the last 24 hours of the metric with both thresholds, so you can check the values before you save.
9. Under **Notification Channel Type**, add one or more channels.

   You can notify more than one channel type from the same alert, such as email and Slack. For Slack, PagerDuty, and Microsoft Teams, select a configuration that includes every realm selected on the alert.
   
   1. For email, enter up to five recipient addresses. Press Enter, comma, or Tab after each address.
   2. For Slack, PagerDuty, or Microsoft Teams, select an existing notification configuration.
10. Select **Enabled**, and then click **Create**.

Log Center can take up to one minute to send the notification after a threshold breach. When the metric no longer breaches the threshold, the alert resolves and Log Center sends a resolution notification. If the alert stays open, then Log Center repeats the notification every four hours.
