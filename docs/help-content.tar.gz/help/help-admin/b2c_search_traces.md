# Search Traces (Beta)

_Find traces for a B2C Commerce service over a selected time period, and narrow the results with filters._

Set the filters in the left panel of the Traces page, and then review the matching traces in the results table. To narrow results to a specific realm or instance, use the realm filter in the upper-right corner of the page.

_(image: Traces results table listing trace ID, root service and operation, span count, error count, duration, and start time for each matching trace.)_

1. Set the **Period (UTC Time Zone)** for the search.

   Select a preset from **Last 1 Hour** up to **Last 5 Days**, or select **Date & time between**, set the start and end date and time, and click **Apply**. Traces are retained for 5 days, so you can search within that window.
2. Under **Service**, select the service that you want to investigate.
3. Optional: Refine the results with the additional filters.

   - **Min Duration**: Show only traces longer than a threshold, such as 100 ms or 1 s.
   - **Span Status**: Filter by OK, ERROR, or UNSET.
   - **HTTP Method**: Filter by GET, POST, PUT, PATCH, or DELETE.
   - **HTTP Status**: Filter by one or more HTTP status codes, such as 404 or 500.

The results table lists the matching traces, showing the Trace ID, Root Service · Operation, Spans, Errors, Duration, and Start columns. Click a trace to open its detail page.

If you already have a trace ID, use **Lookup by Trace ID**: Enter the hexadecimal trace ID and click **Go** to open that trace directly.
