# Use a Positive Security Model

_A positive security model, also known as a safelist approach, defines what is allowed and rejects everything else. Use this approach in B2C Commerce to make sure that you can allowlist only the known good input instead of trying to disallow all possible bad input._

In addition, take the following precautions.

- When validating user data input, verify the input against a safelist of alphanumeric characters instead of filtering out bad input.
- When configuring an access control area, deny access to everything and allow access only to specific authorized resources or functions.
