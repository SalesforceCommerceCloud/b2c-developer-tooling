# Create and Schedule a B2C Commerce Job

_Create a B2C Commerce job to execute various tasks, and then choose when it runs._

[Which Salesforce Commerce Product Do I Have?](https://help.salesforce.com/s/articleView?id=commerce.comm_what_product.htm)

1. From the App Launcher _(image: App Launcher)_, find and select **Administration > Operations > Jobs**.
2. Click **New Job**.
3. Enter an ID and description.
4. Click **Create**.
5. (Optional) Schedule the job to run on a specific date or on a recurring basis.

   If you are not scheduling the job, skip to Step 6.
   
   On a sandbox, automatic time-based execution of custom jobs is disabled.
   
   1. On the job page, click the **Schedule and History** tab.
   2. Select **Enabled**.
   3. Under **Active**, select **Once** or **Recurring Interval**. For **Recurring Interval**, enter **From** and **To**.
   
      > **Note:** The Business Manager job scheduler supports precision only to the minute. While seconds are visible and editable in the interface, modifying them has no effect on the actual schedule.
   4. For recurring jobs, on the job page under **Run Time**, for **Every**, enter an amount and select **Minutes**, **Hours**, **Days**, **Weeks**, or **Months**. The amount is the length of the interval, not the number of times the job runs.
   5. If necessary, select one or more days under **Run Only On These Days:**.
   
   A job doesn't start if a previous execution of the same job is still running, so it's important to understand how long a job takes to execute before scheduling it. It's also important to schedule jobs so that multiple jobs don't try to acquire a lock on the same object at the same time. Run as many as 15 jobs at the same time.
6. (Optional) To prevent modifying a resource while the job is operating on it, on the job page, click the **Resources** tab, and then click **Select...**. In **Resource Locks**, select **System Resource** or **Custom Resource**, set **Value**, and then click **Select**.

   For information about which resource to lock, see [System Resource Locks for B2C Commerce Jobs](https://help.salesforce.com/s/articleView?id=cc.b2c_system_resources_per_entity.htm&type=5).
