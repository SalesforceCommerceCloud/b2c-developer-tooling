# Connect to the Channel Partner

_Configure the SFTP connection between B2C Commerce and your channel partner (OpenAI or Google) to allow product feed uploads._

Before you begin, ensure that the feature switches for your channel are turned on:

- **OpenAI**: Turn on the **Enable OpenAI Feed Generation (CFT)** and **Enable OpenAI Feed SFTP Upload** feature switches.
- **Google**: Turn on the **Google Feed SFTP Upload** feature switch.

Also ensure that you have the Secure File Transfer Protocol (SFTP) credentials for your channel:

- **OpenAI**: OpenAI provides the credentials when onboarding your merchant account.
- **Google**: You retrieve the credentials from Google Merchant Center.

The SFTP connection allows B2C Commerce to securely upload your product feed to the channel partner's infrastructure. Once connected, B2C Commerce stores the credentials securely in the B2C Commerce keystore, and you can reuse them across multiple sites in your realm.

> **Note:** For the Google feed, by connecting you agree to the Terms and Conditions regarding data transfer.

> **Note:** Although you can reuse the same credentials across multiple sites, we recommend using different SFTP credentials for each unique site that you configure this integration with, so that feed uploads for different sites don't interfere with each other.

You enter SFTP credentials in the **SFTP Configuration** section of the **General Settings** tab. For the rest of the General Settings configuration, see [Configure Product Feed General Settings for OpenAI](https://help.salesforce.com/s/articleView?id=cc.b2c_openai_feed_general_settings.htm&type=5) or [Configure Product Feed General Settings for Google](https://help.salesforce.com/s/articleView?id=cc.b2c_google_feed_general_settings.htm&type=5).

> **Restriction:** SFTP credentials can be entered only on production instances, and the daily feed sync runs only on production. You can configure Business Details, field mappings, product filter rules, and the feed preview on any non-production instance: development, staging, or sandbox.

1. Click App Launcher _(image: App Launcher)_, and then select **Merchant Tools > Site > AI & Social Integrations**, and then select your channel (**OpenAI** or **Google**).

   The channel configuration page opens.
2. On the **General Settings** tab, in the **SFTP Configuration** section, enter your SFTP credentials:

   1. For **SFTP Username**, enter your SFTP username.
   2. For **SFTP Password**, enter your SFTP password.
3. Click **Connect**.

   Business Manager validates the credentials by attempting to connect to the SFTP server. If the credentials are invalid, B2C Commerce displays an error message and you can correct them before proceeding. If successful, the status changes to **Connected** and B2C Commerce stores the credentials securely. The SFTP Username and SFTP Password fields are disabled to prevent accidental modifications.

Your B2C Commerce site is now connected to the channel partner, and other sites in your realm can reuse the stored credentials. B2C Commerce stores the credentials with a channel-specific ID:

- **OpenAI**: `openai-sftp-{systemDomain}`
- **Google**: `google-sftp-<site>`, where `<site>` is the site name with spaces replaced by hyphens (for example, `google-sftp-NTO-Outfitters`)

To change your SFTP credentials after connecting, you must first disconnect and then reconnect with the new credentials.

- Turn on the daily feed sync to start uploading your product feed.
- Configure field mappings to customize how B2C Commerce sends your product data to the channel partner.

**Disconnect from the channel partner:** To disconnect, on the **General Settings** tab, in the **SFTP Configuration** section, click **Disconnect**. When you disconnect:

- B2C Commerce removes the channel configuration.
- B2C Commerce deletes the stored SFTP credentials from the keystore.
- The **Enable Daily Feed Sync** toggle is automatically turned off.
- Your field mapping data is preserved and is available when you reconnect.
