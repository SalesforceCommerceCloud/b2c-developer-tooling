# Customize Where Commerce App Components Appear on Your B2C Storefront

_Choose where Commerce app components appear on your Storefront Reference Architecture (SFRA), Composable Storefront, or Storefront Next site._

Prerequisite:

Upgrade your storefront to the latest version.

- For SFRA, see [SFRA Versions and Releases](https://developer.salesforce.com/docs/commerce/sfra/guide/b2c-sfra-versions.html).
- For Composable Storefront, see [Maintain Your Site](https://developer.salesforce.com/docs/commerce/pwa-kit-managed-runtime/guide/maintain.html).
- For Storefront Next, see [Customization Best Practices and Upgrades](https://developer.salesforce.com/docs/commerce/sfnext/guide/sfnext-component-extend-upgrade.html).

1. In Business Manager, click App Launcher _(image: App Launcher)_, and then select **Merchant Tools > Site > Commerce Apps > App Catalog**.
2. Open an installed app that supports component surface area enablement.
3. In the app’s display card, select where to place the component.

   Turn on or turn off components by surface area, such as on the Checkout, Cart, Mini-Cart, and Product Detail pages, without modifying code.
   
   _(image: Display card options for placing the component on your storefront.)_
4. If you’re using Composable Storefront or Storefront Next, review, test, and merge the pull request that applies the change.

   Salesforce Payments doesn’t require you to merge a pull request.
5. Save your changes.
