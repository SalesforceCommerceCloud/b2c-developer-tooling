# Common HTTP Headers for B2C Commerce Events

_Every B2C Commerce event includes the same set of standard `x-sf-cc-*` headers, so your connector can identify and correlate events consistently regardless of the event type._

### Notes

- All timestamps use ISO-8601 format with timezone indicator.
- Instance IDs are normalized to lowercase.
- Site ID is empty for organization-level operations (such as process-level replication, which runs at the organization level).
