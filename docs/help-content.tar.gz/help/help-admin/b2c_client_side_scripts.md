# SiteGenesis Client-Side Scripts

_Client-side js performs functions that don’t require information from the server._

For example error messages. To add payments.js JavaScript to the page, edit the `footer_UI.isml`. All of the SiteGenesis JS is built into a single app.js file.

As an alternate approach, use a separate file. For example, place the mini cart code in app.js and separate code in distinct files for PDP, cart, or multi-step checkout. Each file is loaded by the necessary page. The platform client side JS is automatically injected into SiteGenesis, based on Business manager Configurations. Changes to the JS are unlikely.
