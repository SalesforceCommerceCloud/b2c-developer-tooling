# Denial-of-Service Protection in B2C Commerce

_In a denial-of-service (DoS) attack, the attacker attempts to deny computer resources to a network’s users. Attackers usually accomplish this by overwhelming the target computer system’s resources with unauthorized requests, which prevent valid users from accessing the network._

In a distributed denial-of-service (DDoS) attack, the attack comes from many sources instead of a single intruder. The primary mechanism used to mitigate the impact of a DoS attack is the eCDN, which provides DoS and DDoS protection. The eCDN offers automatic protection against a range of TCP floods, including SYN, UDP, and ICMP attacks. The eCDN can also lessen the impact of DoS attacks. To do so, configure the following: - IP firewall rules - web application firewall (WAF) rule - eCDN security levels - Completely Automated Public Turing test to tell Computers and Humans Apart (CAPTCHA) challenges

You can mitigate credential stuffing attacks using customer and user login lockout policies. You can use sophisticated rate-limiting functionality for custom code used to develop a web service.

When account-level trusted IP lists are configured for storefront eCDN zones, Salesforce automatically applies DDoS Layer 7 overrides on those zones to prevent false-positive challenges on high-volume traffic from trusted sources. These overrides set a reduced sensitivity level and log-only action on specific Cloudflare DDoS managed rules. No additional configuration is required. For details, see [DDoS Layer 7 override details](../admin/b2c_ecdn_security_rules.xml#b2c_ecdn_security_rules/ddos-l7-overrides).

> **Note:** The DDoS Layer 7 override behavior described here is confirmed for storefront eCDN zones. It isn't confirmed for SCAPI zones. For the eCDN controls available on SCAPI zones, see [SCAPI Zone Support for B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_scapi_zone.htm&type=5).
