# Denial-of-Service Protection in B2C Commerce

_In a denial-of-service (DoS) attack, the attacker attempts to deny computer resources to a network’s users. Attackers usually accomplish this by overwhelming the target computer system’s resources with unauthorized requests, which prevent valid users from accessing the network._

In a distributed denial-of-service (DDoS) attack, the attack comes from many sources instead of a single intruder. The primary mechanism used to mitigate the impact of a DoS attack is the eCDN, which provides DoS and DDoS protection. The eCDN offers automatic protection against a range of TCP floods, including SYN, UDP, and ICMP attacks. The eCDN can also lessen the impact of DoS attacks. To do so, configure the following: - IP firewall rules - web application firewall (WAF) rule - eCDN security levels - Completely Automated Public Turing test to tell Computers and Humans Apart (CAPTCHA) challenges

You can mitigate credential stuffing attacks using customer and user login lockout policies. You can use sophisticated rate-limiting functionality for custom code used to develop a web service.

When account-level trusted IP lists are configured for storefront eCDN zones, Salesforce automatically applies DDoS Layer 7 overrides on those zones to prevent false-positive challenges on high-volume traffic from trusted sources. These overrides set a reduced sensitivity level and log-only action on specific Cloudflare DDoS managed rules. No additional configuration is required. For details, see [DDoS Layer 7 Override Details](../admin/b2c_migrate_trusted_ips_to_custom_rules.xml#b2c_migrate_trusted_ips_to_custom_rules/ddos-l7-overrides).

### SCAPI Zone Applicability

Starting with B2C Commerce 26.10, you configure a subset of these eCDN controls on SCAPI zones from the Production instance in Business Manager. There's one SCAPI zone for Development, Staging, and Production. The zone doesn't appear in Business Manager or the CDN API on Development or Staging.

- **Available on SCAPI zones:** Custom rules, rate limiting rules, IP access lists, analytics (HTTP and Security), and cache purge (by tag or path).
- **Not available on SCAPI zones:** WAF managed rules, mutual TLS (mTLS), TLS 1.3 configuration, MRT routing rules, HSTS, hostname and certificate management, Speed settings, Under Attack Mode, custom error pages, Page Shield, notifications, Logpull, Logpush, Host Header Override, and cache rules.

Some rules on SCAPI zones are Salesforce-managed and locked. For example, the MRT-to-SCAPI shared-secret allow-list is visible but not editable. See [SCAPI Zone Support for B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_scapi_zone.htm&type=5).

> **Note:** The DDoS Layer 7 override behavior in this topic is confirmed for storefront eCDN zones. It isn't confirmed for SCAPI zones.
