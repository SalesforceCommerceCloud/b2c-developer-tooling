# Configure WAF Settings for an eCDN Zone for B2C Commerce

_Configure Web Application Firewall (WAF) managed rulesets for an eCDN zone by using the Security Rules tab in Configure Zones in Business Manager._

The Security Rules tab includes a **WAF Rules** section at the bottom of **Zone Security Rules**. Use this section to enable rulesets and configure how matched requests are handled.

> **Note:** eCDN WAF managed rules aren't available on SCAPI zones. See [SCAPI Zone Support for B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_scapi_zone.htm&type=5).

1. In Business Manager, click the App Launcher, and then select **Administration > Sites > Embedded CDN Settings**.
2. Locate the zone you want to configure and select **Configure Zone** from the dropdown menu.
3. Select the **Security Rules** tab, then select the **Zone Security Rules** sub-tab.

   ### Zone Security Rules — Custom Firewall Rules, Rate Limiting, and WAF managed rulesets
   
   _(image: Configure Zones Security Rules tab showing the Zone Security Rules sub-tab with Custom Firewall Rules list, Rate Limiting Rules empty state, and WAF Rules section including WAFv2 eCDN Managed Ruleset and WAFv2 OWASP Managed Ruleset settings)_
4. Expand the **WAF Rules** section.
5. Configure the **WAFv2 eCDN Managed Ruleset**.

   This eCDN-curated ruleset provides high-confidence, high-impact protections and is updated frequently to cover new vulnerabilities.
   
   | Field | Description |
   | --- | --- |
   | Enabled | Turn the ruleset on or off. |
   | Action | What to do on a match: Default, Block, Log, Managed Challenge, JS Challenge, or Legacy Captcha. |
6. Configure the **WAFv2 OWASP Managed Ruleset**.

   This ruleset uses the OWASP ModSecurity Core Rule Set and is aligned with the latest upstream version.
   
   | Field | Description |
   | --- | --- |
   | Enabled | Turn the ruleset on or off. |
   | Action | What to do when the threat-score threshold is exceeded: Block, Log, Managed Challenge, JS Challenge, or Legacy Captcha. |
   | Anomaly Score Threshold | Low (60 and higher), Medium (40 and higher), or High (25 and higher). Lower thresholds catch more requests but can increase false positives. |
   | Paranoia Level | PL1 (default), PL2, PL3, or PL4. Higher levels add stricter rules and can increase false positives. |
7. Configure the **WAFv2 eCDN Exposed Credentials Check**.

   > **Important:** Exposed Credentials Check is deprecated and doesn’t work with Leaked Credentials Detection. To act on leaked credentials, create a custom firewall rule or a rate-limiting rule. See [Create a Custom Firewall Rule for an eCDN Zone](https://help.salesforce.com/s/articleView?id=cc.b2c_create_eCDN_firewall_rule.htm&type=5) and [Create a Rate Limiting Rule for an eCDN Zone](https://help.salesforce.com/s/articleView?id=cc.b2c_eCDN_create_rate_limiting_rule.htm&type=5).
   
   This check compares incoming credentials against a public database of stolen credentials for well-known CMS applications.
   
   | Field | Description |
   | --- | --- |
   | Enabled | Turn the check on or off. |
   | Action | What to do on a match: Default, Block, Log, Managed Challenge, JS Challenge, or Legacy Captcha. |
   
   ### WAF Rules section fields in Zone Security Rules
   
   _(image: WAF Rules section showing configurable fields for WAFv2 eCDN Managed Ruleset, OWASP Managed Ruleset, and Exposed Credentials Check.)_
