# Configure WAF Settings for an eCDN Zone

_Configure web application firewall (WAF) managed rulesets for an eCDN zone for B2C Commerce by using the Security Rules tab in Configure Zones in Business Manager._

The Security Rules tab includes a **WAF Rules** section at the bottom of **Zone Security Rules**. Use this section to enable rulesets and configure how matched requests are handled. For information about what each ruleset does, see [eCDN WAF Managed Rulesets](https://help.salesforce.com/s/articleView?id=cc.b2c_waf_managed_rulesets.htm&type=5).

> **Note:** eCDN WAF managed rules aren't available on SCAPI zones. See [SCAPI Zone Support for B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_scapi_zone.htm&type=5).

> **Tip:** When you turn on WAF for the first time on a zone, set the ruleset **Action** to **Log** for at least a week before you switch to an enforcing action. Log mode records matches without blocking or challenging traffic, so you can review the WAF logs and make data-backed decisions about the action and thresholds for your storefront. See [eCDN WAF Logs](https://help.salesforce.com/s/articleView?id=cc.b2c_waf_net_traffic_logs.htm&type=5).

1. In Business Manager, click the App Launcher, and then select **Administration > Sites > Embedded CDN Settings**.
2. Locate the zone you want to configure and select **Configure Zone** from the dropdown menu.
3. Select the **Security Rules** tab, then select the **Zone Security Rules** sub-tab.

   ### Zone Security Rules — Custom Firewall Rules, Rate Limiting, and WAF managed rulesets
   
   _(image: Configure Zones Security Rules tab showing the Zone Security Rules sub-tab with Custom Firewall Rules list, Rate Limiting Rules empty state, and WAF Rules section including WAFv2 eCDN Managed Ruleset and WAFv2 OWASP Managed Ruleset settings)_
4. Expand the **WAF Rules** section.
5. Configure the **WAFv2 eCDN Managed Ruleset**.

   This eCDN-curated ruleset provides high-confidence, high-impact protections and is updated frequently to cover new vulnerabilities.
   
   | Field | Description |
   | --- | --- |
   | Enabled | Turn the ruleset on or off. |
   | Action | What to do on a match: Default, Block, Log, Managed Challenge, JS Challenge, or Legacy Captcha. |
6. Configure the **WAFv2 OWASP Managed Ruleset**.

   This ruleset uses the OWASP ModSecurity Core Rule Set and is aligned with the latest upstream version.
   
   | Field | Description |
   | --- | --- |
   | Enabled | Turn the ruleset on or off. |
   | Action | What to do when the threat-score threshold is exceeded: Block, Log, Managed Challenge, JS Challenge, or Legacy Captcha. |
   | Anomaly Score Threshold | Low (60 and higher), Medium (40 and higher), or High (25 and higher). Lower thresholds catch more requests but can increase false positives. |
   | Paranoia Level | PL1 (default), PL2, PL3, or PL4. Higher levels add stricter rules and can increase false positives. |
7. Configure the **WAFv2 eCDN Exposed Credentials Check**.

   > **Important:** Exposed Credentials Check is deprecated and doesn’t work with Leaked Credentials Detection. To act on leaked credentials, create a custom firewall rule or a rate-limiting rule. See [Create a Custom Firewall Rule for an eCDN Zone](https://help.salesforce.com/s/articleView?id=cc.b2c_create_eCDN_firewall_rule.htm&type=5) and [Create a Rate Limiting Rule for an eCDN Zone](https://help.salesforce.com/s/articleView?id=cc.b2c_eCDN_create_rate_limiting_rule.htm&type=5).
   
   This check compares incoming credentials against a public database of stolen credentials for well-known CMS applications.
   
   | Field | Description |
   | --- | --- |
   | Enabled | Turn the check on or off. |
   | Action | What to do on a match: Default, Block, Log, Managed Challenge, JS Challenge, or Legacy Captcha. |
   
   ### WAF Rules section fields in Zone Security Rules
   
   _(image: WAF Rules section showing configurable fields for WAFv2 eCDN Managed Ruleset, OWASP Managed Ruleset, and Exposed Credentials Check.)_

After you enable a ruleset in **Log** mode, review the WAF logs before you switch to an enforcing action. When reviewing your logs, consider the following:

- Which rules are triggering, and how often?
- Which countries are triggering rules? Do you sell or ship product to those countries?
- What IP addresses are associated with triggered rules or suspected bad actors? An IP lookup on a troublesome address can identify where it's registered.

| IP Address Registered Source | Reason for Access |
| --- | --- |
| Google | Search engines (typically good bots). |
| Amazon Web Services (AWS) | Good scrubbing (information used across the Internet and intended to drive more sales). |
| Bad scrubbing (inventory scraping bots that target sites to identify valuable content like text, images, or prices). |  |
| Competitor | Competitors scanning your site to gather intelligence. |

If the logs identify many bad actors, tighten protection. For example, raise the OWASP ruleset's Anomaly Score Threshold or paranoia level, or switch the ruleset action to Managed Challenge or Block. If WAF is matching real shopper activity, loosen those settings. For details on the fields in each log, see [eCDN WAF Log Fields and JSON Output](https://help.salesforce.com/s/articleView?id=cc.b2c_waf_log_fields_json_output.htm&type=5).
