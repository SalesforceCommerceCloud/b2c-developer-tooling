# Configure Shopper Profile Sync

_Use Shopper Profile Sync to synchronize registered shoppers between B2C Commerce and your Salesforce org as person accounts._

- Connect your B2C Commerce instance to a Salesforce org. See [Connect Your B2C Commerce to Salesforce](https://help.salesforce.com/s/articleView?id=cc.b2c_connected_comm_salesforce_connection.htm&type=5).
   
   > **Note:** Once you connect your B2C Commerce shopper data with your Salesforce org for a different Service, the Trust and Compliance Documentation applicable to that Service will apply.
- Make sure that you have admin permissions in both Business Manager and the associated Salesforce org.
- Enable person accounts in your Salesforce org. For details, see [Enable Person Accounts](https://help.salesforce.com/s/articleView?id=sales.account_person_enable.htm&type=5).
   
   > **Note:** To map any custom fields from person accounts, make sure that you've created them in your Salesforce org.
- Configure matching and duplicate rules in your Salesforce org. For details, see [Set Up Person Account Duplicate Rules for Shopper Profile Sync](https://help.salesforce.com/s/articleView?id=cc.b2c_set_up_person_account_duplicate_rules_for_shopper_profile_sync.htm).
- If you're migrating existing shopper data, grant admin access to Shopper Profile Sync fields before proceeding. For details, see [Grant Admin Access to Shopper Profile Sync Fields](https://help.salesforce.com/s/articleView?id=cc.b2c_grant_admin_access_to_shopper_profile_sync_fields.htm&type=5).

> **Warning:** Enabling Shopper Profile Sync generates an Account Change Data Capture and Contact Change Data Capture (CDC) event for every shopper profile synchronized to your org. If you have an existing CDC integration with downstream systems consuming these events, the initial synchronization can produce a volume of events that significantly exceeds your daily CDC event entitlement.
> 
> For example, syncing 10 million shoppers against a 150,000 events/day allocation creates a backlog requiring roughly 60 days for downstream consumers to fully process. This may cause substantial delays in event delivery to any system relying on timely CDC updates, including integrations outside of Shopper Profile Sync. Before proceeding, review your current CDC entitlement, assess the size of your shopper dataset, and confirm whether your downstream systems can tolerate the resulting processing lag. If the projected backlog is unacceptable, contact your account team to discuss increasing your CDC event allocation or coordinating a phased enablement before continuing.

Before making changes to production, set up Shopper Profile Sync in a non-production B2C Commerce instance. Apply this practice to the associated [Salesforce sandbox environment](https://help.salesforce.com/s/articleView?id=platform.deploy_sandboxes_parent.htm) as well. For example, if you change the person account schema, test the changes in a lower environment first, then promote them to production.

> **Warning:** Avoid refreshing the connected Salesforce sandbox environment to prevent issues with the connection. If you refreshed your connected Salesforce sandbox environment and need help repairing the connection, contact Salesforce Customer Support.

**Turn On Shopper Profile Sync**

Complete each step in the listed order to configure Shopper Profile Sync. Skipping steps or completing them out of order causes misconfiguration.

1. In Business Manager, click App Launcher _(image: App Launcher)_, and then go to **Administration > Global Preferences > Salesforce Connection**.
2. Click **Get Started** on the Shopper Profile Sync tile.

   _(image: Shopper Profile Sync tile with Get Started button)_
3. If you haven't already connected your B2C Commerce instance to a Salesforce org, follow the setup flow. For more information, see [Connect Your B2C Commerce Instance to Salesforce](https://help.salesforce.com/s/articleView?id=cc.b2c_connected_comm_salesforce_connection.htm).
4. Turn on **Shopper Profile Sync**.

   _(image: Turn on Shopper Profile Sync toggle)_
5. Review and configure your attribute mappings. For more information, see [Configure Attribute Mappings for Shopper Profile Sync](https://help.salesforce.com/s/articleView?id=cc.b2c_configure_attribute_mappings_for_shopper_profile_sync.htm&type=5).

   > **Important:** In the June release, the accountId field on the CustomerUnifiedProfile table isn't populated for existing person accounts. A future release is planned to update all customer profiles to contain their corresponding person account ID. For integration use cases, use the Contact ID instead.
6. Review and configure duplicate rules. For more information, see [Set Up Person Account Duplicate Rules for Shopper Profile Sync](https://help.salesforce.com/s/articleView?id=cc.b2c_set_up_person_account_duplicate_rules_for_shopper_profile_sync.htm&type=5).
7. After you finish your attribute mappings, turn on the **Auto-Sync** toggle.

   _(image: Auto-Sync toggle for Shopper Profile Sync)_

When you turn on auto-sync for the first time, the system performs an initial sync to migrate all existing registered shoppers to your Salesforce org. The initial sync is a background batch operation. Therefore, person accounts don't appear in Salesforce immediately for all records. The total duration for this initial sync depends on the size of your existing B2C Commerce shopper database.

After the initial sync finishes, the system maintains synchronization through a delta sync. The system syncs updates to mapped attributes for existing shoppers in both directions on a scheduled basis.

- B2C Commerce to Salesforce org: Syncs run approximately every hour.
- Salesforce org to B2C Commerce: Syncs run approximately every 5 minutes.

After you turn on **Auto-Sync**, the Data Synchronization section shows the sync status, including timestamps for the last completed and next scheduled syncs.

If you need to turn off the feature, turn off the **Auto-Sync** toggle and then turn off **Shopper Profile Sync**. Previously synced data isn't deleted when you turn off the feature, but new updates no longer sync with account records. Turn on **Shopper Profile Sync** at any time to re-enable the feature.
