# Support Cookie SameSite Attribute Changes for B2C Commerce

_Many browser vendors, for example Google Chrome, have introduced a new default cookie attribute setting of SameSite=Lax. Previously, the SameSite cookie attribute defaulted to SameSite=None. When SameSite is set to None, cookies require the Secure attribute indicating that they require an encrypted HTTPS connection._

To make sure your storefront works with the new cookie behavior, take the following actions:

- Enable the global security preference Enforce HTTPS in Business Manager.
- Determine if your client-side JavaScript code requires adjustments to accommodate the cookie attribute changes.
- Test cross-site scenarios to make sure that third-party integrations work as expected with the cookie attribute changes.

**Enable Enforce HTTPS**

We have implemented changes to make sure that cookies behave as expected after new cookie settings activate. Enable the global security preference Enforce HTTPS so that the server can mark cookies with the Secure attribute and specify SameSite=None. If Enforce HTTPS isn’t enabled, the server doesn’t specify the SameSite attribute. In that case, the browser uses its own default SiteSame setting and can fail to send cookies in cross-site contexts. Depending on the significance of the cookie, not sending it can break critical site functionality.

To enable the global security preference Enforce HTTPS, in Business Manager, click App Launcher _(image: App Launcher)_, and then select **Administration > Global Preferences > Security**. On the Access Restrictions tab, select **Enforce HTTPS** and click **Apply**.

> **Important:** Enable the global security preference Enforce HTTPS. Enabling Enforce HTTPS as a site preference doesn’t enable the necessary functionality. See [b2c_enforce_https.xml](https://help.salesforce.com/s/articleView?id=cc.b2c_enforce_https.htm&type=5) for more information about the effects of enabling Enforce HTTPS globally and per site.

We recommend that you test enabling Enforce HTTPS on a non-production instance before implementing the change on a production instance.

**Test Client-Side Code**

If you set cookies using custom client-side JavaScript, test to determine if your code requires adjustments to accommodate the cookie attribute changes.

**Test Cross-Site Scenarios**

A cross-site scenario is when a user on your site uses a browser to send or retrieve content to or from a site with a different domain name. Common cross-site scenarios affected by the SameSite cookie attribute occur when:

- Content from a different site appears in an iframe.
- Your site uses a POST request to bring the user to a different site.
- Your browser retrieves content from a different site using XMLHttpRequests (XHR). The other site relies on cookies to personalize the response.

If you’re testing using Chrome, keep in mind that cookies that are less than two minutes old, with no SameSite attribute set, default to SameSite=None for cross-site POST requests. To turn off this feature, run Chrome from the command line with the flag `--enable-features=SameSiteDefaultMethodRigorously`. Refer to [SameSite Updates](https://www.chromium.org/updates/same-site) for more information.

To test with the Firefox browser, in the about:config preferences, set both of the following preferences to true:

- network.cookie.sameSite.laxByDefault
- network.cookie.sameSite.noneRequiresSecure
