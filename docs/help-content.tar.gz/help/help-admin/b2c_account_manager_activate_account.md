# Activate a B2C Commerce Account in B2C Commerce

_Before you can activate an account, it must first be created for you by an account administrator. When the administrator creates your account, Account Manager sends a message to your email address. This email message serves as a starting point for activating your account._

[Which Salesforce Commerce Product Do I Have?](https://help.salesforce.com/s/articleView?id=commerce.comm_what_product.htm)

1. Click the activation link in the activation email message.

   This link redirects you to the Account Manager's Change Your Password page.
2. In the **Password** field, specify a password.

   As you enter characters, the page gives you feedback about the security strength of your password.
3. In the **Confirm Password** field, reenter your password.
4. Click the **Change Password** button.

   A message appears indicating that your password was successfully changed.
5. Click **Continue**.

   A second message is sent to your email address, indicating that your password has changed. The purpose of this message is either to confirm that your activation was successful or to warn you that someone else tried to change the password. If someone else tried to change password, contact your account administrator or help desk.
