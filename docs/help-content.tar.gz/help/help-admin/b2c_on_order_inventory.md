# On Order Inventory

_The *On Order Inventory* setting lets you account for ordered inventory that hasn’t been exported for shipping. This topic applies to B2C Commerce._

> **Note:** This feature isn’t available when B2C Commerce is integrated with Salesforce Omnichannel Inventory.

Control the on order reservation behavior based on an inventory list. How you configure this setting depends on how you normally handle orders after the storefront checkout process.

### Import and Export Inventory Lists

Inventory list import considers On Order Inventory an optional value. When the On Order Inventory value is missing:

- For new lists, On Order Inventory isn't enabled.
- For existing lists, On Order Inventory is unchanged.

Inventory list export always considers the On Order Inventory setting.

### Import and Export Site Preferences

Because the On Order setting is related to an inventory list, and isn't a site preference:

- Site Preference export doesn't export the On Order Inventory setting.
- Site Preference import doesn't consider the On Order Inventory setting, but logs a warning: Attribute OnOrderInventoryEnabled is deprecated and was ignored, it's now part of the ProductInventoryList import.

### When to Use on Order Inventory

- Disable the setting (default) if your system exports orders for shipping shortly after orders are placed in the storefront. In this case, it makes sense to increase turnover when an order is placed.
- Enable the setting if your system holds orders for any length of time before exporting them for shipping. In this case, it makes sense to hold reserved inventory in the on-order quantity, and increase turnover only when that inventory is shipped.

If you enable this setting, then when an order is placed, its inventory is handled in a two-step process:

- Creating an order increases the on-order quantity. Deleting, canceling, or failing an order decreases it.
- Exporting an order decreases the on-order quantity and increases the turnover by the same amount. The changes trigger when the order status is set to Exported, which depends on the integration with the shipping process. In general, the status changes when the order is exported to the back-end system responsible for shipping it.

Resetting the allocation level sets the turnover value to zero, but doesn’t affect the on-order value.

> **Note:** Canceling an exported order only reduces the turnover value if the allocation hasn’t been reset since the order was exported. The check compares the order’s exportDate to the inventory record’s allocationResetDate, not to the timestamp of the inventory record update in B2C Commerce. Canceling an order that was exported before the most recent allocation level reset date doesn’t affect the turnover value.

If used, the on-order quantity represents the quantity ordered that isn't yet exported for shipping. The turnover doesn't include the on-order quantity, since it represents the amount that has shipped since the last inventory update. When deciding which product units are available for shipping, Salesforce B2C Commerce uses this formula: `available for shipping = max(0, allocation - turnover )`.

The stock level represents the number of units that can be sold after taking the shipment of all currently placed orders into account: `StockLevel = max(0, allocation - turnover – on-order).`

> **Note:** The On Order Inventory site preference is disabled by default. For sites that use Order Center, which uses the on-order quantity, enable this preference. Order Center defines “exported for shipping” as the point at which shipping orders are created to be exported to the warehouse management system.

### Examples

On Order Inventory Disabled:

| Step | Allocation | Backorder allocation | Turnover | On Order | Stock level | Available for Shipping | Available to Sell |
| --- | --- | --- | --- | --- | --- | --- | --- |
| Inventory allocation is reset to 20 | 20 | 10 | 0 | not used | 20 | 20 | 30 |
| Customer places order1, qty 5 | 20 | 10 | 5 | not used | 15 | 15 | 25 |
| Customer places order2, qty 2 | 20 | 10 | 7 | not used | 13 | 13 | 23 |
| Both orders are exported for shipping | 20 | 10 | 7 | not used | 13 | 13 | 23 |
| Inventory is reset to 11 | 11 | 10 | 0 | not used | 11 | 11 | 21 |

On Order Inventory Enabled:

| Step | Allocation | Backorder allocation | Turnover | On Order | Stock level | Available for Shipping | Available to Sell |
| --- | --- | --- | --- | --- | --- | --- | --- |
| Inventory allocation is reset to 20 | 20 | 10 | 0 | 0 | 20 | 20 | 30 |
| Customer places order1, qty 5 | 20 | 10 | 0 | 5 | 15 | 20 | 25 |
| Order1 is exported for shipping | 20 | 10 | 5 | 0 | 15 | 15 | 25 |
| Customer places order2, qty 2 | 20 | 10 | 5 | 2 | 13 | 15 | 23 |
| Inventory allocation is reset to 11 | 11 | 10 | 0 | 2 | 9 | 11 | 19 |
| Order2 is exported for shipping | 11 | 10 | 2 | 0 | 9 | 9 | 19 |

### Cancellation Examples

Note the timing of the allocation resets in these examples. The B2C Commerce inventory records are updated with an earlier allocationResetDate.

On Order Inventory Disabled:

| Step | Allocation | Backorder allocation | Turnover | On Order | Stock level | Available for Shipping | Available to Sell |
| --- | --- | --- | --- | --- | --- | --- | --- |
| Inventory allocation is reset to 20 | 20 | 10 | 0 | not used | 20 | 20 | 30 |
| Customer places order1, qty 5 | 20 | 10 | 5 | not used | 15 | 15 | 25 |
| Order1 is exported for shipping | 20 | 10 | 5 | not used | 15 | 15 | 25 |
| Inventory allocation is reset to 11 but not yet imported into B2C Commerce | 20 | 10 | 5 | not used | 15 | 15 | 25 |
| Customer places order2, qty 2 | 20 | 10 | 7 | not used | 13 | 13 | 23 |
| Order2 is exported for shipping | 20 | 10 | 7 | not used | 13 | 13 | 23 |
| The inventory allocation reset is imported into B2C Commerce with an inventoryRecord.allocaionResetDate earlier than the Order2.exportDate | 11 | 10 | 2 | not used | 9 | 9 | 19 |
| Order1 is canceled | 11 | 10 | 2 | not used | 9 | 9 | 19 |
| Order2 is canceled | 11 | 10 | 0 | not used | 11 | 11 | 21 |

On Order Inventory Enabled:

| Step | Allocation | Backorder allocation | Turnover | On Order | Stock level | Available for Shipping | Available to Sell |
| --- | --- | --- | --- | --- | --- | --- | --- |
| Inventory allocation is reset to 20 | 20 | 10 | 0 | 0 | 20 | 20 | 30 |
| Customer creates order1 (payment not captured), qty 5 | 20 | 10 | 0 | 5 | 15 | 20 | 25 |
| Customer creates and places order2 (payment captured), qty 2 | 20 | 10 | 0 | 7 | 13 | 20 | 23 |
| Inventory allocation is reset to 11 but not yet imported into B2C Commerce | 20 | 10 | 0 | 7 | 13 | 20 | 23 |
| Order2 is exported for shipping | 20 | 10 | 2 | 5 | 13 | 18 | 23 |
| The inventory allocation reset is imported into B2C Commerce with an inventoryRecord.allocaionResetDate earlier than the Order2.exportDate | 11 | 10 | 2 | 5 | 4 | 9 | 14 |
| Order1 is failed | 11 | 10 | 2 | 0 | 9 | 9 | 19 |
| Order2 is canceled | 11 | 10 | 0 | 0 | 11 | 11 | 21 |
| Undo order1 failure | 11 | 10 | 0 | 5 | 6 | 11 | 16 |
| Undo order2 cancellation | 11 | 10 | 2 | 5 | 4 | 9 | 14 |
