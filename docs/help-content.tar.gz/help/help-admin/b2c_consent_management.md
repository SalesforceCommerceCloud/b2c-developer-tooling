# Consent Management: Track Shopper Consent in B2C Commerce

_Honor and respect your customers’ wishes when they request only specific forms of contact from your company or opt-out of certain types of data-sharing. We provide details to help you determine the best way to comply with the data protection and privacy regulations that apply to your company. This topic applies to B2C Commerce._

Track your shoppers’ approval for how your company interacts with them. Data subjects have the right to consent to the use of their personal data and can object to the processing of their personal data with respect to receiving marketing communications, online tracking, and user profiling. To help you assess your compliance with various data protection and privacy regulations, we give you examples of common shopper requests. And we provide details to help you determine the best way to comply with the regulations that apply to your company. For instance, a shopper visits a website and doesn’t want any of their information tracked while visiting the site.

Many data protection and privacy regulations can require you to delete shoppers’ personal data when a shopper requests to receive only specific forms of contact from your company. We’ve listed a few of the regulations that are important to many companies collecting and processing their shoppers’ data.

- General Data Protection Regulation
- Personal Information Protection Act (PIPA), Japan
- Privacy Act, Australia
- Personal Information Protection and Electronic Documents Act (PIPEDA), Canada

If you have shoppers who request specific methods of contact from your company, review these common requests and the procedures related to them.

| Product | Common Shopper Request | Actions to Consider | Things to Consider |
| --- | --- | --- | --- |
| Salesforce B2C Commerce | I don't want your site to track my personal information for marketing or other purposes. | [Set the Tracking site preference.](https://help.salesforce.com/s/articleView?id=cc.b2c_setting_privacy_preferences.htm&type=5)   Programmatically override the site preference using the Script API.   [Programmatically override the site preference using the Script API.](https://salesforcecommercecloud.github.io/b2c-dev-doc/docs/current/scriptapi/html/api/class_dw_system_Session.html)  Read about a sample consent tracking implementation in SGJC (SiteGenesis JavaScript Controllers). | Use a new site preference, Tracking, to set default tracking behavior for each storefront. To override this behavior for an individual shopper, call the `dw.system.Session.isTrackingAllowed()` and `dw.system.Session.setTrackingAllowed(boolean)` methods. Session cookies are used by default, so you can discuss them with your legal team. |
| B2C Commerce | I don't want your app to track my personal information for marketing or other purposes. | Determine shopper's tracking preference using the Shop API HTTP/HTTPS headers. See the Open Commerce API (OCAPI) Global HTTP Headers topic. | Shop API resources let you set the HTTP(s) header DNT, which indicates whether personal information is tracked. |
| B2C Commerce | I want to know which cookies your site uses to store information about me. | [Review the local browser storage topic](https://help.salesforce.com/s/articleView?id=cc.b2c_local_data_storage.htm&type=5) to understand the usage and lifespan of data stored locally. Inform the shopper of those cookies that can be relevant to their usage. | Many cookies are automatically deleted at the end of each session, but some have longer lifespans. A system or browser crash can prevent deletion. |
