# Set the Payment Capture Timing for B2C Commerce

_Choose when to capture and disburse a payment from the payment issuer to the merchant acquirer for your B2C storefront._

1. In Business Manager, click App Launcher _(image: App Launcher)_, and then select **Merchant Tools > Site > Commerce Apps > App Catalog**.
2. In the Installed Apps section, for Salesforce Payments, click **Manage**.
3. In the Advanced Settings card, for Payment Capture Timing, click **Change**.

   _(image: Change the payment capture timing between capturing payment immediately or later.)_
4. Select the payment capture timing.

   - **Capture immediately**–Salesforce Payments captures payment immediately after authorization. Funds for the captured payment are disbursed immediately.
   - **Capture later**–Salesforce Payments authorizes payment only. Capture and disbursement occur later.
5. Save your changes.
