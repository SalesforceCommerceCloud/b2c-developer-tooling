# Payment Card Capture Timing for B2C Commerce

_Capture timing is when a payment is captured and dispersed from the payment issuer to the merchant acquirer for your B2C storefront._

You set the instance status in Business Manager. Click App Launcher _(image: App Launcher)_, and then select **Merchant Tools > Ordering > Salesforce Payments** and click **Settings**. Salesforce Payments supports two capture settings.

- **Capture against payment cards immediately**–Salesforce Payments captures payment immediately after authorization. Funds for the captured payment are disbursed immediately. Funds aren’t held for other business-specific logic.
- **Capture against payment cards later**–Salesforce Payments authorizes payment only. Capture and disbursement occur later.
