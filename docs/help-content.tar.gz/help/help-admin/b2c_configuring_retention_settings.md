# Configure Retention Settings for B2C Commerce

_Configure the lifetime of inventory and product price records that no longer reference products. You can also configure the lifetime for lists created by anonymous shoppers to retain this information for a longer time period. This information is typically for wish lists and gift registries._

1. In Business Manager, click App Launcher _(image: App Launcher)_, and then select **Administration > Global Preferences > Retention Settings**. Specify retention settings.
2. For Product List Retention, enter the number of days that Salesforce B2C Commerce retains anonymous customer product lists, after which B2C Commerce removes them.

   Enter a value from 1 through 30.
   
   The SiteGenesis application doesn't support the creation of wish lists or gift registries by anonymous customers.
3. For Inventory Record Retention, enter the number of days B2C Commerce stores inventory records that don't reference an existing product. After this time period, B2C Commerce removes the records.

   Enter a value from 1 through 365, or 0 if they aren’t to be removed.
4. For Product Price Retention, enter the number of days B2C Commerce stores product price records that don't reference an existing product. After this time period, B2C Commerce removes the records.

   Enter a value from 1 through 365, or 0 if they aren’t to be removed.
5. Click **Apply**.
