# Transferring Files to an Instance in B2C Commerce

_The first step in importing a feed is transferring it from an external server to the instance you want to import it into. Only XML from within a B2C Commerce instance can be uploaded or downloaded via APIs._

See the API documentation, specifically, for *dw.net.HTTPClient* and *dw.net.FTPClient *for more information.

## Selecting a Transfer Method in B2C Commerce

_There are different methods available for file transfer, depending on the security requirements of the instance you’re transferring files to. Use custom jobs to trigger file transfer automatically. This topic applies to B2C Commerce._

> **Note:** Different instances require different certificates.

The transfer method you choose when transferring files from B2C Commerce to an external system depends on the security requirements of the external system.

Import transfer methods depend on the security requirements of each instance.

The easiest secure transfer method to automate is an HTTPS PUT.

## Manually Add Files to Sandbox Instances in B2C Commerce

_Since primary instance group instances require WebDAV to use authentication, use WebDAV to move files manually on sandbox instances. The WebDAV interface supports binary files (plain XML) and compressed files. This topic applies to B2C Commerce._

|  |
| --- |
| Available in: **B2C Commerce** |

For a feed to appear in the Business Manager, the feed must be stored in the correct subfolder. For example, *catalog* appears in the Import/Export section of Products and Catalogs, while *library* appears in the Import/Export section of Content.

Accessing the Import/Export WebDAV share requires *File Transfer Manager* privileges.

To Manually Add Files Using WebDAV from a Windows Machine:

1. Click App Launcher _(image: App Launcher)_, and then select **Administration > Site Development > Development Setup**.
2. Copy the WebDAV Access Import/Export URL.
3. Add a network place pointing to the URL. Use the name and password you use to log on to the instance.

   Sometimes, you’re asked for the name and password three times when opening new directories within the cartridge.
4. Open the network place and copy the files into the Impex/src directory. You can also create directories.

## Creating File Transfer Jobs in B2C Commerce

_To create a file transfer job, create the job and associate it with the file transfer pipeline you’ve created. This topic applies to B2C Commerce._
