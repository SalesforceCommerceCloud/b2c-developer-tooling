# Configure Site URL Aliases for .my Domains

_Prevent cross-origin (CORS) errors after your B2C Commerce storefront moves to the `.my` Default Domain, manually add the `.my` hostname to your site URL aliases file._

[Which Salesforce Commerce Product Do I Have?](https://help.salesforce.com/s/articleView?id=commerce.comm_what_product.htm)

Without the current `.my` storefront hostname in the aliases file, generated storefront URLs can resolve to a different host than the browser's origin, which breaks features that rely on same-origin requests, such as Page Designer preview. This gap commonly appears after the 26.6 default-domain auto-routing on On-Demand Sandboxes (ODS). Add the hostname on each instance that serves the storefront on the Default Domain.

> **Note:** Site URL aliases files are instance-specific and aren't included in data replication. Individually edit the site URL aliases on each instance (development, staging, production) so that every instance includes the `.my` storefront hostname.

> **Tip:** If external integrations or test automation reference the previous `.dx` storefront hostname, update them to use the new `.my` hostname. Also update any CORS allowed-origins lists and third-party service allowlists so that requests to the `.my` storefront aren't blocked.

1. In Business Manager, click App Launcher _(image: App Launcher)_, and then select **Administration > Sites > Embedded CDN Settings**. Check to see if the `.my` storefront hostname is on the Embedded CDN Settings page. For ODS instances, the format is `<instance>.sbx.my.commercecloud.salesforce.com`.
2. If the `.my` hostname isn't listed in the aliases file, add it.

   1. In Business Manager, click App Launcher _(image: App Launcher)_, and then select **Merchant Tools >  *site*  > SEO & Discoverability > Aliases**.
   2. Add the `.my` hostname as a hostname entry. Set it as the `http-host` and `https-host` in the `settings` section, or add a hostname rule for it, so that generated storefront URLs use the same host that shoppers and preview tools request. For syntax and examples, see [Hostname Aliases for B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_hostname_aliases.htm&type=5).
   3. Click **Save**.
