# Edit an Organization in B2C Commerce

_As an Account Administrator, you can edit an organization to specify a password policy,  allow your users to link their Account Manager account to an existing account in your organization in the Salesforce Platform, and specify the multi-factor authentication (MFA) verification methods that are available for users to verify their identity when logging in to B2C Commerce B2C applications. MFA is required for all Account Manager users to improve security and reduce the risk of unauthorized access and account compromise._

To edit an organization:

[Which Salesforce Commerce Product Do I Have?](https://help.salesforce.com/s/articleView?id=commerce.comm_what_product.htm)

1. Log into Account Manager.
2. Click **Organization**.
3. Click the organization you want to edit.

   The organization detail page opens.
4. In the **Organization Name** field, modify the name.
5. (Optional) Contact users. See [Select Users for Security Notification Emails](https://help.salesforce.com/s/articleView?id=cc.b2c_account_manager_maintain_security_contact_email.htm).
6. (Optional) In the **Password Policy** section, set the values for the following fields:

   | Option | Description |
   | --- | --- |
   | Minimum Password Length | Specifies the minimum length allowed for passwords. In general, the longer the password, the more secure it is. |
   | Length of Password History | Specifies the length of the password history. Passwords that have been used already are not allowed, and the password history determines how many past passwords Account Manager remembers. |
   | Days Until Password Expires | Specifies how long passwords are retained before they expire and require a reset. |
   
   This password policy is only applicable to local users in Account Manager. It does not apply to single sign-on users.
   
   In addition to the Password Policy settings, the following policies apply:
   
   - Minimum complexity must include three of the following
      
      - Number
      - symbol
      - lower case letter
      - upper case letter
   - Maximum number of failed login attempts until an account is locked for 30 minutes: 6
7. (Optional) Automatically Disable Inactive Users.

   1. As of Account Manager version 3.1, this setting is on by default.
   2. Select the number of days before a user is disabled. The default is 90 days.
   
      When you change the activated or deactivated settings, or the days before deletion settings, Account Manager sends an email notification to the address listed for Contact Users. The email is sent 10 days and 1 day before their account is deactivated. To keep an account active, users can log in to any B2C Commerce application.
      
      > **Note:** When enabled, users are automatically purged after 180 days of being in disabled or deleted state. See [b2c_account_manager_delete_account.xml](https://help.salesforce.com/s/articleView?id=cc.b2c_account_manager_delete_account.htm&type=5)
8. Specify the `My Domain` subdomain of your organization is Salesforce Core. See [Configure Account Manager for Identity Federation.](https://help.salesforce.com/s/articleView?id=cc.b2c_account_manager_configure_account_manager_for_identity_federation.htm)

   1. Use the dropdown menu to change the suffix.
   
      The default domain suffix is `my.salesforce.com`. If the identity federation is allowed or enforced, you can change the value. For example, if you use a Salesforce Core sandbox, you can use `sandbox.my.salesforce.com` as the domain suffix.
      
      Supported Salesforce Core domain suffixes include:
      
      - `my.salesforce.com`
      - `sandbox.my.salesforce.com`
      - `develop.my.salesforce.com`
      - `trailblaze.my.salesforce.com`
      - `scratch.my.salesforce.com`
      - `sfdctest.my.salesforce.com`
      
      > **Note:** After a user enters the wrong password 6 times, their account is locked for 30 min. In the Account Manager user list, the account is marked as **temporary locked**.
9. In the **MFA Verification Method Settings** section, define which multifactor authentication methods your users can choose: Salesforce Authenticator, time-based one-time password (TOTP) authenticator apps, or Fast Identity Online (FIDO) U2F/WebAuthn (FIDO2) compatible security keys.
10. Click **Save**.
