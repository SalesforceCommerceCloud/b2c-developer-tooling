# Legacy Zones and Proxy Zone Migration

_Migrate legacy zones to proxy zones by using B2C Commerce Business Manager or the CDN-API. Proxy zones give you standard eCDN configuration and the latest security features, and they prevent common hierarchy-assignment issues._

A legacy zone is shared across your Development, Staging, and Production instances. Migrating a legacy zone to a proxy zone modernizes your eCDN setup and is a prerequisite for Hyperforce. Perform the migration on each instance (Dev, Staging, and Production), and delete the legacy zone only after every instance has been migrated successfully.

**Legacy zone permission rules**: To prevent damage to the production experience, users on a non-Production instance can't modify subdomains configured on other instances. In addition, users can't modify certificates on a zone with at least one Production instance as origin. However, they can add hostnames to existing zones with Production instance origins. Users on Production instances can modify all CDN settings, even if another Production instance of the same retailer is impacted.

**Legacy zone certificates**: Legacy (root) zones, for example, `brand.com`, support only a self-managed certificate. A legacy zone and a proxy zone for the same hostname can't coexist in the same realm and Cloudflare account. When the same hostname (for example, `us.brand.com`) is served from both a root zone (`brand.com`) and an eCDN proxy zone (ending in `cc-ecdn.net`), you must have a valid certificate in both zones. If either certificate expires, or the proxy zone is missing the hostname, that zone can't serve traffic. Upload a valid certificate or use an eCDN managed auto-renewing certificate.

> **Important:** If you already have an active legacy zone for a fully qualified domain name (for example, through eCDN or as an existing Cloudflare Orange-to-Orange customer), the legacy zone takes priority over the proxy zone and wildcard custom hostnames don't work. Migrate and remove the legacy zone to resolve the conflict. See [Cloudflare hostname priority](https://developers.cloudflare.com/ssl/reference/certificate-and-hostname-priority/#hostname-priority).

### Migration Steps

Complete these tasks in order:

- [Migrate a Legacy Zone to a Proxy Zone](https://help.salesforce.com/s/articleView?id=cc.b2c_legacy_migrate_to_proxy_zone.htm&type=5): Start the migration and wait for the new proxy zone to verify.
- [Copy Legacy Zone Settings to a Proxy Zone](https://help.salesforce.com/s/articleView?id=cc.b2c_legacy_configure_proxy_zone_settings.htm&type=5): Copy the settings that don't transfer automatically.
- [Create a Custom Hostname with a Custom Certificate](https://help.salesforce.com/s/articleView?id=cc.b2c_legacy_create_custom_hostname_with_custom_cert.htm&type=5): Replace the auto-generated certificate if you need a different validation method.
- [Update Authoritative DNS](https://help.salesforce.com/s/articleView?id=cc.b2c_legacy_update_auth_dns.htm&type=5): Point your DNS records at the new proxy zone.
- [Remove a Subdomain from a Legacy Zone](https://help.salesforce.com/s/articleView?id=cc.b2c_remove_subdomain_from_legacy.htm&type=5): Remove each migrated subdomain and its self-managed certificate.
- [Delete a Legacy Zone](https://help.salesforce.com/s/articleView?id=cc.b2c_legacy_delete_legacy_zone.htm&type=5): Remove the legacy zone after all subdomains are migrated.

## Related Content

- [Migrate a Legacy Zone to a Proxy Zone](https://help.salesforce.com/s/articleView?id=cc.b2c_legacy_migrate_to_proxy_zone.htm&type=5)
  Start the migration of a B2C Commerce legacy zone to a proxy zone in Business Manager or with the CDN-API. Proxy zones use standard eCDN configuration and the latest security features and prevent common hierarchy-assignment issues. This migration is required to move to Hyperforce, which doesn't support legacy zones.

- [Copy Legacy Zone Settings to a Proxy Zone](https://help.salesforce.com/s/articleView?id=cc.b2c_legacy_configure_proxy_zone_settings.htm&type=5)
  After you migrate a B2C Commerce legacy zone to a proxy zone, most settings transfer automatically. Manually copy the two settings that don't transfer, Logpush and rate limiting rules, from the legacy zone to the new proxy zone.

- [Create a Custom Hostname with a Custom Certificate](https://help.salesforce.com/s/articleView?id=cc.b2c_legacy_create_custom_hostname_with_custom_cert.htm&type=5)
  When you migrate a legacy zone to a proxy zone, a certificate is automatically created with the validation method set to "http". If you need a different validation method, delete the generated certificate and add a custom one. Create the custom certificate in Business Manager for B2C Commerce or use the `addCertificateForZone` API.

- [Update Authoritative DNS](https://help.salesforce.com/s/articleView?id=cc.b2c_legacy_update_auth_dns.htm&type=5)
  After you migrate a B2C Commerce legacy zone to a proxy zone, point your storefront's DNS records at the new proxy zone. Get the DNS CNAME record value from the `getZonesInfo` name property or from Business Manager, and then update the record with your authoritative DNS provider.

- [Remove a Subdomain from a Legacy Zone](https://help.salesforce.com/s/articleView?id=cc.b2c_remove_subdomain_from_legacy.htm&type=5)
  After you migrate a subdomain to the proxy zone, remove it from the legacy zone and delete the self-managed certificate that you uploaded for that subdomain.

- [Delete a Legacy Zone](https://help.salesforce.com/s/articleView?id=cc.b2c_legacy_delete_legacy_zone.htm&type=5)
  After you move all subdomains from the B2C Commerce legacy zone to the proxy zone, delete the legacy zone with the Remove Zone option. This is the final step of the proxy zone migration.
