# Migrating Proxy Zones

_USe B2C Commerce Business Manager or the CDN-API to migrate legacy proxy zones. Migrating these zones give you the latest security features, and prevents common hierarchy assignment issues._

## Related Content

- [Migrate a Legacy Zone to a Proxy Zone](https://help.salesforce.com/s/articleView?id=cc.b2c_migrate_legacy_zone_to_proxy_zone.htm&type=5)
  Migrate legacy zones to proxy zones using B2C Commerce Business Manager or the CDN-API. Proxy zones employ standard eCDN configuration, the latest security features, and prevent common hierarchy assignment issues. Migrating a legacy system to a proxy zone involves several key steps that provide a smooth transition and maintain system integrity. This migration is essential for moving to Hyperforce, as legacy zones aren’t supported.
