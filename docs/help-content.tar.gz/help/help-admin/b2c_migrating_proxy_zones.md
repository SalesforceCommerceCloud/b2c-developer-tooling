# Proxy Zone Migration Overview

_Migrate legacy zones to proxy zones by using B2C Commerce Business Manager or the CDN-API. Proxy zones give you standard eCDN configuration and the latest security features, and they prevent common hierarchy-assignment issues. Migration is required to move to Hyperforce, which doesn't support legacy zones._

A legacy zone is shared across your Development, Staging, and Production instances. Migrating it to a proxy zone modernizes your eCDN setup and is a prerequisite for Hyperforce. Perform the migration on each instance (Dev, Staging, and Production), and delete the legacy zone only after every instance has been migrated successfully.

> **Important:** If you already have an active legacy zone for a fully qualified domain name (for example, through eCDN or as an existing Cloudflare Orange-to-Orange customer), the legacy zone takes priority over the proxy zone and wildcard custom hostnames don't work. Migrate and remove the legacy zone to resolve the conflict.

### Migration Steps

Complete these tasks in order:

1. [Migrate a Legacy Zone to a Proxy Zone](https://help.salesforce.com/s/articleView?id=cc.b2c_legacy_migrate_to_proxy_zone.htm&type=5): Start the migration and wait for the new proxy zone to verify.
2. [Configure Proxy Zone Settings](https://help.salesforce.com/s/articleView?id=cc.b2c_legacy_configure_proxy_zone_settings.htm&type=5): Copy the settings that don't transfer automatically.
3. [Create a Custom Hostname with a Custom Certificate](https://help.salesforce.com/s/articleView?id=cc.b2c_legacy_create_custom_hostname_with_custom_cert.htm&type=5): Replace the auto-generated certificate if you need a different validation method.
4. [Update Authoritative DNS](https://help.salesforce.com/s/articleView?id=cc.b2c_legacy_update_auth_dns.htm&type=5): Point your DNS records at the new proxy zone.
5. [Remove a Subdomain from a Legacy Zone](https://help.salesforce.com/s/articleView?id=cc.b2c_remove_subdomain_from_legacy.htm&type=5): Remove each migrated subdomain and its old certificate.
6. [Delete a Legacy Zone](https://help.salesforce.com/s/articleView?id=cc.b2c_legacy_delete_legacy_zone.htm&type=5): Remove the legacy zone after all subdomains are migrated.

## Related Content

- [Migrate a Legacy Zone to a Proxy Zone](https://help.salesforce.com/s/articleView?id=cc.b2c_legacy_migrate_to_proxy_zone.htm&type=5)
  Start the migration of a B2C Commerce legacy zone to a proxy zone in Business Manager or with the CDN-API. Proxy zones use standard eCDN configuration and the latest security features and prevent common hierarchy-assignment issues. This migration is required to move to Hyperforce, which doesn't support legacy zones.

- [Configure Proxy Zone Settings](https://help.salesforce.com/s/articleView?id=cc.b2c_legacy_configure_proxy_zone_settings.htm&type=5)
  After you migrate a B2C Commerce legacy zone to a proxy zone, most settings transfer automatically. Manually copy the two settings that don't transfer, Logpush and rate limiting rules, from the legacy zone to the new proxy zone.

- [Create a Custom Hostname with a Custom Certificate](https://help.salesforce.com/s/articleView?id=cc.b2c_legacy_create_custom_hostname_with_custom_cert.htm&type=5)
  When you migrate a legacy zone to a proxy zone, a certificate is automatically created with the validation method set to "http". If you need a different validation method, delete the generated certificate and add a custom one. Create the custom certificate in Business Manager for B2C Commerce or use the `addCertificateForZone` API.

- [Update Authoritative DNS](https://help.salesforce.com/s/articleView?id=cc.b2c_legacy_update_auth_dns.htm&type=5)
  Point your B2C Commerce storefront's DNS records at the new proxy zone. Get the DNS CNAME record value from the `getZonesInfo` name property or from Business Manager, and then update the record with your authoritative DNS provider.

- [Remove a Subdomain from a Legacy Zone](https://help.salesforce.com/s/articleView?id=cc.b2c_remove_subdomain_from_legacy.htm&type=5)
  After you migrate a subdomain to the proxy zone, remove it from the legacy zone and delete the old certificate so that the legacy certificate no longer shows on your B2C Commerce storefront.

- [Delete a Legacy Zone](https://help.salesforce.com/s/articleView?id=cc.b2c_legacy_delete_legacy_zone.htm&type=5)
  After you move all subdomains from the B2C Commerce legacy zone to the proxy zone, delete the legacy zone with the Remove Zone option. This is the final step of the proxy zone migration.
