# Storefront Password Protection and Login

_To prevent shoppers from finding your B2C Commerce storefront during development and testing, restrict access. Limit storefront access to merchants and other people involved in the project. This limit prevents crawlers and search engine robots from indexing your storefront and making it available to search engines. Both dynamic content, such as pages, and static content, such as images, are protected._

Configure a storefront password on Business Manager that requires authentication of users trying to access the storefront. This feature blocks access to both dynamic pages and static pages. If a site is storefront protected and the storefront user hasn't provided the appropriate credentials, B2C Commerce returns these HTTP errors.

- 401–Access using a shared password
- 401–Access using a users password ore access key
- 403–Access using the Storefront Toolkit
- 403–Access using the Storefront Toolkit without functional permission

When a shopper or user tries to access a storefront that is in the development stage and has password protection enabled, an Authentication Required window opens. See [Setting Protection Flags and Assigning Passwords](https://help.salesforce.com/s/articleView?id=cc.b2c_setting_protection_flags_and_assigning_passwords.htm&type=5) to learn how to enable or disable storefront password protection.

Business Manager users with the functional permission Access_Protected_Storefront can always log on to the storefront. To let other users access the Storefront, create a shared login. The default username is `storefront`, though you must assign your own password (to be entered for an authentication request). The storefront administrator sets the flag and password through Business Manager.

> **Note:** When activating the storefront protection, invalidate the static content cache to enforce protection of static content. Otherwise any unprotected content that was already delivered is valid until it expires. If the password changes, invalidate the static content cache to enforce the usage of the new password. Otherwise the delivered content is served until it expires.

When a shopper forgets their password and asks for a reset, the password reset token expiration period is 30 minutes.

> **Note:** The password reset token expiration period for Business Manager users is 120 minutes.

### Storefront Default Password Requirements

The default requirements for storefront passwords (managed via *customerlists*) are as follows:

- Minimum password length: 8
- Minimum number of special characters: 1
- Must contain letters: true
- Multiple letters must be of mixed case: true
- Must contain numbers: from false to true: true

> **Note:** Sites with *customerlists* created before Release 17.5 retain the previous defaults if the settings weren't configured, as follows:
> 
> - Minimum password length: 1
> - Minimum number of special characters: 0
> - Must contain letters: false
> - Multiple letters must be of mixed case: false
> - Must contain numbers: false
> 
> If you configured these settings before Release 17.5, B2C Commerce retains the existing settings.

> **Important:** Use the API to perform password checks and obtain the constraints for display to the customer, as follows:
> 
> ```
> boolean : dw.customer.CustomerMgr.isAcceptablePassword(String password)
>  dw.customer.CustomerPasswordConstraints :
>  dw.customer.CustomerMgr.getPasswordConstraints()
> ```

## Related Content

- [Set Protection Flags and Assign Passwords](https://help.salesforce.com/s/articleView?id=cc.b2c_setting_protection_flags_and_assigning_passwords.htm&type=5)
  When you create a B2C Commerce site, there’s no password protection enabled by default. The administrator must set the protection flag and assign a password.

- [Invalidate the Static Cache](https://help.salesforce.com/s/articleView?id=cc.b2c_invalidate_the_static_cache.htm&type=5)
  To enforce protection on your B2C Commerce site, invalidate the static content cache. Otherwise unprotected content that was already delivered is valid until it expires. If you change the password, invalidate the static content cache to enforce the use of the new password.

- [Storefront Login Redirects](https://help.salesforce.com/s/articleView?id=cc.b2c_storefront_login_redirects.htm&type=5)
  In SiteGenesis, B2C Commerce redirects the storefront login via a 302 redirect to prevent credentials from being available with a browser refresh. Any node that requires a login sets the pipeline and parameters to use in the redirect. The `loginredirect.isml` template and the `Login-Redirect` pipeline (both in the SiteGenesis Storefront Core cartridge) perform the redirect.
