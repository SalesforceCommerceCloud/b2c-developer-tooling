# Buy Now Pay Later with Klarna for B2C Commerce

_Klarna is available as a Checkout payment method. With Klarna, shoppers can spread the cost of their order over three or four interest-free payments. To review the countries where Klara is available, see the Stripe documentation. This feature is available for B2C Commerce._

To activate Klarna for your Salesforce Reference Architecture (SFRA) storefront, see [Manage Payment Methods for B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_manage_payment_methods.htm&type=5).

When shoppers select Klarna for payment, they’re redirected to Klarna to complete their cart checkout. In the Klarna window, the shopper reviews and agrees to the payment terms. If the shopper chooses to complete the purchase, Klarna authenticates the shopper’s identity and account. The shopper completes the purchase and returns to your site where the transaction details appear.

These merchant categories are prohibited from using Klarna.

- Charities
- Political organizations, parties, or initiatives
