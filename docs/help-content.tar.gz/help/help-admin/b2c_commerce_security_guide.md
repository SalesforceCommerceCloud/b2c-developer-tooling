# B2C Commerce Security Guide

_To help protect your sites from security threats, follow our security best practices as you set up, administer, and develop your Salesforce B2C Commerce environments._

> **Note:** Salesforce provides the topics in the B2C Commerce Security Guide on an information-only basis. This document is not legal advice and its use creates no attorney-client relationship. Salesforce urges its customers and prospective customers to consult with their own counsel to familiarize themselves with the security requirements that govern their specific situations.
> 
> To the extent the guide outlines Salesforce's current product offerings, those are as of the date of issue of this document only, and are subject to change without notice. Customers are responsible for making their own independent assessment of the information in this document and any use of Salesforce’s products or services, subject to the terms of customer's agreement with Salesforce. This documentation does not modify any agreement between Salesforce and its customers.

## Related Content

- [B2C Commerce Security Model](https://help.salesforce.com/s/articleView?id=cc.b2c_commerce_security_model.htm&type=5)
  Salesforce B2C Commerce security is a partnership between Salesforce and our B2C Commerce customers. As always, Trust is our #1 value at Salesforce. We’re committed to delivering the highest standard in system availability, performance, and security.

- [General Security Best Practices in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_general_security_best_practices.htm&type=5)
  At Salesforce, we understand that the confidentiality, integrity, and availability of your data is vital to your business. We want you to implement maximum protection for your sites against security threats and recommend using the following core best practices as you set up your Salesforce B2C Commerce environments.

- [Security Best Practices for Administrators in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_security_best_practices_for_administrators.htm&type=5)
  You can use Business Manager to secure your site and ensure a safe online shopping environment for your customers. Doing so also secures Business Manager and prevents attackers from removing the security controls you previously configured.

- [Security Best Practices for Developers in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_security_best_practices_for_developers.htm&type=5)
  As a B2C Commerce developer, use these security best practices to develop secure storefronts.
