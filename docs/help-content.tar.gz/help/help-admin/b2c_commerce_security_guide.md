# B2C Commerce Security Guide

_To help protect your sites from security threats, follow our security best practices as you set up, administer, and develop your Salesforce B2C Commerce environments._

> **Note:** Salesforce provides the topics in the B2C Commerce Security Guide on an information-only basis. This document is not legal advice and its use creates no attorney-client relationship. Salesforce urges its customers and prospective customers to consult with their own counsel to familiarize themselves with the security requirements that govern their specific situations.
> 
> To the extent the guide outlines Salesforce's current product offerings, those are as of the date of issue of this document only, and are subject to change without notice. Customers are responsible for making their own independent assessment of the information in this document and any use of Salesforce’s products or services, subject to the terms of customer's agreement with Salesforce. This documentation does not modify any agreement between Salesforce and its customers.
