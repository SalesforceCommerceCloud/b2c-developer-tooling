# Salesforce Payments Platform Configuration for B2C Commerce

_To use the Salesforce Payments plug-in with your B2C Commerce Storefront Reference Architecture (Salesforce Reference Architecture (SFRA)) site, configure your site with Adyen, Stripe, and PayPal._
