# Payment Service Provider Configuration for B2C Commerce

_Configure your Storefront Reference Architecture (SFRA), Composable Storefront, or Storefront Next site with Adyen or Stripe. You can also configure PayPal in addition to either payment gateway._

## Related Content

- [Salesforce Payment Platforms and Services for B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_salesforce_payments_platforms_services.htm&type=5)
  Salesforce Payments supports these Payment Service Providers (PSPs) and payment methods for B2C Commerce.

- [Configure Salesforce Payments with Adyen for B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_configure_salesforce_payments_with_adyen.htm&type=5)
  Integrate your existing Adyen merchant accounts into Salesforce Payments in any B2C Commerce sandbox, staging, development, or production instance. Connect any B2C Commerce instance to a test or live Adyen merchant account.

- [Configure Salesforce Payments with Stripe for B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_configure_salesforce_payments_with_stripe.htm&type=5)
  Configure Stripe merchant accounts with Salesforce Payments in any B2C Commerce sandbox, staging, development, or production instance. Stripe merchant accounts that you create in a B2C Commerce instance can operate in both test and live mode.

- [Configure Salesforce Payments with PayPal for B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_configure_salesforce_payments_with_paypal.htm&type=5)
  Configure the PayPal Payment Service Provider (PSP) with Salesforce Payments for B2C Commerce.

- [Remove a Merchant Account from B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_remove_account_association.htm&type=5)
  Remove a merchant account from your B2C Commerce instance to end the association between them. You can't remove a merchant account that serves as the default for a payment zone until you reassign that default to a different merchant account. After removal, B2C Commerce clears the account from all payment zones.

- [Configure Payment Zones for B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_configure_payments_zones.htm&type=5)
  Create payment zones to assign payment methods to specific currencies and countries for B2C Commerce. After you create a payment zone, assign it to a merchant account. Then, select the payment methods for the zone.
