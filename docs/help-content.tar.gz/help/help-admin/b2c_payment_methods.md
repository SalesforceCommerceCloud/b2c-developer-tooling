# Payment Methods for B2C Commerce

_With Salesforce Payments, you can offer shoppers Checkout, Express Checkout, or both payment methods on your storefront. If you offer Checkout, shoppers can purchase items using Afterpay, Amazon Pay, Bancontact, credit cards, EPS, iDEAL, Klarna, PayPal, SEPA Debit, TWINT, or Venmo. If you offer Express Checkout, shoppers can purchase items using Amazon Pay, Apple Pay, Google Pay, PayPal, or Venmo._

## Related Content

- [Express Checkout Considerations for B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_express_checkout_considerations.htm&type=5)
  Although Express Checkout is often faster and easier to use than the Checkout payment method, features such as coupons, gift wrapping, shopper product customization, and gift card redemption aren’t always a good fit for Express Checkout.

- [Activate a Payment Method for B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_activate_payment_method.htm&type=5)
  Activate the payment methods you want to offer shoppers in your Storefront Reference Architecture (SFRA), Composable Storefront, or Storefront Next site. Offer Checkout, Express Checkout, or both.

- [Configure Payment Methods for B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_configure_payment_methods.htm&type=5)
  Configure payment methods for each payment zone based on your payment provider, region, and currency configuration. The checkout and express checkout payment methods that you configure appear on the checkout page in your Storefront Reference Architecture (SFRA), Composable Storefront, or Storefront Next site.

- [Organize Payment Methods for B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_organize_payment_methods.htm&type=5)
  Arrange the sequence of payment methods to highlight preferred options to your shoppers on the checkout page in your Storefront Reference Architecture (SFRA), Composable Storefront, or Storefront Next site. The payment methods available in your storefront depend on your payment provider, region, and currency configuration.

- [Deactivate a Payment Method for B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_deactivate_payment_method.htm&type=5)
  Disable payment methods from appearing in your Storefront Reference Architecture (SFRA), Composable Storefront, or Storefront Next site.
