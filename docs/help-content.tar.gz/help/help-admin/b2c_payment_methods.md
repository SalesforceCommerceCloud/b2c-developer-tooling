# Payment Methods for B2C Commerce

_With Salesforce Payments, you can offer shoppers Checkout, Express Checkout, or both payment methods on your storefront. If you offer Checkout, shoppers can purchase items using Afterpay, Amazon Pay, Bancontact, credit cards, EPS, iDEAL, Klarna, PayPal, SEPA Debit, TWINT, or Venmo. If you offer Express Checkout, shoppers can purchase items using Amazon Pay, Apple Pay, Google Pay, PayPal, or Venmo._
