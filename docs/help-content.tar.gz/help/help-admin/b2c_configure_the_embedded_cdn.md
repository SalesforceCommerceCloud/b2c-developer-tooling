# Configure the Embedded CDN

_The embedded CDN (eCDN) is a geographically distributed network of proxy servers. Configuring the eCDN improves availability and performance, ultimately enhancing the ability to scale your site (or sites)._

Embedded CDN settings are specific to each instance (development, staging, and production) and are managed individually for each. Creating a proxy zone in production doesn’t automatically replicate a corresponding proxy zone in the development or staging instances.

Site URL aliases files are instance-specific, so site URL aliases are individually managed for each instance (development, staging, and production). Because each instance has its own aliases file, these files aren't included in data replication. This prevents Site URL Management replication from overwriting URL alias settings on Production with the Staging configuration. Individually edit the site URL aliases on each instance (development, staging, production) to have the same aliases on all instances.

> **Note:** Beginning with the 24.4 release, you can configure eCDN for staging in Business Manager.

### eCDN on On-Demand Sandboxes (ODS)

Starting with the 26.6 release, Salesforce automatically provisions eCDN for all On-Demand Sandbox (ODS) instances. Every ODS instance receives an eCDN-fronted Default Domain hostname with no configuration required. With the 26.6 default-domain auto-routing, the storefront host for ODS sandboxes changes from .dx to .my, including for already-provisioned sandboxes. Business Manager, WebDAV/code upload, jobs, and the Sandbox API remain on the .dx host—only the storefront moves to .my. Update external integrations (CORS allowed-origins, third-party whitelists, test URLs) to reference the new .my storefront hostname. The .my certificate is Salesforce-managed and publicly trusted, so no TLS reconfiguration is required.

- **Storefront hostname format:** `<instance>.sbx.my.commercecloud.salesforce.com` (for example, `bldp-001.sbx.my.commercecloud.salesforce.com`)
- **Business Manager hostname format:** `<instance>.dx.commercecloud.salesforce.com`, proxied through the shared BM zone

ODS eCDN uses a shared zone model: all ODS instances in a realm share one storefront zone and one Business Manager zone. web application firewall (WAF) rules, cache settings, MRT routing rules, host header overrides, and PCI policies configured on the zone apply to all instances in that realm.

After provisioning, the Default Zone appears in Business Manager under **Administration > Sites > Embedded CDN Settings**. Use the **Configure Zones** button to manage WAF rules, MRT routing rules, cache settings, host header overrides, and PCI policies for the ODS zone.

> **Important:** With the 26.6 eCDN rollout completed across all ODS clusters, existing ODS sandboxes receive the Default Domain automatically — no re-provision required. Existing vanity domains on ODS aren't migrated and remain on the legacy path.

## Related Content

- [Default Domain Support for B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_default_domain.htm&type=5)
  Default Domain provides a Salesforce-managed, eCDN-enabled hostname for each instance (Development, Staging, and Production) so teams can test without manual DNS, custom domain registration, or certificate management.

- [Configure the eCDN Hostname Alias](https://help.salesforce.com/s/articleView?id=cc.b2c_configuring_eCDN_hostname_alias.htm&type=5)
  A hostname alias is required to create short, meaningful URLs for external search engines to index. Assign at least one hostname alias that is the current hostname on which the instance is running.

- [Create a Zone in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_creating_a_zone.htm&type=5)
  The CDN configuration is organized around zones. A zone represents a root or apex domain (for example, example.com). A hostname is a subdomain of a specific zone (for example, www.example.com).

- [Add an SSL Certificate to an eCDN Zone and Configure DNS Mapping](https://help.salesforce.com/s/articleView?id=cc.b2c_add_a_certificate_to_a_zone.htm&type=5)
  Add SSL certificates to your hostnames for Zones, and map DNS values from B2C Commerce to your DNS provider account. Add eCDN managed certificates and self-managed certificates.

- [Update an eCDN Zone's Certificate](https://help.salesforce.com/s/articleView?id=cc.b2c_update_a_zones_certificate.htm&type=5)
  When your SSL certificate expires, or you update the hostnames assigned to an SSL certificate, update the certificate in Business Manager. Update eCDN managed certificates and self-manged certificates

- [Configure an eCDN Zone in Business Manager](https://help.salesforce.com/s/articleView?id=cc.b2c_configuring_a_zone.htm&type=5)
  Configure SSL/TLS, certificates, security rules, performance, custom pages, request logs, and Under Attack Mode for an eCDN zone by using the Configure Zone screen in Business Manager.

- [Add Hostnames (Subdomains)](https://help.salesforce.com/s/articleView?id=cc.b2c_adding_hostnames.htm&type=5)
  Subdomains of the same zone can be configured on the same Salesforce B2C Commerce instance, or on different instances of different realms of the same retailer.

- [Migrating Proxy Zones](https://help.salesforce.com/s/articleView?id=cc.b2c_migrating_proxy_zones.htm&type=5)
  USe B2C Commerce Business Manager or the CDN-API to migrate legacy proxy zones. Migrating these zones give you the latest security features, and prevents common hierarchy assignment issues.

- [Configure a Page Shield Policy for the eCDN](https://help.salesforce.com/s/articleView?id=cc.b2c_configure_eCDN_page_shield_policy.htm&type=5)
  Set up a Page Shield policy to make sure only trusted scripts run on sensitive store pages like cart and checkout. A Page Shield policy helps your store comply with the Payment Card Industry Data Security Standard (PCI DSS) 4.0 client-side security requirements.

- [Create a Custom Firewall Rule for an eCDN Zone](https://help.salesforce.com/s/articleView?id=cc.b2c_create_eCDN_firewall_rule.htm&type=5)
  Configure a custom firewall rule to control incoming traffic based on specified request parameters.

- [Configure a Host Header Override Rule for an eCDN Zone](https://help.salesforce.com/s/articleView?id=cc.b2c_eCDN_configure_host_header_override.htm&type=5)
  To support a single hostname across multiple realms, create a Host Header Override Rule for sites that use an external content delivery network (CDN). This rule replaces unique hostnames with a common hostname to maintain the single-hostname setup. If you reuse a hostname, traffic can be unintentionally served from a different realm.

- [Create a Rate Limiting Rule for an eCDN Zone](https://help.salesforce.com/s/articleView?id=cc.b2c_eCDN_create_rate_limiting_rule.htm&type=5)
  Configure a rate limiting rule to specify rate limits for requests that match a particular expression and then perform an action when requests reach those rate limits. Rate limiting rules improve storefront availability, target specific traffic patterns and combat threats, such as bots.

- [Analyze HTTP and Security Traffic for an eCDN Zone](https://help.salesforce.com/s/articleView?id=cc.b2c_analyze_eCDN_traffic.htm&type=5)
  To get insights into HTTP traffic and security data, use the eCDN Analytics tab in Business Manager. The Analytics tab shows the Traffic Analysis timeline chart, top traffic statistics across multiple dimensions, and per-rule activity. Switch between HTTP and Security views to see request traffic or firewall events for the same zone and time range.

- [Storefront Fast Setup – eCDN Step](https://help.salesforce.com/s/articleView?id=cc.b2c_fast_storefront_setup_ecdn.htm&type=5)
  The Storefront Next Fast Setup workflow in Business Manager automatically provisions an eCDN Default Domain zone as part of storefront creation via the `SetupEcdnForStorefront` job step.
