# Set Protection Flags and Assign Passwords

_When you create a B2C Commerce site, there’s no password protection enabled by default. The administrator must set the protection flag and assign a password._

|  |
| --- |
| Available in: **B2C Commerce** |

1. Click App Launcher _(image: App Launcher)_, and then select **Administration > Sites > Manage Sites > *site* > Site Status**.
2. On the Site Status tab, set the Site Status to Online (Protected).
3. Select **Access using shared password**
4. Enter a password in the Password field.

   Specify a password that meets the following requirements:
   
   - Non-empty string
   - Characters a-z, A-Z, and 0-9
   - There’s no minimum or maximum length
   - The password never expires
      
      > **Note:** If the flag isn't set, the password field can be empty.
   
   For storefront applications that enforce mappings between email address and username, login attributes are required to support any character that is valid in an email address. The following special characters are allowed for usernames and customer logins.
   
   `#!&$%*+/?=^`~}|{`
   
   This allows the use of all supported email address formats as user and customer logins.
5. Click **Apply**.
