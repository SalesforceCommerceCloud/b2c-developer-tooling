# Order Placed Event

_B2C Commerce fires an order placed event when an order reaches a placed state and the placement transaction commits. The webhook body is the order representation from the Orders API, and you can route the event by site._

**Available in:** B2C Commerce release 26.10 and later.

### Event ID

### HTTP headers

The order placed event uses the standard Commerce Cloud platform headers documented in [Common HTTP Headers for B2C Commerce Events](https://help.salesforce.com/s/articleView?id=cc.b2c_event_common_headers.htm&type=5). For this event, `x-sf-cc-event-id` is `sf.cc.order.placed`, and `x-sf-cc-site-id` is the site where the order was placed. That site ID is also the site used to resolve a site-scoped route. The event is site-specific, so you can register an organization-wide route or a route for an individual site.

### JSON payload

The webhook body is the [Order](https://developer.salesforce.com/docs/commerce/commerce-api/references/orders?meta=type%3AOrder) resource from the B2C Commerce Orders API. Field presence and values vary with the order, customer, payment, promotion, shipping, fulfillment, and environment configuration. The event type identifier is carried in `x-sf-cc-event-id`, not in the body.

The body groups order data as follows.

### Example: order placed event

Values in this example are synthetic. Payment tokens and transaction identifiers are non-functional. Optional fields can be omitted on a real order.

```
{
  "adjustedMerchandizeTotalTax": 2.45,
  "adjustedShippingTotalTax": 0.30,
  "billingAddress": {
    "address1": "123 Example Street",
    "address2": "Suite 100",
    "city": "Example City",
    "countryCode": "US",
    "firstName": "Test",
    "fullName": "Test User",
    "lastName": "User",
    "phone": "5550100000",
    "postalCode": "00000",
    "stateCode": "CA"
  },
  "confirmationStatus": "confirmed",
  "createdBy": "storefront",
  "creationDate": "2026-01-15T12:00:00.000Z",
  "currency": "USD",
  "customerInfo": {
    "customerId": "test-customer-id",
    "customerName": "Test User",
    "email": "test.user@example.com",
    "guest": true
  },
  "customerLocale": "en_US",
  "exportStatus": "ready",
  "invoiceNo": "TEST-INVOICE-001",
  "lastModified": "2026-01-15T12:00:00.000Z",
  "merchandizeTotalTax": 2.45,
  "orderNo": "TEST-ORDER-001",
  "orderTotal": 57.74,
  "paymentInstruments": [
    {
      "paymentCard": {
        "cardType": "Visa",
        "creditCardExpired": false,
        "creditCardToken": "test-token",
        "expirationMonth": 12,
        "expirationYear": 2030,
        "holder": "Test User",
        "maskedNumber": "************1111",
        "numberLastDigits": "1111"
      },
      "paymentInstrumentId": "test-payment-instrument",
      "paymentMethodId": "CREDIT_CARD",
      "paymentTransaction": {
        "amount": 57.74,
        "transactionId": "test-transaction-001"
      }
    }
  ],
  "paymentStatus": "not_paid",
  "placeDate": "2026-01-15T12:00:00.000Z",
  "productItems": [
    {
      "adjustedTax": 2.45,
      "basePrice": 49.00,
      "bonusProductLineItem": false,
      "gift": false,
      "grossPrice": 51.45,
      "itemId": "test-item-001",
      "itemText": "Test Product",
      "minOrderQuantity": 1,
      "netPrice": 49.00,
      "position": 1,
      "priceAfterItemDiscount": 49.00,
      "priceAfterOrderDiscount": 49.00,
      "productId": "TEST-PRODUCT-001",
      "productName": "Test Product",
      "quantity": 1,
      "shipmentId": "test-shipment-001",
      "stepQuantity": 1,
      "tax": 2.45,
      "taxBasis": 49.00,
      "taxRate": 0.05
    }
  ],
  "productSubTotal": 49.00,
  "productTotal": 49.00,
  "shipments": [
    {
      "adjustedMerchandizeTotalTax": 2.45,
      "adjustedShippingTotalTax": 0.30,
      "gift": false,
      "merchandizeTotalTax": 2.45,
      "productSubTotal": 49.00,
      "productTotal": 49.00,
      "shipmentId": "test-shipment-001",
      "shipmentNo": "TEST-SHIPMENT-001",
      "shipmentTotal": 57.74,
      "shippingAddress": {
        "address1": "456 Sample Avenue",
        "address2": "Unit 200",
        "city": "Sample City",
        "countryCode": "US",
        "firstName": "Test",
        "fullName": "Test User",
        "lastName": "User",
        "phone": "5550100001",
        "postalCode": "00000",
        "stateCode": "CA"
      },
      "shippingMethod": {
        "id": "TEST-SHIPPING-METHOD"
      },
      "shippingStatus": "not_shipped",
      "shippingTotal": 5.99,
      "shippingTotalTax": 0.30,
      "taxTotal": 2.75
    }
  ],
  "shippingItems": [
    {
      "adjustedTax": 0.30,
      "basePrice": 5.99,
      "grossPrice": 6.29,
      "itemId": "test-shipping-item-001",
      "itemText": "Shipping",
      "netPrice": 5.99,
      "priceAfterItemDiscount": 5.99,
      "shipmentId": "test-shipment-001",
      "tax": 0.30,
      "taxBasis": 5.99,
      "taxRate": 0.05,
      "type": "fixed_price"
    }
  ],
  "shippingStatus": "not_shipped",
  "shippingTotal": 5.99,
  "shippingTotalTax": 0.30,
  "siteId": "TestSite",
  "status": "new",
  "taxation": "net",
  "taxTotal": 2.75
}
```

### Order placed implementation notes

- The event is fired asynchronously after the order placement transaction commits.
- The event is site-specific. Configure a connector for one site, or use an organization-wide route.
- The body follows the Orders API order representation. Adding fields to that representation can add fields to later events. Don't rely on a field that the order doesn't populate.
