# Security Settings for B2C Commerce

_Configure Business Manager security settings. Configuring login settings only applies to accounts that haven't migrated to unified authentication. Unified authentication links the login of all Business Manager instances to the Account Manage login. As of 19.5, all new instances are linked to the Account Manager login._

## Related Content

- [Migrate Users to Unified Authentication via Account Manager](https://help.salesforce.com/s/articleView?id=cc.b2c_configure_migration_to_unified_login.htm&type=5)
  To let your users log in to their instances via Account Manager, migrate them to Unified Authentication. After you migrate them, users manage only one set of login credentials. To increase security on your instances, use Account Manager's two-factor authentication. This topic applies to B2C Commerce.

- [Configure Login Settings for B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_login_settings.htm&type=5)
  In Business Manager, it's important to configure user password restrictions and login lockout policies.

- [Configure Access Settings for B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_ip_address_settings.htm&type=5)
  Limit access based on IP addresses. If you don't provide an allowlist or blocklist, the feature isn't active and these settings have no effect. This topic applies to B2C Commerce.

- [Configure the Enforce HTTPS Global Preference](https://help.salesforce.com/s/articleView?id=cc.b2c_configure_enforce_https_global_preference.htm&type=5)
  Enforce the use of HTTPS for all sites in an instance. When this setting is enabled, URLs generate using the HTTPS protocol, and incoming page requests that use HTTP redirect to HTTPS. HTTP requests to Open Commerce API (OCAPI)'s session bridge aren't accepted. Also, instead of a combination of session cookies and secure tokens, secure session cookies are used, which helps avoid incorrect (false positive) session hijacking detections. Enable the Enforce HTTPS global preference to let browsers send cookies in cross-site contexts. This topic applies to B2C Commerce.

- [Set HSTS for Business Manager in Global Preferences](https://help.salesforce.com/s/articleView?id=cc.b2c_configure_hsts_for_business_manager.htm&type=5)
  HTTP Strict Transport Security (HSTS) can substantially improve the security of the Business Manager. To secure Business Manager, HSTS instructs web browsers to access the domain using only HTTPS.

- [Clear Secure File Transfer Protocol (SFTP) Known Good Hosts for B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_clear_sftp_known_good_hosts.htm&type=5)
  Business Manager remembers hosts previously used for SFTP. Clear these remembered known hosts.

- [Add a System Use Notification Message in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_configure_system_use_notification_message_settings.htm&type=5)
  Create a system use notification message that displays when your users log in. You can also require them to acknowledge this message before continuing to log in.
