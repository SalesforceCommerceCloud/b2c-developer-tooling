# Change the User Interface Locale for Business Manager

_The Business Manager user interface for B2C Commerce supports multiple languages._

1. In Business Manager, select your profile in the top right of the page.
2. In the Preferences section, select a preferred locale for the UI and for the date.
3. Click **Apply**.
