# Product Filter Rules

_Product filter rules control which products from your B2C Commerce catalog sync to ChatGPT. Configure include and exclude rules to broaden or narrow the default ruleset based on how your catalog is organized._

Product filter rules let you precisely control which products appear in the OpenAI product feed. Configure rules from the OpenAI integration page in Business Manager to reflect how your catalog is actually organized—using standard product flags, custom attributes, brands, categories, prices, or inventory levels.

### Default Behavior

By default, the rule builder includes two preloaded conditions in a single include rule:

- **Online** = `true`
- **Searchable** = `true`

These conditions match the original feed eligibility behavior: only products that are online and searchable appear in the feed. Keep, modify, or remove these defaults to fit your catalog. For example, if you manage catalog visibility through custom attributes rather than the standard flags, replace the defaults with rules that reflect how your catalog actually works.

Each site maintains its own independent filter configuration.

### How Include and Exclude Rules Work

The rule builder supports two rule types:

- **Include rules**: A product appears in the feed only if it matches at least one include rule.
- **Exclude rules**: A product that matches any exclude rule is removed from the feed, even if it satisfies an include rule. Exclusions always take precedence.

Within a single rule group, conditions use AND logic—a product matches the group only when all conditions are true. Across multiple rule groups, conditions use OR logic—a product that qualifies under any group is included.

For step-by-step instructions, see [b2c_openai_feed_configure_product_filter.xml](https://help.salesforce.com/s/articleView?id=cc.b2c_openai_feed_configure_product_filter.htm&type=5).

### Filter Types

The rule builder supports the following filter types:

| Filter | Matches Products By | Example |
| --- | --- | --- |
| **Product ID** | Specific product IDs | `mens-shirt-001`, `mens-shirt-002` |
| **Brand** | Brand attribute value | Nike, Adidas |
| **Category** | Category assignment, optionally including subcategories | `mens-clothing` |
| **Price** | Current price (supports ranges and comparisons) | Price ≥ 50.00 |
| **Inventory (ATS)** | Available-to-sell quantity | ATS ≥ 10 |
| **Online** | Whether the product is set to online | `true` or `false` |
| **Searchable** | Whether the product is set to searchable | `true` or `false` |
| **Custom attribute** | Any site-defined product attribute | `c_groupName` = Men's Products |

### Common Scenarios

Use the following configurations as a starting point for common goals:

| Goal | Configuration |
| --- | --- |
| Sync only a specific category | Include rule: Category filter |
| Exclude clearance items | Exclude rule: Custom attribute `c_onSale` = `true` |
| Restrict to specific brands | Include rule: Brand filter listing allowed brands |
| Sync a custom product group | Include rule: Custom attribute `c_groupName` = your group name |

### Filter Rules and Search Visibility

Product filter rules control which products are *included* in the feed. A separate field, **is_eligible_search**, controls whether products that pass the filter rules are *discoverable* in ChatGPT search. The two layers work together:

- Filter rules act as the first gate: products that don't match the include rules (or that match an exclude rule) never appear in the feed.
- **is_eligible_search** acts as the second gate: among products that pass the filter rules, this field determines which ones surface in ChatGPT search results.

Most often, map **is_eligible_search** to a constant `true` so that all products that pass the filter rules are discoverable in search. For finer-grained control, map **is_eligible_search** to a custom product attribute (for example, `c_chatGPT_eligible`) to toggle search visibility at the individual product level. To configure the mapping, see [b2c_openai_feed_mapping.xml](https://help.salesforce.com/s/articleView?id=cc.b2c_openai_feed_mapping.htm&type=5).

### Master Products, Variation Groups, and Product Sets

The feed automatically excludes master products, variation groups, and product sets, exporting only individual variant products (SKUs) and standalone products. Variants inherit attribute data from their variation group or master product, so including masters, variation groups, or product sets in the feed produces non-sellable entries that ChatGPT might reject or deprioritize.

If you currently have a large feed, you might see a reduction in total product count after the next daily sync. This reduction is intentional.
