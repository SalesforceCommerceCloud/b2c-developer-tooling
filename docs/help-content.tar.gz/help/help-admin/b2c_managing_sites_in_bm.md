# Managing Sites in Business Manager

_In Business Manager, you can manage various aspects of sites, such as the B2C Commerce storefront sites, the Business Manager site itself, and the global static cache._

See [Creating a New Site in Business Manager](https://developer.salesforce.com/docs/commerce/b2c-commerce/guide/b2c-managing-sites-for-dev.html#create-a-site-in-business-manager) to create a new site.

1. Click App Launcher _(image: App Launcher)_, and then select**Site****Adminstrator****Manage Sites.**

   Use the sort buttons to sort your sites. Sites appear in this order throughout the Business Manager user interface.
2. Click a site in the Storefront Sites table to manage an individual site.

   See [Configuring Storefront Sites](https://help.salesforce.com/s/articleView?id=cc.b2c_configuring_storefront_sites.htm&type=5).
3. On the Storefront Sites page, in the Business Manager section, click the **Business Manager** link to manage Business Manager.

   See [Configuring a Business Manager Site](https://help.salesforce.com/s/articleView?id=cc.b2c_configuring_a_business_manager_site.htm&type=5).
4. On the Storefront Sites page, in the Global Static Cache section, click the **Global Static Cache** link to manage the global static cache.

   See [Configure the Static Content Cache](https://developer.salesforce.com/docs/commerce/b2c-commerce/guide/b2c-content-cache.html#cache-configuration).

## Related Content

- [Configuring Storefront Sites for B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_configuring_storefront_sites.htm&type=5)
  New sites require some level of access control. Many use a single shared password for all users. Using a Business Manager login with the functional permission provides a much higher level of security and access control, in particular with frequent password renewals and employees leaving an organization.

- [Configuring the Business Manager Site](https://help.salesforce.com/s/articleView?id=cc.b2c_configuring_a_business_manager_site.htm&type=5)
  Configure the Business Manager site for your B2C Commerce instance.

- [Mark a Site as Live in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_marking_a_site_as_live.htm&type=5)
  You must mark new sites as live after support enables the option.
