# View Trace Details (Beta)

_Read the span waterfall for a single B2C Commerce trace to see how a request moves across services and where it spends time._

The trace detail page shows the spans in the trace as a nested waterfall, ordered from the first span to the last.

_(image: The trace detail page, with the trace summary and details at the top and the spans shown below as a nested waterfall of duration bars in the Service and Operation column.)_

- The **Service & Operation** column identifies each span.
- Span duration shows the time spent in each service.
- Span status indicates whether the operation completes successfully (OK), returns an error (ERROR), or has no recorded status (UNSET).
- To focus on one part of the request path, click the plus or minus control next to a span to expand or collapse its child spans.

### Span Details

Click a span in the waterfall to open its details. The panel shows the span **Status** (OK, ERROR, or UNSET), its **Duration**, the **Span** operation name, and its **Parent** span. The root span lists its parent as **(root)**.

The panel also shows **Resource Attributes** and **Span Attributes** as key-value tables. Resource attributes describe the source that emits the span, and span attributes describe the individual operation. A table with no values shows **(none)**. To close the panel, click **Close**.
