# Customer Lists Preferences for B2C Commerce

_Use customer site preferences to control how your storefront responds to failed login attempts by customers. You can optionally lock out a customer's account after a specified number of failed attempts, preventing *brute force* attempts to crack the customer's password._

1. In Business Manager, click App Launcher _(image: App Launcher)_, and then select **Administration > Sites > Customer Lists.**
2. On the Customer Lists page, click a customer list or click **Edit**.
3. For a new list, enter the required information and click **Apply** in the Customer List page General tab.
4. Select the **Customer Number Sequence**:

   - Unique per organization
   - Unique per customer list: select a starting value and enter a format pattern.
5. Configure the Customer Profile Retention.

   Enter the number of days that Salesforce B2C Commerce stores customer profiles (1-99.999). Profiles are automatically removed for customers who haven’t visited the site within the specified number of days. Leave blank if you never want to remove customer profiles.
   
   > **Note:** Use the data cleanup job to delete expired customers.
   
   1. In Business Manager, click App Launcher _(image: App Launcher)_, and then select **Administration > Operations > Jobs**
   2. Use job ssfcc-data-cleanup.
   
      This job includes the job-step CleanupExpiredCustomers. The step checks the customer retention value, in order, against LASTVISITTIME, LASTLOGINTIME, and CREATIONDATE. All customers who have been inactive for more than the defined retention days are marked as expired and processed for deletion.
      
      > **Note:** For the production environments, the customer retention days is configured as 730 days.
6. Configure the Customer Login Settings.

   1. Enable or disable customer lockout after the specified number of tries.
   
      This field is set to `True` by default for all customers to prevent brute-force password guessing attempts. Customers can wait 30 minutes for the lockout period to expire or reset their password immediately, which allows for account access and continued shopping. For site administrators, this field can be set to `False` if they prefer to disable this security feature.
   2. Enter a value for the Maximum Invalid Login Attempts, from 1 to 200.
   3. Select the Lockout Effective Period, from 1 minute to 10 days (default is 2 hours).
   4. Select the Login Attempt Reset Time, from **Never** to one day (default is one day).
   5. Select the Minimum Password Length.
   6. Enter the Minimum Password Special Characters required for a valid password.
   
      Any character other than A-Z, a-z, or 0-9 counts as a special character, including the at (@) sign. Business Manager shows these examples: $%/()[]{}=?!.,-_*|+~#.
   7. Select if the password requires letters. If `True`, select if any letter case or a mix of letter case is required.
   8. Select if the password requires numbers.
   9. Select the Passwords Expire In interval, the period after which a password expires, from Never to 90 days (default is `Never`).
7. Click **Apply** to accept your changes, or **Reset** to reject your changes.
