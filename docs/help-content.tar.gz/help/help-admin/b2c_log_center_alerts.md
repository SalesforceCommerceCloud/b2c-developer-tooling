# Log Center Alerts in B2C Commerce

_Monitor custom alerts across all Log Center data sources from a centralized interface. Configure notifications to identify application performance degradations before they affect your users. Route alerts in real time via email, Slack, and PagerDuty to help your teams respond to critical system events._

_(image: Alert Management)_
