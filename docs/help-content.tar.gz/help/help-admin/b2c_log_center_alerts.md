# Log Center Alerts in B2C Commerce

_Monitor custom alerts across all Log Center data sources from a centralized interface. Configure notifications to identify application performance degradations before they affect your users. Route alerts in real time via email, Slack, and PagerDuty to help your teams respond to critical system events._

_(image: Alert Management)_

> **Note:** You can’t delete a notification channel while one or more alerts use it. Before you delete the channel, remove it from those alerts or delete the alerts that use it.

_(image: The Confirm Delete dialog showing an error that the notification channel can't be deleted because it's still used by the listed alerts, which must be unlinked from the channel before deleting it.)_

## Related Content

- [Log Center Alert Types in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_log_center_alert_types_in_b2c_commerce.htm&type=5)
  To determine the best method for monitoring your environment, review the available alert types in this table.

- [Create a Log Center Alert](https://help.salesforce.com/s/articleView?id=cc.b2c_create_a_log_center_alert.htm&type=5)
  Monitor conditions and send notifications in B2C Commerce Log Center. Catch behavioral anomalies early, get notified when a log delivery pipeline fails, or create an alert for a specific incident.

- [Create a Slack Channel for Log Center Alerts](https://help.salesforce.com/s/articleView?id=cc.b2c_create_a_slack_channel_for_log_center_alerts.htm&type=5)
  To keep your teams aligned during incidents, set up Slack notifications in B2C Commerce.

- [Create a PagerDuty Channel for Log Center Alerts](https://help.salesforce.com/s/articleView?id=cc.b2c_create_a_pagerduty_channel_for_log_center_alerts.htm&type=5)
  For on-call escalation and incident management, set up PagerDuty notifications in B2C Commerce. When you route Log Center notifications in B2C Commerce to PagerDuty, the alert's state lifecycle is mapped to a specific PagerDuty action and severity. Each alert monitor uses a unique deduplication key, so repeated triggers update the existing open incident instead of creating duplicate incidents.

- [How Notification Channels Respond to Alert States](https://help.salesforce.com/s/articleView?id=cc.b2c_how_notification_channels_respond_to_alert_states.htm&type=5)
  How a notification channel in B2C Commerce responds to an alert is based on the alert state. An anomaly detection alert fires once when an anomaly is detected and doesn’t track whether a condition persists or is cleared.

- [Access Control for Log Center Alerts](https://help.salesforce.com/s/articleView?id=cc.b2c_access_control_for_log_center_alerts.htm&type=5)
  Verify that your role allows alert creation and management in B2C Commerce Log Center.

- [Troubleshoot Log Center Alerts](https://help.salesforce.com/s/articleView?id=cc.b2c_troubleshoot_log_center_alerts.htm&type=5)
  If you’re missing Log Center notifications in B2C Commerce, check these likely causes and fixes.
