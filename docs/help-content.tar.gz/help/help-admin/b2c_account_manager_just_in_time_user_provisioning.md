# Just-In-Time User Provisioning In Account Manager and B2C Commerce

_Just-in-time user provisioning automates creating a user account in Account Manager eliminating the need for admins to add users manually. It also links the account with the Salesforce Identity account used for single sign-on (SSO)._

[Which Salesforce Commerce Product Do I Have?](https://help.salesforce.com/s/articleView?id=commerce.comm_what_product.htm)

Just-in-time user provisioning requires that you set identity federation to Allowed or Enforce. It also requires the user to verify their Salesforce My Domain. Just-in-time user provisioning is supported with third-party Identity and Access Management (IAM) using Salesforce Identity. This requires that Salesforce Identity is also configured for Just-in-time provisioning.

After a user is automatically provisioned, the admin can assign roles. By default, roles aren’t assigned as part of just-in-time user provisioning.

**See Also:**

- [Configure Account manager for Identity Federation in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_account_manager_configure_account_manager_for_identity_federation.htm)
- [Just-in-Time Provisioning for Security Assertion Markup Language (SAML)](https://help.salesforce.com/s/articleView?id=xcloud.sso_jit_about.htm&type=5)
