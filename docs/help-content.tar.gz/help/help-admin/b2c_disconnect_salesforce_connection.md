# Disconnect Your B2C Commerce Sandbox Instance from Salesforce

_When you refresh a Salesforce sandbox that's connected to your B2C Commerce instance, the sandbox org ID changes, and the connection becomes unavailable. Disconnect the instance from the sandbox in Business Manager to remove the broken connection and related configuration. You can then connect the instance to the refreshed sandbox or to a different sandbox._

Use this procedure when the Salesforce Connection page shows a connection error after you refresh the connected Salesforce sandbox.

1. In Business Manager, click the App Launcher _(image: App Launcher)_, and then select **Administration > Global Preferences > Salesforce Connection**.
2. If the connection status is **Connection error**, click **Disconnect from Salesforce**.

   If the connection status is **Verifying connection**, refresh the page. If the status does not change after a few minutes, contact Salesforce Customer Support.
3. Click **Disconnect**.

   A success message appears. B2C Commerce returns to the [Salesforce Connection page](https://help.salesforce.com/s/articleView?id=cc.b2c_connected_comm_salesforce_connection.htm&type=5) after a successful disconnect.

If B2C Commerce can't disconnect from the Salesforce sandbox, click **Try Again**. If you still can't disconnect the instance, contact Salesforce Customer Support.

> **Important:** To disconnect a B2C Commerce production instance from a Salesforce production org, contact Salesforce Customer Support.
