# Deactivate a Payment Method for B2C Commerce

_Disable payment methods from appearing in your Storefront Reference Architecture (SFRA), Composable Storefront, or Storefront Next site._

1. In Business Manager, click App Launcher _(image: App Launcher)_, and then select **Merchant Tools > Site > Ordering > Salesforce Payments**.
2. Click **Configure** and select the payment method you want to deactivate.
3. Click **Next**.

   When you deactivate Checkout on a site, shopper payment information doesn't migrate between B2C Commerce and Stripe or Adyen. Any payment account information that Stripe or Adyen stored before the site was deactivated isn't available or viewable in the registered shopper's account on the storefront.
4. Confirm and click **Deactivate**.

   You can't activate one checkout method and deactivate the other checkout method at the same time.
5. To reactivate a payment method, repeat the activation process.
