# Default Domain Support for B2C Commerce

_Default Domain provides a Salesforce-managed, eCDN-enabled hostname for each instance (Development, Staging, and Production) so teams can test without manual DNS, custom domain registration, or certificate management._

### What Is the Default Domain?

The Default Domain is a Salesforce-owned, pre-configured hostname for your B2C Commerce instances (Development, Staging, and Production) with eCDN features enabled.

**Example Default Domain format:** `<realm>-<stg>.my.commercecloud.salesforce.com` (for example, `abcd-stg.my.commercecloud.salesforce.com`).

This domain co-exists with your custom branded domain (for example, `www.example.com`) and is intended for **developer testing, load testing, pre-production review**, and enabling eCDN when you don't yet have or want a custom domain.

### 1. Accessing the Default Domain

After provisioning a new realm (or enabling the feature for an existing realm during a pilot), the Default Domain is immediately available.

1. **Locate the Domain:** In Business Manager, open the Embedded CDN settings page. The Default Domain is listed as one of the hostnames.
2. **Access:** Use the provided URL in your browser.
   
   - **Development or Staging:** These environments are typically protected sites; authenticate with your user credentials to access. Add a "Block All" eCDN rule on Development or Staging to block access.
   - **Production:** The Default Domain can be public if you choose not to use a custom domain, but it is primarily for lower-environment testing.
      
      If you do not have a vanity domain, you might run into issues navigating in Page Designer and Preview functions; for example, development functions fail with preview.
      
      In this case:
      
      1. Create a vanity hostname for the Page Designer and Preview functions.
      2. Create a custom rule to allow your IPs or User-Agents in the Default zone for this traffic.
      3. Disable the Block All rule in Production.
         
         > **Note:** Removing the foundational "Block All" rule makes the Default Domain fully public for all sites in Production and, therefore, isn't a recommended option without additional security or rate limit rules.
      
      _(image: Disable Block All rule.)_
      
      _(image: View Block All rule in Business Manager Embedded CDN Settings.)_
      
      - **Default Production Security Configuration:** To maintain security, the Production Default Domain has a final "Block All" rule at the eCDN layer.
      - Add explicit "Allow" rules (for sites/paths) **above** the "Block All" rule for any content you want to be publicly accessible via the Default Domain.
      - **Removing the foundational "Block All" rule makes the Default Domain fully public for all sites in Production and triggers an explicit notification.**

### 2. Configuring eCDN on the Default Domain

The Default Domain is fully configurable via both the Business Manager (BM) UI and the CDN API, just like a custom domain. You can also stack an external CDN in front of the Default Domain. For details, see [Configure an External CDN or Third-Party Proxy](https://help.salesforce.com/s/articleView?id=cc.b2c_configuring_an_external_cdn.htm&language=en_US&type=5).

> **Note:** For trusted IPs, if you have configured IP access restrictions via the Trusted IPs feature, the default "Block All" security rule for the Production Default Domain is skipped for traffic originating from those trusted IP addresses. The preferred approach is to use Security rules.

### 3. Impact on Custom Domains

The Default Domain doesn't change the functionality or behavior of existing custom domains.

- **Co-existence:** Default and custom domains can exist on the same instance.
- **Branding:** Custom domains remain preferred for external, branded storefronts.
- **Consistency:** Changes to the Default Domain don't affect your custom domain configuration.

### 4. Key Caveats (Important)

### 5. Default Domain on On-Demand Sandboxes (ODS)

Starting with the 26.6 release, eCDN Default Domain is available on all ODS instance types (dev, prd, partner) and is automatically provisioned when a new ODS instance is created. No DNS changes or certificate management is required.

> **Important:** With the 26.6 default-domain auto-routing, the storefront host for ODS sandboxes changes from `<realm>-<NNN>.dx.commercecloud.salesforce.com` to `<realm>-<NNN>.my.commercecloud.salesforce.com`, including for already-provisioned sandboxes. Business Manager, WebDAV/code upload, jobs, and the Sandbox API remain on the `.dx` host—only the storefront moves to `.my`.

> **Note:** The current ODS Default Domain support is scoped to Storefront Next use cases. Custom vanity domain support for ODS through eCDN isn't generally available yet.

_(image: Embedded CDN Settings page for an ODS sandbox showing the auto-provisioned Default Zone zzpq.sbx.my.commercecloud.salesforce.com with Add Hostname and Configure Zones buttons.)_

_(image: Embedded CDN Settings dropdown for an ODS sandbox showing the Configure Zone and Configure Routing Rules options.)_

_(image: Configure Zones Security Rules view for ODS zone zzpq.sbx.my.commercecloud.salesforce.com showing Custom Firewall Rules and Rate Limiting Rules sections.)_

_(image: Embedded CDN Settings page for an ODS sandbox showing a registered hostname with the Configure Zone and Configure Routing Rules dropdown open.)_

### 6. Vanity Domains on ODS

Vanity hostnames on ODS is not currently supported.

For step-by-step zone creation and vanity domain migration guidance, see [Create a Zone in B2C Commerce](https://help.salesforce.com/s/articleView?id=cc.b2c_creating_a_zone.htm).
