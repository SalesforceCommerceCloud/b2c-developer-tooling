# Default Domain Support for B2C Commerce

_Default Domain is a Salesforce-managed, eCDN-enabled hostname provided for each B2C Commerce instance (development, staging, and production), so you can test without manual DNS, custom domain registration, or certificate management. Use the Default Domain for developer testing, load testing, and preproduction review, whether you're working alongside an existing custom branded domain (for example, www.example.com) or haven't set one up yet._

[Which Salesforce Commerce Product Do I Have?](https://help.salesforce.com/s/articleView?id=commerce.comm_what_product.htm)

For a developer-focused overview of Default Domains, instance eCDN, and SSL, see the blog post [Salesforce B2C: Default Domains, Instance eCDN & SSL for Devs](https://developer.salesforce.com/blogs/2026/04/salesforce-b2c-default-domains-instance-ecdn-ssl-for-devs). On On-Demand Sandboxes (ODS), the Default Domain is the only option. Custom domains on ODS via eCDN aren't supported. See [Default Domain on On-Demand Sandboxes (ODS)](https://help.salesforce.com/s/articleView?id=cc.b2c_default_domain_ods.htm&type=5).

**Example Default Domain format:** `<realm>-<stg>.my.commercecloud.salesforce.com` (for example, `abcd-stg.my.commercecloud.salesforce.com`).

### Accessing the Default Domain

After provisioning a new realm (or enabling the feature for an existing realm during a pilot), the Default Domain is immediately available.

In Business Manager, the Embedded CDN settings page lists the Default Domain as one of the hostnames.

- **To access the Default Domain:** Use the provided URL in your browser.
   
   - **Development or Staging:** These environments are typically protected sites; authenticate with your user credentials to access. Adding a Block All eCDN rule on Development or Staging blocks access.
   - **Production:** The Default Domain can be public if you choose not to use a custom domain, but it's primarily for lower-environment testing. If you don't have a custom domain, you can run into issues navigating in Page Designer and Preview functions; for example, development functions fail with preview. To resolve these issues:
      
      - Create a custom hostname for the Page Designer and Preview functions.
      - Create a custom rule to allow your IPs or User-Agents in the Default zone for this traffic.
      - Disable the Block All rule in Production.
         
         > **Note:** Removing the foundational Block All rule makes the Default Domain fully public for all sites in Production and, therefore, isn't a recommended option without additional security or rate limit rules.
      
      _(image: Disable Block All rule.)_
      
      _(image: View Block All rule in Business Manager Embedded CDN Settings.)_
      
      **Default Production security configuration:** To maintain security, the Production Default Domain has a final Block All rule at the eCDN layer. Add explicit Allow rules (for sites/paths) **above** the Block All rule for any content you want to be publicly accessible via the Default Domain.

### Configuring eCDN on the Default Domain

The Default Domain is fully configurable via both the Business Manager (BM) UI and the CDN API, just like a custom domain. You can also stack an external CDN in front of the Default Domain. For details, see [Configure an External CDN or Third-Party Proxy](https://help.salesforce.com/s/articleView?id=cc.b2c_configuring_an_external_cdn.htm&language=en_US&type=5).

> **Note:** For trusted IPs, if you have configured IP access restrictions via the Trusted IPs feature, the default Block All security rule for the Production Default Domain is skipped for traffic originating from those trusted IP addresses. The preferred approach is to use Security rules.

### Impact on Custom Domains

The Default Domain doesn't change the functionality or behavior of existing custom domains.

- **Coexistence:** Default and custom domains can exist on the same instance.
- **Branding:** Custom domains remain preferred for external, branded storefronts.
- **Consistency:** Changes to the Default Domain don't affect your custom domain configuration.

### Key Caveats

- **Protected Sites:** Protect the Default Domain similarly to a protected storefront. See [B2C Storefront Password Protection](https://help.salesforce.com/s/articleView?id=cc.b2c_storefront_password_protection.htm&type=5).
- **Certificate Management:** Editing, deleting, or uploading certificates for the Default Domain is blocked and is visually disabled in BM UI. Attempts to perform these actions result in an error.
- **Realm Availability:** The Default Domain is automatically visible for **new realms** created after the 26.1 CDN API release. Existing realms are onboarded during the pilot/migration phase.

## Related Content

- [Default Domain on On-Demand Sandboxes](https://help.salesforce.com/s/articleView?id=cc.b2c_default_domain_ods.htm&type=5)
  B2C Commerce On-Demand Sandboxes (ODS) are served exclusively through the Salesforce-managed Default Domain starting with the 26.6 release. When you create a development, production, or partner ODS instance, B2C Commerce provisions the Default Domain automatically and handles DNS and certificates for you.
