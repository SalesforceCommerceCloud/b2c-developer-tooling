# Default Domain Support for B2C Commerce

_Default Domain provides a Salesforce-managed, eCDN-enabled hostname for each instance (Development, Staging, and Production) so teams can test without manual DNS, custom domain registration, or certificate management._

For a developer-focused overview of Default Domains, instance eCDN, and SSL, see the blog post [Salesforce B2C: Default Domains, Instance eCDN & SSL for Devs](https://developer.salesforce.com/blogs/2026/04/salesforce-b2c-default-domains-instance-ecdn-ssl-for-devs). On On-Demand Sandboxes (ODS), the Default Domain is the only option — custom (vanity) domains on ODS via eCDN aren't supported. See [Default Domain on On-Demand Sandboxes (ODS)](https://help.salesforce.com/s/articleView?id=cc.b2c_default_domain_ods.htm&type=5).

### What Is the Default Domain?

The Default Domain is a Salesforce-owned, pre-configured hostname for your B2C Commerce instances (Development, Staging, and Production) with eCDN features enabled.

**Example Default Domain format:** `<realm>-<stg>.my.commercecloud.salesforce.com` (for example, `abcd-stg.my.commercecloud.salesforce.com`).

This domain co-exists with your custom branded domain (for example, `www.example.com`) and is intended for **developer testing, load testing, pre-production review**, and enabling eCDN when you don't yet have or want a custom domain.

### 1. Accessing the Default Domain

After provisioning a new realm (or enabling the feature for an existing realm during a pilot), the Default Domain is immediately available.

1. **Locate the Domain:** In Business Manager, open the Embedded CDN settings page. The Default Domain is listed as one of the hostnames.
2. **Access:** Use the provided URL in your browser.
   
   - **Development or Staging:** These environments are typically protected sites; authenticate with your user credentials to access. Add a "Block All" eCDN rule on Development or Staging to block access.
   - **Production:** The Default Domain can be public if you choose not to use a custom domain, but it is primarily for lower-environment testing.
      
      If you do not have a vanity domain, you might run into issues navigating in Page Designer and Preview functions; for example, development functions fail with preview.
      
      In this case:
      
      1. Create a vanity hostname for the Page Designer and Preview functions.
      2. Create a custom rule to allow your IPs or User-Agents in the Default zone for this traffic.
      3. Disable the Block All rule in Production.
         
         > **Note:** Removing the foundational "Block All" rule makes the Default Domain fully public for all sites in Production and, therefore, isn't a recommended option without additional security or rate limit rules.
      
      _(image: Disable Block All rule.)_
      
      _(image: View Block All rule in Business Manager Embedded CDN Settings.)_
      
      - **Default Production Security Configuration:** To maintain security, the Production Default Domain has a final "Block All" rule at the eCDN layer.
      - Add explicit "Allow" rules (for sites/paths) **above** the "Block All" rule for any content you want to be publicly accessible via the Default Domain.
      - **Removing the foundational "Block All" rule makes the Default Domain fully public for all sites in Production and triggers an explicit notification.**

### 2. Configuring eCDN on the Default Domain

The Default Domain is fully configurable via both the Business Manager (BM) UI and the CDN API, just like a custom domain. You can also stack an external CDN in front of the Default Domain. For details, see [Configure an External CDN or Third-Party Proxy](https://help.salesforce.com/s/articleView?id=cc.b2c_configuring_an_external_cdn.htm&language=en_US&type=5).

> **Note:** For trusted IPs, if you have configured IP access restrictions via the Trusted IPs feature, the default "Block All" security rule for the Production Default Domain is skipped for traffic originating from those trusted IP addresses. The preferred approach is to use Security rules.

### 3. Impact on Custom Domains

The Default Domain doesn't change the functionality or behavior of existing custom domains.

- **Co-existence:** Default and custom domains can exist on the same instance.
- **Branding:** Custom domains remain preferred for external, branded storefronts.
- **Consistency:** Changes to the Default Domain don't affect your custom domain configuration.

### 4. Key Caveats (Important)

## Related Content

- [Default Domain on On-Demand Sandboxes (ODS)](https://help.salesforce.com/s/articleView?id=cc.b2c_default_domain_ods.htm&type=5)
  B2C Commerce On-Demand Sandboxes (ODS) are served exclusively through the Salesforce-managed Default Domain. Custom (vanity) domains on ODS via eCDN aren't supported and aren't planned.
