# Security Logs Streaming

_Security logs contain sensitive information such as login info, and client download info._

### Roles and Permissions

To set up security logs streaming requires the Log Center External Admin role. With the Log Center External Admin role you are able to:

- Create and update Security Logs streaming configuration
- Add users to the edit permission list. Users on the permissions list can update the security logs streaming configuration

When a user's role changes from "Log Center External Admin" to "User," any streaming security logs they configured are disabled. Another "Log Center External Admin" user must set up a new stream. If the user was on the edit permission list, they can still edit the existing configuration.

The Enable Security Logs option is not active for users not assigned the Log Center External Admin role

See Also:

- [Roles Managed in Account Manager](https://help.salesforce.com/s/articleView?id=cc.b2c_account_manager_roles.htm&type=5)
