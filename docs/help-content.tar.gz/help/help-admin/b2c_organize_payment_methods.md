# Organize Payment Methods for B2C Commerce

_Arrange the sequence of payment methods to highlight preferred options to your shoppers on the checkout page in your Storefront Reference Architecture (SFRA), Composable Storefront, or Storefront Next site. The payment methods available in your storefront depend on your payment provider, region, and currency configuration._

1. In Business Manager, click App Launcher _(image: App Launcher)_, and then select **Merchant Tools > Site > Commerce Apps > App Catalog**.
2. In the Installed Apps section, for Salesforce Payments, click **Manage**.
3. In the Merchant Account card, select a payment zone.

   The payment zone you select determines the available payment methods.
4. In the Checkout Payment Methods and Express Payment Methods cards, drag the items in the list into your preferred order.

   _(image: Drag the payment methods into your preferred order.)_
5. Repeat these steps for each payment zone.
