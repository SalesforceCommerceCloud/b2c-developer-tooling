# Configure Duo as an Authentication Provider

_This guide serves as a general integration overview for B2C Commerce. For precise instructions, Salesforce advises consulting the most up-to-date integration documentation specific to your Identity Provider (IDP), such as Duo._

[Which Salesforce Commerce Product Do I Have?](https://help.salesforce.com/s/articleView?id=commerce.comm_what_product.htm)

The SSO support for B2C Commerce is done via core-licensed products and requires three connections.

- Duo
- Salesforce Platform
- Account Manager

To enable Salesforce SSO and enable Salesforce provisioning with Duo, use this [Duo documentation](https://duo.com/docs/sso-salesforce#:~:text=Enable%20SSO%20in%20Salesforce,-Add%20Duo%20Single&text=In%20the%20Salesforce%20Classic%20UI,Click%20Save.). The Duo documentation also includes step-by-step instructions and screenshots on how to configure Duo as an authentication provider in Salesforce.
