# Email Notifications

_Email notifications are sent to users based on how the account is created and the identity federation setting for your organization in Account Manager. This topic applies to Account Manager and B2C Commerce._

[Which Salesforce Commerce Product Do I Have?](https://help.salesforce.com/s/articleView?id=commerce.comm_what_product.htm)

- When an admin creates or resets a user account with Salesforce Identity Management (SFIDM) and identity federation is either allowed or enforced
- When a user links their account to SFIDM.
