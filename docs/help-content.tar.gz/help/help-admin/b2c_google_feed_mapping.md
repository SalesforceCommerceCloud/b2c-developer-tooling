# Map Product Fields for Google

_Configure how B2C Commerce product attributes map to Google feed fields using the field mapping interface._

Before you configure field mappings, ensure that the Google integration is set up for your site:

- [Configure Catalog and Order Feeds for Einstein](https://help.salesforce.com/s/articleView?id=cc.b2c_product_feed_configure_einstein.htm&type=5)
- [Meet the Prerequisites](https://help.salesforce.com/s/articleView?id=cc.b2c_product_feed_prerequisites.htm&type=5)
- [Connect to Google](https://help.salesforce.com/s/articleView?id=cc.b2c_product_feed_connect.htm&type=5)

The field mapping interface shows all Google feed fields and their default mappings, and it supports overriding mappings with different B2C Commerce attributes. Fields are organized into the following categories:

- **Required fields**: Require a mapping to generate a valid feed.
- **Optional fields**: Enhance product data but aren't required.
- **Non-overridable fields**: System-managed fields that are visible in the Field Mapping table but can't be changed. Examples: **id**, **availability**, and **is_bundle**.

The Field Mapping table groups fields into sections—**Basic Product Data**, **Price and Availability**, and **Detailed Product Info**—followed by an **Additional Optional Fields** section where you can map custom product details.

By default, B2C Commerce applies smart mappings to map B2C Commerce standard attributes to Google fields. Override these defaults with different standard attributes or custom attributes from your catalog as needed.

Not every field has a default mapping. Default mappings are created when B2C Commerce can derive the value using standard B2C Commerce attributes.

You can override a default mapping in three ways:

- **Map to a different attribute**: Select a B2C Commerce standard attribute or custom attribute whose type matches the Google field's type. B2C Commerce uses the attribute's value for each product.
- **Set a constant value**: Enter a fixed value, such as your brand name or a return-policy label, that B2C Commerce uses for every product in the feed.
- **Set a pattern**: Enter a pattern that resolves to a different value for each product, such as a URL template that includes the product ID. Use a pattern when the value depends on per-product data but isn't already stored in a single attribute.

1. Click App Launcher _(image: App Launcher)_, and then select **Merchant Tools > Site > AI & Social Integrations > Google**.
2. Click **Catalog**.

   In the Field Mapping section, the table displays the following columns:
   
   - **Channel Field**: The Google feed field name.
   - **B2C Commerce Field**: The mapped B2C Commerce attribute (shows the default mapping if one applies).
   - **Action**: An **Override** button to override a field's default mapping, and a **Reset** button to restore the field's default mappings.
   - **Required**: Indicates whether the field is required by Google.
   - **Example**: Shows a sample value for the channel field.
   
   > **Note:** Fields that are required but don't have a default mapping are highlighted in red with a warning icon. You must configure these fields before B2C Commerce can generate the feed.
3. (Optional) To find a specific field, type a value in the **Search** field.
4. (Optional) Click **Filter by Priority** to select a filter value (All, Required, or Optional) to control which fields are listed.
5. To override a default mapping, click **Override** next to the field.

   1. To map to a different attribute, in the dropdown, select a B2C Commerce attribute to map to this field.
   
      The list shows product attributes whose type matches the Google field's type. It includes both standard product attributes and custom attributes defined in your catalog.
   2. To use a fixed value or a per-product pattern, click **Override with constant value or pattern** and enter the value or pattern.
   
      Use a constant value when every product in the feed should have the same value, such as a return-policy label. Use a pattern when the value depends on per-product data but isn't stored in a single attribute, such as a URL template that includes the product ID.
6. To reset a field to its default mapping, click **Reset** next to the field.

B2C Commerce saves your field mapping overrides. The next time B2C Commerce generates the feed, it uses your configured mappings.

> **Note:** Common overrides include mapping **description** to **longDescription** for more detailed text, mapping **brand** to **manufacturer**, mapping **google_product_category** to the appropriate Google category, and setting **custom_label_0** through **custom_label_4** to segment products for reporting and bidding in Google.

For the complete list of Google feed fields—required and optional—and their default mappings to B2C Commerce attributes, see:

## Related Content

- [Product Feed Field Reference for Google](https://help.salesforce.com/s/articleView?id=cc.b2c_google_feed_default_mappings.htm&type=5)
  Reference information for the product feed fields used with Google, including required fields, optional fields, and their default mappings to B2C Commerce attributes.
